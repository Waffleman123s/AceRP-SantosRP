--[[
	Name: garbage_worker.lua
	For: SantosRP
	By: Ultra

	Note: Lots of the code for this job is modified/fixed up code from the garbage truck addon itself
	note server copy of sw_garbagetruck
]]--

local Job = {}
Job.ID = 15
Job.Enum = "JOB_GARBWORKER"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Sanitation Worker"
Job.PayPerLoad = 200
Job.PlayerCap = GM.Config.Job_GarbageWorker_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarID = "garbage_truck"
Job.ParkingLotPos = GM.Config.TowParkingZone
Job.CarSpawns = GM.Config.TowCarSpawns
Job.TruckVolume = 5000 *4
Job.TruckFxPos = Vector( -5.698053, -154, 80.042198 )
Job.m_tblTrucks = JOB_GARBWORKER and GAMEMODE.Jobs:GetJobByID( JOB_GARBWORKER ).m_tblTrucks or {}
Job.FxSounds = {
	"ambient/materials/cupdrop.wav",
	"ambient/materials/platedrop3.wav",
	"ambient/materials/platedrop2.wav",
	"ambient/materials/platedrop1.wav",
	"ambient/materials/cartrap_rope3.wav",
	"ambient/materials/cartrap_rope2.wav",
	"ambient/materials/cartrap_rope1.wav",
	"ambient/materials/rock1.wav",
	"ambient/materials/rock2.wav",
	"ambient/materials/rock3.wav",
	"physics/glass/glass_bottle_break1.wav",
	"physics/glass/glass_bottle_break2.wav",
	"physics/wood/wood_box_break1.wav",
	"physics/wood/wood_box_break2.wav",
	"physics/plastic/plastic_barrel_break2.wav",
	"physics/plastic/plastic_barrel_break1.wav",
	"physics/cardboard/cardboard_box_break1.wav",
	"physics/cardboard/cardboard_box_break2.wav",
}

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 15 },
		{ PlayTime = 4 *(60 *60), Pay = 19 },
		{ PlayTime = 12 *(60 *60), Pay = 25 },
		{ PlayTime = 24 *(60 *60), Pay = 35 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 40 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 45 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 56 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 62 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 68 },
	}	
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 8 },
		{ PlayTime = 4 *(60 *60), Pay = 10 },
		{ PlayTime = 12 *(60 *60), Pay = 12 },
		{ PlayTime = 24 *(60 *60), Pay = 15 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 19 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 23 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 29 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 36 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 44 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 55 },
	}
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_GARBWORKER then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
end

function Job:OnPlayerSpawnGarbageTruck( pPlayer, entCar )
	entCar.IsGarbageTruck = true
	pPlayer:AddNote( "You spawned your garbage truck!" )
	self.m_tblTrucks[entCar] = true

	entCar.AddGarbage = function( ent, intAmount )
		local last = ent:GetNWInt( "GarbVolume", 0 )
		ent:SetNWInt( "GarbVolume", math.Clamp(ent:GetNWInt("GarbVolume", 0) +intAmount, 0, Job.TruckVolume) )
		if ent:GetNWInt( "GarbVolume", 0 ) ~= last and ent:GetNWInt( "GarbVolume", 0 ) >= Job.TruckVolume then
			if IsValid( ent:GetDriver() ) then
				ent:GetDriver():AddNote( "Your truck is full! Return to the incinerator to empty it.", NOTIFY_HINT )
			end
		end
	end
	entCar.GetGarbage = function( ent )
		return ent:GetNWInt( "GarbVolume", 0 )
	end
end

function Job:PlayerSpawnGarbageTruck( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.CarID, self.CarSpawns, self.ParkingLotPos )
	if IsValid( car ) then
		self:OnPlayerSpawnGarbageTruck( pPlayer, car )
	end
end

function Job:PlayerStowGarbageTruck( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingLotPos )
end

hook.Add( "EntityRemoved", "UnrefGarbageTruckJob", function( eEnt )
	Job.m_tblTrucks[eEnt] = nil
end )

hook.Add( "PlayerEnteredVehicle", "GarbageTruckHint", function( pPlayer, entVeh )
	if not entVeh.IsGarbageTruck then return end
	pPlayer:AddNote( "Press left mouse to deploy the fork, Right mouse to grab a dumpster." )
	pPlayer:AddNote( "With a dumpster attached, hold space and forward/back to operate the fork." )
end )

local function dumpsterFilter( eEnt )
	if eEnt:IsVehicle() and not eEnt.UID then return false end
	if eEnt.IsGarbageTruck then return false end
	return true
end

hook.Add( "Tick", "ThinkGarbageJob", function()
	local driver
	for k, v in pairs( Job.m_tblTrucks ) do
		if not IsValid( k ) then Job.m_tblTrucks[k] = nil continue end
		driver = k:GetDriver()
		local isDumping

		if IsValid( driver ) and driver:KeyDown( IN_ATTACK2 ) then
			if k:GetPos():Distance( GAMEMODE.Config.GarbageWorkerDumpPos ) <= GAMEMODE.Config.GarbageWorkerMaxDumpDist then
				local angs = GAMEMODE.Config.GarbageWorkerDumpAngs
				if k:GetGarbage() > 0 and GAMEMODE.Util:AngleInRange( k:GetAngles(), angs.Min, angs.Max ) then
					--dump time!
					if (k.m_intLastGarbFx or 0) < CurTime() then
						k.m_intLastGarbFx = CurTime() +0.33
					
						local snd, _ = table.Random( Job.FxSounds )
						k:EmitSound( snd, 80, math.random(80, 110), math.Rand(0.66, 0.85) )

						local effectData = EffectData()
						effectData:SetOrigin( k:LocalToWorld(Job.TruckFxPos) )
						effectData:SetNormal( k:GetAngles():Right() )
						util.Effect( "trashFx", effectData )

						local num = 200
						local take = k:GetGarbage() >= num and num or k:GetGarbage()
						k:AddGarbage( -take )
						driver.m_intGarbageTaken = (driver.m_intGarbageTaken or 0) +take

						if driver.m_intGarbageTaken >= Job.TruckVolume then
							driver.m_intGarbageTaken = driver.m_intGarbageTaken -Job.TruckVolume
							driver:AddBankMoney( Job.PayPerLoad, "Garbage collection commission" )
							driver:AddNote( "You earned a $".. string.Comma(Job.PayPerLoad).. " bonus for collecting trash!" )
						end
					end
					
					isDumping = true
				end
			end

			if not isDumping then
				--Handle grabbing a dumpster
				if k.SWGbTruckDumpsterWeldUnweld == 0 then
					local ent = util.TraceLine{
						start = k:GetPos() +(k:GetAngles():Up() *32),
						endpos = k:GetPos() +(k:GetAngles():Right() *-220) +(k:GetAngles():Up() *32),
						filter = dumpsterFilter
					}.Entity

					if IsValid( ent ) and ent:GetClass() == "ent_dumpster" then
						ent:AttachToGarbageTruck( k )
					end
				else
					if IsValid( k.m_entAttachedDumpster ) then
						k.m_entAttachedDumpster:RemoveFromGarbageTruck( true )
					end
				end
			end
		elseif IsValid( driver ) and IsValid( k.m_entAttachedDumpster ) then
			--The moving fork thingy
			if driver:KeyDown( IN_JUMP ) then 
				if k.m_entAttachedDumpster:GetPos():Distance( k:GetPos() ) <= 300 then
					if not k.SoundGbTruckForkUp then
						k.SoundGbTruckForkUp = CreateSound( k, "SW_GbTruck_Fork_Up" )
					--	k.SoundGbTruckForkUp:ChangePitch( 0.75, 0 )
					end
					
					if not k.SoundGbTruckForkDown then
						k.SoundGbTruckForkDown = CreateSound( k, "SW_GbTruck_Fork_Down" )
					--	k.SoundGbTruckForkDown:ChangePitch( 0.75, 0 )
					end
					
					if driver:KeyDown( IN_FORWARD ) then
						local phys = k.m_entAttachedDumpster:GetPhysicsObject()
						if IsValid( phys ) then
							if k.m_entAttachedDumpster:GetAngles().r < 89 then phys:SetVelocity( k.m_entAttachedDumpster:GetAngles():Up() *160 ) end
							if not k.SoundGbTruckForkUp:IsPlaying() then
								k.SoundGbTruckForkUp:Play()
							end
						
							k.__SW_buffer01 = nil
						end
					elseif driver:KeyDown( IN_BACK ) then
						local phys = k.m_entAttachedDumpster:GetPhysicsObject()
						if IsValid( phys ) then
							phys:SetVelocity( k.m_entAttachedDumpster:GetAngles():Up() *-150 )
							if not k.SoundGbTruckForkDown:IsPlaying() then
								k.SoundGbTruckForkDown:Play()
							end
							
							k.__SW_buffer02 = nil
						end
					end
				end
			end
		end

		if (not IsValid(driver) or not driver:KeyDown(IN_FORWARD)) and not k.__SW_buffer01 then 
			if k.SoundGbTruckForkUp then k.SoundGbTruckForkUp:Stop() end
			k.SoundGbTruckForkUp = nil
			k.__SW_buffer01 = true
		end
		
		if (not IsValid(driver) or not driver:KeyDown(IN_BACK)) and not k.__SW_buffer02 then 
			if k.SoundGbTruckForkDown then k.SoundGbTruckForkDown:Stop() end
			k.SoundGbTruckForkDown = nil
			k.__SW_buffer02 = true
		end
	
		if (not IsValid(driver) or not driver:KeyDown(IN_JUMP)) then
			if k.SoundGbTruckForkUp then k.SoundGbTruckForkUp:Stop() end
			if k.SoundGbTruckForkDown then k.SoundGbTruckForkDown:Stop() end
			k.SoundGbTruckForkUp = nil
			k.SoundGbTruckForkDown = nil
		end
	end
end )

GM.Jobs:Register( Job )