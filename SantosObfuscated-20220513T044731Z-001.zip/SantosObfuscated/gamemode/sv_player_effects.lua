--[[
	Name: sv_playereffects.lua
	For: SantosRP
	By: Ultra
]]--

GM.PlayerEffects = {}
GM.PlayerEffects.m_tblRegister = {}
GM.PlayerEffects.m_tblPlayers = {}

function GM.PlayerEffects:Load()
	local foundFiles, foundFolders = file.Find( GM.Config.GAMEMODE_PATH.. "effects/*.lua", "LUA" )
	for k, v in pairs( foundFiles ) do
		AddCSLuaFile( GM.Config.GAMEMODE_PATH.. "effects/".. v )
		include( GM.Config.GAMEMODE_PATH.. "effects/".. v )
	end
end

function GM.PlayerEffects:Register( tblEffect )
	self.m_tblRegister[tblEffect.ID] = tblEffect
	if tblEffect.Setup then
		tblEffect:Setup()
	end
end

function GM.PlayerEffects:GetEffect( strEffectID )
	return self.m_tblRegister[strEffectID]
end

function GM.PlayerEffects:GetPlayerEffects( pPlayer )
	return self.m_tblPlayers[pPlayer] or {}
end

function GM.PlayerEffects:LoadSavedEffects( pPlayer )
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable then return false end
	
	for k, v in pairs( saveTable.ActiveEffects or {} ) do
		self:AddEffect( pPlayer, k, v, false, true, true )
	end

	GAMEMODE.Net:SendFullPlayerEffectsUpdate( pPlayer )
end

function GM.PlayerEffects:LazyTick( pPlayer )
	local time = CurTime()
	local saveTable, dataChanged = GAMEMODE.Char:GetCurrentSaveTable( pPlayer ), false
	if not saveTable then return end
	saveTable.ActiveEffects = saveTable.ActiveEffects or {}

	local count = 0
	for k, v in pairs( self.m_tblPlayers[pPlayer] or {} ) do
		self:UpdatePlayerEffect( pPlayer, k, time )

		if self.m_tblPlayers[pPlayer][k][2] == 0 then
			self:ClearEffect( pPlayer, k, true )
			saveTable.ActiveEffects[k] = nil
			dataChanged = true
		else
			saveTable.ActiveEffects[k] = self.m_tblPlayers[pPlayer][k][2]
			dataChanged = true

			if self.m_tblRegister[k].LazyTick then
				self.m_tblRegister[k]:LazyTick( pPlayer )
			end
		end
	end

	if dataChanged then
		GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "ActiveEffects" )
	end
end

function GM.PlayerEffects:GamemodeOnCharacterDeath( pPlayer )
	self:ClearAll( pPlayer )
end

function GM.PlayerEffects:GamemodePlayerGoUncon( pPlayer )
	for k, v in pairs( self:GetPlayerEffects(pPlayer) ) do
		if self.m_tblRegister[k].GamemodePlayerGoUncon then
			self.m_tblRegister[k]:GamemodePlayerGoUncon( pPlayer )
		end
	end
end

function GM.PlayerEffects:GamemodeOnPlayerClearUncon( pPlayer )
	for k, v in pairs( self:GetPlayerEffects(pPlayer) ) do
		if self.m_tblRegister[k].GamemodeOnPlayerClearUncon then
			self.m_tblRegister[k]:GamemodeOnPlayerClearUncon( pPlayer )
		end
	end
end

function GM.PlayerEffects:GamemodeEditNeedDecay( pPlayer, strNeedID, tblValue )
	for k, v in pairs( self:GetPlayerEffects(pPlayer) ) do
		if self.m_tblRegister[k].GamemodeEditNeedDecay then
			self.m_tblRegister[k]:GamemodeEditNeedDecay( pPlayer, strNeedID, tblValue )
		end
	end
end

function GM.PlayerEffects:GamemodeEditNeedRegen( pPlayer, strNeedID, tblValue )
	for k, v in pairs( self:GetPlayerEffects(pPlayer) ) do
		if self.m_tblRegister[k].GamemodeEditNeedRegen then
			self.m_tblRegister[k]:GamemodeEditNeedRegen( pPlayer, strNeedID, tblValue )
		end
	end
end

function GM.PlayerEffects:GamemodeEditInventorySize( pPlayer, tblData )
	for k, v in pairs( self:GetPlayerEffects(pPlayer) ) do
		if self.m_tblRegister[k].GamemodeEditInventorySize then
			self.m_tblRegister[k]:GamemodeEditInventorySize( pPlayer, tblData )
		end
	end
end

function GM.PlayerEffects:SetupMove( pPlayer, ... )
	if not self.m_tblPlayers[pPlayer] then return end
	for k, v in pairs( self.m_tblPlayers[pPlayer] ) do
		if self.m_tblRegister[k].SetupMove then
			self.m_tblRegister[k]:SetupMove( pPlayer, ... )
		end
	end
end

function GM.PlayerEffects:GamemodeCanTasePlayer( pPlayer )
	for k, v in pairs( self:GetPlayerEffects(pPlayer) ) do
		if self.m_tblRegister[k].GamemodeCanTasePlayer then
			local val = self.m_tblRegister[k]:GamemodeCanTasePlayer( pPlayer )
			if val ~= nil then return val end
		end
	end
end

function GM.PlayerEffects:EntityFireBullets( eEnt, tblBullet )
	if not eEnt:IsPlayer() then return end
	if not self.m_tblPlayers[eEnt] then return end

	local bRet
	for k, v in pairs( self.m_tblPlayers[eEnt] ) do
		if self.m_tblRegister[k].EntityFireBullets then
			if self.m_tblRegister[k]:EntityFireBullets( eEnt, tblBullet ) then
				bRet = true
			end
		end
	end

	if bRet then return true end
end

function GM.PlayerEffects:UpdatePlayerEffect( pPlayer, strEffectID, intTime )
	--If duration is below 0, don't bother, this effect has no length to it
	if self.m_tblPlayers[pPlayer][strEffectID][2] < 0 then return end
	
	--Calc delta since we last updated duration, then subtract delta from duration
	local time = intTime or CurTime()
	local lastTime = self.m_tblPlayers[pPlayer][strEffectID][1]

	self.m_tblPlayers[pPlayer][strEffectID][1] = time
	self.m_tblPlayers[pPlayer][strEffectID][2] = math.max( 0, self.m_tblPlayers[pPlayer][strEffectID][2] -(time -lastTime) )
end

function GM.PlayerEffects:AddEffect( pPlayer, strEffectID, intDur, bIgnoreOnStart, bDontNetwork, bDontSave )
	local a, _ = self:GetEffect( strEffectID ):CanGive( pPlayer, intDur )
	if not a then return false end

	self.m_tblPlayers[pPlayer] = self.m_tblPlayers[pPlayer] or {}

	--Since we lazily update active effects, force an update before we mess around with duration to maintain accuracy
	local time = CurTime()
	if self.m_tblPlayers[pPlayer][strEffectID] then
		self:UpdatePlayerEffect( pPlayer, strEffectID, time )
	end
	
	--Insert or add to the effect duration
	self.m_tblPlayers[pPlayer][strEffectID] = self.m_tblPlayers[pPlayer][strEffectID] or { time, 0 }
	if intDur == -1 then
		self.m_tblPlayers[pPlayer][strEffectID][2] = intDur
	else
		self.m_tblPlayers[pPlayer][strEffectID][2] = math.max( 0, self.m_tblPlayers[pPlayer][strEffectID][2] +intDur )
	end

	--If duration is zero, go ahead and remove it right away
	if self.m_tblPlayers[pPlayer][strEffectID][2] == 0 then
		self:ClearEffect( pPlayer, strEffectID, bDontNetwork )
		return false
	end

	--Save this
	if not bDontSave then
		local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
		if saveTable then
			saveTable.ActiveEffects = saveTable.ActiveEffects or {}
			saveTable.ActiveEffects[strEffectID] = self.m_tblPlayers[pPlayer][strEffectID][2]
			GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "ActiveEffects" )
		end
	end
	
	--Call OnStart()
	if not bIgnoreOnStart then
		self:GetEffect( strEffectID ):OnStart( pPlayer )
	end
	
	if not bDontNetwork then
		GAMEMODE.Net:SendStartPlayerEffect(
			pPlayer,
			strEffectID,
			self.m_tblPlayers[pPlayer][strEffectID][1],
			self.m_tblPlayers[pPlayer][strEffectID][2]
		)
	end

	return true
end

function GM.PlayerEffects:RemoveEffect( pPlayer, strEffectID, intDur )
	if not self.m_tblPlayers[pPlayer] then return end
	if not self.m_tblPlayers[pPlayer][strEffectID] then return end

	--Since we lazily update active effects, force an update before we mess around with duration to maintain accuracy
	local time = CurTime()
	if self.m_tblPlayers[pPlayer][strEffectID] then
		self:UpdatePlayerEffect( pPlayer, strEffectID, time )
	end
	
	--Remove time from this effect
	self.m_tblPlayers[pPlayer][strEffectID][2] = math.max( 0, self.m_tblPlayers[pPlayer][strEffectID][2] -intDur )

	--Remove it, duration zero
	if self.m_tblPlayers[pPlayer][strEffectID][2] <= 0 then
		self:ClearEffect( pPlayer, strEffectID )
		return
	else
		--Save this
		local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
		if saveTable then
			saveTable.ActiveEffects = saveTable.ActiveEffects or {}
			saveTable.ActiveEffects[strEffectID] = self.m_tblPlayers[pPlayer][strEffectID][2]
			GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "ActiveEffects" )
		end

		GAMEMODE.Net:UpdatePlayerEffect(
			pPlayer,
			strEffectID,
			self.m_tblPlayers[pPlayer][strEffectID][1],
			self.m_tblPlayers[pPlayer][strEffectID][2]
		)
	end
end

function GM.PlayerEffects:ClearEffect( pPlayer, strEffectID, bDontSave )
	if not self.m_tblPlayers[pPlayer] then return end
	if not self.m_tblPlayers[pPlayer][strEffectID] then return end

	--Remove effect from tracking
	self.m_tblPlayers[pPlayer][strEffectID] = nil

	--Call OnStop()
	self:GetEffect( strEffectID ):OnStop( pPlayer )

	--Save this
	if not bDontSave then
		local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
		if saveTable then
			saveTable.ActiveEffects = saveTable.ActiveEffects or {}
			saveTable.ActiveEffects[strEffectID] = nil
			GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "ActiveEffects" )
		end
	end
	
	GAMEMODE.Net:SendStopPlayerEffect( pPlayer, strEffectID )
end

function GM.PlayerEffects:ClearAll( pPlayer )
	if not self.m_tblPlayers[pPlayer] then return end
	if table.Count( self.m_tblPlayers[pPlayer] ) <= 0 then return end
	
	--Call OnStop()
	for k, v in pairs( self.m_tblPlayers[pPlayer] ) do
		self:GetEffect( k ):OnStop( pPlayer )
	end

	--Remove all effects
	self.m_tblPlayers[pPlayer] = {}

	--Save this
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if saveTable then
		saveTable.ActiveEffects = {}
		GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "ActiveEffects" )
	end

	GAMEMODE.Net:ClearPlayerEffects( pPlayer )
end

function GM.PlayerEffects:GetDuration( pPlayer, strEffectID )
	if not self.m_tblPlayers[pPlayer] then return 0 end
	return self.m_tblPlayers[pPlayer][strEffectID] and (self.m_tblPlayers[pPlayer][strEffectID][2] or 0) or 0
end

function GM.PlayerEffects:HasEffect( pPlayer, strEffectID )
	if not self.m_tblPlayers[pPlayer] then return false end
	return self.m_tblPlayers[pPlayer][strEffectID] and true
end
concommand.Add("clearae", function( ply )
	ply.PlayerEffects:ClearAll()
    print("It works!")
end)