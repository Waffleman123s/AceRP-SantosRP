--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--
GM.NPC = {}
GM.NPC.m_tblNPCRegister = {}
GM.NPC.MaxDynamicArgs = 6

function GM.NPC:LoadNPCs()
	GM:PrintDebug( 0, "->LOADING NPCs" )

	local foundFiles, foundFolders = file.Find( GM.Config.GAMEMODE_PATH.. "npcs/*.lua", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )
		include( GM.Config.GAMEMODE_PATH.. "npcs/".. v )
		AddCSLuaFile( GM.Config.GAMEMODE_PATH.. "npcs/".. v )
	end

	GM:PrintDebug( 0, "->NPCs LOADED" )
end

function GM.NPC:Register( tblNPC )
	self.m_tblNPCRegister[tblNPC.UID] = tblNPC

	if tblNPC.RegisterDialogEvents then
		if tblNPC.OnPlayerEndDialog then
			GM.Dialog:RegisterDialogEvent( tblNPC.UID.. "_end_dialog", tblNPC.OnPlayerEndDialog, tblNPC )
		end

		tblNPC:RegisterDialogEvents()
	end
end

function GM.NPC:GetNPCMeta( strNPCUID )
	return self.m_tblNPCRegister[strNPCUID]
end

function GM.NPC:Initialize()
	for k, v in pairs( self.m_tblNPCRegister ) do
		if v.Initialize then v:Initialize() end
	end
end

function GM.NPC:Tick()
	self:UpdateRobberies()
end

function GM.NPC:InitPostEntity()
end

function GM.NPC:PlayerDeath( pPlayer )
	self:GamemodeOnPlayerRagdolled( pPlayer )
end

function GM.NPC:GamemodeOnPlayerRagdolled( pPlayer )
	pPlayer.m_entTalkingNPC = nil
end

function GM.NPC:PlayerBuyNPCItem( pPlayer, strNPCID, strItemID, intAmount )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= strNPCID then return end

	local npc = self:GetNPCMeta( strNPCID )
	if not npc or not npc.ItemsForSale then return end

	if CurTime() < (pPlayer.m_intLastNPCBuyTime or 0) then return end
	pPlayer.m_intLastNPCBuyTime = CurTime() +1

	if npc.CanPlayerBuy and npc:CanPlayerBuy( pPlayer, strItemID, intAmount, pPlayer:GetTalkingNPC() ) == false then
		return
	end	

	local price = npc.ItemsForSale[strItemID] *intAmount
	if not npc.NoSalesTax then
		price = GAMEMODE.Econ:ApplyTaxToSum( "sales", price )
	end
	
	if not pPlayer:CanAfford( price ) then
		pPlayer:AddNote( "You can't afford that!" )
		return
	end

	if GAMEMODE.Inv:GivePlayerItem( pPlayer, strItemID, intAmount ) then
		pPlayer:TakeMoney( price, "Merchant purchase" )
		pPlayer:AddNote( "You purchased ".. intAmount.. " ".. strItemID )
		hook.Call( "GamemodePlayerBuyNPCItem", GAMEMODE, pPlayer, strNPCID, strItemID, intAmount )
	else
		pPlayer:AddNote( "There is not enough space in your inventory for that!" )
	end
end

function GM.NPC:PlayerSellNPCItem( pPlayer, strNPCID, strItemID, intAmount )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= strNPCID then return end

	local npc = self:GetNPCMeta( strNPCID )
	if not npc or not npc.ItemsCanBuy then return end

	if CurTime() < (pPlayer.m_intLastNPCBuyTime or 0) then return end
	pPlayer.m_intLastNPCBuyTime = CurTime() +1

	if npc.CanPlayerSell and npc:CanPlayerSell( pPlayer, strItemID, intAmount, pPlayer:GetTalkingNPC() ) == false then
		return
	end
	
	local amt = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, strItemID )
	if not amt or amt <= 0 then return end
	intAmount = math.min( intAmount, amt )
	
	local price = npc.ItemsCanBuy[strItemID] *intAmount
	if GAMEMODE.Inv:TakePlayerItem( pPlayer, strItemID, intAmount ) then
		pPlayer:AddMoney( price, "Merchant sale" )
		pPlayer:AddNote( "You sold ".. intAmount.. " ".. strItemID )
		hook.Call( "GamemodePlayerSellNPCItem", GAMEMODE, pPlayer, strNPCID, strItemID, intAmount )
	end
end

--[[ NPC Store Robbery ]]--
GM.NPC.m_tblBeingRobbed = {}

function GM.NPC:PlayerCanRob( pPlayer )
	if not IsValid( pPlayer:GetActiveWeapon() ) then return false end
	local p = GAMEMODE.Inv:GetItem( GAMEMODE.Player:GetSharedGameVar(pPlayer, "eq_slot_PrimaryWeapon", "") )
	local s = GAMEMODE.Inv:GetItem( GAMEMODE.Player:GetSharedGameVar(pPlayer, "eq_slot_SecondaryWeapon", "") )
	local a = GAMEMODE.Inv:GetItem( GAMEMODE.Player:GetSharedGameVar(pPlayer, "eq_slot_AltWeapon", "") )
	local wep = pPlayer:GetActiveWeapon()
	local canRob

	if p and p.CanRobStore and p.EquipGiveClass then
		if wep:GetClass() == p.EquipGiveClass then
			canRob = true
		end
	end
	if s and s.CanRobStore and s.EquipGiveClass then
		if wep:GetClass() == s.EquipGiveClass then
			canRob = true
		end
	end
	if a and a.CanRobStore and a.EquipGiveClass then
		if wep:GetClass() == a.EquipGiveClass then
			canRob = true
		end
	end

	return canRob
end

--bIsChildNPC: Include this npc in the robbery of a parent npc, but don't allow the child to be robbed alone
function GM.NPC:InstallRobberyFunctions( tblNPC, bIsChildNPC )
	if not bIsChildNPC then
		tblNPC.PlayerStartRobbery = function( tblNPC, pPlayer )
			if not pPlayer:WithinTalkingRange() then return end
			if pPlayer:GetTalkingNPC().UID ~= tblNPC.UID then return end
			local ent = pPlayer:GetTalkingNPC()

			if ent.m_bBeingRobbed or pPlayer.m_bInStoreRobbery then return end
			if GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < GAMEMODE.Config.NPCRobbery_MinCops then
				pPlayer:AddNote( "There must be at least ".. GAMEMODE.Config.NPCRobbery_MinCops.. " active police to rob a store." )	
				return
			end

			if (pPlayer.m_intLastStoreRobTime or 0) > CurTime() then
				local timeLeft = math.ceil( (pPlayer.m_intLastStoreRobTime -CurTime()) /60 )
				pPlayer:AddNote( ("You must wait %s minutes before you may rob another store"):format(timeLeft) )	
				return
			end

			if not GAMEMODE.NPC:PlayerCanRob( pPlayer ) then return end
			if (ent.m_intLastRobCooldown or 0) > CurTime() then
				GAMEMODE.Net:ShowNPCDialog( pPlayer, tblNPC.UID.. "_cant_rob" )
				return
			end

			GAMEMODE.NPC:PlayerStartRobbery( pPlayer, tblNPC, ent )
		end
	end

	tblNPC.PlayerGiveAllClear = function( tblNPC, pPlayer )
		if not pPlayer:WithinTalkingRange() then return end
		if pPlayer:GetTalkingNPC().UID ~= tblNPC.UID then return end
		local ent = pPlayer:GetTalkingNPC()

		if ent.m_bBeingRobbed then return end
		if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
		if (ent.m_intLastRobTime or 0) > CurTime() then
			ent.m_intLastRobTime = nil
			GAMEMODE.Net:ShowNPCDialog( pPlayer, tblNPC.UID.. "_cop_ackallclear" )
			return
		end
	end
	
	local oldCanBuy = tblNPC.CanPlayerBuy
	tblNPC.CanPlayerBuy = function( _, pPlayer, strItemID, intAmount, entNPC )
		if entNPC.m_bBeingRobbed or (entNPC.m_intLastRobTime or 0) > CurTime() then return false end
		if oldCanBuy then return oldCanBuy( tblNPC, pPlayer, strItemID, intAmount, entNPC ) end
	end

	local oldCanSell = tblNPC.CanPlayerSell
	tblNPC.CanPlayerSell = function( _, pPlayer, strItemID, intAmount, entNPC )
		if entNPC.m_bBeingRobbed or (entNPC.m_intLastRobTime or 0) > CurTime() then return false end
		if oldCanSell then return oldCanSell( tblNPC, pPlayer, strItemID, intAmount, entNPC ) end
	end

	local oldOnTalk = tblNPC.OnPlayerTalk
	tblNPC.OnPlayerTalk = function( _, entNPC, pPlayer, ... )
		if entNPC.m_bBeingRobbed then return end
		if (entNPC.m_intLastRobTime or 0) > CurTime() then
			GAMEMODE.Net:ShowNPCDialog( pPlayer, tblNPC.UID.. "_post_rob" )
			return
		end

		oldOnTalk( tblNPC, entNPC, pPlayer, ... )
	end

	GM.Dialog:RegisterDialogEvent( tblNPC.UID.. "_start_robbery", tblNPC.PlayerStartRobbery, tblNPC )
	GM.Dialog:RegisterDialogEvent( tblNPC.UID.. "_cop_robclear", tblNPC.PlayerGiveAllClear, tblNPC )
end

function GM.NPC:PlayerStartRobbery( pPlayer, tblNPC, entNPC )
	self.m_tblBeingRobbed[entNPC] = {
		Player = pPlayer,
		Data = tblNPC,
		StartTime = CurTime(),
		Len = math.random(
			GAMEMODE.Config.NPCRobbery_MinMoneyCollectTime,
			GAMEMODE.Config.NPCRobbery_MaxMoneyCollectTime
		),
		DownScale = 1,
	}

	if entNPC.m_tblPartnerNPCs then
		for k, v in pairs( entNPC.m_tblPartnerNPCs ) do
			v.m_bBeingRobbed = true
			GAMEMODE.PlayerAnims:ApplyAnimID( v, "hands_up_npc" )
		end
	end

	self.m_tblBeingRobbed[entNPC].SilentAlarm = math.random( 1, 3 ) == 1
	if math.random( 1, 3 ) == 1 then
		self.m_tblBeingRobbed[entNPC].AlarmTime = math.Rand(
			GAMEMODE.Config.NPCRobbery_MinAlarmDelay,
			GAMEMODE.Config.NPCRobbery_MaxAlarmDelay
		)
	else
		self.m_tblBeingRobbed[entNPC].AlarmTime = 0
	end
	
	entNPC.m_bBeingRobbed = true
	GAMEMODE.PlayerAnims:ApplyAnimID( entNPC, "hands_up_npc" )
	pPlayer:AddNote( "You started a robbery!", nil, 30 )
	pPlayer:AddNote( "Wait on the store clerk to collect your money!", nil, 30 )
	pPlayer:AddNote( "Stay close by your hostage to complete the robbery!", nil, 30 )
	pPlayer.m_bInStoreRobbery = true

	hook.Call( "GamemodePlayerStartNPCRobbery", GAMEMODE, pPlayer, entNPC, tblNPC )
end

function GM.NPC:OnRobberyEnd( pPlayer, tblNPC, entNPC, bKillLoot )
	entNPC.m_bBeingRobbed = nil
	entNPC.m_intLastRobTime = CurTime() +GAMEMODE.Config.NPCRobbery_Cooldown1
	entNPC.m_intLastRobCooldown = CurTime() +GAMEMODE.Config.NPCRobbery_Cooldown2

	if entNPC.m_tblPartnerNPCs then
		for k, v in pairs( entNPC.m_tblPartnerNPCs ) do
			v.m_bBeingRobbed = nil
			v.m_intLastRobTime = CurTime() +GAMEMODE.Config.NPCRobbery_Cooldown1
			v.m_intLastRobCooldown = CurTime() +GAMEMODE.Config.NPCRobbery_Cooldown2
			GAMEMODE.PlayerAnims:RemoveAnimID( v, "hands_up_npc" )
		end
	end

	if bKillLoot then
		local data = self.m_tblBeingRobbed[entNPC]
		if IsValid( data.m_entLoot ) then
			data.m_entLoot:Remove()
		end
	end

	if IsValid( pPlayer ) then
		pPlayer.m_intLastStoreRobTime = CurTime() +GAMEMODE.Config.NPCRobbery_Cooldown3
		pPlayer.m_bInStoreRobbery = nil
	end
	
	self.m_tblBeingRobbed[entNPC] = nil
	GAMEMODE.PlayerAnims:RemoveAnimID( entNPC, "hands_up_npc" )

	if entNPC.m_sndAlarm then
		entNPC.m_sndAlarm:Stop()
		entNPC.m_sndAlarm = nil
	end

	hook.Call( "GamemodePlayerEndNPCRobbery", GAMEMODE, pPlayer, entNPC, tblNPC )
end

function GM.NPC:UpdateRobberies()
	for npc, v in pairs( self.m_tblBeingRobbed ) do
		if not IsValid( npc ) then self.m_tblBeingRobbed[npc] = nil continue end

		if not IsValid( v.Player ) then
			self:OnRobberyEnd( v.Player, v.Data, npc, true )
			continue
		end

		--Game over!
		if not IsValid( v.m_entLoot ) and v.Player:IsIncapacitated() or v.Player:GetPos():Distance( npc:GetPos() ) > 850 then
			v.Player:AddNote( "You failed the robbery!" )
			self:OnRobberyEnd( v.Player, v.Data, npc, true )
			continue
		end
		
		--Check if we need to sound the alarm (if any) right now
		local dur = CurTime() -v.StartTime
		if dur > v.Len *v.AlarmTime then
			--play alarm
			if not v.SilentAlarm then
				npc.m_sndAlarm = CreateSound( npc, "ambient/alarms/alarm1.wav" )
				npc.m_sndAlarm:Play()
			end

			if not v.m_bAlertCops then
				v.m_bAlertCops = true
				self:RobberyAlertPolice( npc )
			end
		end

		--Check our current progress
		if v.StartTime +(v.Len *v.DownScale) > CurTime() then
			--Update our progress, faster if our weapon is pointed at them
			--todo lol
		else
			--If we are done, spawn the loot
			if not v.m_bSpawnedLoot then
				v.m_bSpawnedLoot = true
				v.m_entLoot = GAMEMODE.Inv:CreateItemEntity( "Stolen Money", 1, npc:LocalToWorld(Vector(32, 0, 64)), Angle(0, 0, 0) )
				v.m_entLoot.m_tblRobberyData = v
				v.m_entLoot.m_entRobNPC = npc
				v.m_entLoot.IsStolenMoney = true

				v.Player:AddNote( "The clerk has collected your money!" )
			else
				if not IsValid( v.m_entLoot ) then
					--Someone has taken the loot! Robbery over!
					self:OnRobberyEnd( v.Player, v.Data, npc )
				end
			end
		end
	end
end

function GM.NPC:RobberyAlertPolice( entNPC )
	if not entNPC.m_tblNPCData or not entNPC.m_tblNPCData.LocationName then return end
	GAMEMODE.Jobs:GetJobByID( JOB_POLICE ):TextAllPlayers( "Dispatch ", ("10-31 Armed robbery at %s"):format(
		entNPC.m_tblNPCData.LocationName
	) )
end

hook.Add( "GamemodePlayerUseDroppedItem", "PlayerTakeStolenMoney", function( pPlayer, entItem )
	if not entItem.IsStolenMoney then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
	
	pPlayer:AddNote( "You recovered stolen money!" )
	entItem:Remove()

	if entItem.m_tblRobberyData and IsValid( entItem.m_tblRobberyData.Player ) then
		entItem.m_tblRobberyData.Player:AddNote( "The police have recovered the stolen money!" )
	end
	return false
end )

hook.Add( "GamemodePlayerTookItem", "PlayerTakeStolenMoney", function( pPlayer, entItem )
	if not entItem.IsStolenMoney then return end
	if entItem.m_tblRobberyData and IsValid( entItem.m_tblRobberyData.Player ) then
		if entItem.m_tblRobberyData.Player ~= pPlayer then
			entItem.m_tblRobberyData.Player:AddNote( "The money has been taken!" )

			if GAMEMODE.NPC.m_tblBeingRobbed[entItem.m_entRobNPC] then
				entItem.m_tblRobberyData.Player:AddNote( "You completed the robbery!" )
			end
		end
		
		pPlayer:AddNote( "You have taken the money!" )
		if GAMEMODE.NPC.m_tblBeingRobbed[entItem.m_entRobNPC] then
			pPlayer:AddNote( "You completed the robbery!" )
		end
	end
end )

hook.Add( "GamemodeOnNPCKilled", "EndNPCRobbery", function( entNPC, entAttacker, entInflictor )
	if not entNPC.m_bBeingRobbed then return end
	
	entAttacker:AddNote( "You killed a hostage!" )

	if GAMEMODE.NPC.m_tblBeingRobbed[entNPC] then
		if entNPC.m_tblPartnerNPCs then
			--Make sure our partner npcs are all dead before ending the robbery early
			local robberyOver = true
			for _, npc in pairs( entNPC.m_tblPartnerNPCs ) do
				if IsValid( npc.m_entDeathRag ) then continue end
				robberyOver = false
				break
			end

			if robberyOver then
				GAMEMODE.NPC:OnRobberyEnd(
					GAMEMODE.NPC.m_tblBeingRobbed[entNPC].Player,
					GAMEMODE.NPC.m_tblBeingRobbed[entNPC].Data,
					entNPC
				)
				entAttacker:AddNote( "You ended the robbery!" )
			end
		else
			--We have no partners, end the robbery
			GAMEMODE.NPC:OnRobberyEnd(
				GAMEMODE.NPC.m_tblBeingRobbed[entNPC].Player,
				GAMEMODE.NPC.m_tblBeingRobbed[entNPC].Data,
				entNPC
			)
			entAttacker:AddNote( "You ended the robbery!" )
		end
	else
		--A partner npc was killed, look for the parent and other partners
		if IsValid( entNPC.m_entParentNPC ) and GAMEMODE.NPC.m_tblBeingRobbed[entNPC.m_entParentNPC] then
			local robberyOver, parent = IsValid( entNPC.m_entParentNPC.m_tblPartnerNPCs ), nil
			for _, child in pairs( entNPC.m_entParentNPC.m_tblPartnerNPCs ) do
				if child == entNPC or IsValid( child.m_entDeathRag ) then continue end
				robberyOver = false
				break
			end

			if robberyOver then
				GAMEMODE.NPC:OnRobberyEnd(
					GAMEMODE.NPC.m_tblBeingRobbed[entNPC.m_entParentNPC].Player,
					GAMEMODE.NPC.m_tblBeingRobbed[entNPC.m_entParentNPC].Data,
					entNPC.m_entParentNPC
				)
				entAttacker:AddNote( "You ended the robbery!" )
			end
		end
	end
end )