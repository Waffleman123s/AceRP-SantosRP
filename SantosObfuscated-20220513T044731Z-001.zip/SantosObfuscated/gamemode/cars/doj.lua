local Car = {}
Car.Make = "Chevy"
Car.Name = "Chevy Tahoe"
Car.UID = "chev_dojcar"
Car.Job = "JOB_JUDGE"
Car.Desc = ""
Car.Model = "models/LoneWolfie/chev_suburban.mdl"
Car.Script = "scripts/vehicles/LWCars/chev_tahoe.txt"
Car.FuellTank = 65
Car.FuelConsumption = 1

Car.LPlates = {
	{
		pos = Vector( 0, 140.5, 28 ), 
		ang = Angle( 0, 180, 90 ),
		scale = 0.025
	},
	{
		pos = Vector( 0, -158, 27 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.020
	}
}
GM.Cars:RegisterJobCar( Car )