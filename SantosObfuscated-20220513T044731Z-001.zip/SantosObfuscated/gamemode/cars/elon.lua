local Car = {}
Car.VIP = true
Car.Make = "Tesla"
Car.Name = "2019 Tesla Model 3"
Car.UID = "model3_sgm"
Car.Desc = "Tesla"
Car.Model = "models/sentry/model3.mdl"
Car.Script = "scripts/vehicles/sentry/model3.txt"
Car.Price = 35000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Tesla"
Car.Name = "2016 Model S P90D"
Car.UID = "models_sgm"
Car.Desc = "Tesla"
Car.Model = "models/sentry/models.mdl"
Car.Script = "scripts/vehicles/sentry/models.txt"
Car.Price = 45995
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )