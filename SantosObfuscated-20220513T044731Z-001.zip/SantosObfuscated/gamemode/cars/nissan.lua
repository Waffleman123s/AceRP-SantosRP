local Car = {}
Car.VIP = true
Car.Make = "Nissan" -- trunk doesnt work
Car.Name = "1992 Nissan Skyline R32 GT-R Custom"
Car.UID = "nissanskyliner32gtrcustom"
Car.Desc = "Nissan"
Car.Model = "models/crsk_autos/nissan/skyline_r32_gtr_custom.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_nissan_skyline_r32_gtr_custom.txt"
Car.Price = 55000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Nissan"
Car.Name = "2017 Nissan GT-R Nismo"
Car.UID = "nismor35"
Car.Desc = "Nissan"
Car.Model = "models/sentry/nismor35.mdl"
Car.Script = "scripts/vehicles/sentry/nismor35.txt"
Car.Price = 175900
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Nissan"
Car.Name = "1994 Nissan 180SX"
Car.UID = "nissan180sx"
Car.Desc = "Nissan"
Car.Model = "models/sentry/180sx_new.mdl"
Car.Script = "scripts/vehicles/sentry/180sx_new.txt"
Car.Price = 13600
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Nissan"
Car.Name = "1998 Nissan 240SX"
Car.UID = "nissan240sx"
Car.Desc = "Nissan"
Car.Model = "models/sentry/240sx.mdl"
Car.Script = "scripts/vehicles/sentry/240sx.txt"
Car.Price = 12029
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Nissan"
Car.Name = "1976 Fairlady Devil Z"
Car.UID = "nissanfdz"
Car.Desc = "Nissan"
Car.Model = "models/crsk_autos/nissan/fairladyz_s30z_devilz.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_nissan_fairladyz_s30z_devilz.txt"
Car.Price = 100000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Nissan"
Car.Name = "2016 Nissan 370Z Nismo Z34"
Car.UID = "nissan370z"
Car.Desc = "Nissan"
Car.Model = "models/crsk_autos/nissan/370z_2016.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_nissan_370z_2016.txt"
Car.Price = 41990
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Nissan"
Car.Name = "1997 Nissan Sentra GXE"
Car.UID = "sky_sentra97_ico"
Car.Desc = "Nissan"
Car.Model = "models/skyautomotive/sentra97.mdl"
Car.Script = "scripts/vehicles/skyautos/sentra97.txt"
Car.Price = 2400
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )