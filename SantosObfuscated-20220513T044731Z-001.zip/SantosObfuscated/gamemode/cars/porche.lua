local Car = {}
Car.VIP = true
Car.Make = "Porsche"
Car.Name = "1995 Porsche 911 (993) GT2"
Car.UID = "crsk_porsche_911_gt2_993_1995"
Car.Desc = "Porsche"
Car.Model = "models/crsk_autos/porsche/911_gt2_993_1995.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_porsche_911_gt2_993_1995.txt"
Car.Price = 80000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Porsche"
Car.Name = "2012 Porsche 911 GT2 RS"
Car.UID = "porsche_911_gt_mlw"
Car.Desc = "Porsche"
Car.Model = "models/mlautomotive/porsche_911_gt2.mdl"
Car.Script = "scripts/vehicles/mlautomotive/porsche_911_gt2.txt"
Car.Price = 250000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )