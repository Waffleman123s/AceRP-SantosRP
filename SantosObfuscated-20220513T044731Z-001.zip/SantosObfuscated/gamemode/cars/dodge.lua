local Car = {}
Car.Make = "Dodge"
Car.Name = "2009 Dodge Caravan"
Car.UID = "dodgegrandc"
Car.Desc = "Dodge"
Car.Model = "models/sentry/grandcaravan.mdl"
Car.Script = "scripts/vehicles/sentry/caravan.txt"
Car.Price = 6988
Car.FuellTank = 65
Car.FuelConsumption = 1

GM.Cars:Register( Car )

local Car = {}
Car.Make = "Dodge"
Car.Name = "2015 Dodge Challenger SRT Hellcat"
Car.UID = "dodgechallengersrthellcat15"
Car.Desc = "Dodge"
Car.Model = "models/crsk_autos/dodge/challenger_hellcat_2015.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_dodge_challenger_hellcat_2015.txt"
Car.Price = 60990
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Dodge"
Car.Name = "1994 Dodge Ram 2500"
Car.UID = "ctv_1994_dodge_ram_2500"
Car.Desc = "Dodge"
Car.Model = "models/ctvehicles/dodge/ram_2500_1994.mdl"
Car.Script = "scripts/vehicles/ctvehicles/ctv_1994_dodge_ram_2500.txt"
Car.Price = 15100
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )