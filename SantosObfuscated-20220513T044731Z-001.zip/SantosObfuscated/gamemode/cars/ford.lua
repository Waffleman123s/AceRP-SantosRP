--[[
Property of acerp.gg ©2022
By: Tylr (tylrdevs@gmail.com, Tylr#6345)
For: AceRP.gg 
]]--
local Car = {}
Car.VIP = true
Car.Make = "Ford"
Car.Name = "2018 Ford Mustang GT"
Car.UID = "fordmustang18"
Car.Desc = "Ford"
Car.Model = "models/crsk_autos/ford/mustang_gt_2018.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_ford_mustang_gt_2018.txt"
Car.Price = 75000
Car.FuellTank = 65
Car.FuelConsumption = 1
Car.LPlates = {
	{
    pos = Vector(0, 113.5, 20.4),
    ang = Angle(0, 180, 90),
    scale = 0.027
    }, 
    {    
    pos = Vector(0, -118, 40.8),
    ang = Angle(0, 0, 80),
    scale = 0.029
    }
}
Car.Trunk = {
	pos = Vector( -0.104207, -114.290062, 51.879532 ),
	dot = -0.910578,
	dist = 60.243106,
	weight = 350,
	volume = 300,
}
GM.Cars:Register( Car )


local Car = {}
Car.Make = "Ford"
Car.Name = "1994 Crown Victoria LX"
Car.UID = "fordcviclx94"
Car.Desc = "Ford"
Car.Model = "models/crsk_autos/ford/crownvictoria_1994.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_ford_crownvictoria_1994.txt"
Car.Price = 14000
Car.FuellTank = 65
Car.FuelConsumption = 1
Car.Trunk = {
    pos = Vector( -18.412548, 4.847075, 59.110794 ),
    dot = -0.296491,
    dist = 35.693220,
	weight = 350,
	volume = 300,
}
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Ford"
Car.Name = "1982 Ford Bronco"
Car.UID = "crsk_ford_bronco_1982"
Car.Desc = "Ford"
Car.Model = "models/crsk_autos/ford/bronco_1982.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_ford_bronco_1982.txt"
Car.Price = 42990
Car.FuellTank = 65
Car.FuelConsumption = 1
Car.LPlates = {
	{
	pos = Vector(0, 100.8, 30.6),
	ang = angForward,
    },{
	pos = Vector(0, -116.5, 29.9),
	ang = angBackward
	}
}
Car.Trunk = {
    pos = Vector( -23.422077, -11.901295, 71.091431 ),
    dot = -0.309036,
    dist = 33.734379,
	weight = 350,
	volume = 300,
}
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Ford"
Car.Name = "2013 Ford Focus"
Car.UID = "focusstmc"
Car.Desc = "Ford"
Car.Model = "models/marcuscars/focus.mdl"
Car.Script = "scripts/vehicles/marcuscars/focus.txt"
Car.Price = 14500
Car.FuellTank = 65
Car.FuelConsumption = 1
Car.Trunk = {
    pos = Vector( -23.422077, -11.901295, 71.091431 ),
    dot = -0.309036,
    dist = 33.734379,
	weight = 350,
	volume = 300,
}
GM.Cars:Register( Car )