-- Not really misc but just cars that don't deserve their own lua file cuz theres not enough of them

local Car = {} 
Car.VIP = true
Car.Make = "Winnebago"
Car.Name = "1980s Winnebago"
Car.UID = "rv"
Car.Desc = "Winnebago"
Car.Model = "models/sentry/rv.mdl"
Car.Script = "scripts/vehicles/sentry/rv.txt"
Car.Price = 15000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Caisson"
Car.Name = "2013 Caisson Elementary C"
Car.UID = "bus"
Car.Desc = "Caisson"
Car.Model = "models/sentry/bus.mdl"
Car.Script = "scripts/vehicles/sentry/bus.txt"
Car.Price = 15000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Subaru"
Car.Name = "2015 Subaru WRX STI"
Car.UID = "crsk_subaru_wrx_sti_2015"
Car.Desc = "Subaru"
Car.Model = "models/crsk_autos/subaru/wrx_sti_2015.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_subaru_wrx_sti_2015.txt"
Car.Price = 30000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Aston Martin"
Car.Name = "2017 Aston Martin DB11"
Car.UID = "crsk_aston_db11_2017"
Car.Desc = "Aston Martin"
Car.Model = "models/crsk_autos/aston_martin/db11_2017.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_aston_db11_2017.txt"
Car.Price = 211995
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Land Rover"
Car.Name = "1967 Land Rover Series IIa Station Wagon"
Car.UID = "crsk_landrover_series_IIa_stationwagon"
Car.Desc = "Land Rover"
Car.Model = "models/crsk_autos/landrover/series_iia_stationwagon.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_landrover_series_iia_stationwagon.txt"
Car.Price = 26400
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Maserati"
Car.Name = "2014 Maserati Alfieri Concept"
Car.UID = "crsk_maserati_alfieri_concept"
Car.Desc = "Maserati"
Car.Model = "models/crsk_autos/maserati/alfieri_concept_2014.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_maserati_alfieri_concept.txt"
Car.Price = 1000000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Mitsubishi"
Car.Name = "1987 Mitsubishi Galant VR-4 E39A"
Car.UID = "crsk_mitsubishi_galante39a"
Car.Desc = "Mitsubishi"
Car.Model = "models/crsk_autos/mitsubishi/galante39a_1987.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_mitsubishi_galante39a.txt"
Car.Price = 8700
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Ferrari"
Car.Name = "2017 Ferrari 812 Superfast"
Car.UID = "crsk_ferrari_812superfast_2017"
Car.Desc = "Ferrari"
Car.Model = "models/crsk_autos/ferrari/812superfast_2017.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_ferrari_812superfast_2017.txt"
Car.Price = 315000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Chrysler"
Car.Name = "1970 Chrysler 300 Hurst Edition"
Car.UID = "crsk_chrysler_300_hurst_1970_low"
Car.Desc = "Chrysler"
Car.Model = "models/crsk_autos/chrysler/300_hurst_1970.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_chrysler_300_hurst_1970.txt"
Car.Price = 19000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )