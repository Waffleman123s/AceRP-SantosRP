local Car = {}
Car.Make = "Toyota"
Car.Name = "1985 Toyota Sprinter Trueno"
Car.UID = "toyotast"
Car.Desc = "Toyota"
Car.Model = "models/sentry/ae86.mdl"
Car.Script = "scripts/vehicles/sentry/trueno.txt"
Car.Price = 7000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Toyota"
Car.Name = "2013 Toyota Land Cruiser"
Car.UID = "toyotalc"
Car.Desc = "Toyota"
Car.Model = "models/crsk_autos/toyota/landcruiser_200_2013.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_toyota_landcruiser_200_2013_black.txt"
Car.Price = 15000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )