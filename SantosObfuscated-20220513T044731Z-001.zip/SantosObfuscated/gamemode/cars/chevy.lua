--[[
Property of acerp.gg ©2022
By: Tylr (tylrdevs@gmail.com, Tylr#6345)
For: AceRP.gg 
]]--

Car = {}
Car.VIP = true
Car.Make = "Chevy"
Car.Name = "1964 Chevy Impala SS"
Car.UID = "impalasgm"
Car.Desc = "Chevy"
Car.Model = "models/sentry/impala.mdl"
Car.Script = "scripts/vehicles/sentry/impala.txt"
Car.Price = 34600
Car.FuellTank = 65
Car.FuelConsumption = 1

Car.Trunk = {
	pos = Vector( 0.502346, -146.432648, 47.124599 ),
	dot = -0.951915,
	dist = 61.053222,
	weight = 450,
	volume = 500,
}
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Chevy"
Car.Name = "1970 Chevrolet El Camino SS 454"
Car.UID = "chevy_ecss4454"
Car.Desc = "Chevy"
Car.Model = "models/sentry/elcamino.mdl"
Car.Script = "scripts/vehicles/sentry/elcamino.txt"
Car.Price = 30000
Car.FuellTank = 65
Car.FuelConsumption = 1

Car.Trunk = {
    pos = Vector( -15.819408, 17.381506, 48.235149 ),
    dot = -0.294828,
    dist = 35.128251,
	weight = 750,
	volume = 600,
}
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Chevy"
Car.Name = "1996 Chevrolet Corvette Grand Sport"
Car.UID = "96grandsport_sgm"
Car.Desc = "Chevy"
Car.Model = "models/sentry/96grandsport.mdl"
Car.Script = "scripts/vehicles/sentry/96grandsport.txt"
Car.Price = 29350
Car.FuellTank = 65
Car.FuelConsumption = 1

Car.Trunk = {
	pos = Vector( 1.117355, -97.899277, 46.527607 ),
	dot = -0.903139,
	dist = 53.476088,
	weight = 250,
	volume = 200,
}
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Chevy"
Car.Name = "1957 Chevrolet Corvette C1"
Car.UID = "corvette_c1_1957"
Car.Desc = "Chevy"
Car.Model = "models/crsk_autos/chevrolet/corvette_c1_1957.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_chevrolet_corvette_c1_1957.txt"
Car.Price = 75900
Car.FuellTank = 65
Car.FuelConsumption = 1

Car.Trunk = {
	pos = Vector( 1.117355, -97.899277, 46.527607 ),
	dot = -0.903139,
	dist = 53.476088,
	weight = 250,
	volume = 200,
}
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Chevy"
Car.Name = "2020 Chevrolet Colorado ZR2"
Car.UID = "ctv_colorado_zr2"
Car.Desc = "Chevy"
Car.Model = "models/ctvehicles/chevrolet/colorado_zr2.mdl"
Car.Script = "scripts/vehicles/ctvehicles/ctv_colorado_zr2.txt"
Car.Price = 41400
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )