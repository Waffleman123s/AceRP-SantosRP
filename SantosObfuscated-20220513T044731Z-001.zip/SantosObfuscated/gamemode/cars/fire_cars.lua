--[[
	Name: fire_cars.lua
	For: SantosRP
	By: Ultra
]]--

local Car = {}
Car.Make = "Government"
Car.Name = "Fire Engine"
Car.UID = "fire_truck"
Car.Job = "JOB_FIREFIGHTER"
Car.Desc = "A fire truck."
Car.Model = "models/sentry/firetruk_hi.mdl"
Car.Script = "scripts/vehicles/sentry/firetruk_hi.txt"
Car.FuellTank = 120
Car.FuelConsumption = 20
Car.PreviewSkin = 1
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = 500,
        ["maxSpeed"] = 800,
        ["horsepower"] = 750,
    }
}
Car.LPlates = {
	{
		pos = Vector( 0, 214, 31 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.030
	},
	{
		pos = Vector( 0, -176.5, 33 ),
		ang = Angle( 0, 2, 90 ),
		scale = 0.022
	}
}
Car.Trunk = {
	pos = Vector( -52.123066, -104.753357, 92.377998 ),
	dot = -0.702682,
	dist = 97.984719,
	weight = 850,
	volume = 850,
}
GM.Cars:RegisterJobCar( Car )

--[[local Car = {}
Car.Make = "MTL"
Car.Name = "Pierce Fire Engine"
Car.UID = "fire_truck"
Car.Job = "JOB_FIREFIGHTER"
Car.Desc = "A firetruck."
Car.Model = "models/sentry/fireengine.mdl"
Car.Script = "scripts/vehicles/sentry/fireengine.txt"
Car.PreviewSkin = 0
Car.FuellTank = 120
Car.FuelConsumption = 20
Car.LPlates = {
	{
		pos = Vector( 27.2, 235.5, 34.2 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.030
	},
	{
		pos = Vector( 28.329515, -190.577164, 47.563362 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.022
	}
}
GM.Cars:RegisterJobCar( Car )]]--

-- local Car = {}
-- Car.Make = "Ford"
-- Car.Name = "F150 Fire"
-- Car.UID = "fire_first"
-- Car.Job = "JOB_FIREFIGHTER"
-- Car.Desc = "A first responder truck."
-- Car.Model = "models/talonvehicles/tal_f150_pol.mdl"
-- Car.Script = "scripts/vehicles/tal_f150pol.txt"
-- Car.PreviewSkin = 5
-- Car.FuellTank = 120
-- Car.FuelConsumption = 20
-- Car.VehicleParams = {
--     ["engine"] = {
--         ["shiftUpRPM"] = 400,
--         ["maxSpeed"] = 800,
--         ["horsepower"] = 250,
--     }
-- }
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 1, 127, 26 ),
-- 		ang = Angle( 0, 180, 90 ),
-- 		scale = 0.022
-- 	},
-- 	{
-- 		pos = Vector( 0, -139, 28 ),
-- 		ang = Angle( 0, 0, 95 ),
-- 		scale = 0.024
-- 	}
-- }
-- Car.Trunk = {
-- 	pos = Vector( 0.925793, -139.081558, 55.549919 ),
-- 	dot = -0.928649,
-- 	dist = 63.781632,
-- 	weight = 850,
-- 	volume = 850,
-- }
-- GM.Cars:RegisterJobCar( Car )

--[[local Car = {}
Car.Make = "Ford"
Car.Name = "Crown Victoria"
Car.UID = "fd_cvfirstrespond"
Car.Job = "JOB_FIREFIGHTER"
Car.Desc = "A first responder vehicle."
Car.Model = "models/tdmcars/emergency/for_crownvic.mdl"
Car.Script = "scripts/vehicles/TDMCars/for_crownvic.txt"
Car.FuellTank = 65
Car.PreviewSkin = 6
Car.FuelConsumption = 20
Car.LPlates = {
	{
		pos = Vector( 0, 127.5, 22.5 ),
		ang = Angle( 0, 180, 100 ),
		scale = 0.018
	},
	{
		pos = Vector( 0, -123.5, 38.8 ),
		ang = Angle( 0, 0, 80 ),
		scale = 0.025
	}
}
Car.Trunk = {
	pos = Vector( 0.449644, -123.719170, 46.760685 ),
	dot = -0.935411,
	dist = 55.238367,
	weight = 350,
	volume = 300,
}
GM.Cars:RegisterJobCar( Car )]]--