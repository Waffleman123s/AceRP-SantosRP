--[[
	Name: cl_npcs.lua
	For: SantosRP
	By: Ultra
]]--

GM.NPC = (GAMEMODE or GM).NPC or {}
GM.NPC.m_tblNPCRegister = (GAMEMODE or GM).NPC.m_tblNPCRegister or {}

function GM.NPC:LoadNPCs()
	GM:PrintDebug( 0, "->LOADING NPCs" )

	local foundFiles, foundFolders = file.Find( GM.Config.GAMEMODE_PATH.. "npcs/*.lua", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )
		include( GM.Config.GAMEMODE_PATH.. "npcs/".. v )
	end

	GM:PrintDebug( 0, "->NPCs LOADED" )
end

function GM.NPC:Register( tblNPC )
	self.m_tblNPCRegister[tblNPC.UID] = tblNPC

	if tblNPC.RegisterDialogEvents then
		tblNPC:RegisterDialogEvents()
	end
end

function GM.NPC:GetNPCMeta( strNPCUID )
	return self.m_tblNPCRegister[strNPCUID]
end

function GM.NPC:Initialize()
	for k, v in pairs( self.m_tblNPCRegister ) do
		if v.Initialize then v:Initialize() end
	end
end


--[[ NPC Store Robbery ]]--
function GM.NPC:PlayerCanRob()
	if not IsValid( LocalPlayer():GetActiveWeapon() ) then return false end
	local p = GAMEMODE.Inv:GetItem( GAMEMODE.Player:GetSharedGameVar(LocalPlayer(), "eq_slot_PrimaryWeapon", "") )
	local s = GAMEMODE.Inv:GetItem( GAMEMODE.Player:GetSharedGameVar(LocalPlayer(), "eq_slot_SecondaryWeapon", "") )
	local a = GAMEMODE.Inv:GetItem( GAMEMODE.Player:GetSharedGameVar(LocalPlayer(), "eq_slot_AltWeapon", "") )
	local wep = LocalPlayer():GetActiveWeapon()
	local canRob

	if p and p.CanRobStore and p.EquipGiveClass then
		if wep:GetClass() == p.EquipGiveClass then
			canRob = true
		end
	end
	if s and s.CanRobStore and s.EquipGiveClass then
		if wep:GetClass() == s.EquipGiveClass then
			canRob = true
		end
	end
	if a and a.CanRobStore and a.EquipGiveClass then
		if wep:GetClass() == a.EquipGiveClass then
			canRob = true
		end
	end

	return canRob
end

local robConfirmMessages = {
	"Who do you think you are!",
	"Are you serious!?",
	"I can't belive this! Not again!",
}
local robMessages = {
	"(Rob) Hands Up! Give me everything you've got!",
	"(Rob) No sudden movements! Give me the money!",
	"(Rob) Hands Up! Empty the register!",
}
function GM.NPC:InstallRobberyFunctions( tblNPC, bIsChildNPC )
	if not bIsChildNPC then
		local oldFunc = tblNPC.StartDialog
		tblNPC.StartDialog = function( ... )
			oldFunc( ... )

			if not GAMEMODE.NPC:PlayerCanRob() then return end

			local msg, _ = table.Random( robMessages )
			GAMEMODE.Dialog:AddOption( msg, function()
				msg, _ = table.Random( robConfirmMessages )

				GAMEMODE.Dialog:ShowDialog()
				GAMEMODE.Dialog:SetModel( tblNPC.Model )
				GAMEMODE.Dialog:SetTitle( tblNPC.Name )
				GAMEMODE.Dialog:SetPrompt( msg )

				GAMEMODE.Dialog:AddOption( "Shut up and get moving!", function()
					GAMEMODE.Net:SendNPCDialogEvent( tblNPC.UID.. "_start_robbery" )
					GAMEMODE.Dialog:HideDialog()
				end )
				GAMEMODE.Dialog:AddOption( "Just kidding! Haha...", function()
					GAMEMODE.Net:SendNPCDialogEvent( tblNPC.UID.. "_end_dialog" )
					GAMEMODE.Dialog:HideDialog()
				end )
			end )
		end
	end

	tblNPC.StartDialog_CantRob = function( tblNPC )
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( tblNPC.Model )
		GAMEMODE.Dialog:SetTitle( tblNPC.Name )
		GAMEMODE.Dialog:SetPrompt( "I was just robbed, I have nothing to give you!" )

		GAMEMODE.Dialog:AddOption( "Oh, well... I was never here!", function()
			GAMEMODE.Net:SendNPCDialogEvent( tblNPC.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end

	tblNPC.StartDialog_PostRobbery = function( tblNPC )
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( tblNPC.Model )
		GAMEMODE.Dialog:SetTitle( tblNPC.Name )
		GAMEMODE.Dialog:SetPrompt( "Sorry but I just got robbed, I'm not open right now!" )

		if GAMEMODE.Jobs:GetPlayerJobID( LocalPlayer() ) == JOB_POLICE then
			GAMEMODE.Dialog:AddOption( "(All Clear) We've got everything under control now.", function()
				GAMEMODE.Net:SendNPCDialogEvent( tblNPC.UID.. "_cop_robclear" )
				GAMEMODE.Dialog:HideDialog()
			end )
		end
		
		GAMEMODE.Dialog:AddOption( "Oh, sorry to hear that.", function()
			GAMEMODE.Net:SendNPCDialogEvent( tblNPC.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end

	tblNPC.StartDialog_CopAckAllClear = function( tblNPC )
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( tblNPC.Model )
		GAMEMODE.Dialog:SetTitle( tblNPC.Name )
		GAMEMODE.Dialog:SetPrompt( "Thanks for the help!" )

		GAMEMODE.Dialog:AddOption( "That'll be all for now.", function()
			GAMEMODE.Net:SendNPCDialogEvent( tblNPC.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end

	GM.Dialog:RegisterDialog( tblNPC.UID.. "_cant_rob", tblNPC.StartDialog_CantRob, tblNPC )
	GM.Dialog:RegisterDialog( tblNPC.UID.. "_post_rob", tblNPC.StartDialog_PostRobbery, tblNPC )
	GM.Dialog:RegisterDialog( tblNPC.UID.. "_cop_ackallclear", tblNPC.StartDialog_CopAckAllClear, tblNPC )
end