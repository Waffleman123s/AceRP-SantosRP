--[[
	Name: sh_asphyxiated.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Asphyxiated"
Effect.Icon48 = "santosrp/ae_icons/Asphyxiated 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Asphyxiated 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 2,
		["Stamina"] = 2,
		["Health"] = 3,
	}
}

function Effect:Setup()
end

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Asphyxiated", -30, -60 )
	else
		self.m_sndHeartbeat = CreateSound( pPlayer, "player/heartbeatloop.wav" )
		self.m_sndHeartbeat:PlayEx( 0.05, 80 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Asphyxiated" )
	else
		self.m_sndHeartbeat:Stop()
		self.m_sndHeartbeat = nil
	end
end

if SERVER then
	function Effect:GamemodePlayerGoUncon( pPlayer )
		GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
	end

	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
		end
	end

	function Effect:LazyTick( pPlayer )
		if GAMEMODE.Jail:IsPlayerInJail( pPlayer ) or pPlayer:IsUncon() then return end
		if CurTime() > (pPlayer.m_intLastFX_AsphyxiatedHealthDecay or 0) then
			pPlayer:SetHealth( math.max(pPlayer:Health() -10, 0) )
			pPlayer.m_intLastFX_AsphyxiatedHealthDecay = CurTime() +1

			if pPlayer:Health() <= 0 then
				pPlayer:GoUncon( false, true )
			end
		end
	end
elseif CLIENT then
	function Effect:Tick()
		local scalar = math.Remap( LocalPlayer():Health(), 0, 100, 0, 1 )
		self.m_sndHeartbeat:ChangeVolume( Lerp(scalar, 0.5, 0.05), 0 )
	end
end

GM.PlayerEffects:Register( Effect )