--[[
	Name: sh_drowning.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Drowning"
Effect.Icon48 = "santosrp/ae_icons/Drowning 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Drowning 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
		["Stamina"] = 3,
		["Health"] = 3,
	}
}

function Effect:Setup()
	if CLIENT then return end
	hook.Add( "GamemodePlayerWaterLevelChanged", "WatchWaterLevel:Drowning", function( pPlayer, intNewLevel, intLastLevel )
		if intNewLevel ~= 3 then
			GAMEMODE.PlayerEffects:ClearEffect( pPlayer, Effect.ID )
		end
	end )
end

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Drowning", -100, -100 )
	else
		self.m_sndHeartbeat = CreateSound( pPlayer, "player/heartbeatloop.wav" )
		self.m_sndHeartbeat:PlayEx( 0.5, 80 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Drowning" )
		pPlayer.m_intLastFX_Asphyxiated = nil
	else
		self.m_sndHeartbeat:Stop()
		self.m_sndHeartbeat = nil
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, strNeedID, 2 )
		end
	end

	function Effect:LazyTick( pPlayer )
		if pPlayer:IsUncon() then GAMEMODE.PlayerEffects:ClearEffect( pPlayer, Effect.ID ) return end
		if CurTime() > (pPlayer.m_intLastFX_Asphyxiated or 0) then
			pPlayer.m_intLastFX_Asphyxiated = CurTime() +1
			pPlayer:EmitSound( "player/pl_drown".. math.random(1, 3).. ".wav", 60, 100, 0.8 )
			pPlayer:SetHealth( math.max(pPlayer:Health() -5, 0) )

			if pPlayer:Health() <= 0 then
				pPlayer:GoUncon()
			end
		end
	end
elseif CLIENT then
	function Effect:RenderScreenspaceEffects()
		local scalar = math.Remap( LocalPlayer():Health(), 0, 100, 0, 1 )
		local pow = Lerp( scalar, 10, 1 )
		local scale = Lerp( scalar, 1, 0.1 )
		DrawToyTown( (math.sin(RealTime() *2) *pow) +(pow +2), ScrH() *scale, 1 )
		--DrawMotionBlur( 0.4, 0.9, 0.05 )
	end
end

GM.PlayerEffects:Register( Effect )