--[[
	Name: sh_severe_intox.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Severe Intoxication"
Effect.Icon48 = "santosrp/ae_icons/Severe Intoxication 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Severe Intoxication 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
		["Stamina"] = 3,
		["Vomiting"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:SevereIntox", -100, -100 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:SevereIntox" )
		pPlayer.m_intLastFX_IntoxVomit = nil
	end
end

function Effect:SetupMove( pPlayer, pMoveData, pUserCmd )
	if CLIENT and pPlayer ~= LocalPlayer() then return end
	if not pPlayer:InVehicle() then
		pMoveData:SetMoveAngles( pMoveData:GetMoveAngles() +Angle(
			0,
			math.sin( CurTime() *1.2 ) *20,
			0
		) )
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, strNeedID, 2 )
		end
	end

	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_IntoxVomit or 0) then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Vomiting", math.random(8, 14), false, false, true )
			pPlayer.m_intLastFX_IntoxVomit = CurTime() +math.random( 18, 25 )
		end
	end
elseif CLIENT then
	function Effect:RenderScreenspaceEffects()
		DrawToyTown( (math.sin(RealTime() *2) *10) +12, ScrH() *1, 1 )
		DrawMotionBlur( 0.4, 0.9, 0.05 )
	end

	--[[function Effect:GetMotionBlurValues( intW, intH, intForward, intRot )
		intRot = intRot +(math.sin( RealTime() *1.2 ) *0.05)
		return intW, intH, intForward, intRot
	end]]--

	function Effect:CreateMove( pUserCmd )
		if not LocalPlayer():InVehicle() then return end
		pUserCmd:SetSideMove( pUserCmd:GetSideMove() +(math.sin(CurTime() *4) *100) )
	end
end

GM.PlayerEffects:Register( Effect )