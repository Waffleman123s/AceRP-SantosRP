--[[
	Name: sh_cig.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Cigarette Smoking"
Effect.Icon48 = "santosrp/ae_icons/Hunter Wrynn Disease 48x48.png"
Effect.Icon18 = "santosrp/ae_icons/Hunter Wrynn Disease 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {
		["Cool Factor"] = 1,
	},
	Drains = {
		["Smoker's Cough"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] ~= self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, self.PacOutfit )
		end
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] == self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, "" )
		end

		pPlayer.m_intLastFX_CigCough = nil
	end
end

if SERVER then
	function Effect:Cough( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		pPlayer:EmitSound( "ambient/voices/cough".. math.random(1, 4)..".wav", 75, 95 )
		pPlayer:ViewPunch( Angle(math.random(6, 12), 0, 0) )
	end

	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_CigCough or 0) then
			if math.random( 1, 3 ) == 1 then
				self:Cough( pPlayer )
			end

			pPlayer.m_intLastFX_CigCough = CurTime() +math.random( 60, 120 )
		end
	end
end

Effect.PacOutfit = "drug_cig"
Effect.PacOutfitSlot = {
	Name = "int_drug_cig",
	Data = {
		Type = "GAMEMODE_INTERNAL_PAC_ONLY",
		Internal = true,
		KeepOnDeath = false,
		PacEnabled = true,
	},
}
GM.Inv:RegisterEquipSlot( Effect.PacOutfitSlot.Name, Effect.PacOutfitSlot.Data )

GM.PacModels:Register( Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "686013029",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.30000001192093),
							["Material"] = "models/props_wasteland/concretewall066a",
							["Size"] = 0.07,
							["Position"] = Vector(1.4700000286102, 0, 0),
							["Angles"] = Angle(-90, 0, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "968541480",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "4226166498",
							["Name"] = "cherry",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["Material"] = "models/weapons/v_crossbow/rebar_glow",
							["Size"] = 0.07,
							["Position"] = Vector(1.5499999523163, 0, 0),
							["Angles"] = Angle(-90, 0, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
				},
				["self"] = {
					["ClassName"] = "model",
					["UniqueID"] = "3894885173",
					["Model"] = "models/pissedmeoff.mdl",
					["Size"] = 0.65,
					["Position"] = Vector(0.88388061523438, -6.5858764648438, -1.0126342773438),
					["Name"] = "cigarette",
					["Angles"] = Angle(19.313579559326, -86.569694519043, -1.8829755783081),
				},
			},
			[2] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 5,
					["UniqueID"] = "3514151176",
					["StickToSurface"] = false,
					["Material"] = "particle/particle_smokegrenade1",
					["AirResistance"] = 30,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.93278503417969, -6.3522338867188, 0.0014572143554688),
					["Sliding"] = false,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["DieTime"] = 8,
					["FireDelay"] = 12,
					["ClassName"] = "particles",
					["Bounce"] = 0,
					["Gravity"] = Vector(0, 0, 2),
					["Name"] = "cig_smoke",
					["Angles"] = Angle(7.7266508014873e-005, -87.288673400879, -2.4972880055429e-005),
					["StartSize"] = 0,
					["RollDelta"] = -0.2,
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "234646324",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )

GM.PacModels:Register( "female_".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 5,
					["UniqueID"] = "3514151176",
					["StickToSurface"] = false,
					["Material"] = "particle/particle_smokegrenade1",
					["AirResistance"] = 30,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.24172973632813, -6.385009765625, 0.000885009765625),
					["Sliding"] = false,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["DieTime"] = 8,
					["FireDelay"] = 12,
					["ClassName"] = "particles",
					["Bounce"] = 0,
					["Gravity"] = Vector(0, 0, 2),
					["Name"] = "cig_smoke",
					["Angles"] = Angle(7.7266508014873e-005, -87.288673400879, -2.4972880055429e-005),
					["StartSize"] = 0,
					["RollDelta"] = -0.2,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "968541480",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "4226166498",
							["Name"] = "cherry",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["Material"] = "models/weapons/v_crossbow/rebar_glow",
							["Size"] = 0.07,
							["Position"] = Vector(1.5499999523163, 0, 0),
							["Angles"] = Angle(-90, 0, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "686013029",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.30000001192093),
							["Material"] = "models/props_wasteland/concretewall066a",
							["Size"] = 0.07,
							["Position"] = Vector(1.4700000286102, 0, 0),
							["Angles"] = Angle(-90, 0, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
				},
				["self"] = {
					["ClassName"] = "model",
					["UniqueID"] = "3894885173",
					["Model"] = "models/pissedmeoff.mdl",
					["Size"] = 0.65,
					["Position"] = Vector(0.043670654296875, -6.3189086914063, -0.87332153320313),
					["Name"] = "cigarette",
					["Angles"] = Angle(19.313579559326, -86.569694519043, -1.8829755783081),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "234646324",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitModelOverload( Effect.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Effect.PacOutfit )

GM.PacModels:Register( "m04".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 5,
					["UniqueID"] = "3514151176",
					["StickToSurface"] = false,
					["Material"] = "particle/particle_smokegrenade1",
					["AirResistance"] = 30,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.93278503417969, -6.3522338867188, 0.0014572143554688),
					["Sliding"] = false,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["DieTime"] = 8,
					["FireDelay"] = 12,
					["ClassName"] = "particles",
					["Bounce"] = 0,
					["Gravity"] = Vector(0, 0, 2),
					["Name"] = "cig_smoke",
					["Angles"] = Angle(7.7266508014873e-005, -87.288673400879, -2.4972880055429e-005),
					["StartSize"] = 0,
					["RollDelta"] = -0.2,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "968541480",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "4226166498",
							["Name"] = "cherry",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["Material"] = "models/weapons/v_crossbow/rebar_glow",
							["Size"] = 0.07,
							["Position"] = Vector(1.5499999523163, 0, 0),
							["Angles"] = Angle(-90, 0, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "686013029",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.30000001192093),
							["Material"] = "models/props_wasteland/concretewall066a",
							["Size"] = 0.07,
							["Position"] = Vector(1.4700000286102, 0, 0),
							["Angles"] = Angle(-90, 0, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
				},
				["self"] = {
					["ClassName"] = "model",
					["UniqueID"] = "3894885173",
					["Model"] = "models/pissedmeoff.mdl",
					["Size"] = 0.65,
					["Position"] = Vector(1.2772369384766, -6.3361206054688, -0.9464111328125),
					["Name"] = "cigarette",
					["Angles"] = Angle(19.313579559326, -86.569694519043, -1.8829755783081),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "234646324",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitFaceIDOverload( Effect.PacOutfit, "male_04", "m04".. Effect.PacOutfit )

GM.PlayerEffects:Register( Effect )