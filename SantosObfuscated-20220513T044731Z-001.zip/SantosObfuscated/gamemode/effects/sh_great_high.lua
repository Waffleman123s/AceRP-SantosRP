--[[
	Name: sh_great_high.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Great High"
Effect.Icon48 = "santosrp/ae_icons/Great High 48x48.png"
Effect.Icon18 = "santosrp/ae_icons/Great High 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {
		["Health"] = 2,
	},
	Drains = {
		["Hunger"] = 3,
		["Move Speed"] = 3,
		["Smoker's Cough"] = 3,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		self:Cough( pPlayer )

		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] ~= self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, self.PacOutfit )
		end

		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:GreatHigh", -30, -60 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] == self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, "" )
		end

		pPlayer.m_intLastFX_GHighCough = nil
		pPlayer.m_intLastFX_GreatHighHealthRegen = nil
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:GreatHigh" )
	end
end

if SERVER then
	function Effect:Cough( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		pPlayer:EmitSound( "ambient/voices/cough".. math.random(1, 4)..".wav", 75, 95 )
		pPlayer:ViewPunch( Angle(math.random(6, 12), 0, 0) )
	end

	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_GHighCough or 0) then
			self:Cough( pPlayer )

			pPlayer.m_intLastFX_GHighCough = CurTime() +math.random( 45, 90 )
		end

		if CurTime() > (pPlayer.m_intLastFX_GreatHighHealthRegen or 0) then
			pPlayer:SetHealth( math.min(pPlayer:Health() +1, 100) )
			pPlayer.m_intLastFX_GreatHighHealthRegen = CurTime() +10
		end
	end

	function Effect:GamemodeEditNeedDecay( pPlayer, strNeedID, tblVal )
		if strNeedID ~= "Hunger" then return end
		tblVal[1] = tblVal[1] +15
	end
elseif CLIENT then
	function Effect:RenderScreenspaceEffects()
		DrawBloom(
			0.275,
			1.3,
			10,
			10,
			1,
			1.3,
			1,
			1,
			1
		)
		DrawToyTown( 2, ScrH() )
	end
end

Effect.PacOutfit = "drug_weed"
Effect.PacOutfitSlot = {
	Name = "int_drug_weed",
	Data = {
		Type = "GAMEMODE_INTERNAL_PAC_ONLY",
		Internal = true,
		KeepOnDeath = false,
		PacEnabled = true,
	},
}

GM.PlayerEffects:Register( Effect )