--[[
	Name: sh_vomit.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Vomiting"
Effect.Icon48 = "santosrp/ae_icons/Vomiting 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Vomiting 18x18.png"
Effect.MaxDuration = 30
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
		["Hunger"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Vomit", -100, -100 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Vomit" )
		pPlayer.m_intLastFX_Vomit = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_Vomit or 0) then
			self:MakePlayerVomit( pPlayer )
			pPlayer.m_intLastFX_Vomit = CurTime() +math.random( 4, 15 )
		end
	end

	local randomSounds = {
		Sound( "npc/zombie/zombie_pain1.wav" ),
		Sound( "npc/zombie/zombie_pain3.wav" ),
		Sound( "npc/barnacle/barnacle_die1.wav" ),
	}
	function Effect:MakePlayerVomit( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		local snd = table.Random( randomSounds )
		pPlayer:EmitSound( snd )

		GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Hunger", math.random(5, 15) )

		timer.Create( ("effect_vomit_%p"):format(pPlayer), 0.1, 10, function()
			if not IsValid( pPlayer ) or not pPlayer:Alive() then return end
			
			local effectData = EffectData()
			effectData:SetOrigin( pPlayer:GetShootPos() +(pPlayer:EyeAngles():Forward() *8) )
			effectData:SetNormal( pPlayer:GetAimVector() )
			util.Effect( "vomitSpray", effectData )
			pPlayer:ViewPunch( Angle(10, 0, 0) )
		end )
	end
elseif CLIENT then
	local drunkColor = {
		["$pp_colour_addr"] = 0,
		["$pp_colour_addg"] = 0,
		["$pp_colour_addb"] = 0,
		["$pp_colour_brightness"] = 0,
		["$pp_colour_contrast"] = 1,
		["$pp_colour_colour"] = 1,
		["$pp_colour_mulr"] = 0,
		["$pp_colour_mulg"] = 0,
		["$pp_colour_mulb"] = 0
	}

	function Effect:RenderScreenspaceEffects()
		--DrawColorModify( drunkColor )
		--DrawToyTown(  )
	end

	function Effect:GetMotionBlurValues( intW, intH, intForward, intRot )
		return intW, intH, intForward, intRot
	end
end

GM.PlayerEffects:Register( Effect )