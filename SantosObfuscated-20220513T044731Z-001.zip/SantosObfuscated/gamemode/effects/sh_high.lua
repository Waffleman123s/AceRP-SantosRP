--[[
	Name: sh_high.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "High"
Effect.Icon48 = "santosrp/ae_icons/High 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/High 18x18.png"
Effect.MaxDuration = 60 *10
Effect.EfForwardScale = 0.33
Effect.Effects = {
	Gains = {
		["Health"] = 1,
	},
	Drains = {
		["Hunger"] = 2,
		["Move Speed"] = 2,
		["Smoker's Cough"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )["Great High"]
	if data or intDuration > self.MaxDuration then
		if GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID] then
			GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
		end

		if not bNoAutoForward then
			if GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Great High", intDuration *self.EfForwardScale ) then
				return false, true
			end
		else
			return false, GAMEMODE.PlayerEffects:GetEffect( "Great High" ):CanGive( pPlayer, intDuration *self.EfForwardScale )
		end
		
		return false
	end

	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		if not bNoAutoForward then
			if GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Great High", ((data[2] -(CurTime() -data[1])) +intDuration) *self.EfForwardScale ) then
				GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
				return false, true
			end
		else
			return false, GAMEMODE.PlayerEffects:GetEffect( "Great High" ):CanGive( pPlayer, intDuration )
		end

		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		self:Cough( pPlayer )

		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] ~= self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, self.PacOutfit )
		end

		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:High", -20, -40 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] == self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, "" )
		end

		pPlayer.m_intLastFX_HighCough = nil
		pPlayer.m_intLastFX_HighHealthRegen = nil
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:High" )
	end
end

if SERVER then
	function Effect:Cough( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		pPlayer:EmitSound( "ambient/voices/cough".. math.random(1, 4)..".wav", 75, 95 )
		pPlayer:ViewPunch( Angle(math.random(6, 12), 0, 0) )
	end

	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_HighCough or 0) then
			self:Cough( pPlayer )

			pPlayer.m_intLastFX_HighCough = CurTime() +math.random( 45, 90 )
		end

		if CurTime() > (pPlayer.m_intLastFX_HighHealthRegen or 0) then
			pPlayer:SetHealth( math.min(pPlayer:Health() +1, 100) )
			pPlayer.m_intLastFX_HighHealthRegen = CurTime() +15
		end
	end

	function Effect:GamemodeEditNeedDecay( pPlayer, strNeedID, tblVal )
		if strNeedID ~= "Hunger" then return end
		tblVal[1] = tblVal[1] +10
	end
elseif CLIENT then
	function Effect:RenderScreenspaceEffects()
		DrawBloom(
			0.425,
			1.3,
			10,
			10,
			1,
			1.3,
			1,
			1,
			1
		)
		DrawToyTown( 1.5, ScrH() )
	end
end

Effect.PacOutfit = "drug_weed"
Effect.PacOutfitSlot = {
	Name = "int_drug_weed",
	Data = {
		Type = "GAMEMODE_INTERNAL_PAC_ONLY",
		Internal = true,
		KeepOnDeath = false,
		PacEnabled = true,
	},
}
GM.Inv:RegisterEquipSlot( Effect.PacOutfitSlot.Name, Effect.PacOutfitSlot.Data )

GM.PacModels:Register( Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 5,
					["UniqueID"] = "1447211353",
					["StickToSurface"] = false,
					["EndSize"] = 40,
					["Material"] = "particle/particle_smokegrenade1",
					["NumberParticles"] = 6,
					["AirResistance"] = 20,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.62043762207031, -6.2371215820313, 0.0017318725585938),
					["Sliding"] = false,
					["DieTime"] = 20,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["RandomRollSpeed"] = 0.1,
					["Bounce"] = 0,
					["ClassName"] = "particles",
					["FireDelay"] = 20,
					["Spread"] = 0.8,
					["Gravity"] = Vector(0, 0, 0.80000001192093),
					["Angles"] = Angle(9.3488211859949e-005, -84.328323364258, -2.4172466510208e-005),
					["StartSize"] = 0,
					["RollDelta"] = 0.2,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-90, -0.00044594760402106, 0.00046106442459859),
							["ClassName"] = "clip",
							["UniqueID"] = "2534860599",
							["Position"] = Vector(0.0009307861328125, -0.0106201171875, -0.82891845703125),
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "314179253",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2451388655",
							["Name"] = "cherry",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["ClassName"] = "model",
							["Size"] = 0.09,
							["Material"] = "models/weapons/v_crossbow/rebar_glow",
							["Position"] = Vector(0, 0, 0.0099999997764826),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["EditorExpand"] = true,
						},
					},
					[3] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "3577223228",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.30000001192093),
							["ClassName"] = "model",
							["Size"] = 0.1,
							["Material"] = "models/props_canal/rock_riverbed01a",
							["Position"] = Vector(0, 0, 0.10000000149012),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["EditorExpand"] = true,
						},
					},
				},
				["self"] = {
					["UniqueID"] = "1785750490",
					["Name"] = "blunt",
					["Scale"] = Vector(1, 1, 9.6999998092651),
					["EditorExpand"] = true,
					["Size"] = 0.1,
					["ClassName"] = "model",
					["Angles"] = Angle(0.85738605260849, 3.4882729053497, -107.416015625),
					["Position"] = Vector(1.0161743164063, -8.7052612304688, 1.4518127441406),
					["Model"] = "models/props_junk/PopCan01a.mdl",
					["Material"] = "models/props_pipes/GutterMetal01a",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "571262028",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )

GM.PacModels:Register( "female_".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 5,
					["UniqueID"] = "1447211353",
					["StickToSurface"] = false,
					["EndSize"] = 40,
					["Material"] = "particle/particle_smokegrenade1",
					["NumberParticles"] = 6,
					["AirResistance"] = 20,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(-0.20269775390625, -5.9537353515625, 0.00201416015625),
					["Sliding"] = false,
					["DieTime"] = 20,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["RandomRollSpeed"] = 0.1,
					["Bounce"] = 0,
					["ClassName"] = "particles",
					["FireDelay"] = 20,
					["Spread"] = 0.8,
					["Gravity"] = Vector(0, 0, 0.80000001192093),
					["Angles"] = Angle(7.8547178418376e-005, -92.67830657959, -4.6317221858772e-005),
					["StartSize"] = 0,
					["RollDelta"] = 0.2,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-90, -0.00044594760402106, 0.00046106442459859),
							["ClassName"] = "clip",
							["UniqueID"] = "2534860599",
							["Position"] = Vector(0.0009307861328125, -0.0106201171875, -0.82891845703125),
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "263057254",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2451388655",
							["Name"] = "cherry",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["ClassName"] = "model",
							["Size"] = 0.09,
							["Material"] = "models/weapons/v_crossbow/rebar_glow",
							["Position"] = Vector(0, 0, 0.0099999997764826),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["EditorExpand"] = true,
						},
					},
					[3] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "3577223228",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.30000001192093),
							["ClassName"] = "model",
							["Size"] = 0.1,
							["Material"] = "models/props_canal/rock_riverbed01a",
							["Position"] = Vector(0, 0, 0.10000000149012),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["EditorExpand"] = true,
						},
					},
				},
				["self"] = {
					["UniqueID"] = "1785750490",
					["Name"] = "blunt",
					["Scale"] = Vector(1, 1, 9.6999998092651),
					["EditorExpand"] = true,
					["Size"] = 0.1,
					["ClassName"] = "model",
					["Angles"] = Angle(0.85738265514374, 3.4882907867432, -111.07164001465),
					["Position"] = Vector(0.17916870117188, -8.2879028320313, 1.5643615722656),
					["Model"] = "models/props_junk/PopCan01a.mdl",
					["Material"] = "models/props_pipes/GutterMetal01a",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "788241134",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitModelOverload( Effect.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Effect.PacOutfit )

GM.PacModels:Register( "m04".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-90, -0.00044594760402106, 0.00046106442459859),
							["ClassName"] = "clip",
							["UniqueID"] = "2534860599",
							["Position"] = Vector(0.0009307861328125, -0.0106201171875, -0.82891845703125),
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "833359847",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2451388655",
							["Name"] = "cherry",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["ClassName"] = "model",
							["Size"] = 0.09,
							["Material"] = "models/weapons/v_crossbow/rebar_glow",
							["Position"] = Vector(0, 0, 0.0099999997764826),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["EditorExpand"] = true,
						},
					},
					[3] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "3577223228",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.30000001192093),
							["ClassName"] = "model",
							["Size"] = 0.1,
							["Material"] = "models/props_canal/rock_riverbed01a",
							["Position"] = Vector(0, 0, 0.10000000149012),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["EditorExpand"] = true,
						},
					},
				},
				["self"] = {
					["UniqueID"] = "1785750490",
					["Name"] = "blunt",
					["Scale"] = Vector(1, 1, 9.6999998092651),
					["EditorExpand"] = true,
					["Size"] = 0.1,
					["ClassName"] = "model",
					["Angles"] = Angle(0.857386469841, 3.4882705211639, -111.1372756958),
					["Position"] = Vector(1.4902954101563, -8.3141479492188, 1.6209411621094),
					["Model"] = "models/props_junk/PopCan01a.mdl",
					["Material"] = "models/props_pipes/GutterMetal01a",
				},
			},
			[2] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 5,
					["UniqueID"] = "1447211353",
					["StickToSurface"] = false,
					["EndSize"] = 40,
					["Material"] = "particle/particle_smokegrenade1",
					["NumberParticles"] = 6,
					["AirResistance"] = 20,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.62043762207031, -6.2371215820313, 0.0017318725585938),
					["Sliding"] = false,
					["DieTime"] = 20,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["RandomRollSpeed"] = 0.1,
					["Bounce"] = 0,
					["ClassName"] = "particles",
					["FireDelay"] = 20,
					["Spread"] = 0.8,
					["Gravity"] = Vector(0, 0, 0.80000001192093),
					["Angles"] = Angle(9.3488211859949e-005, -84.328323364258, -2.4172466510208e-005),
					["StartSize"] = 0,
					["RollDelta"] = 0.2,
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "571262028",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitFaceIDOverload( Effect.PacOutfit, "male_04", "m04".. Effect.PacOutfit )

GM.PlayerEffects:Register( Effect )