--[[
	Name: sh_broken_chest.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Broken Chest"
Effect.Icon48 = "santosrp/ae_icons/Broken Chest or Back 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Broken Chest or Back 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Bullet Accuracy"] = 1,
		["Carry Weight"] = 2,
		["Carry Volume"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

if SERVER then
	function Effect:GamemodeEditInventorySize( pPlayer, tblData )
		tblData[1] = tblData[1] -150
		tblData[2] = tblData[2] -150
	end

	function Effect:EntityFireBullets( pPlayer, tblBullet )
		--tblBullet.Dir = tblBullet.Dir +Vector( math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1) ) *0.025
		tblBullet.Spread = tblBullet.Spread +VectorRand() *0.25
		return true
	end
elseif CLIENT then
	function Effect:GamemodeEditInventorySize( tblData )
		tblData[1] = tblData[1] -150
		tblData[2] = tblData[2] -150
	end
end

GM.PlayerEffects:Register( Effect )