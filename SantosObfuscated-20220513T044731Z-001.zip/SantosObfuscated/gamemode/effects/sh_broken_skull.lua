--[[
	Name: sh_broken_skull.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Fractured Skull"
Effect.Icon48 = "santosrp/ae_icons/Broken Skull 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Broken Skull 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Bullet Accuracy"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		
	end
end

if SERVER then
	function Effect:EntityFireBullets( pPlayer, tblBullet )
		--tblBullet.Dir = tblBullet.Dir +Vector( math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1) ) *0.75
		tblBullet.Spread = tblBullet.Spread +VectorRand() *0.25
		return true
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )