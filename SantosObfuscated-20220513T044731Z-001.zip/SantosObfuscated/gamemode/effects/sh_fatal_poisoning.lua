--[[
	Name: sh_fatal_poisoning.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Fatal Poisoning"
Effect.Icon48 = "santosrp/ae_icons/Fatal Poisoning 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Fatal Poisoning 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 2,
		["Stamina"] = 3,
		["Health"] = 2,
		["Vomiting"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Fatal Poisoning", -40, -60 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Fatal Poisoning" )
		pPlayer.m_intLastFX_PoisoningHealthDecay = nil
		pPlayer.m_intLastFX_PoisonVomit = nil
	end
end

if SERVER then
	function Effect:GamemodeOnPlayerClearUncon( pPlayer )
		GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
	end
	
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, strNeedID, 2 )
		end
	end

	function Effect:LazyTick( pPlayer )
		if GAMEMODE.Jail:IsPlayerInJail( pPlayer ) or pPlayer:IsUncon() then return end
		if CurTime() > (pPlayer.m_intLastFX_PoisoningHealthDecay or 0) then
			pPlayer:SetHealth( math.max(pPlayer:Health() -2, 0) )
			pPlayer.m_intLastFX_PoisoningHealthDecay = CurTime() +2

			if pPlayer:Health() <= 0 then
				pPlayer:GoUncon()
			end
		end

		if CurTime() > (pPlayer.m_intLastFX_PoisonVomit or 0) then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Vomiting", math.random(8, 14), false, false, true )
			pPlayer.m_intLastFX_PoisonVomit = CurTime() +math.random( 18, 25 )
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )