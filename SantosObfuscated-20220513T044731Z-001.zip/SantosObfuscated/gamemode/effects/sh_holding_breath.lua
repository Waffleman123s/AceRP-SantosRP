--[[
	Name: sh_holding_breath.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Holding Breath"
Effect.Icon48 = "santosrp/ae_icons/Asphyxiated 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Asphyxiated 18x18.png"
Effect.MaxDuration = 30
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 2,
		["Stamina"] = 2,
	}
}

function Effect:Setup()
	if CLIENT then return end
	hook.Add( "GamemodeLazyTick", "WatchWaterLevel", function( pPlayer )
		if not IsValid( pPlayer ) then return end
		local level = pPlayer:WaterLevel()
		local last = pPlayer.m_intLastWaterLevel or 0

		if level ~= last then
			pPlayer.m_intLastWaterLevel = level
			hook.Call( "GamemodePlayerWaterLevelChanged", GAMEMODE, pPlayer, level, last )
		end
	end )

	hook.Add( "GamemodePlayerWaterLevelChanged", "WatchWaterLevel", function( pPlayer, intNewLevel, intLastLevel )
		if intNewLevel == 3 then
			if pPlayer:IsUncon() or GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )["Drowning"] then return end
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, Effect.ID, Effect.MaxDuration )
		else
			GAMEMODE.PlayerEffects:ClearEffect( pPlayer, Effect.ID )
		end
	end )
end

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Holding Breath", -30, -60 )
	else
		self.m_sndHeartbeat = CreateSound( pPlayer, "player/heartbeatloop.wav" )
		self.m_sndHeartbeat:PlayEx( 0.05, 80 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Holding Breath" )
		if (pPlayer.m_intLastWaterLevel or 0) == 3 then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Drowning", -1 )
		end
	else
		self.m_sndHeartbeat:Stop()
		self.m_sndHeartbeat = nil
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
		end
	end
elseif CLIENT then
	function Effect:Tick()
		local timeLeft = GAMEMODE.PlayerEffects:GetEffectDuration( self.ID )
		local scalar = math.Remap( timeLeft, 0, self.MaxDuration, 0, 1 )
		self.m_sndHeartbeat:ChangeVolume( Lerp(scalar, 0.5, 0.05), 0 )
	end
end

GM.PlayerEffects:Register( Effect )