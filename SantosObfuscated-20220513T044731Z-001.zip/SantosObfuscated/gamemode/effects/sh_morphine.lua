--[[
	Name: sh_morphine.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Sedation"
Effect.Icon48 = "santosrp/ae_icons/Exhausted 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Exhausted 18x18.png"
Effect.MaxDuration = 60 *5
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
		["Stamina"] = 3,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Sedation", -100, -100 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Sedation" )
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -15
		end
	end
elseif CLIENT then

	function Effect:RenderScreenspaceEffects()
		DrawToyTown( (math.sin(RealTime() *2) *10) +12, ScrH() *1, 1 )
		DrawMotionBlur( 0.4, 0.9, 0.05 )
	end

	--[[function Effect:GetMotionBlurValues( intW, intH, intForward, intRot )
		return intW, intH, intForward, intRot
	end]]--
end

GM.PlayerEffects:Register( Effect )