--[[
	Name: sh_intox.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Intoxication"
Effect.Icon48 = "santosrp/ae_icons/Intoxication 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Intoxication 18x18.png"
Effect.MaxDuration = 60 *10
Effect.EfForwardScale = 0.33
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )["Severe Intoxication"]
	if data or intDuration > self.MaxDuration then
		if GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID] then
			GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
		end

		if not bNoAutoForward then
			if GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Severe Intoxication", intDuration *self.EfForwardScale ) then
				return false, true
			end
		else
			return false, GAMEMODE.PlayerEffects:GetEffect( "Severe Intoxication" ):CanGive( pPlayer, intDuration *self.EfForwardScale )
		end
		
		return false
	end

	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		if not bNoAutoForward then
			if GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Severe Intoxication", ((data[2] -(CurTime() -data[1])) +intDuration) *self.EfForwardScale ) then
				GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
				return false, true
			end
		else
			return false, GAMEMODE.PlayerEffects:GetEffect( "Severe Intoxication" ):CanGive( pPlayer, ((data[2] -(CurTime() -data[1])) +intDuration) *self.EfForwardScale )
		end

		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Intox", -30, -60 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Intox" )
	end
end

function Effect:SetupMove( pPlayer, pMoveData, pUserCmd )
	if CLIENT and pPlayer ~= LocalPlayer() then return end
	if not pPlayer:InVehicle() then
		pMoveData:SetMoveAngles( pMoveData:GetMoveAngles() +Angle(
			0,
			math.sin( CurTime() *1.2 ) *16,
			0
		) )
	end
end

if SERVER then

elseif CLIENT then
	function Effect:RenderScreenspaceEffects()
		DrawToyTown( (math.sin(RealTime() *2) *4) +5, ScrH() *1, 1 )
		DrawMotionBlur( 0.4, 0.9, 0.02 )
	end

	--[[function Effect:GetMotionBlurValues( intW, intH, intForward, intRot )
		intRot = intRot +(math.sin( RealTime() *0.6 ) *0.033)
		return intW, intH, intForward, intRot
	end]]--

	function Effect:CreateMove( pUserCmd )
		if not LocalPlayer():InVehicle() then return end
		pUserCmd:SetSideMove( pUserCmd:GetSideMove() +(math.sin(CurTime() *4) *75) )
	end
end

GM.PlayerEffects:Register( Effect )