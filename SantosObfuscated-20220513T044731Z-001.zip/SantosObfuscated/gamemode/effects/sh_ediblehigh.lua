--[[
	Name: sh_ediblehigh.lua
	For: Project Steele
	By: <a>Turtle</a>
]]--

local Effect = {}
Effect.ID = "EdibleHigh"
Effect.Icon48 = "santosrp/ae_icons/High 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/High 18x18.png"
Effect.MaxDuration = 60 *10
Effect.EfForwardScale = 0.33
Effect.Effects = {
	Gains = {
		["Health"] = 2,
	},
	Drains = {
		["Hunger"] = 2,
		["Move Speed"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:High", -20, -40 )
		pPlayer:EmitSound( "santosrp/eating.mp3" )
	elseif CLIENT then
		RunConsoleCommand( "dsp_player", "4" )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_EdibleHighHealthRegen = nil
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:High" )
	elseif CLIENT then
		RunConsoleCommand( "dsp_player", "0" )
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_EdibleHighHealthRegen or 0) then
			pPlayer:SetHealth( math.min(pPlayer:Health() +1, 100) )
			pPlayer.m_intLastFX_EdibleHighHealthRegen = CurTime() +15
		end
	end

	function Effect:GamemodeEditNeedDecay( pPlayer, strNeedID, tblVal )
		if strNeedID ~= "Hunger" then return end
		tblVal[1] = tblVal[1] +10
	end
elseif CLIENT then
	function Effect:RenderScreenspaceEffects()
		DrawBloom(
			0.425,
			1.3,
			10,
			10,
			1,
			1.3,
			1,
			1,
			1
		)
		DrawToyTown( 1.5, ScrH() )
	end
end
GM.PlayerEffects:Register( Effect )