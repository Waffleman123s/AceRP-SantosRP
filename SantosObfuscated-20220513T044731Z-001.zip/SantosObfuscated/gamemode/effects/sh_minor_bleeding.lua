--[[
	Name: sh_minor_bleeding.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Minor Bleeding"
Effect.Icon48 = "santosrp/ae_icons/Minor Bleeding 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Minor Bleeding 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Health"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data and not GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )["Heavy Bleeding"]
end

function Effect:OnStart( pPlayer )
	if SERVER then
		pPlayer:AddNote( "You are bleeding!" )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_MinorBleeding = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if pPlayer:IsUncon() or not pPlayer:Alive() then return end
		if CurTime() > (pPlayer.m_intLastFX_MinorBleeding or 0) then
			pPlayer:SetHealth( math.max(pPlayer:Health() -1, 0) )
			pPlayer.m_intLastFX_MinorBleeding = CurTime() +6

			if pPlayer:Health() <= 0 then
				pPlayer:GoUncon()
			end
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )