--[[
	Property of acerp.gg ©2022
	By: Ultra
	Edited By: QuackDuck  (QuackDuck#6610)
	For: AceRP.gg 
]]--

GM.Buddy = {}

--Call to scan for broken buddy pairs against a player
function GM.Buddy:ValidateBuddyStatus( pPlayer, bSendUpdate )
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable or not saveTable.Buddies then return end

	local changed
	local id
	for k, v in pairs( player.GetAll() ) do
		id = v:GetCharacterID()
		if id then
			--They aren't friends with us anymore
			if saveTable.Buddies[id] and not self:IsPlayerBuddyWith( v:GetCharacterID(), pPlayer:GetCharacterID() ) then
				saveTable.Buddies[id] = nil
				changed = true
			end

			--We aren't friends with them anymore
			if self:IsPlayerBuddyWith( v:GetCharacterID(), pPlayer:GetCharacterID() ) and not saveTable.Buddies[id] then
				self:PlayerRemoveBuddy( v, pPlayer:GetCharacterID() )
			end
		end
	end

	if changed then
		if bSendUpdate then GAMEMODE.Net:SendFullBuddyUpdate( pPlayer ) end
		GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Buddies" )		
	end
end

function GM.Buddy:GetPlayerBuddyID( pPlayer, pOther )
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable or not saveTable.Buddies then return end

	local buddyID = pOther:GetCharacterID()
	if saveTable.Buddies[buddyID] then
		return buddyID
	end
end

function GM.Buddy:GetPlayerByBuddyID( intBuddyID )
	for k, v in pairs( player.GetAll() ) do
		if not v:GetCharacterID() then continue end
		if v:GetCharacterID() == tonumber( intBuddyID ) then
			return v
		end
	end
end

function GM.Buddy:GetPlayerBuddyData( pPlayer, intBuddyID, charID )
	if !charID then
		local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
		if not saveTable or not saveTable.Buddies then return end
		return saveTable.Buddies
	end
	if not _playerbuddyinfos[charID] then return end
	if not _playerbuddyinfos[charID][intBuddyID] then return end
	return _playerbuddyinfos[charID][intBuddyID]
end

function GM.Buddy:IsPlayerBuddyWith( iCharID, iOtherCharID )
	-- if not IsValid( pOther ) then return false end
	
	-- local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	-- if not saveTable or not saveTable.Buddies then return false end
	-- if not pOther:GetCharacterID() then return false end
	if IsEntity(iCharID) then
		iCharID = iCharID:GetCharacterID()
	end
	if IsEntity(iOtherCharID) then
		iOtherCharID = iOtherCharID:GetCharacterID()
	end

	-- return saveTable.Buddies[pOther:GetCharacterID()] or false
	-- print("owners charID: "..iCharID.." / users: "..iOtherCharID)
	if not _playerbuddyinfos[iCharID] then -- print("uhh my ass") 
		return end
	-- PrintTable(_playerbuddyinfos[iCharID])
	if not _playerbuddyinfos[iCharID][iOtherCharID] then -- print("so close.") 
		return end
	return _playerbuddyinfos[iCharID][iOtherCharID]
end

function GM.Buddy:IsCarShared( pPlayer, pOwner )
	if not self:IsPlayerBuddyWith( pOwner, pPlayer:GetCharacterID() ) then -- print("not buddies? :(") 
		return false end
	-- print("checking shared doors...")

	return self:GetPlayerBuddyData( pOwner, pPlayer:GetCharacterID(), pOwner:GetCharacterID() ).Settings.ShareCar
	-- return self:GetPlayerBuddyData( pOwner, pPlayer:GetCharacterID() ).Settings.ShareCar
end

function GM.Buddy:IsDoorShared( pPlayer, pOwner )
	if not self:IsPlayerBuddyWith( pOwner, pPlayer:GetCharacterID() ) then --print("not buddies? :(")
		return false end
	-- print("checking shared doors...")

	return self:GetPlayerBuddyData( pOwner, pPlayer:GetCharacterID(), pOwner ).Settings.ShareDoors
end

function GM.Buddy:IsItemShared( pPlayer, pOwner )
	if not self:IsPlayerBuddyWith( pOwner, pPlayer:GetCharacterID() ) then --print("not buddies? :(")
		return false end

	return self:GetPlayerBuddyData( pOwner, pPlayer:GetCharacterID(), pOwner:GetCharacterID() ).Settings.ShareItems


	-- return self:GetPlayerBuddyData( pOwner, pPlayer:GetCharacterID(), pOwner:GetCharacterID() ).Settings.ShareItems
end

function GM.Buddy:PlayerGrantAll( pPlayer, strKey, bGrant )
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable or not saveTable.Buddies then return end

	for k, v in pairs( saveTable.Buddies ) do
		v.Settings[strKey] = bGrant
	end

	GAMEMODE.Net:SendFullBuddyUpdate( pPlayer )
	GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Buddies" )
	local iCharID = pPlayer:GetCharacterID()
	if not _playerbuddyinfos[iCharID] then return end
	for k, v in pairs( _playerbuddyinfos[iCharID] ) do
		v.Settings[strKey] = bGrant
	end

end

function GM.Buddy:PlayerAddBuddy( pPlayer, intBuddyID )
	local otherPlayer = self:GetPlayerByBuddyID( intBuddyID )
	if not IsValid( otherPlayer ) then return end
	
	if pPlayer == otherPlayer or not IsValid( otherPlayer ) then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable or not otherPlayer:GetCharacterID() then return end

	saveTable.Buddies = saveTable.Buddies or {}
	if _playerbuddyinfos[pPlayer:GetCharacterID()] then
		_playerbuddyinfos[pPlayer:GetCharacterID()][intBuddyID] = {
			Settings = {
				ShareCar = false,
				ShareDoors = false,
				ShareItems = false,
			},
			LastName = otherPlayer:Nick()
		}
	end
	
	saveTable.Buddies[intBuddyID] = {
		Settings = {
			ShareCar = false,
			ShareDoors = false,
			ShareItems = false,
		},
		LastName = otherPlayer:Nick()
	}

	

	GAMEMODE.Net:SendBuddyUpdate( pPlayer, intBuddyID )
	GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Buddies" )
end

function GM.Buddy:PlayerRemoveBuddy( pPlayer, intBuddyID )
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable or not saveTable.Buddies then return end

	if saveTable.Buddies[intBuddyID] then
		saveTable.Buddies[intBuddyID] = nil
		GAMEMODE.Net:SendBuddyUpdate( pPlayer, intBuddyID )
		GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Buddies" )

		--Make them remove us now, if they are in the game
		local otherPlayer = self:GetPlayerByBuddyID( intBuddyID )
		if IsValid( otherPlayer ) then
			self:PlayerRemoveBuddy( otherPlayer, pPlayer:GetCharacterID() )
		end
		_playerbuddyinfos[pPlayer:GetCharacterID()][intBuddyID] = nil
	end
end

function GM.Buddy:PlayerUpdateBuddyKey( pPlayer, intBuddyID, strKey, vaValue )
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable or not saveTable.Buddies then return end
	if not saveTable.Buddies[intBuddyID] then return end
	if saveTable.Buddies[intBuddyID].Settings[strKey] == nil then return end
	if vaValue == nil then return end
	
	if _playerbuddyinfos[pPlayer:GetCharacterID()] then
		if _playerbuddyinfos[pPlayer:GetCharacterID()][intBuddyID] then
			_playerbuddyinfos[pPlayer:GetCharacterID()][intBuddyID].Settings[strKey] = vaValue
		end 
	end

	saveTable.Buddies[intBuddyID].Settings[strKey] = vaValue
	GAMEMODE.Net:SendBuddyUpdate( pPlayer, intBuddyID )
	GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Buddies" )
end

function GM.Buddy:PlayerHandshake( pPlayer, pTarget )
	if not pPlayer.m_tblBuddyBuffer then pPlayer.m_tblBuddyBuffer = {} end
	if (pPlayer.m_tblBuddyBuffer[pTarget] or 0) > CurTime() then return end
	if self:IsPlayerBuddyWith( pPlayer, pTarget ) then return end

	--Did they shake hands with us first?
	if pTarget.m_tblBuddyBuffer and pTarget.m_tblBuddyBuffer[pPlayer] then
		if CurTime() > pTarget.m_tblBuddyBuffer[pPlayer] then
			pTarget.m_tblBuddyBuffer[pPlayer] = nil
			return
		else
			--now buddies
			GAMEMODE.Util:PlayerEmitSound( pPlayer, "Hello" )
			pPlayer:AddNote( ("You are now buddies with %s!"):format(pTarget:Nick()) )
			pTarget:AddNote( ("You are now buddies with %s!"):format(pPlayer:Nick()) )
			pTarget.m_tblBuddyBuffer[pPlayer] = nil

			self:PlayerAddBuddy( pPlayer, pTarget:GetCharacterID() )
			self:PlayerAddBuddy( pTarget, pPlayer:GetCharacterID() )
			return
		end
	end

	pPlayer.m_tblBuddyBuffer[pTarget] = CurTime() +60
	GAMEMODE.Util:PlayerEmitSound( pPlayer, "Hello" )
	pTarget:AddNote( ("%s would like to be your buddy!"):format(pPlayer:Nick()) )
	pTarget:AddNote( "Confirm this by looking at the player and right clicking with your hands." )
end

hook.Add( "GamemodePlayerSelectCharacter", "SendBuddyData", function( pPlayer )
	GAMEMODE.Buddy:ValidateBuddyStatus( pPlayer, false )
	GAMEMODE.Net:SendFullBuddyUpdate( pPlayer )
end )