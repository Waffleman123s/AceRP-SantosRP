--[[
	Name: sv_characters.lua
	For: SantosRP
	By: Ultra
]]--

GM.Char = {}
GM.Char.SEX_MALE = 0
GM.Char.SEX_FEMALE = 1

function GM.Char:SendCharacterErrorMsg( pPlayer, strMsg )
	GAMEMODE.Net:SendCharacterErrorMsg( pPlayer, strMsg )
end

function GM.Char:GetMaxCharacters( pPlayer )
	local data = GAMEMODE.Player:GetPlayerVIPFlag( pPlayer, "extra_characters" )
	if data and data.Num then
		return GAMEMODE.Config.MaxCharacters +data.Num
	else
		return GAMEMODE.Config.MaxCharacters
	end
end

function GM.Char:NewCharacter()
	local newCharacter = {
		Name = { First = "", Last = "" },
		Model = { Base = "", Overload = nil },
		Sex = self.SEX_MALE,
		Skin = 0,
		Inventory = {},
		Equipped = {},
		Money = { Wallet = 0, Bank = 0 },
		Bodygroup = {},
		Vehicles = {},
		SaveTable = {},
	}
	return newCharacter
end

function GM.Char:GetPlayerCharacters( pPlayer )
	if not pPlayer:GetGamemodeData() then return end
	return pPlayer:GetGamemodeData().Characters
end

function GM.Char:GetPlayerCharacter( pPlayer )
	return self:GetPlayerCharacters( pPlayer )[pPlayer:GetCharacterID()]
end

function GM.Char:GetCharacterSaveTable( pPlayer, intCharID )
	if not self:GetPlayerCharacter( pPlayer ) then return; end;
	return pPlayer:GetGamemodeData().Characters[intCharID].SaveTable
end

function GM.Char:GetCurrentSaveTable( pPlayer )
	if not pPlayer:GetGamemodeData() then return end
	if not pPlayer:GetGamemodeData().SelectedCharacter then return end
	return self:GetCharacterSaveTable( pPlayer, pPlayer:GetCharacterID() )
end

--Note: for saving data tied to just the player, see Player:WriteCookie instead
function GM.Char:WriteCookie( pPlayer, intCharID, strKey, strValue )
	local tbl = self:GetCharacterSaveTable( pPlayer, intCharID )
	if not tbl then return end
	tbl.Cookies = tbl.Cookies or {}
	tbl.Cookies[strKey] = strValue
	GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Cookies" )
end

function GM.Char:GetCookie( pPlayer, intCharID, strKey )
	local tbl = self:GetCharacterSaveTable( pPlayer, intCharID )
	if not tbl or not tbl.Cookies then return end
	return tbl.Cookies[strKey]
end

function GM.Char:PlayerRequestCharacter( pPlayer, intCharID )
	if not pPlayer:GetGamemodeData() then return end
	if not pPlayer:GetPlayerSQLID() then return end
	if pPlayer.m_bInCharCreateQuery then return end
	if self:GetPlayerCharacter( pPlayer ) then return end
	if not self:GetPlayerCharacters( pPlayer )[intCharID] then return end

	if pPlayer.m_intLastCharDelTime and pPlayer.m_intLastCharDelTime > os.time() then
		local len = pPlayer.m_intLastCharDelTime -os.time()
		pPlayer:AddNote( ("You must wait %s before you may delete another character"):format(GAMEMODE.Util:FormatTime(len, true, true)) )
		return
	end

	pPlayer.m_intReqCharDelID = intCharID
	pPlayer.m_strCharDelAckCode = ("%d%d%d%d%d%d%d%d"):format(
		math.random(0, 9),
		math.random(0, 9),
		math.random(0, 9),
		math.random(0, 9),
		math.random(0, 9),
		math.random(0, 9),
		math.random(0, 9),
		math.random(0, 9)
	)

	GAMEMODE.Net:SendDelCharacterPrompt( pPlayer, intCharID, pPlayer.m_strCharDelAckCode )
end

function GM.Char:PlayerDeleteCharacter( pPlayer, strDelAckCode )
	if type(ststrDelAckCoder) == "string" and (not strDelAckCode or not pPlayer.m_strCharDelAckCode or pPlayer.m_strCharDelAckCode ~= strDelAckCode) then return end
	if not pPlayer:GetPlayerSQLID() then return end
	if not pPlayer.m_intReqCharDelID then return end
	if not pPlayer:GetGamemodeData() then return end
	if pPlayer.m_bInCharCreateQuery then return end
	if self:GetPlayerCharacter( pPlayer ) then return end
	if not self:GetPlayerCharacters( pPlayer )[pPlayer.m_intReqCharDelID] then return end

	hook.Call( "GamemodePlayerDeleteCharacter", GAMEMODE, pPlayer, pPlayer.m_intReqCharDelID )

	local id = GAMEMODE.SQL:GetPlayerPoolID(pPlayer:SteamID64()) or 1
	self:GetPlayerCharacters( pPlayer )[pPlayer.m_intReqCharDelID] = nil
	GAMEMODE.SQL:DeleteCharacter( id, pPlayer.m_intReqCharDelID )

	pPlayer.m_intLastCharDelTime = os.time() +GAMEMODE.Config.CharacterDeleteCooldown
	GAMEMODE.SQL:UpdatePlayerLastCharacterDelTime( id, pPlayer:GetPlayerSQLID(), pPlayer.m_intLastCharDelTime )

	pPlayer.m_intReqCharDelID = nil
	pPlayer.m_strCharDelAckCode = nil

	--Resend characters
	GAMEMODE.Net:SendPlayerCharacters( pPlayer )
end

function GM.Char:PlayerForceDeleteCharacter( pPlayer )
	print("Deleting Character");
	if not pPlayer:GetPlayerSQLID() then return false end
	print("Passed SQL ID");
	if not pPlayer:GetGamemodeData() then return false end
	print("Passed Gamemode Data");
	if pPlayer.m_bInCharCreateQuery then return false end
	print("Passed Char Create Query");
	if not self:GetPlayerCharacters( pPlayer )[pPlayer:GetCharacterID()] then return false end
	print("Passed Get Characters");

	print("Hook Call Deletion Character");
	hook.Call( "GamemodePlayerDeleteCharacter", GAMEMODE, pPlayer, pPlayer:GetCharacterID() )

	local id = GAMEMODE.SQL:GetPlayerPoolID(pPlayer:SteamID64()) or 1
	self:GetPlayerCharacters( pPlayer )[pPlayer:GetCharacterID()] = nil
	GAMEMODE.SQL:DeleteCharacter( id, pPlayer:GetCharacterID() )

	pPlayer.m_intLastCharDelTime = os.time() +GAMEMODE.Config.CharacterDeleteCooldown
	GAMEMODE.SQL:UpdatePlayerLastCharacterDelTime( id, pPlayer:GetPlayerSQLID(), pPlayer.m_intLastCharDelTime )

	pPlayer.m_intReqCharDelID = nil
	pPlayer.m_strCharDelAckCode = nil

	--Resend characters
	GAMEMODE.Net:SendPlayerCharacters( pPlayer )
	print("Deleted Character");
	return true;
end

function GM.Char:PlayerCreateCharacter( pPlayer, tblChar )
	if not pPlayer:GetGamemodeData() then return end
	if pPlayer.m_bInCharCreateQuery then return end
	if self:GetPlayerCharacter( pPlayer ) then return end
	
	--[[ Validate the name ]]--
	--Check for valid data
	if type( tblChar.Name.First ) ~= "string" or type( tblChar.Name.Last ) ~= "string" then
		self:SendCharacterErrorMsg( pPlayer, "You must enter a first and last name." )
		return
	end

	--Check for 0 length
	if tblChar.Name.First:len() == 0 or tblChar.Name.Last:len() == 0 then
		self:SendCharacterErrorMsg( pPlayer, "You must enter a first and last name." )
		return
	end

	--Check for lazy people
	if tblChar.Name.First:lower() == "john" and tblChar.Name.Last:lower() == "doe" then
		self:SendCharacterErrorMsg( pPlayer, "Stop being lazy and think of a better name!" )
		return		
	end

	--Check for numbers
	if tblChar.Name.First:match( "[0-9]" ) or tblChar.Name.Last:match( "[0-9]" ) then
		self:SendCharacterErrorMsg( pPlayer, "Your name may not have any numbers in it." )
		return
	end

	--Check for banned chars
	if tblChar.Name.First:match( "[./&><-]" ) or tblChar.Name.Last:match( "[./&><-]" ) then
		self:SendCharacterErrorMsg( pPlayer, "Your name may not have any of the following characters - ./&><-" )
		return
	end

	--Check for over max length
	if tblChar.Name.First:len() == GAMEMODE.Config.NameLength.First then
		self:SendCharacterErrorMsg( pPlayer, ("Your first name may not exceed %s characters."):format(GAMEMODE.Config.NameLength.First) )
		return
	end
	if tblChar.Name.Last:len() == GAMEMODE.Config.NameLength.Last then
		self:SendCharacterErrorMsg( pPlayer, ("Your last name may not exceed %s characters."):format(GAMEMODE.Config.NameLength.Last) )
		return
	end

	--[[ Validate the sex and model ]]--
	if tblChar.Sex ~= self.SEX_MALE and tblChar.Sex ~= self.SEX_FEMALE then
		self:SendCharacterErrorMsg( pPlayer, "Internal Error: Invalid sex." )
		return
	end

	local modelList = GAMEMODE.Config.PlayerModels[tblChar.Sex == self.SEX_MALE and "Male" or "Female"]
	if not modelList[tblChar.Model or ""] then
		self:SendCharacterErrorMsg( pPlayer, "Internal Error: Invalid model." )
		return
	end

	--[[ Validate the skin ]]--
	if not GAMEMODE.Util:ValidPlayerSkin( tblChar.Model, tblChar.Skin or 0 ) then
		self:SendCharacterErrorMsg( pPlayer, "Internal Error: Invalid skin." )
		return
	end

	--Check if this name is already taken, if not then create the character
	pPlayer.m_bInCharCreateQuery = true
	GAMEMODE.SQL:CheckCharacterNameTaken( tblChar.Name.First, tblChar.Name.Last, function( bNameTaken )
		if not IsValid( pPlayer ) then return end
		if bNameTaken then
			self:SendCharacterErrorMsg( pPlayer, "This name is already in use!" )
			pPlayer.m_bInCharCreateQuery = false
			return
		end

		--Create the new character data
		local newChar = self:NewCharacter()
		newChar.Name.First = tblChar.Name.First
		newChar.Name.Last = tblChar.Name.Last
		newChar.Sex = tblChar.Sex
		newChar.Model.Base = tblChar.Model
		newChar.Skin = tblChar.Skin
		newChar.Money = {
			Wallet = GAMEMODE.Config.StartingMoney.Wallet,
			Bank = GAMEMODE.Config.StartingMoney.Bank,
		}

		GAMEMODE.SQL:InsertNewCharacter( pPlayer, newChar, function( intCharID )
			if not IsValid( pPlayer ) then return end
			pPlayer.m_bInCharCreateQuery = false
			self:GetPlayerCharacters(pPlayer)[intCharID] = newChar
			hook.Call( "GamemodePlayerCreateCharacter", GAMEMODE, pPlayer, intCharID )
			self:PlayerSelectCharacter( pPlayer, intCharID )

			GAMEMODE.Util:NextTick( function()
				if not IsValid( pPlayer ) or pPlayer.m_intCachedCharacterID ~= intCharID then return end
				for k, v in pairs( GAMEMODE.Config.StartingItems ) do
					GAMEMODE.Inv:GivePlayerItem( pPlayer, k, v )
				end
				GAMEMODE.SQL:CommitPlayerDiffs( pPlayer:SteamID64() )
			end )
		end )
	end )
end

function GM.Char:PlayerSelectCharacter( pPlayer, intCharID )
	if not pPlayer:GetGamemodeData() then return end
	local selectedChar = self:GetPlayerCharacters( pPlayer )[intCharID]
	if not selectedChar then return end
	if self:GetPlayerCharacter( pPlayer ) then return end --Do not allow an already loaded character to switch

	pPlayer:GetGamemodeData().SelectedCharacter = intCharID
	pPlayer.m_intCachedCharacterID = intCharID
	GAMEMODE.SQL:ClearPlayerDiffTable( pPlayer:SteamID64() ) --Clear the sql diff table
	GAMEMODE.Jobs:SetPlayerJob( pPlayer, JOB_CIVILIAN, nil, true ) --Set them to the civ job

	if gspeak then
		gspeak:updateName( pPlayer, pPlayer:Nick() )
	end
	self:OnPlayerSelectCharacter( pPlayer, intCharID, selectedChar )

	pPlayer:KillSilent()
	pPlayer:Spawn()
end

function GM.Char:OnPlayerSelectCharacter( pPlayer, intCharID, tblChar )
	--Apply the new game vars for the selected character
	GAMEMODE.Player:SetGameVar( pPlayer, "money_wallet", tblChar.Money.Wallet, true )
	GAMEMODE.Player:SetGameVar( pPlayer, "money_bank", tblChar.Money.Bank, true )
	GAMEMODE.Player:SetGameVar( pPlayer, "char_skin", tblChar.Skin, true )
	GAMEMODE.Player:SetGameVar( pPlayer, "char_model_base", tblChar.Model.Base, true )
	GAMEMODE.Player:SetGameVar( pPlayer, "char_model_overload", tblChar.Model.Overload or "", true )
	GAMEMODE.Player:SetGameVar( pPlayer, "vehicles", tblChar.Vehicles, true )

	GAMEMODE.Player:SetSharedGameVar( pPlayer, "name_first", tblChar.Name.First, true )
	GAMEMODE.Player:SetSharedGameVar( pPlayer, "name_last", tblChar.Name.Last, true )
	GAMEMODE.Player:SetSharedGameVar( pPlayer, "char_id", intCharID, true )
	GAMEMODE.Player:SetSharedGameVar( pPlayer, "char_sex", tblChar.Sex, true )

	--Apply any saved equipment slots
	for slotName, data in pairs( GAMEMODE.Inv.m_tblEquipmentSlots ) do
		GAMEMODE.Player:SetSharedGameVar( pPlayer, "eq_slot_".. slotName, tblChar.Equipped[slotName] or "", true )
	end

	hook.Call( "GamemodePlayerSelectCharacter", GAMEMODE, pPlayer, intCharID, tblChar )

	--Let the player know we are loading all their stuff
	GAMEMODE.Net:SendPlayerLoadingCharacter( pPlayer )

	--Send all of this stuff on delays, maybe it will help with the spawn delay?
	local delayInterval = 1
	timer.Simple( delayInterval, function() --Send the players game vars
		if not IsValid( pPlayer ) then return end
		GAMEMODE.Net:SendFullGameVarUpdate( pPlayer )

		timer.Simple( delayInterval, function() --Send the players inventory
			if not IsValid( pPlayer ) then return end
			GAMEMODE.Net:SendFullInventoryUpdate( pPlayer )

			timer.Simple( delayInterval, function() --Send the players shared game vars
				if not IsValid( pPlayer ) then return end
				GAMEMODE.Net:SendFullSharedGameVarUpdate( pPlayer )

				timer.Simple( delayInterval, function() --Update the players in-game status
					if not IsValid( pPlayer ) then return end
					GAMEMODE.Net:SetPlayerInGame( pPlayer, true )
				end )
			end )
		end )
	end )

	--Send the new players game vars to everyone else
	GAMEMODE.Net:SendAllSharedGameVarUpdate( pPlayer )
end

hook.Add( "GamemodeDefineGameVars", "DefineCharacterVars", function( pPlayer )
	GAMEMODE.Player:DefineGameVar( pPlayer, "money_wallet", 0, "UInt32", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "money_bank", 0, "UInt32", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "char_skin", 0, "UInt8", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "char_model_base", "", "String", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "char_model_overload", "", "String", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "vehicles", {}, "Table", true )

	GAMEMODE.Player:DefineSharedGameVar( pPlayer, "name_first", "", "String", true )
	GAMEMODE.Player:DefineSharedGameVar( pPlayer, "name_last", "", "String", true )
	GAMEMODE.Player:DefineSharedGameVar( pPlayer, "char_id", 0, "UInt32", true )
	GAMEMODE.Player:DefineSharedGameVar( pPlayer, "char_sex", 0, "UInt4", true )
	GAMEMODE.Player:DefineSharedGameVar( pPlayer, "vip_group", "", "String", true )
	
	for slotName, data in pairs( GAMEMODE.Inv.m_tblEquipmentSlots ) do
		GAMEMODE.Player:DefineSharedGameVar( pPlayer, "eq_slot_".. slotName, "", "String", true )
	end

	GAMEMODE.Player:SetSharedGameVar( pPlayer, "vip_group", pPlayer:GetVIPGroup() or "" ) --This needs to be set before the character loading screen
end )