--[[
	Name: sv_entity.lua
	For: SantosRP
	By: Ultra
]]--

GM.Entity = {}
GM.Entity.m_tblRegister = {}
GM.Entity.m_tblWepRegister = {}
g_Edicts = g_Edicts or {}

function GM.Entity:InstallEdictWatchdog()
	g_EntsCreate = g_EntsCreate or ents.Create
	g_CurEntEdicts = g_CurEntEdicts or #ents.GetAll()
	ents.Create = function( strClassName, ... )
		if g_CurEntEdicts > GAMEMODE.Config.MaxEntityEdicts then
			GAMEMODE:LogDebug( "[WARNING][ERROR] Max entity edicts reached! Tried to create entity #".. (g_CurEntEdicts +1).. "! [".. strClassName.. "]\n" )
			return
		end

		local ent = g_EntsCreate( strClassName, ... )
		if ent then
			g_CurEntEdicts = g_CurEntEdicts +1
			g_Edicts[ent] = true
			return ent
		end
	end
end

function GM.Entity:EntityRemoved( eEnt )
	if g_Edicts[eEnt] then
		g_CurEntEdicts = g_CurEntEdicts -1
		g_Edicts[eEnt] = nil
	end
end

function GM.Entity:Dissolve( eEnt )
	if eEnt.m_bDissolving then return end
	if eEnt:IsPlayer() then return end
	eEnt.m_bDissolving = true

	local dissolver = ents.Create( "env_entity_dissolver" )
	if not dissolver then
		eEnt:Remove()
		return
	end

	dissolver:SetPos( eEnt:LocalToWorld(eEnt:OBBCenter()) )
	dissolver:SetKeyValue( "dissolvetype", 3 )
	dissolver:Spawn()
	dissolver:Activate()
	
	local name = "Dissolving_".. math.random()
	eEnt:SetName( name )
	dissolver:Fire( "Dissolve", name, 0 )
	dissolver:Fire( "Kill", eEnt, 0.10 )
end