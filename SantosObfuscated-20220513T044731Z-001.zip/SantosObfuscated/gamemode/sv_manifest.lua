--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--

GM.PRECOMPILED = false
if GM.PRECOMPILED then
	if not santosLib then require "santoslib" end
	if not santosLib then error( "Missing module! gmsv_santoslib_win32!" ) return end
	local lib = santosLib; _G.santosLib = {}
	function GM.loadChunk( strPath, intLen )
		local data = file.Read( strPath, "LUA" )
		if not data or data:len() <= 0 then return error( "invalid file to load! ".. strPath ) end
		return lib.LoadPrecompiledChunk( data, intLen or data:len() )()
	end

	function GM.loadString( strChunk, intLen )
		if not strChunk or strChunk:len() <= 0 then return error( "invalid string to load!" ) end
		return lib.LoadPrecompiledChunk( strChunk, intLen or strChunk:len() )()
	end

	function GM.LockLib()
		if lib then lib.Lock() lib = nil end
	end
end

local function loadFile( str )
	if GM.PRECOMPILED then
		GM.loadChunk( str:Replace(".lua", ".dat") )
	else
		include( str )
	end
end

AddCSLuaFile "santosrp/gamemode/cl_init.lua"
AddCSLuaFile "santosrp/gamemode/cl_manifest.lua"
AddCSLuaFile "santosrp/gamemode/cl_networking.lua"
AddCSLuaFile "santosrp/gamemode/cl_player.lua"
AddCSLuaFile "santosrp/gamemode/cl_player_damage.lua"
AddCSLuaFile "santosrp/gamemode/cl_characters.lua"
AddCSLuaFile "santosrp/gamemode/cl_inventory.lua"
AddCSLuaFile "santosrp/gamemode/cl_gui.lua"
AddCSLuaFile "santosrp/gamemode/cl_npcs.lua"
AddCSLuaFile "santosrp/gamemode/cl_properties.lua"
AddCSLuaFile "santosrp/gamemode/cl_calcview.lua"
AddCSLuaFile "santosrp/gamemode/cl_cinicam.lua"
AddCSLuaFile "santosrp/gamemode/cl_cars.lua"
AddCSLuaFile "santosrp/gamemode/cl_jobs.lua"
AddCSLuaFile "santosrp/gamemode/cl_jail.lua"
AddCSLuaFile "santosrp/gamemode/cl_map.lua"
AddCSLuaFile "santosrp/gamemode/cl_hud.lua"
AddCSLuaFile "santosrp/gamemode/cl_license.lua"
AddCSLuaFile "santosrp/gamemode/cl_skills.lua"
AddCSLuaFile "santosrp/gamemode/cl_player_effects.lua"
AddCSLuaFile "santosrp/gamemode/cl_needs.lua"
AddCSLuaFile "santosrp/gamemode/cl_buddies.lua"
AddCSLuaFile "santosrp/gamemode/cl_apps.lua"
AddCSLuaFile "santosrp/gamemode/cl_module.lua"
AddCSLuaFile "santosrp/gamemode/cl_plasticsurgeon.lua"
-- AddCSLuaFile "santosrp/gamemode/cl_voice.lua"
-- AddCSLuaFile "santosrp/gamemode/cl_images.lua"


AddCSLuaFile "santosrp/gamemode/sh_config.lua"
AddCSLuaFile "santosrp/gamemode/sh_init.lua"
AddCSLuaFile "santosrp/gamemode/sh_propprotect.lua"
AddCSLuaFile "santosrp/gamemode/sh_economy.lua"
AddCSLuaFile "santosrp/gamemode/sh_npcdialog.lua"
AddCSLuaFile "santosrp/gamemode/sh_util.lua"
AddCSLuaFile "santosrp/gamemode/sh_unconscious.lua"
AddCSLuaFile "santosrp/gamemode/sh_santos_customs.lua"
AddCSLuaFile "santosrp/gamemode/sh_pacmodels.lua"
AddCSLuaFile "santosrp/gamemode/sh_chat.lua"
AddCSLuaFile "santosrp/gamemode/sh_player_anims.lua"

include "santosrp/gamemode/sh_config.lua"
include "santosrp/gamemode/sh_util.lua"
include "santosrp/gamemode/sh_propprotect.lua"
include "santosrp/gamemode/sh_economy.lua"
include "santosrp/gamemode/sh_npcdialog.lua"
include "santosrp/gamemode/sh_unconscious.lua"
include "santosrp/gamemode/sh_santos_customs.lua"
include "santosrp/gamemode/sh_pacmodels.lua"
include "santosrp/gamemode/sh_chat.lua"
include "santosrp/gamemode/sh_player_anims.lua"

include "santosrp/gamemode/sv_config.lua"
loadFile "santosrp/gamemode/sv_networking.lua"
loadFile "santosrp/gamemode/sv_servernet.lua"
loadFile "santosrp/gamemode/sv_player.lua"
loadFile "santosrp/gamemode/sv_entity.lua"
loadFile "santosrp/gamemode/sv_player_damage.lua"
loadFile "santosrp/gamemode/sv_entity_damage.lua"
loadFile "santosrp/gamemode/sv_characters.lua"
loadFile "santosrp/gamemode/sv_jobs.lua"
loadFile "santosrp/gamemode/sv_economy.lua"
loadFile "santosrp/gamemode/sv_inventory.lua"
loadFile "santosrp/gamemode/sv_npcs.lua"
loadFile "santosrp/gamemode/sv_properties.lua"
loadFile "santosrp/gamemode/sv_cars.lua"
loadFile "santosrp/gamemode/sv_map.lua"
loadFile "santosrp/gamemode/sv_jail.lua"
loadFile "santosrp/gamemode/sv_license.lua"
loadFile "santosrp/gamemode/sv_mysql.lua"
loadFile "santosrp/gamemode/sv_mysql_player.lua"
loadFile "santosrp/gamemode/sv_bailout.lua"
loadFile "santosrp/gamemode/sv_bank_storage.lua"
loadFile "santosrp/gamemode/sv_phone.lua"
loadFile "santosrp/gamemode/sv_santos_customs.lua"
loadFile "santosrp/gamemode/sv_skills.lua"
loadFile "santosrp/gamemode/sv_player_effects.lua"
loadFile "santosrp/gamemode/sv_needs.lua"
loadFile "santosrp/gamemode/sv_buddies.lua"
loadFile "santosrp/gamemode/sv_apps.lua"
loadFile "santosrp/gamemode/sv_module.lua"
loadFile "santosrp/gamemode/sv_plasticsurgeon.lua"
loadFile "santosrp/gamemode/sv_chop_shop.lua"
-- loadFile "santosrp/gamemode/sv_voice.lua"

-- loadFile "sv_pvs_buffer.lua"


--Load vgui
local foundFiles, foundFolders = file.Find( GM.Config.GAMEMODE_PATH.. "vgui/*.lua", "LUA" )
for k, v in pairs( foundFiles ) do
	AddCSLuaFile( GM.Config.GAMEMODE_PATH.. "vgui/".. v )
end


if PRIVATE_SERVER then
	resource.AddWorkshop( "533494097" ) -- gspeak
end

-- Main Contents
resource.AddWorkshop( '2405304084' ) -- VG1
resource.AddWorkshop( '2405290015' ) -- VG2
resource.AddWorkshop( '2405300895' ) -- VG3
resource.AddWorkshop( '2408150447' ) -- VG5
resource.AddWorkshop( '2491461764' ) -- VG6
resource.AddWorkshop( '2780453110' ) -- VG7
resource.AddWorkshop( '2220268768' ) --dass

print("[SRPGG] Contents added to client FastDL.")

resource.AddWorkshop( '419088923' ) -- 1994 Nissan 180SX
resource.AddWorkshop( '343729375' ) -- [LW] Ford F350 Ambulance
resource.AddWorkshop( '218869210' ) -- SGM Shared Textures
resource.AddWorkshop( '908141123' ) -- CrSk Autos - Nissan 370Z Nismo Z34 2016
resource.AddWorkshop( '935754808' ) -- CrSk Shared Textures
resource.AddWorkshop( '349050451' ) -- Customizable Weaponry 2.0
resource.AddWorkshop( '358608166' ) -- Extra Customizable Weaponry 2.0
resource.AddWorkshop( '473082505' ) -- [CW 2.0] Thompson 1928A1 WW2
resource.AddWorkshop( '591075724' ) -- [CW 2.0] Mosin Nagant
resource.AddWorkshop( '717188718' ) -- [CW 2.0] Glock 17
resource.AddWorkshop( '886451400' ) -- [CW 2.0] Khris' Shared Content
resource.AddWorkshop( '359830105' ) -- Unofficial Extra Customizable Weaponry 2.0
resource.AddWorkshop( '719660218' ) -- [CW 2.0] M4A1 Carbine
resource.AddWorkshop( '354842171' ) -- [CW2] KK HK416 (2016)
resource.AddWorkshop( '1132466603' ) -- StormFox - Environment mod
resource.AddWorkshop( '1195774784' ) -- (Ready Or Not) Swat Operator PM/Ragdoll
resource.AddWorkshop( '1869061697' ) -- [MLW Autos] 2012 Porsche 911 GT2 RS
resource.AddWorkshop( '1871539732' ) -- [MLW Autos] BMW M3 GTR 2002
resource.AddWorkshop( '266579667' ) -- [LW] Shared Textures
resource.AddWorkshop( '258999371' ) -- [LW] Chevrolet Suburban/Tahoe Pack
resource.AddWorkshop( '390056021' ) -- [LW] 2015 Dodge Charger RT
resource.AddWorkshop( '263574779' ) -- [LW] Chevrolet Impala Package
resource.AddWorkshop( '379100546' ) -- [LW] Dodge Ram 1500 Outdoorsman
resource.AddWorkshop( '2390529107' ) -- [CrSk] Nissan Fairlady Z Devil Z +simfphys
resource.AddWorkshop( '1718735412' ) -- Vampire the Masquerade Bloodlines - Civilian Models
resource.AddWorkshop( '487748977' ) -- turrys turbochurged wheelchur
resource.AddWorkshop( '172564799' ) -- Nissan 240SX
resource.AddWorkshop( '1541253539' ) -- MSCars - Shared Content
resource.AddWorkshop( '151171713' ) -- LoneWolfies Police (and stuff) Package
resource.AddWorkshop( '1250923355' ) -- CrSk Motorcycles - Jawa 350/634 1978 [BETA]
resource.AddWorkshop( '1108778572' ) -- CrSk Autos - Toyota Land Cruiser 200 '13
resource.AddWorkshop( '921286020' ) -- CrSk Autos - Subaru WRX STI 2015
resource.AddWorkshop( '867658522' ) -- CrSk Autos - Rolls-Royce Silver Spirit Mk III 1993
resource.AddWorkshop( '889189074' ) -- CrSk Autos - Rolls-Royce Silver Cloud III 1963
resource.AddWorkshop( '1130199748' ) -- CrSk Autos - Rolls-Royce Dawn 2016
resource.AddWorkshop( '1122521573' ) -- CrSk Autos - Nissan Skyline R32 GT-R Custom
resource.AddWorkshop( '1648865906' ) -- CrSk Autos - Porsche 911 (993) GT2 '95
resource.AddWorkshop( '871302676' ) -- CrSk Autos - Mitsubishi Galant VR-4 E39A 1987
resource.AddWorkshop( '882169017' ) -- CrSk Autos - Mercedes-Benz E 500 (W124) '94
resource.AddWorkshop( '1610803203' ) -- CrSk Autos - Mercedes-AMG G 63 '19
resource.AddWorkshop( '1280737529' ) -- CrSk Autos - Maserati Alfieri Concept 2014
resource.AddWorkshop( '1398767926' ) -- CrSk Autos - Land Rover Series IIa Station Wagon 1967
resource.AddWorkshop( '1082017009' ) -- CrSk Autos - Honda Prelude SN 1980
resource.AddWorkshop( '954212428' ) -- CrSk Autos - Honda NSX '17
resource.AddWorkshop( '1700580773' ) -- CrSk Autos - Ford Mustang '18 (GT/RTR)
resource.AddWorkshop( '1233767854' ) -- CrSk Autos - Honda Integra DC2 Type R 1998
resource.AddWorkshop( '1633093318' ) -- CrSk Autos - Ford Crown Victoria LX '94
resource.AddWorkshop( '1244002460' ) -- CrSk Autos - Ford Bronco 1982 Pack (Regular/police)
resource.AddWorkshop( '1193706065' ) -- CrSk Autos - Ferrari 812 Superfast 2017
resource.AddWorkshop( '943999362' ) -- CrSk Autos - Dodge Challenger SRT Hellcat 2015
resource.AddWorkshop( '1603545638' ) -- CrSk Autos - Chrysler 300 Hurst Edition '70
resource.AddWorkshop( '1256100440' ) -- CrSk Autos - Chevrolet Corvette C1 1957
resource.AddWorkshop( '890978176' ) -- CrSk Autos - BMW i8 2015
resource.AddWorkshop( '903738342' ) -- CrSk Autos - Aston Martin DB11 2017
resource.AddWorkshop( '207383773' ) -- Caisson Elementary C
resource.AddWorkshop( '1565789469' ) -- Azok30 Shared Textures
resource.AddWorkshop( '1659975424' ) -- Azok30 - YAMAHA TMAX 530 2018 [Lil Bape]
resource.AddWorkshop( '1652952973' ) -- Azok30 - KTM 690 SMC R 2017 & 2019 [Lil Bape]
resource.AddWorkshop( '1911094926' ) -- 2020 Ford Police Interceptor Utility
resource.AddWorkshop( '489369053' ) -- 1986 Chevrolet Silverado/Gmc Sierra
resource.AddWorkshop( '198943240' ) -- 1985 Toyota Sprinter Trueno
resource.AddWorkshop( '139149628' ) -- 1970 Chevrolet El Camino SS 454
resource.AddWorkshop( '207758856' ) -- 1980s Recreational Vehicle
resource.AddWorkshop( '388947812' ) -- 1964 Chevrolet Impala SS
resource.AddWorkshop( '825409735' ) -- 2017 Nissan GT-R Nismo
resource.AddWorkshop( '930216475' ) -- 2016 Tesla Model S P90D
resource.AddWorkshop( '889843691' ) -- 2016 Chevrolet Silverado 2500 HD
resource.AddWorkshop( '658478551' ) -- 2015 Mercedes-Benz AMG GT
resource.AddWorkshop( '187723581' ) -- 2013 Ford Explorer
resource.AddWorkshop( '198738919' ) -- 2010 Ford Taurus SHO
resource.AddWorkshop( '1754694971' ) -- 2019 Tesla Model 3
resource.AddWorkshop( '204078855' ) -- 2009 Dodge Grand Caravan
resource.AddWorkshop( '418587732' ) -- 1996 Chevrolet Corvette Grand Sport
resource.AddWorkshop( '1605989105' ) -- Message Board - Simple Roleplay Addition
resource.AddWorkshop( '2304089398' ) -- Realistic Radio - The Most Advanced Radio System
resource.AddWorkshop( '691812012' ) -- Fallout 76 - Workstation Props
resource.AddWorkshop( '1444105144' ) -- Insurgency Impact FX
resource.AddWorkshop( '1525218777' ) -- vFire - Dynamic Fire for Garry's Mod
resource.AddWorkshop( '754071086' ) -- GTA V Firetruck
resource.AddWorkshop( '755229772' ) -- The Female Police
resource.AddWorkshop( '1433492471' ) -- [CTVehicles] 1994 Dodge Ram 2500
resource.AddWorkshop( '2340248439' ) -- [CTVehicles] Chevrolet Colorado ZR2 (+simfphys)
resource.AddWorkshop( '1348270094' ) -- [CTVehicles] Shared Textures
resource.AddWorkshop( '357350543' ) -- PAYDAY2 Loot & Body Bag Ragdolls
resource.AddWorkshop( '148215278' ) -- GMod Tower: Accessories Pack
resource.AddWorkshop( '2496119217' ) -- Ford-350-Riverden-Hospital
resource.AddWorkshop( '1558590071' ) -- Prisoner Jumpsuit (Playermodels)
resource.AddWorkshop( '394277409' ) -- SligWolf's Garbage Truck
resource.AddWorkshop( '2152878058' ) -- Civilian Pack: Real Fashion
resource.AddWorkshop( '1649131424' ) -- Civilian Pack 1: Urban Fashion
resource.AddWorkshop( '1962766895' ) -- Civilian Pack 2: Everyday Casual - Females
resource.AddWorkshop( '654706619' ) -- Shared textures for cars
resource.AddWorkshop( '655347908' ) -- 2013 Ford Focus ST
resource.AddWorkshop( '1103964943' ) -- [SKY] 1997 Nissan Sentra
resource.AddWorkshop( '1484166977' ) -- [DK] Toyota Corolla (E120) 2001
resource.AddWorkshop( '2247645672' ) -- Pills model pack
resource.AddWorkshop( '108024198' ) -- Food and Household items
resource.AddWorkshop( '2441211404' ) -- Police Shield - Content
resource.AddWorkshop( '282958377' ) -- Animal masks from PAYDAY 2
resource.AddWorkshop( '2174343063' ) -- Surgical Mask | Cerrahi Maske
resource.AddWorkshop( '104607228' ) -- Fire Extinguisher
resource.AddWorkshop( '2485178558' ) -- APhone
resource.AddWorkshop( '1881266226' ) -- Escape From Tarkov - Backpack Models (Ragdolls)
resource.AddWorkshop( '1810745063' ) -- Escape From Tarkov - Body Armour Models (Ragdolls)
resource.AddWorkshop( '783530452' ) -- Rust Backpack (Prop)
resource.AddWorkshop( '898975958' ) -- BMW M3 E46 GTR
resource.AddWorkshop( '2751919419' ) -- Peterbilt Trailers Edited Collison Heights

resource.AddWorkshop( '1174019751' ) -- Blue's Slots - Double Or Nothing Content
resource.AddWorkshop( '843596994' ) -- Blue's Slots - Content
resource.AddWorkshop( '1214133562' ) -- Casino Kit: Slots (Server Content) (Models Only)
resource.AddWorkshop( '2461796697' ) -- [PM-Ragdoll] Roro Police Pack
resource.AddWorkshop( '2086174798' ) -- Talk Modes - whisper/talk/yell - Content
resource.AddWorkshop( '748590370' ) -- [Skylar Automotive] Shared Textures
resource.AddWorkshop( '220336312' ) -- PermaProps
resource.AddWorkshop( '1327063206' ) -- 2010 Ford CVPI [P7B]
resource.AddWorkshop( '1595332211' ) -- GmodAdminSuite
resource.AddWorkshop( '373224120' ) -- 2002 Nissan MINES Skyline R34
resource.AddWorkshop( '1962770123' ) -- Civilian Pack 2: Everyday Casual - Males (Playermodels)
resource.AddWorkshop( '669642096' ) -- Drones Rewrite
resource.AddWorkshop( '603576261' ) -- Photon | GTA V Utility Truck
resource.AddWorkshop( '489864412' ) -- TDM's Prop Pack
resource.AddWorkshop( '323285641' ) -- GTA V Drivable Vehicles for Garry's Mod
resource.AddWorkshop( '732127148' ) -- 1998 Ford Crown Victoria P71
resource.AddWorkshop( '1819166858' ) -- Ballistic Shields [Workshop Content]
resource.AddWorkshop( '622810630' ) -- RP Rockford v2 (Map File Only)
resource.AddWorkshop( '328735857' ) -- RP Rockford (Models/Materials Only)
resource.AddWorkshop( '2782265858' ) -- DSteps: Dynamic Footsteps
resource.AddWorkshop( '1847505933' ) -- Draconic Base
resource.AddWorkshop( '2419834360' ) -- Contextual Player Animations
resource.AddWorkshop( '2558917151' ) -- Dynamic Flashlight *UPDATED*
resource.AddWorkshop( '2155366756' ) -- VManip (Base)
resource.AddWorkshop( '2155841271' ) -- [VManip] Contextual Animations
resource.AddWorkshop( '2156004721' ) -- [VManip] Manual Pickup


-- resource.AddWorkshop( "685130934" ) --ServerGuard
--[[ Dated shit ]]--
-- --Maze Client Content
-- resource.AddWorkshop "962934000"
-- resource.AddWorkshop "962935950"
-- resource.AddWorkshop "962963170"
-- resource.AddWorkshop "962938207"
-- resource.AddWorkshop "962942403"
-- resource.AddWorkshop "962946177"
-- resource.AddWorkshop "962949398"
-- resource.AddWorkshop "962953357"
-- resource.AddWorkshop "962954993"
-- resource.AddWorkshop "962955729"
-- resource.AddWorkshop "962956711"
-- resource.AddWorkshop "962958714"
-- resource.AddWorkshop "962960279"
-- resource.AddWorkshop "962961320"
-- game.AddParticles "particles/srp_01.pcf"
-- resource.AddWorkshop( "802923282" ) -- 2017 Ford F-150 Raptor
-- resource.AddWorkshop( "412149725" ) -- suits and robbers
-- resource.AddWorkshop( "144641310" ) -- secret service suits
-- resource.AddWorkshop( "640534796" ) -- Girl Police{ Playermodels } beta
-- resource.AddWorkshop( "632470227" ) -- vcmod
-- resource.AddWorkshop( "313279727" ) -- polciebadge
-- resource.AddWorkshop( "608313093" ) -- polcie npc
-- resource.AddWorkshop( "607528442" ) -- medic npc
-- resource.AddWorkshop( "607745024" ) -- Firefighter npc
-- resource.AddWorkshop( "130227747" ) -- bus
-- resource.AddWorkshop( "403451691" ) -- tow truck
-- resource.AddWorkshop( "314312925" ) -- Hand cuffs
-- resource.AddWorkshop( "450304784" ) -- defib
-- resource.AddWorkshop( "266579667" ) -- lw shared textures
-- resource.AddWorkshop( "280384240" ) -- faces
-- resource.AddWorkshop( "582856674" ) -- f150 shared
-- resource.AddWorkshop( "218869210" ) -- sgm shared
-- resource.AddWorkshop( "468739142" ) -- fireman
-- resource.AddWorkshop( "163597346" ) -- flaslight texture
-- resource.AddWorkshop( "107901100" ) -- water texture
-- resource.AddWorkshop( "482659412" ) -- drugs
-- resource.AddWorkshop( "320396634" ) -- lambo
-- resource.AddWorkshop( "229560848" ) -- Combine Coffee
-- resource.AddWorkshop( "394277409" ) -- Garbage truck
-- resource.AddWorkshop( "247188645" ) -- [LW] Mercedes-Benz Sprinter Pack