--[[
	Name: towtruck.lua
	For: SantosRP
	By: Ultra
]]
--
local Job = {}
Job.ID = 6
Job.Enum = "JOB_TOW"
Job.TeamColor = Color(255, 100, 160, 255)
Job.Name = "Tow Truck Driver"

Job.PlayerCap = GM.Config.Job_Tow_PlayerCap or {
	Min = 2,
	MinStart = 8,
	Max = 6,
	MaxEnd = 60
}

Job.ParkingLotPos = GM.Config.TowParkingZone
Job.TruckSpawns = GM.Config.TowCarSpawns
Job.TruckID = "tow_truck"
Job.FlatbedID = "tow_flatbed"

if PUBLIC_SERVER then
	Job.Pay = {
		{
			PlayTime = 0,
			Pay = 35
		},
		{
			PlayTime = 4 * (60 * 60),
			Pay = 40
		},
		{
			PlayTime = 12 * (60 * 60),
			Pay = 45
		},
		{
			PlayTime = 24 * (60 * 60),
			Pay = 50
		},
		{
			PlayTime = (24 * (60 * 60)) * 2,
			Pay = 75
		},
		{
			PlayTime = (24 * (60 * 60)) * 7,
			Pay = 90
		}
	}
else
	Job.Pay = {
		{
			PlayTime = 0,
			Pay = 35
		},
		{
			PlayTime = 4 * (60 * 60),
			Pay = 40
		},
		{
			PlayTime = 12 * (60 * 60),
			Pay = 45
		},
		{
			PlayTime = 24 * (60 * 60),
			Pay = 50
		},
		{
			PlayTime = (24 * (60 * 60)) * 2,
			Pay = 75
		},
		{
			PlayTime = (24 * (60 * 60)) * 7,
			Pay = 90
		}
	}
end

if not PRIVATE_SERVER then
	hook.Add("Initialize", "GamemodeInitJob_Tow", function()
		GAMEMODE.Module:GetModule("Chat Radios"):RegisterChannel(7, "Tow Services", false)
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 7
		Job.ChannelKeys = {}
	end)
end

function Job:OnPlayerJoinJob(pPlayer)
	local data = {}

	for k, v in pairs(player.GetAll()) do
		local car = GAMEMODE.Cars:GetCurrentPlayerCar(v)
		if not IsValid(car) or not car:GetNWBool("Impound") then continue end
		data[#data + 1] = ("%s %s\nPlate #:%s"):format(car.CarData.Make, car.CarData.Name, car:GetNWString("plate_serial", ""))
	end

	if #data <= 0 then return end
	GAMEMODE.Net:SendTextMessage(pPlayer, "Tow Dispatch", "There are currently vehicles wanted for impound!\n" .. table.concat(data, "\n"))
	pPlayer:EmitSound("santosrp/sms.mp3")
end

function Job:OnPlayerQuitJob(pPlayer)
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer)

	if curCar and curCar.Job and curCar.Job == JOB_TOW then
		curCar:Remove()
	end
end

function Job:PlayerLoadout(pPlayer)
	pPlayer:Give("weapon_vehicle_welder")
end

function Job:OnPlayerSpawnFlatbed(pPlayer, entCar)
	if not IsValid(pPlayer) or not IsValid(entCar) then return end
	local vecOffset = Vector(0.5, -2.197299, 1)
	local angOffset = Angle(0, 0, 0)
	local bed = ents.Create("ent_towtruck_bed")
	bed:SetPos(entCar:LocalToWorld(vecOffset))
	bed:SetAngles(entCar:LocalToWorldAngles(angOffset))
	bed:SetOwner(entCar)
	bed:Spawn()
	bed:Activate()
	bed:SetTruck(entCar, vecOffset, angOffset)
	bed:GetPhysicsObject():Wake()
	bed.AdminPhysGun = true
	local btnLock = ents.Create("ent_button")
	btnLock:SetModel("models/maxofs2d/button_05.mdl")
	btnLock:SetPos(entCar:LocalToWorld(Vector(-43.819336, -32.144527, 47.464691)))
	btnLock:SetAngles(entCar:LocalToWorldAngles(Angle(0, -90, 90)))
	btnLock:SetOwner(entCar)
	btnLock:Spawn()
	btnLock:Activate()
	btnLock:SetParent(entCar)
	btnLock:SetModelScale(0.5)
	btnLock.BlockPhysGun = true

	btnLock:SetCanUseCallback(function(entBtn, pPlayer)
		if IsValid(entCar) and IsValid(entCar:GetDriver()) then return end

		return GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_TOW
	end)

	bed:SetBedLockButton(btnLock)
	local btnBack = ents.Create("ent_button")
	btnBack:SetModel("models/maxofs2d/button_06.mdl")
	btnBack:SetIsToggle(false)
	btnBack:SetPos(entCar:LocalToWorld(Vector(-44.391602, -40.890621, 47.378601)))
	btnBack:SetAngles(entCar:LocalToWorldAngles(Angle(-90, 0, 0)))
	btnBack:SetOwner(entCar)
	btnBack:Spawn()
	btnBack:Activate()
	btnBack:SetParent(entCar)
	btnBack:SetModelScale(0.25)
	btnBack.BlockPhysGun = true

	btnBack:SetCanUseCallback(function(entBtn, pPlayer)
		if IsValid(entCar) and IsValid(entCar:GetDriver()) then return end

		return GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_TOW
	end)

	bed:SetTranslateBackButton(btnBack)
	local btnForward = ents.Create("ent_button")
	btnForward:SetModel("models/maxofs2d/button_06.mdl")
	btnForward:SetIsToggle(false)
	btnForward:SetPos(entCar:LocalToWorld(Vector(-44.391602, -48.897945, 47.378601)))
	btnForward:SetAngles(entCar:LocalToWorldAngles(Angle(-90, 0, 0)))
	btnForward:SetOwner(entCar)
	btnForward:Spawn()
	btnForward:Activate()
	btnForward:SetParent(entCar)
	btnForward:SetModelScale(0.25)
	btnForward.BlockPhysGun = true

	btnForward:SetCanUseCallback(function(entBtn, pPlayer)
		if IsValid(entCar) and IsValid(entCar:GetDriver()) then return end

		return GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_TOW
	end)

	bed:SetTranslateForwardButton(btnForward)
	local btnWBack = ents.Create("ent_button")
	btnWBack:SetModel("models/maxofs2d/button_06.mdl")
	btnWBack:SetIsToggle(false)
	btnWBack:SetPos(entCar:LocalToWorld(Vector(-44.391602, -68.314453, 47.378601)))
	btnWBack:SetAngles(entCar:LocalToWorldAngles(Angle(-90, 0, 0)))
	btnWBack:SetOwner(entCar)
	btnWBack:Spawn()
	btnWBack:Activate()
	btnWBack:SetParent(entCar)
	btnWBack:SetModelScale(0.25)
	btnWBack.BlockPhysGun = true

	btnWBack:SetCanUseCallback(function(entBtn, pPlayer)
		if IsValid(entCar) and IsValid(entCar:GetDriver()) then return end

		return GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_TOW
	end)

	bed:SetWinchBackButton(btnWBack)
	local btnWForward = ents.Create("ent_button")
	btnWForward:SetModel("models/maxofs2d/button_06.mdl")
	btnWForward:SetIsToggle(false)
	btnWForward:SetPos(entCar:LocalToWorld(Vector(-44.391602, -60.279293, 47.378601)))
	btnWForward:SetAngles(entCar:LocalToWorldAngles(Angle(-90, 0, 0)))
	btnWForward:SetOwner(entCar)
	btnWForward:Spawn()
	btnWForward:Activate()
	btnWForward:SetParent(entCar)
	btnWForward:SetModelScale(0.25)
	btnWForward.BlockPhysGun = true

	btnWForward:SetCanUseCallback(function(entBtn, pPlayer)
		if IsValid(entCar) and IsValid(entCar:GetDriver()) then return end

		return GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_TOW
	end)

	bed:SetWinchForwardButton(btnWForward)
	local btnWRel = ents.Create("ent_button")
	btnWRel:SetModel("models/maxofs2d/button_01.mdl")
	btnWRel:SetIsToggle(false)
	btnWRel:SetPos(entCar:LocalToWorld(Vector(-45.289066, -77.012695, 48.113190)))
	btnWRel:SetAngles(entCar:LocalToWorldAngles(Angle(90, 180, 0)))
	btnWRel:SetOwner(entCar)
	btnWRel:Spawn()
	btnWRel:Activate()
	btnWRel:SetParent(entCar)
	btnWRel:SetModelScale(0.25)
	btnWRel.BlockPhysGun = true

	btnWRel:SetCanUseCallback(function(entBtn, pPlayer)
		if IsValid(entCar) and IsValid(entCar:GetDriver()) then return end

		return GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_TOW
	end)

	bed:SetWinchReleaseButton(btnWRel)
	entCar.BedEnt = bed
	entCar.IsTow = true
	entCar:DeleteOnRemove(bed)
	entCar:DeleteOnRemove(btnLock)
	entCar:DeleteOnRemove(btnBack)
	entCar:DeleteOnRemove(btnForward)
	entCar:DeleteOnRemove(btnWBack)
	entCar:DeleteOnRemove(btnWForward)
	entCar:DeleteOnRemove(btnWRel)
	pPlayer:AddNote("You spawned your tow truck!")
end

hook.Add("PlayerEnteredVehicle", "")

function Job:OnPlayerSpawnTowTruck(pPlayer, entCar)
	-- if not pPlayer:IsDonator() then return end
	entCar.towHook = ents.Create("ent_towhook")
	entCar.towHook:SetPos(entCar:GetPos() + Vector(4.305450, -176.516785, 32.415520))
	entCar.towHook:SetAngles(entCar:GetAngles() + Angle(90, 0, 0))
	entCar.towHook:Spawn()
	entCar.towHook:SetPlayerOwner(pPlayer)
	entCar.towHook:SetSaveValue("fademindist", GAMEMODE.Config.DetailPropFadeMin)
	entCar.towHook:SetSaveValue("fademaxdist", GAMEMODE.Config.DetailPropFadeMax)
	entCar.IsTow = true
	entCar.IsTowKeys = true

	entCar:CallOnRemove("RemoveOtherThings", function(entCar)
		if IsValid(entCar.towHook) then
			if IsValid(entCar.towHook.m_pWeld) then
				entCar.towHook.m_pWeld:Remove()
			end

			if IsValid(entCar.towHook:GetAttachedTo()) then
				entCar.towHook:GetAttachedTo():SetHandbrake(false)
			end

			if entCar.towHook.m_funcOnRelease then
				entCar.towHook.m_funcOnRelease(entCar.towHook, entCar.towHook:GetAttachedTo())
			end

			entCar.towHook:GetPhysicsObject():SetMass(64)
			entCar.towHook:SetAttachedTo(NULL)
			entCar.towHook:GetPhysicsObject():RecheckCollisionFilter()

			timer.Simple(4, function()
				if not IsValid(entCar.towHook) then return end
				entCar.towHook.Last = nil
			end)
		end

		SafeRemoveEntity(entCar.towHook)
	end)

	entCar.towHook:CallOnRemove("RemoveAttachment", function(towHook)
		if IsValid(entCar.towHook) then
			if IsValid(entCar.towHook.m_pWeld) then
				entCar.towHook.m_pWeld:Remove()
			end

			if IsValid(entCar.towHook:GetAttachedTo()) then
				entCar.towHook:GetAttachedTo():SetHandbrake(false)
			end

			if entCar.towHook.m_funcOnRelease then
				entCar.towHook.m_funcOnRelease(entCar.towHook, entCar.towHook:GetAttachedTo())
			end

			entCar.towHook:GetPhysicsObject():SetMass(64)
			entCar.towHook:SetAttachedTo(NULL)
			entCar.towHook:GetPhysicsObject():RecheckCollisionFilter()

			timer.Simple(4, function()
				if not IsValid(entCar.towHook) then return end
				entCar.towHook.Last = nil
			end)
		end
	end)

	entCar.towHook.m_pConst, entCar.towHook.m_pRope = constraint.Elastic(entCar.towHook, entCar, 0, 0, Vector(0, 0, 0), Vector(0, -160, 110), 100000, 0.75, 0.2, "cable/cable2", 1, true)
	entCar.m_pNoCollide = constraint.NoCollide(entCar, entCar.towHook, 0, 0)
	entCar.towHook.car = entCar
	pPlayer:AddNote("You spawned your tow truck!")
end

--Player wants to spawn a tow truck
function Job:PlayerSpawnTowTruck(pPlayer)
	local car = GAMEMODE.Cars:PlayerSpawnJobCar(pPlayer, self.TruckID, self.TruckSpawns, self.ParkingLotPos)

	if IsValid(car) then
		self:OnPlayerSpawnTowTruck(pPlayer, car)
	end
end

--Player wants to spawn a flatbed
function Job:PlayerSpawnFlatbed(pPlayer)
	local car = GAMEMODE.Cars:PlayerSpawnJobCar(pPlayer, self.FlatbedID, self.TruckSpawns, self.ParkingLotPos)

	if IsValid(car) then
		self:OnPlayerSpawnFlatbed(pPlayer, car)
	end
end

--Player wants to stow their tow truck
function Job:PlayerStowTowTruck(pPlayer)
	GAMEMODE.Cars:PlayerStowJobCar(pPlayer, self.ParkingLotPos)
end

function Job:PlayerRequestImpoundVehicle(pPlayer)
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_TOW) then return end
	local car = GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer)

	if not IsValid(car) or not car.IsTow or not IsValid(car.BedEnt) then
		pPlayer:AddNote("You don't have a tow truck!")

		return
	end

	--distance check
	if not GAMEMODE.Util:VectorInRange(car:GetPos(), self.ParkingLotPos.Min, self.ParkingLotPos.Max) then
		pPlayer:AddNote("Your truck must be in the parking zone!")

		return
	end

	local bed = car.BedEnt

	if not bed:IsBedLocked() then
		pPlayer:AddNote("Your tow truck bed must be locked!")

		return
	end

	local veh = bed:GetCarryingVehicle()

	if not IsValid(veh) or not veh.UID then
		pPlayer:AddNote("You aren't towing a vehicle!")

		return
	end

	local owner = veh:GetPlayerOwner()

	if not IsValid(owner) or owner == pPlayer then
		pPlayer:AddNote("That vehicle has no owner.")

		return
	end

	if not veh:GetNWBool("impound", false) then
		pPlayer:AddNote("That vehicle is not marked for impound!")

		return
	end

	local ownerData = GAMEMODE.Cars:GetPlayerCarData(owner, veh.UID)
	if not ownerData or ownerData.Impounded then return end
	ownerData.Impounded = true
	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "vehicles")
	hook.Call("GamemodeOnVehicleImpounded", GAMEMODE, pPlayer, owner, veh.UID)
	pPlayer:AddMoney(GAMEMODE.Config.TowImpoundBonus, "Tow impound commission")
	pPlayer:AddNote("You earned $" .. string.Comma(GAMEMODE.Config.TowImpoundBonus) .. " for impounding a vehicle!")
	owner:AddNote("Your vehicle has been impounded!")

	--Issue bill
	GAMEMODE.Econ:IssuePlayerBill(owner, "impound", ("Vehicle Impound: %s %s"):format(veh.CarData.Make, veh.CarData.Name), GAMEMODE.Config.ImpoundBillCost, GAMEMODE.Config.ImpoundBillInterval, {
		veh_uid = veh.UID,
		interval = 1
	})

	SafeRemoveEntityDelayed(veh, 0)
end

hook.Add("GamemodePlayerSendTextMessage", "TowJobTexting", function(pSender, strText, strNumberSendTo)
	if strNumberSendTo ~= "Roadside Assistance" then return end

	if pSender.m_intLastTowText and pSender.m_intLastTowText > CurTime() then
		local time = math.Round(pSender.m_intLastTowText - CurTime())
		GAMEMODE.Net:SendTextMessage(pSender, "Roadside Assistance", "You must wait " .. time .. " seconds before you can send another message to roadside assistance.")
		pSender:EmitSound("santosrp/sms.mp3")

		return true
	end

	local sentTo = 0
	strText = "Roadside assistance call from " .. GAMEMODE.Player:GetGameVar(pSender, "phone_number") .. "\n(" .. pSender:Nick() .. "):\n" .. strText

	for k, v in pairs(player.GetAll()) do
		if GAMEMODE.Jobs:GetPlayerJobID(v) == JOB_TOW then
			GAMEMODE.Net:SendTextMessage(v, "Tow Dispatch", strText)
			v:EmitSound("santosrp/sms.mp3")
			sentTo = sentTo + 1
		end
	end

	local respMsg = ""

	if sentTo == 0 then
		respMsg = "No roadside services are available right now. Sorry!"
	else
		respMsg = "Your message was received by dispatch and sent to " .. sentTo .. " workers."
	end

	GAMEMODE.Net:SendTextMessage(pSender, "Roadside Assistance", respMsg)
	pSender:EmitSound("santosrp/sms.mp3")
	pSender.m_intLastTowText = CurTime() + 60

	return
end)

hook.Add("PlayerEnteredVehicle", "TowTips", function(pPlayer, entVeh, intRole)
	if not entVeh.IsTow then return end

	if entVeh.IsTowKeys then
		pPlayer:AddNote("'LSHIFT' to lower hook")
		pPlayer:AddNote("'LALT' to raise hook")
		pPlayer:AddNote("'SPACE + LEFT CLICK' to detach hook")
	end

	if not IsValid(entVeh.BedEnt) then return end

	if not entVeh.BedEnt:IsBedLocked() then
		pPlayer:AddNote("The truck bed is currently unlocked!")
		pPlayer:AddNote("This will impact your speed, please lock the bed before driving.")
	end
end)

--Custom exit spawns for the flatbed, try to handle it here first since the default one is kind of crappy
local spawns = {Vector(-102.989403, 80.599289, 43.687336), Vector(85.989922, 85.333710, 39.285664)}

hook.Add("PlayerLeaveVehicle", "FlatbedExitSpawn", function(pPlayer, entVeh)
	if entVeh.IsTow and IsValid(entVeh.BedEnt) then
		for i = 1, #spawns do
			if GAMEMODE.Util:MinMaxsStuck(entVeh:LocalToWorld(spawns[i]), pPlayer:OBBMins(), pPlayer:OBBMaxs()) then continue end
			pPlayer:SetPos(entVeh:LocalToWorld(spawns[i]))

			return
		end
	elseif IsValid(entVeh:GetParent()) and entVeh:GetParent().IsTow and IsValid(entVeh:GetParent().BedEnt) then
		for i = 1, #spawns, -1 do
			if GAMEMODE.Util:MinMaxsStuck(entVeh:LocalToWorld(spawns[i]), pPlayer:OBBMins(), pPlayer:OBBMaxs()) then continue end
			pPlayer:SetPos(entVeh:LocalToWorld(spawns[i]))

			return
		end
	end
end)

GM.Jobs:Register(Job)