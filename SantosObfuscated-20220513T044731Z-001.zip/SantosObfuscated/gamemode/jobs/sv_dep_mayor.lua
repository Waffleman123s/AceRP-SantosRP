--[[
	Name: sv_dep_mayor.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "mayor", 54 )

local Job = {}
Job.ID = 16
Job.Enum = "JOB_DEPUTY_MAYOR"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Deputy Mayor"
Job.WhitelistName = "deputy_mayor"
Job.PlayerCap = { Min = 1, MinStart = 1, Max = 1, MaxEnd = 1 }

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 6000 },
		{ PlayTime = 12 *(60 *60), Pay = 8500 },
		{ PlayTime = 24 *(60 *60), Pay = 9000 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 10000 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 16500 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 6000 },
		{ PlayTime = 12 *(60 *60), Pay = 8500 },
		{ PlayTime = 24 *(60 *60), Pay = 9000 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 10000 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 16500 },
	}
end

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_DepMayor", function()
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 8
		Job.ChannelKeys = {
			[8] = true,
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_SSERVICE then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
	if PRIVATE_SERVER then
		pPlayer:Give( "weapon_gspeak_radio_ss" )
	end
end

hook.Add( "GamemodeCanPlayerSetJob", "PermaDepMayor", function( pPlayer, intJobID )
	if intJobID ~= JOB_DEPUTY_MAYOR and GAMEMODE.Jobs:IsPlayerWhitelisted( pPlayer, JOB_DEPUTY_MAYOR ) then
		if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then
			GAMEMODE.Jobs:SetPlayerJob( pPlayer, JOB_DEPUTY_MAYOR )
		else
			pPlayer:AddNote( "You may not have another job as deputy mayor!" )
		end
		
		return false
	end
end )

hook.Add( "GamemodeBuildPlayerComputerApps", "AutoInstallDepMayorApps", function( pPlayer, entComputer, tblApps )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end
	tblApps["turbotax97.exe"] = GAMEMODE.Apps:GetComputerApp( "turbotax97.exe" )
	tblApps["nsa.exe"] = GAMEMODE.Apps:GetComputerApp( "nsa.exe" )
end )

GM.Jobs:Register( Job )