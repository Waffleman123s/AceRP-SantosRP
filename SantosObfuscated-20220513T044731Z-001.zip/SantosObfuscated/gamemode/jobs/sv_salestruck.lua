--[[
	Name: salestruck.lua
	For: SantosRP
	By: Ultra
]]--

--Job protocols start at 50 to save space for other things in the gamemode
GM.Net:AddProtocol( "sales_truck", 52 )

local Job = {}
Job.ID = 8
Job.Enum = "JOB_SALES_TRUCK"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Sales Truck Driver"
Job.PlayerCap = GM.Config.Job_SalesTruck_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.ParkingLotPos = GM.Config.SalesParkingZone
Job.TruckSpawns = GM.Config.SalesCarSpawns
Job.TruckID = "sales_truck"

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
end

Job.m_tblTruckTypes = {
	[1] = {
		Name = "Mechanic", Skin = 4, Items = {
			["Crafting Table"] = 600,
			["Assembly Table"] = 600,
			["Gun Smithing Table"] = 900,
			["Road Flare"] = 60,
			["Terracotta Pot"] = 100,
			["Stove"] = 425,

			--fluids
			["Cleaning Solution"] = 25,
			["Bucket of Fertilizer"] = 15,
			["Potting Soil"] = 10,

			--crafting items
			["Wood Plank"] = 110,
			["Paint Bucket"] = 35,
			["Metal Bracket"] = 80,
			["Metal Bar"] = 60,
			["Metal Plate"] = 70,
			["Metal Pipe"] = 65,
			["Metal Hook"] = 40,
			["Metal Bucket"] = 70,
			["Plastic Bucket"] = 45,
			["Wrench"] = 80,
			["Pliers"] = 80,
			["Car Battery"] = 300,
			["Circular Saw"] = 250,
			["Cinder Block"] = 20,
			["Bleach"] = 20,
			["Radiator"] = 225,
			["Crowbar"] = 75,
			["Engine Block"] = 700,
			["Large Cardboard Box"] = 20,
			["Plastic Crate"] = 70,
			["Chunk of Plastic"] = 15,
			["Cloth"] = 20,
			["Rubber Tire"] = 300,

			--misc building items
			["Concrete Barrier"] = 110,
			["Wire Fence 01"] = 150,
			["Wire Fence 02"] = 150,
			["Wire Fence 03"] = 150,
			["Large Blast Door"] = 300,
			["Blast Door"] = 225,
			["Large Wood Plank"] = 30,
			["Large Wood Fence"] = 150,
			["Wood Fence"] = 125,
		} 
	},
}

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_SALES_TRUCK then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
end

function Job:OnPlayerSpawnSalesTruck( pPlayer, entCar, intTruckID )
	entCar.TruckID = intTruckID
	entCar.IsSalesTruck = true
	entCar:SetSkin( self.m_tblTruckTypes[intTruckID].Skin )
	entCar:SetNWInt( "sales_truck_id", intTruckID )
	pPlayer:AddNote( "You spawned your sales truck!" )
end

--Player wants to spawn a sales truck
function Job:PlayerSpawnSalesTruck( pPlayer, intTruckID )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.TruckID, self.TruckSpawns, self.ParkingLotPos )
	if IsValid( car ) then
		self:OnPlayerSpawnSalesTruck( pPlayer, car, intTruckID )
	end
end

--Player wants to stow their sales truck
function Job:PlayerStowSalesTruck( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingLotPos )
end

function Job:PlayerBuyItem( pPlayer, entCar, strItem, intAmount )
	if CurTime() < (pPlayer.m_intLastSalesTruckBuy or 0) then return end
	pPlayer.m_intLastSalesTruckBuy = CurTime() +1
	
	if not self.m_tblTruckTypes[entCar:GetNWInt("sales_truck_id", 0)] then return end
	if not self.m_tblTruckTypes[entCar:GetNWInt("sales_truck_id", 0)].Items[strItem] then return end
	intAmount = math.max( intAmount or 1, 1 )

	local itemPrice = self.m_tblTruckTypes[entCar:GetNWInt("sales_truck_id", 0)].Items[strItem]
	local itemPriceTaxed = GAMEMODE.Econ:ApplyTaxToSum( "sales", itemPrice *intAmount )
	local ownerPay = math.ceil( itemPrice *0.32 ) *intAmount
	local price = itemPriceTaxed +ownerPay

	if not pPlayer:CanAfford( price ) then
		pPlayer:AddNote( "You can't afford that!" )
		return
	end

	if GAMEMODE.Inv:GivePlayerItem( pPlayer, strItem, intAmount ) then
		pPlayer:TakeMoney( price, "Sales truck purchase" )
		entCar:GetPlayerOwner():AddMoney( ownerPay, "Sale truck commission" )
		pPlayer:AddNote( "You purchased ".. intAmount.. " ".. strItem.. "." )
		entCar:GetPlayerOwner():AddNote( "You earned $".. ownerPay.. " by selling merchandise!" )
	else
		pPlayer:AddNote( "Your inventory is full!" )
	end
end

function GM.Net:OpenSalesTruckMenu( pPlayer, entSalesTruck )
	self:NewEvent( "sales_truck", "open" )
		net.WriteEntity( entSalesTruck )
	self:FireEvent( pPlayer )
end

GM.Net:RegisterEventHandle( "sales_truck", "b", function( intMsgLen, pPlayer )
	if not IsValid( pPlayer.UsedSalesTruck ) then return end
	if pPlayer.UsedSalesTruck:GetPos():Distance( pPlayer:GetPos() ) > 200 then return end
	
	local itemID, amount = net.ReadString(), net.ReadUInt( 8 )
	Job:PlayerBuyItem( pPlayer, pPlayer.UsedSalesTruck, itemID, amount )
end )

hook.Add( "PlayerUse", "UseSalesTruck", function( pPlayer, eEnt )
	if not IsValid( eEnt ) or not eEnt:IsVehicle() or not eEnt.IsSalesTruck then return end

	local dot = (pPlayer:GetEyeTrace().HitPos -eEnt:GetPos()):GetNormal():Dot( eEnt:GetForward() )
	if dot < -0.19 and CurTime() >(pPlayer.m_intLastUsedSalesTruck or 0) then
		GAMEMODE.Net:OpenSalesTruckMenu( pPlayer, eEnt )
		pPlayer.m_intLastUsedSalesTruck = CurTime() +1
		pPlayer.UsedSalesTruck = eEnt
		return false
	end
end )

GM.Jobs:Register( Job )