--[[
	Name: sv_bus_driver.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 9
Job.Enum = "JOB_BUS_DRIVER"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Bus Driver"
Job.ParkingGaragePos = GM.Config.BusParkingZone
Job.PlayerCap = GM.Config.Job_BusDriver_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarSpawns = GM.Config.BusCarSpawns
Job.BusID = "mtl_bus"
Job.BusChargeAmount = 35

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 17 },
		{ PlayTime = 4 *(60 *60), Pay = 23 },
		{ PlayTime = 12 *(60 *60), Pay = 27 },
		{ PlayTime = 24 *(60 *60), Pay = 35 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 42 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 52 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 60 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 72 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 95 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 12 },
		{ PlayTime = 4 *(60 *60), Pay = 15 },
		{ PlayTime = 12 *(60 *60), Pay = 19 },
		{ PlayTime = 24 *(60 *60), Pay = 23 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 29 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 35 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 43 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 55 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 67 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 83 },
	}
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_BUS_DRIVER then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
end

function Job:OnPlayerSpawnBus( pPlayer, entCar )
	entCar.IsBus = true
	pPlayer:AddNote( "You spawned your bus!" )
end

--Player wants to spawn a bus
function Job:PlayerSpawnBus( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.BusID, self.CarSpawns, self.ParkingGaragePos )
	if IsValid( car ) then
		self:OnPlayerSpawnBus( pPlayer, car )
	end
end

--Player wants to stow their bus
function Job:PlayerStowBus( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingGaragePos )
end

local chargeAmount = Job.BusChargeAmount
hook.Add( "CanPlayerEnterVehicle", "BusCanEnter", function( pPlayer, entVehicle, strRole )
	local parent = entVehicle:GetParent()
	if IsValid( parent ) and parent.IsBus then
		if not IsValid( parent:GetDriver() ) or parent:GetPlayerOwner() ~= parent:GetDriver() then return end
		if not pPlayer:CanAfford( chargeAmount ) then return false end
		if CurTime() < (pPlayer.m_intLastBusBoardTime or 0) then return false end
	end
end )

hook.Add( "PlayerEnteredVehicle", "BusCharge", function( pPlayer, entVehicle, intRole )
	local parent = entVehicle:GetParent()
	if IsValid( parent ) and parent.IsBus then
		if not IsValid( parent:GetDriver() ) then return end
		if parent:GetPlayerOwner() == pPlayer then return end
		if parent:GetDriver() ~= parent:GetPlayerOwner() then return end

		pPlayer:TakeMoney( chargeAmount, "Bus fare" )
		pPlayer:AddNote( "You were charged $".. chargeAmount.. " to board this bus." )
		pPlayer.m_intLastBusBoardTime = CurTime() +3

		entVehicle:GetParent():GetDriver():AddMoney( chargeAmount, "Bus fare" )
		entVehicle:GetParent():GetDriver():AddNote( "You received $".. chargeAmount.. " from someone boarding your bus!" )
	end
end )

GM.Jobs:Register( Job )