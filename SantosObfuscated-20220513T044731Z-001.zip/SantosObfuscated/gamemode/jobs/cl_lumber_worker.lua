--[[
	Name: sv_city_worker.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 974
Job.Enum = "JOB_LUMBERWORKER"
Job.TeamColor = Color( 146, 120, 160, 255 )
Job.Name = "Lumber Worker"
Job.PlayerCap = GM.Config.Job_LumberWorker_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarID = "gmc_lumber"
Job.ParkingLotPos = GM.Config.CityWorkerParkingZone
Job.CarSpawns = GM.Config.CityWorkerCarSpawns

--IE: Cut tree, move wood? is van enabled for lumber? change to different vehicle probably.
Job.VanItems = { --TODO: Modify to santosrp items from the lumber addon
	["Lumber Axe"] = 1
}

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

hook.Add( "GamemodeDefineGameVars", "DefineLumberWorkerVars", function( pPlayer )
	GAMEMODE.Player:DefineGameVar( "lwork_dest", "", "String", true )
	GAMEMODE.Player:DefineGameVar( "lwork_type", "", "String", true )
end )

local MAT_WORKICON = Material( "icon16/money.png", "" )
hook.Add( "HUDPaint", "DrawLumberWorkerJob", function()
	if GAMEMODE.Jobs:GetPlayerJobID( LocalPlayer() ) ~= JOB_LUMBERWORKER then return end
	if GAMEMODE.Player:GetGameVar( "lwork_type", "" ) == "" then return end
	
	local type = GAMEMODE.Player:GetGameVar( "lwork_type", "" ) --TODO: update the game tasks.
	if type == "tree_event" then
		local pos = Vector( GAMEMODE.Player:GetGameVar("lwork_dest", "0 0 0") )
		if not pos then return end
		
		pos = (pos +Vector(0, 0, 8)):ToScreen()
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( MAT_WORKICON )
		surface.DrawTexturedRect( pos.x, pos.y, 16, 16 )

		draw.SimpleTextOutlined(
			"Cut down this tree!",
			"Trebuchet18",
			pos.x,
			pos.y +18,
			Color( 240, 240, 240, 255 ),
			TEXT_ALIGN_CENTER,
			TEXT_ALIGN_TOP,
			1,
			Color( 0, 0, 0, 255 )
		)	
	end
end )

function GM.Net:LumberWorker_RequestMoveJobItemFromVan( entVan, strItemID, intAmount )
	self:NewEvent( "ent", "lwork_van_take" )
		net.WriteEntity( entVan )
		net.WriteString( strItemID )
		net.WriteUInt( intAmount, 16 )
	self:FireEvent()
end

function GM.Net:LumberWorker_RequestMoveJobItemToVan( entVan, strItemID, intAmount )
	self:NewEvent( "ent", "lwork_van_add" )
		net.WriteEntity( entVan )
		net.WriteString( strItemID )
		net.WriteUInt( intAmount, 16 )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "ent", "lwork_van_upd", function( intMsgLen, pPlayer )
	hook.Call( "GamemodeRefreshLumberWorkVanMenu", GAMEMODE )
end )

GM.Jobs:Register( Job )