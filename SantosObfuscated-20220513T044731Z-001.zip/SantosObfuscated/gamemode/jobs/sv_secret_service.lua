--[[
	Name: secret_service.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 13
Job.Enum = "JOB_SSERVICE"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Secret Service"
if PRIVATE_SERVER then
	Job.WhitelistName = "sservice"
else
	Job.WhitelistName = nil
end
Job.PlayerCap = GM.Config.Job_SService_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarLimit = math.ceil( Job.PlayerCap.Max *0.66 )
Job.PendingPlayerApps = {}
Job.SSGaragePos = GM.Config.SSParkingZone
Job.CarSpawns = GM.Config.SSCarSpawns

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 60 },
		{ PlayTime = 12 *(60 *60), Pay = 75 },
		{ PlayTime = 24 *(60 *60), Pay = 80 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 90 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 135 },
		{ PlayTime = (24 *(60 *60)) *14, Pay = 160 },
		{ PlayTime = (24 *(60 *60)) *30, Pay = 200 },
		{ PlayTime = (24 *(60 *60)) *365, Pay = 420 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 60 },
		{ PlayTime = 12 *(60 *60), Pay = 75 },
		{ PlayTime = 24 *(60 *60), Pay = 80 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 90 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 135 },
		{ PlayTime = (24 *(60 *60)) *14, Pay = 160 },
		{ PlayTime = (24 *(60 *60)) *30, Pay = 200 },
		{ PlayTime = (24 *(60 *60)) *365, Pay = 420 },
	}
end

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_SS", function()
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 8
		Job.ChannelKeys = {
			[8] = true,
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_SSERVICE then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
	--pPlayer:Give( "policebadgewallet" )

	if PRIVATE_SERVER then
		pPlayer:Give( "weapon_gspeak_radio_ss" )
	end
end

function Job:PlayerApply( pPlayer )
	if pPlayer.m_intLastSSApply then
		if pPlayer.m_intLastSSApply > CurTime() then
			pPlayer:AddNote( ("You must wait for %d seconds before you may apply again."):format(pPlayer.m_intLastSSApply -CurTime()) )
			return false
		end
	end

	self.PendingPlayerApps[pPlayer] = true
	pPlayer.m_intLastSSApply = GAMEMODE.Config.SSApplyInterval

	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Jobs:GetPlayerJobID( v ) == JOB_MAYOR or GAMEMODE.Jobs:GetPlayerJobID( v ) == JOB_DEPUTY_MAYOR then
			GAMEMODE.Net:SendMayorSSApps( v )
			break
		end
	end

	pPlayer:AddNote( "You have applied for the secret service!" )
	return true
end

function Job:PlayerPullApp( pPlayer )
	self.PendingPlayerApps[pPlayer] = nil

	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Jobs:GetPlayerJobID( v ) == JOB_MAYOR or GAMEMODE.Jobs:GetPlayerJobID( v ) == JOB_DEPUTY_MAYOR then
			GAMEMODE.Net:SendMayorSSApps( v )
			break
		end
	end

	pPlayer:AddNote( "You pulled your application for the secret service!" )
end

function Job:PlayerHasApp( pPlayer )
	return self.PendingPlayerApps[pPlayer]
end

function Job:ApprovePlayerApp( pPlayer )
	self.PendingPlayerApps[pPlayer] = nil
	GAMEMODE.Jobs:SetPlayerJob( pPlayer, JOB_SSERVICE )
	pPlayer:AddNote( "They mayor has approved your secret service application!" )
end

function Job:DenyPlayerApp( pPlayer )
	self.PendingPlayerApps[pPlayer] = nil
	pPlayer:AddNote( "They mayor has denied your secret service application!" )
end

function Job:MayorFirePlayer( pPlayer )
	pPlayer:AddNote( "The mayor has fired you from the secret service!" )
	GAMEMODE.Jobs:SetPlayerJob( pPlayer, JOB_CIVILIAN )
end

function Job:OnPlayerSpawnSSCar( pPlayer, entCar )
	local color, skin, groups = net.ReadColor(), net.ReadUInt( 8 ), net.ReadTable()
	entCar:SetColor( color )
	entCar:SetSkin( skin )

	for k, v in pairs( groups ) do
		entCar:SetBodygroup( k, v )
	end

	entCar.IsCopCar = true
	pPlayer:AddNote( "Your spawned your government car!" )
end

--Player wants to spawn a gov car
GM.Net:RegisterEventHandle( "mayor", "ss_sp_c", function( intMsgLen, pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "ss_spawn_car" then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_SSERVICE and
		GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and
		GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end

	local car = GAMEMODE.Cars:PlayerSpawnJobCar(
		pPlayer,
		net.ReadString(),
		Job.CarSpawns,
		Job.SSGaragePos, 
		(GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_MAYOR or GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_DEPUTY_MAYOR) and
			JOB_SSERVICE or nil
	)

	if IsValid( car ) then
		Job:OnPlayerSpawnSSCar( pPlayer, car )
	end
end )

--Player wants to stow their gov car
GM.Net:RegisterEventHandle( "mayor", "ss_st", function( intMsgLen, pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "ss_spawn_car" then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_SSERVICE and
		GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and
		GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end

	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, Job.SSGaragePos )
end )

function GM.Net:SendMayorSSApps( pMayor )
	if GAMEMODE.Jobs:GetPlayerJobID( pMayor ) ~= JOB_MAYOR and GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end
	
	for k, v in pairs( Job.PendingPlayerApps ) do
		if not IsValid( k ) then Job.PendingPlayerApps[k] = nil end
	end

	self:NewEvent( "mayor", "upd_ss_app" )
		net.WriteUInt( table.Count(Job.PendingPlayerApps), 8 )

		for k, v in pairs( Job.PendingPlayerApps ) do
			net.WriteEntity( k )
		end
	self:FireEvent( pMayor )
end

GM.Net:RegisterEventHandle( "mayor", "ss_apr", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["nsa.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end

	local target = net.ReadEntity()
	if not IsValid( target ) or not target:IsPlayer() or target == pPlayer then return end
	if GAMEMODE.Jobs:GetPlayerJobID( target ) == JOB_SSERVICE then return end
	if not Job.PendingPlayerApps[target] then return end
	Job:ApprovePlayerApp( target )

	GAMEMODE.Net:SendMayorSSApps( pPlayer )
end )

GM.Net:RegisterEventHandle( "mayor", "ss_dny", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["nsa.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end

	local target = net.ReadEntity()
	if not IsValid( target ) or not target:IsPlayer() or target == pPlayer then return end
	if GAMEMODE.Jobs:GetPlayerJobID( target ) == JOB_SSERVICE then return end
	if not Job.PendingPlayerApps[target] then return end
	Job:DenyPlayerApp( target )

	GAMEMODE.Net:SendMayorSSApps( pPlayer )
end )

GM.Net:RegisterEventHandle( "mayor", "ss_fire", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["nsa.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end

	local target = net.ReadEntity()
	if not IsValid( target ) or not target:IsPlayer() or target == pPlayer then return end
	if GAMEMODE.Jobs:GetPlayerJobID( target ) ~= JOB_SSERVICE then return end
	Job:MayorFirePlayer( target )

	GAMEMODE.Net:SendMayorSSApps( pPlayer )
end )

hook.Add( "GamemodePlayerSetJob", "UpdateMayorApps", function( pPlayer, intJobID )
	if intJobID ~= JOB_MAYOR and intJobID ~= JOB_DEPUTY_MAYOR then return end
	GAMEMODE.Net:SendMayorSSApps( pPlayer )
end )

local lastTick = 0
hook.Add( "Tick", "CheckForMayorSS", function()
	if lastTick > CurTime() then return end
	lastTick = CurTime() +10
	
	if GAMEMODE.Jobs:GetNumPlayers( JOB_MAYOR ) > 0 then return end
	if GAMEMODE.Jobs:GetNumPlayers( JOB_DEPUTY_MAYOR ) > 0 then return end
	if GAMEMODE.Jobs:GetNumPlayers( JOB_SSERVICE ) > 0 then
		for k, v in pairs( player.GetAll() ) do
			if not GAMEMODE.Jobs:PlayerIsJob( v, JOB_SSERVICE ) then continue end
			GAMEMODE.Jobs:SetPlayerJob( v, JOB_CIVILIAN )
			v:AddNote( "You have been removed from the secret service as the mayor has left the game." )
		end
	end
end )

GM.Jobs:Register( Job )