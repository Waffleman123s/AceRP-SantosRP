--[[
	Name: salestruck.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "sales_truck", 52 )

local Job = {}
Job.ID = 8
Job.Enum = "JOB_SALES_TRUCK"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Sales Truck Driver"
Job.PlayerCap = GM.Config.Job_SalesTruck_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.ParkingLotPos = GM.Config.SalesParkingZone
Job.TruckSpawns = GM.Config.SalesCarSpawns
Job.TruckID = "sales_truck"

Job.m_tblTruckTypes = {
	[1] = {
		Name = "Mechanic", Skin = 4, Items = {
			["Crafting Table"] = 600,
			["Assembly Table"] = 600,
			["Gun Smithing Table"] = 900,
			["Road Flare"] = 60,
			["Terracotta Pot"] = 100,
			["Stove"] = 425,

			--fluids
			["Cleaning Solution"] = 25,
			["Bucket of Fertilizer"] = 15,
			["Potting Soil"] = 10,

			--crafting items
			["Wood Plank"] = 110,
			["Paint Bucket"] = 35,
			["Metal Bracket"] = 80,
			["Metal Bar"] = 60,
			["Metal Plate"] = 70,
			["Metal Pipe"] = 65,
			["Metal Hook"] = 40,
			["Metal Bucket"] = 70,
			["Plastic Bucket"] = 45,
			["Wrench"] = 80,
			["Pliers"] = 80,
			["Car Battery"] = 300,
			["Circular Saw"] = 250,
			["Cinder Block"] = 20,
			["Bleach"] = 20,
			["Radiator"] = 225,
			["Crowbar"] = 75,
			["Engine Block"] = 700,
			["Large Cardboard Box"] = 20,
			["Plastic Crate"] = 70,
			["Chunk of Plastic"] = 15,
			["Cloth"] = 20,
			["Rubber Tire"] = 300,

			--misc building items
			["Concrete Barrier"] = 110,
			["Wire Fence 01"] = 150,
			["Wire Fence 02"] = 150,
			["Wire Fence 03"] = 150,
			["Large Blast Door"] = 300,
			["Blast Door"] = 225,
			["Large Wood Plank"] = 30,
			["Large Wood Fence"] = 150,
			["Wood Fence"] = 125,
		}
	},
}

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

function GM.Net:PlayerBuySalesTruckItem( strItemID, intAmount )
	self:NewEvent( "sales_truck", "b" )
		net.WriteString( strItemID )
		net.WriteUInt( intAmount or 1, 8 )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "sales_truck", "open", function( intMsgLen, pPlayer )
	local truckEnt = net.ReadEntity()
	GAMEMODE.Gui:ShowSalesTruckMenu( truckEnt )
end )

GM.Jobs:Register( Job )