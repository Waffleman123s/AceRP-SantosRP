--[[
	Name: cl_dep_mayor.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 16
Job.Enum = "JOB_DEPUTY_MAYOR"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Deputy Mayor"
Job.WhitelistName = "deputy_mayor"
Job.PlayerCap = { Min = 1, MinStart = 1, Max = 1, MaxEnd = 1 }

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_DepMayor", function()
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 8
		Job.ChannelKeys = {
			[8] = true,
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

GM.Jobs:Register( Job )