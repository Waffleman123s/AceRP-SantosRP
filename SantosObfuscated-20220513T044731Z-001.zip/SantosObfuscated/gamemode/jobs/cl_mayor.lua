--[[
	Name: mayor.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "mayor", 54 )

local Job = {}
Job.ID = 12
Job.Enum = "JOB_MAYOR"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Mayor"
Job.WhitelistName = "mayor"
Job.PlayerCap = { Min = 1, MinStart = 1, Max = 1, MaxEnd = 1 }

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Mayor", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 8, "Secret Service", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 8
		Job.ChannelKeys = {
			[8] = true,
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

function GM.Net:RequestUpdateTaxRate( strTaxID, intNewValue )
	self:NewEvent( "mayor", "updt" )
		net.WriteString( strTaxID )
		net.WriteFloat( intNewValue )
	self:FireEvent()
end

function GM.Net:RequestUpdateBatchedTaxRate( tblTaxes )
	self:NewEvent( "mayor", "updtb" )
		net.WriteUInt( table.Count(tblTaxes), 8 )

		for k, v in pairs( tblTaxes ) do
			net.WriteString( k )
			net.WriteFloat( v )
		end
	self:FireEvent()
end

GM.Jobs:Register( Job )