--[[
	Name: judge.lua
	For: TalosLife
	By: TalosLife
]]--

local Job = {}
Job.ID = 20
Job.Enum = "JOB_JUDGE"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Judge"
Job.WhitelistName = "judge"
Job.Pay = {
	{ PlayTime = 0, Pay = 1100 },
	{ PlayTime = 4 *(60 *60), Pay = 1300 },
	{ PlayTime = 12 *(60 *60), Pay = 1400 },
	{ PlayTime = 24 *(60 *60), Pay = 1650 },
}
Job.PlayerCap = GM.Config.Job_Prosecutor_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.ParkingLotPos = GM.Config.RoadParkingZone
Job.CarSpawns = GM.Config.RoadParkingSpawns
Job.SUVID = "chev_dojcar"

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end


if SERVER then
	function Job:PlayerLoadout( pPlayer )
	end

	function Job:OnPlayerSpawnSUVCar( pPlayer, entCar )
		pPlayer:AddNote( "You spawned your DOJ SUV!" )
		timer.Simple(1, function()
		entCar:SetColor(Color(0, 0, 0))
		entCar:SetSkin( 1 )
        end)
	end

	--Player wants to spawn a SUV
	function Job:PlayerSpawnSUVCar( pPlayer )
		local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.SUVID, self.CarSpawns, self.ParkingGaragePos )
		if IsValid( car ) then
			self:OnPlayerSpawnSUVCar( pPlayer, car )
		end
	end

	--Player wants to stow their SUV
	function Job:PlayerStowSUV( pPlayer )
		GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingGaragePos )
	end
end

GM.Jobs:Register( Job )