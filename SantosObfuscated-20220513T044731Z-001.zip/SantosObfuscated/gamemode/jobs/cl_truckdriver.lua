--[[
	Name: taxi_driver.lua
	For: SantosRP
	By: Ultra
]]
--
local Job = {}
Job.ID = 17
Job.Enum = "JOB_TRUCKDRIVER"
Job.TeamColor = Color(255, 100, 160, 255)
Job.Name = "Truck Driver"

Job.PlayerCap = {
	Min = 2,
	MinStart = 8,
	Max = 2,
	MaxEnd = 60
}

Job.ParkingLotPos = GM.Config.TowParkingZone
Job.TruckSpawns = GM.Config.TowCarSpawns
Job.TruckID = "peterbilt_379"

function Job:OnPlayerJoinJob(pPlayer)
end

function Job:OnPlayerQuitJob(pPlayer)
end

hook.Add("HUDPaint", "DrawTruckDriverJob", function()
	if GAMEMODE.Jobs:GetPlayerJobID(LocalPlayer()) ~= JOB_TRUCKDRIVER then return end
	if not LocalPlayer():GetNWBool("InTruckJob") then return end
	local pickup = LocalPlayer():GetNWString("TrailerPickup")
	local dropoff = LocalPlayer():GetNWString("TrailerDropoff")
	draw.SimpleTextOutlined("Trailer Pickup Location: " .. pickup, "handcuffTextSmall", 5, 55, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined("Trailer Dropoff Location: " .. dropoff, "handcuffTextSmall", 5, 80, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
end)

hook.Add("PostDrawTranslucentRenderables", "DrawTruckDriverJob", function()
	if GAMEMODE.Jobs:GetPlayerJobID(LocalPlayer()) ~= JOB_TRUCKDRIVER then return end
	if not LocalPlayer():GetNWBool("InTruckJob") then return end
	local trailer = LocalPlayer():GetNWEntity("Trailer")
	local dropoffSpot = LocalPlayer():GetNWVector("TrailerDropPos")
	local ang = Angle(0, EyeAngles().y - 90, 90)

	if IsValid(trailer) then
		cam.Start3D2D(trailer:GetPos() + Vector(0, 0, 256 + math.sin(CurTime()) * 4), ang, 0.5)
		draw.WordBox(2, -60, 0, "Your Trailer", "handcuffTextSmall", Color(0, 140, 0, 150), Color(255, 255, 255, 255))
		cam.End3D2D()
	end

	if LocalPlayer():GetPos():DistToSqr(dropoffSpot) > (1200 * 1200) then return end
	cam.Start3D2D(dropoffSpot + Vector(0, 0, 64 + math.sin(CurTime()) * 2), ang, 0.25)
	draw.WordBox(2, -60, 0, "Trailer Drop-Off", "handcuffTextSmall", Color(0, 140, 0, 150), Color(255, 255, 255, 255))
	draw.SimpleText("Drop your trailer off here.", "handcuffTextSmall", 0, 45, color_white, 1, 1)
	cam.End3D2D()
end)

GM.Jobs:Register(Job)