--[[
	Name: sv_city_worker.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 14
Job.Enum = "JOB_CITYWORKER"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "City Worker"
Job.PlayerCap = GM.Config.Job_CityWorker_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarID = "city_van"
Job.ParkingLotPos = GM.Config.RoadParkingZone
Job.CarSpawns = GM.Config.RoadParkingSpawns

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
end

--[[if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 20 },
		{ PlayTime = 4 *(60 *60), Pay = 25 },
		{ PlayTime = 12 *(60 *60), Pay = 29 },
		{ PlayTime = 24 *(60 *60), Pay = 37 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 45 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 53 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 65 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 72 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 80 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 95 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 10 },
		{ PlayTime = 4 *(60 *60), Pay = 12 },
		{ PlayTime = 12 *(60 *60), Pay = 15 },
		{ PlayTime = 24 *(60 *60), Pay = 19 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 23 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 29 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 36 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 45 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 55 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 69 },
	}
end]]

Job.m_tblEvents = JOB_CITYWORKER and GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblEvents or {}
Job.m_tblSpawned = JOB_CITYWORKER and GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblSpawned or {}
Job.DefaultTrunk = {
	["City Issue Traffic Cone"] = 10,
	["Shovel"] = 1,
	["Adjustable Wrench"] = 1,
	["Lawn Mower"] = 1,
	["City Issue Traffic Barrel"] = 10,
}

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_CITYWORKER then
		curCar:Remove()
	end

	for k, v in pairs( ents.GetAll() ) do
		if v.CityWorkerEnt and v.SpawnedFor == pPlayer then
			v:Remove()
		elseif v.IsItem and v.ItemData.JobItem then
			if v.ItemData.JobItem == "JOB_CITYWORKER" and v.CreatedBy == pPlayer then
				v:Remove()
			end
	end
end

	GAMEMODE.Player:SetGameVar( pPlayer, "cwork_dest", "" )
	GAMEMODE.Player:SetGameVar( pPlayer, "cwork_type", "" )
	pPlayer.m_entCurFixEvent = nil
end

function Job:PlayerLoadout( pPlayer )
end

function Job:OnPlayerSpawnVan( pPlayer, entCar )
	for k, v in pairs(self.DefaultTrunk) do
		GAMEMODE.TrunkStorage:AddToTrunkForce(entCar:EntIndex(), k, v)
	end
	entCar.IsCityVan = true
	entCar:SetSkin( 14 )
	pPlayer:AddNote( "You spawned your city utility truck!" )
end

function Job:PlayerSpawnVan( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.CarID, self.CarSpawns, self.ParkingLotPos )
	if IsValid( car ) then
		self:OnPlayerSpawnVan( pPlayer, car )
	end
end

function Job:PlayerStowVan( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingLotPos )
end

function Job:RegisterEvent( strID, tbl )
	self.m_tblEvents[strID] = tbl
end

function Job:SpawnNewEvent( pPlayer )
	if pPlayer.m_entCurFixEvent then return end
	
	local eventNo = math.random( 1, table.Count(self.m_tblEvents) )
	local iter = 0
	for k, v in pairs( self.m_tblEvents ) do
		iter = iter +1
		if eventNo == iter then
			pPlayer.m_entCurFixEvent = v.spawn( pPlayer )
			if pPlayer.m_entCurFixEvent then
				pPlayer:AddNote( "You have a new activity to perform for the city!" )
				GAMEMODE.Player:SetGameVar( pPlayer, "cwork_type", k )
			end

			break
		end
	end
end

local playerChecks = {}
local lastCheck = CurTime() +1
hook.Add( "Think", "ThinkCityDamage", function()
	if lastCheck > CurTime() then return end
	lastCheck = CurTime() +1

	if GAMEMODE.Jobs:GetNumPlayers( JOB_CITYWORKER ) <= 0 then return end

	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Jobs:GetPlayerJobID( v ) ~= JOB_CITYWORKER then continue end
		if (playerChecks[v] or 0) > CurTime() then continue end
		playerChecks[v] = CurTime() +math.random( GAMEMODE.Config.MinDmgEventTime, GAMEMODE.Config.MaxDmgEventTime )

		Job:SpawnNewEvent( v )
	end

	for k, v in pairs( playerChecks ) do
		if not IsValid( k ) then playerChecks[k] = nil end
	end
end )

-- hook.Add( "PlayerUse", "UseCityTruck", function( pPlayer, eEnt )
-- 	if not GAMEMODE.Jobs:PlayerIsJob( pPlayer, JOB_CITYWORKER ) then return end
-- 	if not IsValid( eEnt ) or not eEnt:IsVehicle() or not eEnt.IsCityVan then return end

-- 	local dot = (pPlayer:GetEyeTrace().HitPos -eEnt:GetPos()):GetNormal():Dot( eEnt:GetForward() )
-- 	if dot < -0.9 and CurTime() >(pPlayer.m_intLastUsedCityTruck or 0) then
-- 		GAMEMODE.Net:ShowNWMenu( pPlayer, "city_worker_van" )
-- 		pPlayer.m_intLastUsedCityTruck = CurTime() +1
-- 		return false
-- 	end
-- end )

hook.Add( "GamemodeDefineGameVars", "DefineCityWorkerVars", function( pPlayer )
	GAMEMODE.Player:DefineGameVar( pPlayer, "cwork_dest", "", "String", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "cwork_type", "", "String", true )
end )

-------------------------------------------------------------------------

Job:RegisterEvent( "broken_hydrant", {
	spawn = function( pSpawnedFor )
		Job.m_tblSpawned["broken_hydrant"] = Job.m_tblSpawned["broken_hydrant"] or {}

		local num, found, data, idx = 0, nil, nil, nil
		while true do
			data, idx = table.Random( GAMEMODE.Config.HydrantDmgPoints )
			if not Job.m_tblSpawned["broken_hydrant"][idx] then
				found = idx
				break
			end

			num = num +1
			if num >= 3 then break end
		end
		if not found then return end
		Job.m_tblSpawned["broken_hydrant"][found] = true

		local ent = ents.Create( "ent_broken_hydrant" )
		ent:SetPos( data.pos )
		ent:SetAngles( data.ang +Angle( 0, math.random(-180, 180), 0) )
		ent:Spawn()
		ent:Activate()
		ent:SetModel("models/props/cs_assault/firehydrant.mdl")
		ent:CallOnRemove( "updEvent", function()
			--done
			GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblSpawned["broken_hydrant"][found] = nil
			GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblEvents["broken_hydrant"].finish( ent.m_entRemovedBy, pSpawnedFor )
		end )

		pSpawnedFor:DeleteOnRemove( ent )
		ent.CityWorkerEnt = true
		ent.SpawnedFor = pSpawnedFor
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", tostring(data.pos) )

		return true
	end,

	finish = function( pRemover, pSpawnedFor )
		if not IsValid( pRemover ) then return end
		if not IsValid( pSpawnedFor ) then return end
		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_CITYWORKER ) then return end
		
		pSpawnedFor.m_entCurFixEvent = nil

		local pay = 500
		pRemover:AddNote( "You earned $".. pay.. " for fixing a leaking fire hydrant!" )
		pRemover:AddNote( "These funds have been sent to your bank account." )
		pRemover:AddBankMoney( pay, "City services commission" )

		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", "" )
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_type", "" )
	end,
} )

Job:RegisterEvent( "mow_grass", {
	spawn = function( pSpawnedFor )
		Job.m_tblSpawned["mow_grass"] = Job.m_tblSpawned["mow_grass"] or {}

		local num, found, data, idx = 0, nil, nil, nil
		while true do
			data, idx = table.Random( GAMEMODE.Config.MowableGrassZones )
			if not Job.m_tblSpawned["mow_grass"][idx] then
				found = idx
				break
			end

			num = num +1
			if num >= 3 then break end
		end
		if not found then return end
		Job.m_tblSpawned["mow_grass"][found] = true

		local grassEnts = {}
		local numGrass = math.random( #data.Grass *0.6, #data.Grass )
		local i = 1
		for k, v in RandomPairs( data.Grass ) do
			local ent = ents.Create( "ent_mowable_grass" )
			ent:SetPos( data.Grass[i].pos )
			ent:SetAngles( data.Grass[i].ang )
			ent:Spawn()
			ent:Activate()
			ent:CallOnRemove( "updEvent", function()
				grassEnts[ent] = nil
				if table.Count( grassEnts ) <= 0 then
					--done
					GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblSpawned["mow_grass"][found] = nil
					GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblEvents["mow_grass"].finish( pSpawnedFor )
				end
			end )

			pSpawnedFor:DeleteOnRemove( ent )
			ent.CityWorkerEnt = true
			ent.SpawnedFor = pSpawnedFor
			pSpawnedFor.m_tblMowData = data
			grassEnts[ent] = true

			GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", data.Name )
			i = i+1
			if i >= numGrass then break end
		end

		return true
	end,

	finish = function( pSpawnedFor )
		if not IsValid( pSpawnedFor ) then return end
		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_CITYWORKER ) then return end

		pSpawnedFor.m_entCurFixEvent = nil

		if pSpawnedFor.m_tblMowData then
			pSpawnedFor:AddBankMoney( pSpawnedFor.m_tblMowData.Pay, "City services commission" )
			pSpawnedFor:AddNote( "You earned $".. string.Comma(pSpawnedFor.m_tblMowData.Pay).. " for mowing grass!" )
			pSpawnedFor:AddNote( "These funds have been sent to your bank account." )
		end

		pSpawnedFor.m_tblMowData = nil
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", "" )
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_type", "" )
	end,
} )

Job:RegisterEvent( "road_debris", {
	spawn = function( pSpawnedFor )
		Job.m_tblSpawned["road_debris"] = Job.m_tblSpawned["road_debris"] or {}

		local num, found, data, idx = 0, nil, nil, nil
		while true do
			data, idx = table.Random( GAMEMODE.Config.RoadDamageSpawns )
			if not Job.m_tblSpawned["road_debris"][idx] then
				found = idx
				break
			end

			num = num +1
			if num >= 3 then break end
		end
		if not found then return end
		Job.m_tblSpawned["road_debris"][found] = true

		local ent = ents.Create( "ent_road_debris" )
		ent:SetPos( data.pos )
		ent:SetAngles( data.ang )
		ent:Spawn()
		ent:Activate()
		ent:CallOnRemove( "updEvent", function()
			--done
			GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblSpawned["road_debris"][found] = nil
			GAMEMODE.Jobs:GetJobByID( JOB_CITYWORKER ).m_tblEvents["road_debris"].finish( ent.m_entRemovedBy, pSpawnedFor )
		end )

		pSpawnedFor:DeleteOnRemove( ent )
		ent.CityWorkerEnt = true
		ent.SpawnedFor = pSpawnedFor
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", tostring(data.pos) )

		return true
	end,

	finish = function( pRemover, pSpawnedFor )
		if not IsValid( pRemover ) then return end
		if not IsValid( pSpawnedFor ) then return end
		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_CITYWORKER ) then return end
		
		pSpawnedFor.m_entCurFixEvent = nil

		local pay = 500
		pRemover:AddNote( "You earned $".. pay.. " for clearing debris off the road!" )
		pRemover:AddNote( "These funds have been sent to your bank account." )
		pRemover:AddBankMoney( pay, "City services commission" )

		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", "" )
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_type", "" )
	end,
} )


local function updatePlayer( pPlayer )
	GAMEMODE.Net:NewEvent( "ent", "cwork_van_upd" )
	GAMEMODE.Net:FireEvent( pPlayer )
end
GM.Net:RegisterEventHandle( "ent", "cwork_van_take", function( intMsgLen, pPlayer )
	local van = net.ReadEntity()
	if not IsValid( van ) or not van.IsCityVan then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_CITYWORKER then return end
	if pPlayer:GetPos():Distance( van:GetPos() ) > 200 then return end

	local itemName = net.ReadString()
	if not Job.VanItems[itemName] then return end

	local itemNum = math.Clamp( net.ReadUInt(16), 0, Job.VanItems[itemName] -GAMEMODE.Inv:GetPlayerItemAmount(pPlayer, itemName) )
	if itemNum <= 0 then return end
	
	if not GAMEMODE.Inv:PlayerHasItemEquipped( pPlayer, itemName ) then
		if GAMEMODE.Inv:GivePlayerItem( pPlayer, itemName, itemNum ) then
			updatePlayer( pPlayer )
		end
	end
end )

GM.Net:RegisterEventHandle( "ent", "cwork_van_add", function( intMsgLen, pPlayer )
	local van = net.ReadEntity()
	if not IsValid( van ) or not van.IsCityVan then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_CITYWORKER then return end
	if van:GetPos():Distance( van:GetPos() ) > 200 then return end

	local itemName = net.ReadString()
	if not Job.VanItems[itemName] then return end

	local itemNum = math.Clamp( net.ReadUInt(16), 0, GAMEMODE.Inv:GetPlayerItemAmount(pPlayer, itemName) )
	if itemNum <= 0 then return end
	
	if GAMEMODE.Inv:TakePlayerItem( pPlayer, itemName, itemNum ) then
		updatePlayer( pPlayer )
	end
end )

GM.Jobs:Register( Job )