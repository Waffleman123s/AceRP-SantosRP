--[[
	Name: taxi_driver.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 5
Job.Enum = "JOB_TAXI"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Taxi Driver"
Job.ParkingGaragePos = GM.Config.TaxiParkingZone
Job.PlayerCap = GM.Config.Job_Taxi_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarSpawns = GM.Config.TaxiCarSpawns
Job.TaxiID = "taxi_cab"
Job.TaxiChargeAmount = 3
Job.TaxiChargeInterval = 10

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_TAXI then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
end

function Job:OnPlayerSpawnTaxi( pPlayer, entCar )
	entCar.IsTaxi = true
	pPlayer:AddNote( "You spawned your taxi cab!" )
end

--Player wants to spawn a taxi
function Job:PlayerSpawnTaxiCab( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.TaxiID, self.CarSpawns, self.ParkingGaragePos )
	if IsValid( car ) then
		self:OnPlayerSpawnTaxi( pPlayer, car )
	end
end

--Player wants to stow their taxi
function Job:PlayerStowTaxiCab( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingGaragePos )
end

hook.Add( "GamemodePlayerSendTextMessage", "TaxiJobTexting", function( pSender, strText, strNumberSendTo )
	if strNumberSendTo ~= "Taxi Services" then return end
	if pSender.m_intLastTaxiText and pSender.m_intLastTaxiText > CurTime() then
		local time = math.Round( pSender.m_intLastTaxiText -CurTime() )
		GAMEMODE.Net:SendTextMessage( pSender, "Taxi Services", "You must wait ".. time.. " seconds before you can send another message to taxi services." )
		pSender:EmitSound( "santosrp/sms.mp3" )
		return true
	end
	local sentTo = 0
	strText = "Taxi Services call from ".. GAMEMODE.Player:GetGameVar(pSender, "phone_number").. "\n(".. pSender:Nick().. "):\n".. strText
	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Jobs:GetPlayerJobID( v ) == JOB_TAXI then
			GAMEMODE.Net:SendTextMessage( v, "Taxi Dispatch", strText )
			v:EmitSound( "santosrp/sms.mp3" )
			sentTo = sentTo +1
		end
	end

	local respMsg = ""
	if sentTo == 0 then
		respMsg = "No taxi services are available right now. Sorry!"
	else
		respMsg = "Your message was received by dispatch and sent to ".. sentTo.. " workers."
	end
	
	GAMEMODE.Net:SendTextMessage( pSender, "Taxi Services", respMsg )
	pSender:EmitSound( "santosrp/sms.mp3" )
	pSender.m_intLastTaxiText = CurTime() +60
	return
end )

hook.Add( "PlayerEnteredVehicle", "TaxiCharge", function( pPlayer, entVehicle, intRole )
	if IsValid( entVehicle:GetParent() ) and entVehicle:GetParent().IsTaxi then
		entVehicle:GetParent().m_tblPlayers = entVehicle:GetParent().m_tblPlayers or {}
		entVehicle:GetParent().m_tblPlayers[pPlayer] = { LastTime = 0, Count = 0 }
	end
end )

hook.Add( "PlayerLeaveVehicle", "TaxiCharge", function( pPlayer, entVehicle, intRole )
	if IsValid( entVehicle:GetParent() ) and entVehicle:GetParent().IsTaxi then
		if not entVehicle:GetParent().m_tblPlayers then return end
		entVehicle:GetParent().m_tblPlayers[pPlayer] = nil
	end
end )

local chargeAmount = Job.TaxiChargeAmount
timer.Create( "TaxiChargePlayers", 1, 0, function()
	for k, v in pairs( player.GetAll() ) do
		if not v:InVehicle() or not v:GetVehicle().IsTaxi then continue end

		for ply, data in pairs( v:GetVehicle().m_tblPlayers or {} ) do
			if CurTime() < data.LastTime then continue end
			data.LastTime = CurTime() +Job.TaxiChargeInterval

			if ply == v:GetVehicle():GetDriver() then continue end
			if ply:GetMoney() >= chargeAmount then
				ply:TakeMoney( chargeAmount, "Taxi fare" )
				v:AddMoney( chargeAmount, "Taxi fare" )

				data.Count = data.Count +1
				if data.Count >= 6 then
					ply:AddNote( "You were charged $".. chargeAmount *data.Count.. " for your time in the taxi." )
					v:AddNote( "You earned $".. chargeAmount *data.Count.. " from one of your passengers." )
					data.Count = 0
				end
			end
		end
	end
end )

GM.Jobs:Register( Job )