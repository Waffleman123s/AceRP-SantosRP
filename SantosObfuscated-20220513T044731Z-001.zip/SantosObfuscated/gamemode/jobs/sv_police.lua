--[[
	Name: police.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "police", 51 )

local Job = {}
Job.ID = 2
Job.Enum = "JOB_POLICE"
Job.Receives911Messages = true
Job.TeamColor = Color( 255, 0, 0, 255 )
Job.Name = "Police"
Job.WhitelistName = "police"
Job.PlayerModel = {
	Male_Fallback = "models/roro/police_male_2.mdl",
	Female_Fallback = "models/portal/player/female_police02.mdl",

	Male = {
		["male_01"] = "models/roro/police_male_1.mdl",
		["male_02"] = "models/roro/police_male_2.mdl",
		["male_03"] = "models/roro/police_male_3.mdl",
		["male_04"] = "models/roro/police_male_4.mdl",
		["male_05"] = "models/roro/police_male_5.mdl",
		["male_06"] = "models/roro/police_male_6.mdl",
		["male_07"] = "models/roro/police_male_7.mdl",
		["male_08"] = "models/roro/police_male_8.mdl",
		["male_09"] = "models/roro/police_male_9.mdl",
	},
	Female = {
		["female_01"] = "models/portal/player/female_police02.mdl",
	},
}
-- Job.ClothingLockerExtraModels = {
-- 	["pmc_swat"] = {
-- 		Male_Fallback = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl", --"models/player/pmc_4/pmc__11.mdl",
-- 		Female_Fallback = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl", --"models/player/pmc_4/pmc__11.mdl",

-- 		Male = {
-- 		["male_01"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
-- 		},
-- 		Female = {
-- 		["female_01"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
-- 		},
-- 	},
-- }
Job.CanWearCivClothing = true
Job.PlayerCap = GM.Config.Job_Police_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarLimit = math.ceil( Job.PlayerCap.Max *0.66 )
Job.PoliceGaragePos = GM.Config.CopParkingZone
Job.CarSpawns = GM.Config.CopCarSpawns

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 500 },
		{ PlayTime = 12 *(60 *60), Pay = 650 },
		{ PlayTime = 24 *(60 *60), Pay = 700 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 800 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 1250 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 1500 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 1900 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 4200 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 500 },
		{ PlayTime = 12 *(60 *60), Pay = 650 },
		{ PlayTime = 24 *(60 *60), Pay = 700 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 800 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 1250 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 1500 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 1900 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 4200 },
	}
end

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Police", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 1, "Police", false )
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 2, "Police Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 1
		Job.ChannelKeys = {
			[2] = true, --Police Encrypted
			[4] = true, --Fire Encrypted
			[6] = true, --EMS Encrypted
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
	pPlayer.m_bJobCivModelOverload = false
end

function Job:OnPlayerQuitJob( pPlayer )
	pPlayer.m_bJobCivModelOverload = false
	pPlayer.m_intSelectedJobModelSkin = nil
	pPlayer.m_tblSelectedJobModelBGroups = nil
	pPlayer.m_strSelectedJobModelOverload = nil

	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_POLICE then
		curCar:Remove()
	end
end

function Job:GetPlayerModel( pPlayer, bUnModified )
	if pPlayer.m_bJobCivModelOverload and not bUnModified then
		return GAMEMODE.Jobs:GetJobByID( JOB_CIVILIAN ):GetPlayerModel( pPlayer )
	end

	if pPlayer.m_strSelectedJobModelOverload and not bUnModified then
		return pPlayer.m_strSelectedJobModelOverload
	end

	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( pPlayer, "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)

	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end

function Job:PlayerSetModel( pPlayer )
	pPlayer:SetModel( self:GetPlayerModel(pPlayer) )

	local selcSkin = pPlayer.m_bJobCivModelOverload and GAMEMODE.Player:GetGameVar( pPlayer, "char_skin", 0 ) or nil
	if not selcSkin then selcSkin = pPlayer.m_intSelectedJobModelSkin end
	pPlayer:SetSkin( selcSkin and selcSkin or 0 )

	if pPlayer.m_tblSelectedJobModelBGroups then
		for k, v in pairs( pPlayer:GetBodyGroups() ) do
			if pPlayer.m_tblSelectedJobModelBGroups[v.id] then
				if pPlayer.m_tblSelectedJobModelBGroups[v.id] > pPlayer:GetBodygroupCount( v.id ) -1 then continue end
				pPlayer:SetBodygroup( v.id, pPlayer.m_tblSelectedJobModelBGroups[v.id] )
			end
		end
	end
end

function Job:PlayerLoadout( pPlayer )
	pPlayer:Give( "weapon_handcuffer" )
	pPlayer:Give( "weapon_ticket_giver" )
	-- pPlayer:Give( "dsr_megaphone" )
	--pPlayer:Give( "policebadgewallet" )
	pPlayer:SetArmor( 75 )

	if PRIVATE_SERVER then
		pPlayer:Give( "weapon_gspeak_radio_cop" )
	end
end

function Job:TextAllPlayers( strSenderName, strMsg )
	local num = 0
	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Jobs:GetPlayerJobID( v )  ~= self.ID then continue end
		GAMEMODE.Net:SendTextMessage( v, strSenderName, strMsg )
		v:EmitSound( "santosrp/sms.mp3" )
		num = num +1
	end
	return num
end

function Job:OnPlayerSpawnCopCar( pPlayer, entCar )
	local color, skin, groups = net.ReadColor(), net.ReadUInt( 8 ), net.ReadTable()
	entCar:SetColor( color )
	entCar:SetSkin( skin )

    local data = GAMEMODE.Cars:GetJobCarByUID(entCar.UID)
    if data.VehicleParams then
      GAMEMODE.Cars:ApplyVehicleParams(entCar, "VehicleParamsModify", data.VehicleParams)
    end
    
	entCar.IsCopCar = true
	pPlayer:AddNote( "Your spawned your police car!" )

	for k, v in pairs( groups ) do
		entCar:SetBodygroup( k, v )
	end
end

--Player wants to spawn a cop car
GM.Net:RegisterEventHandle( "police", "sp_c", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "cop_spawn_car" then return end

	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, net.ReadString(), Job.CarSpawns, Job.PoliceGaragePos )
	if IsValid( car ) then
		Job:OnPlayerSpawnCopCar( pPlayer, car )
	end
end )

--Player wants to stow their cop car
GM.Net:RegisterEventHandle( "police", "st", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "cop_spawn_car" then return end

	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, Job.PoliceGaragePos )
end )

function GM.Net:SendCopImpoundAppUpdate( pPlayer, pTarget )
	local lst = {}
	for uid, data in pairs( pTarget:GetCharacter().Vehicles ) do
		if data.Impounded then
			lst[#lst+1] = uid
		end
	end
	
	GAMEMODE.Net:NewEvent( "police", "sid" )
		net.WriteEntity( pTarget )
		net.WriteUInt( #lst, 16 )
		if #lst > 0 then
			for k, v in pairs( lst ) do
				net.WriteString( v )
			end
		end
	GAMEMODE.Net:FireEvent( pPlayer )
end

--Player wants to release another player's car from impound
GM.Net:RegisterEventHandle( "police", "rid", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["impound.exe"] then return end

	local owner, uid = net.ReadEntity(), net.ReadString()
	if not IsValid( owner ) or not owner:IsPlayer() then return end
	
	local ownerData = GAMEMODE.Cars:GetPlayerCarData( owner, uid )
	if not ownerData or not ownerData.Impounded then return end
	ownerData.Impounded = nil
	GAMEMODE.SQL:MarkDiffDirty( owner, "vehicles" )

	hook.Call( "GamemodeOnPlayerFreeImpoundedCar", GAMEMODE, pPlayer, owner, uid )

	owner:AddNote( "Your vehicle has been released from impound!" )
	pPlayer:AddNote( "You released a vehicle from impound!" )
	GAMEMODE.Net:SendCopImpoundAppUpdate( pPlayer, owner )

	for k, data in pairs( GAMEMODE.Econ:GetPlayerBills(owner) ) do
		if data.Type ~= "impound" then continue end
		if not data.MetaData or not data.MetaData.veh_uid then continue end

		if data.MetaData.veh_uid == uid then
			GAMEMODE.Char:GetCurrentSaveTable( owner ).Bills[k] = nil
			GAMEMODE.SQL:MarkDiffDirty( owner, "data_store", "Bills" )
			GAMEMODE.Net:SendPlayerBills( owner )
			break
		end
	end
end )

--Player is requesting a list of impounded vehicles for target
GM.Net:RegisterEventHandle( "police", "gid", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
	local target = net.ReadEntity()
	if not IsValid( target ) or not target:IsPlayer() then return end
	if not target:GetCharacter() or not target:GetCharacter().Vehicles then return end
	GAMEMODE.Net:SendCopImpoundAppUpdate( pPlayer, target )
end )

hook.Add( "KeyPress", "OpenCopComputer", function( pPlayer, intKey )
	if not GAMEMODE.Jobs:PlayerIsJob( pPlayer, JOB_POLICE ) then return end
	if not IsValid( pPlayer:GetVehicle() ) then return end
	
	if IsValid( pPlayer:GetVehicle():GetParent() ) then
		if not pPlayer:GetVehicle():GetParent().IsCopCar then return end
	else
		if not pPlayer:GetVehicle().IsCopCar then return end
	end

	if intKey == IN_RELOAD then
		GAMEMODE.Net:ShowNWMenu( pPlayer, "cop_car_computer" )
	end
end )

hook.Add( "PlayerEnteredVehicle", "CopComputerHint", function( pPlayer, entVeh, intRole )
	if not GAMEMODE.Jobs:PlayerIsJob( pPlayer, JOB_POLICE ) then return end
	if entVeh.IsCopCar then
		pPlayer:AddNote( "Press 'R' to open your police computer" )
	end
end )

hook.Add( "GamemodePlayerSendTextMessage", "PoliceJobTexting", function( pSender, strText, strNumberSendTo )
	if strNumberSendTo ~= "911" then return end
	if pSender.m_intLast911 and pSender.m_intLast911 > CurTime() then
		local time = math.Round( pSender.m_intLast911 -CurTime() )
		GAMEMODE.Net:SendTextMessage( pSender, "911", "You must wait ".. time.. " seconds before you can send another message to dispatch.", true )
		pSender:EmitSound( "santosrp/sms.mp3" )
		return true
	end

	local sentTo = 0
	strText = "911 from ".. pSender:aphone_GetNumber().. "\n(".. pSender:Nick().. "):\n".. strText
	local sendTo = {}
	util.AddNetworkString "qd.notify:ems"

	for k, v in pairs( player.GetAll() ) do
		if not GAMEMODE.Jobs:GetPlayerJob( v ) then continue end
		if GAMEMODE.Jobs:GetPlayerJob( v ).Receives911Messages then
			GAMEMODE.Net:SendTextMessage( v, "Dispatch", strText, false, pSender )
			v:EmitSound( "santosrp/sms.mp3" )
			table.insert(sendTo, v)
			sentTo = sentTo +1
		end
	end
	net.Start("qd.notify:ems")
		net.WriteEntity(pSender)
	net.Send(sendTo)

	local respMsg = ""
	if sentTo == 0 then
		respMsg = "No emergency services are available right now. Sorry!"
	else
		respMsg = "Your message was received by dispatch and sent to ".. sentTo.. " officers."
	end
	-- print(pSender:Nick())
	GAMEMODE.Net:SendTextMessage( pSender, "911", respMsg, true )
	pSender:EmitSound( "santosrp/sms.mp3" )
	-- pSender:SetNWInt("called_911", CurTime())

	pSender.m_intLast911 = CurTime() +GAMEMODE.Config.Text911CoolDown
	return true
end )

hook.Add( "GamemodeOnPlayerJailBreak", "AlertPolice", function( pJailedPlayer )
	local str = ("%s has escaped from jail!"):format( pJailedPlayer:Nick() )
	for k, v in pairs( player.GetAll() ) do
		if v == pJailedPlayer then continue end
		if GAMEMODE.Jobs:GetPlayerJobID( v ) ~= JOB_POLICE then continue end
		GAMEMODE.Net:SendTextMessage( v, "Dispatch", str )
	end
end )

hook.Add( "GamemodeBuildPlayerComputerApps", "AutoInstallCopApps", function( pPlayer, entComputer, tblApps )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_POLICE then return end
	if not entComputer.IsCopComputer then return end
	tblApps["impound.exe"] = GAMEMODE.Apps:GetComputerApp( "impound.exe" )
end )

hook.Add( "GamemodePlayerCanSpawnCar", "BlockImpoundedCars", function( pPlayer, strCarUID )
	local data = GAMEMODE.Cars:GetPlayerCarData( pPlayer, strCarUID )
	if not data then return end
	if data.Impounded then
		pPlayer:AddNote( "That vehicle is currently at impound!" )
		pPlayer:AddNote( "You must pay your impound bill to retrieve this vehicle." )
		return false
	end
end )

hook.Add( "GamemodePlayerSellCar", "RemoveImpoundBills", function( pPlayer, strCarUID )
	for uid, data in pairs( GAMEMODE.Econ:GetPlayerBills(pPlayer) ) do
		if data.Type ~= "impound" then continue end
		if not data.MetaData or not data.MetaData.veh_uid then continue end

		if data.MetaData.veh_uid == strCarUID then
			GAMEMODE.Char:GetCurrentSaveTable( pPlayer ).Bills[uid] = nil
			GAMEMODE.SQL:MarkDiffDirty( pPlayer, "data_store", "Bills" )
			GAMEMODE.Net:SendPlayerBills( pPlayer )
			break
		end
	end
end )

GM.Jobs:Register( Job )