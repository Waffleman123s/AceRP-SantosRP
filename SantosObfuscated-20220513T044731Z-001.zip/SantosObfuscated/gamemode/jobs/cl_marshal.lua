--[[
	Name: cl_marshal.lua
	For: SantosRP
	By: Xrayhunter
]]--

GM.Net:AddProtocol( "marshal", 56 )

local Job = {}
Job.ID = 1002
Job.Enum = "JOB_MARSHAL"
Job.Receives911Messages = true
Job.TeamColor = Color( 3, 165, 252, 255 )
Job.Name = "Marshal"
Job.WhitelistName = "marshal"
Job.PlayerModel = {
	Male_Fallback = "models/player/darkley/marshal_02.mdl",
	Female_Fallback = "models/player/darkley/marshal_02.mdl",

	Male = {
		["male_01"] = "models/player/darkley/marshal_01.mdl",
		["male_02"] = "models/player/darkley/marshal_02.mdl",
		["male_03"] = "models/player/darkley/marshal_03.mdl",
		["male_04"] = "models/player/darkley/marshal_04.mdl",
		["male_05"] = "models/player/darkley/marshal_05.mdl",
		["male_06"] = "models/player/darkley/marshal_05.mdl",
		["male_07"] = "models/player/darkley/marshal_05.mdl",
		["male_08"] = "models/player/darkley/marshal_05.mdl",
		["male_09"] = "models/player/darkley/marshal_05.mdl",
	},
	Female = {
		-- ["female_01"] = "models/kerry/detective/male_02.mdl",
	},
}
Job.ClothingLockerExtraModels = {
	-- ["pmc_swat"] = {
	-- 	Male_Fallback = "models/omgwtfbbq/quantum_break/characters/operators/monarchoperator01.mdl", --"models/player/pmc_4/pmc__11.mdl",
	-- 	Female_Fallback = "models/omgwtfbbq/quantum_break/characters/operators/monarchoperator01.mdl", --"models/player/pmc_4/pmc__11.mdl",

	-- 	Male = {},
	-- 	Female = {},
	-- },
}
Job.CanWearCivClothing = false
Job.PlayerCap = GM.Config.Job_Police_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.PoliceGaragePos = GM.Config.CopParkingZone
Job.CarSpawns = GM.Config.CopCarSpawns

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Police", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 7, "Marshal", false )
		-- GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 2, "Police Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 1
		-- Job.ChannelKeys = {
		-- 	[2] = true, --Police Encrypted
		-- 	[4] = true, --Fire Encrypted
		-- 	[6] = true, --EMS Encrypted
		-- }
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

function Job:GetPlayerModel( pPlayer, bUnModified )
	if pPlayer.m_bJobCivModelOverload and not bUnModified then
		return GAMEMODE.Jobs:GetJobByID( JOB_CIVILIAN ):GetPlayerModel( pPlayer )
	end

	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)

	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end 

function GM.Net:RequestSpawnMarshalCar( strJobCarID, colColor, intSkin, tblBodygroups )
	print("MARSHAL REQ?");
	self:NewEvent( "marshal", "sp_c" )
		net.WriteString( strJobCarID )
		net.WriteColor( colColor or Color(255, 255, 255, 255) )
		net.WriteUInt( intSkin or 0, 8 )
		net.WriteTable( tblBodygroups or {} )
	self:FireEvent()
end

function GM.Net:RequestStowCopCar()
	self:NewEvent( "marshal", "st" )
	self:FireEvent()
end

function GM.Net:SendCopImpoundRequest( pPlayer )
	self:NewEvent( "marshal", "gid" )
		net.WriteEntity( pPlayer )
	self:FireEvent()
end

function GM.Net:SendCopImpoundRelRequest( pPlayer, strCarUID )
	self:NewEvent( "marshal", "rid" )
		net.WriteEntity( pPlayer )
		net.WriteString( strCarUID )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "marshal", "sid", function( intMsgLen, pPlayer )
	local target = net.ReadEntity()
	local len = net.ReadUInt( 16 )
	local lst = {}
	if len > 0 then
		for i = 1, len do
			lst[#lst+1] = net.ReadString()
		end
	end
	hook.Call( "GamemodeOnGetCopImpoundRecords", GAMEMODE, target, lst )
end )

GM.Jobs:Register( Job )