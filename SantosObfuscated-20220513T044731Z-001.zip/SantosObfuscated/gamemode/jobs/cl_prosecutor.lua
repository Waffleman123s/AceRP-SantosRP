--[[
	Name: prosecutor.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 11
Job.Enum = "JOB_PROSECUTOR"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Prosecutor"
Job.WhitelistName = "Prosecutor"
Job.PlayerCap = GM.Config.Job_Prosecutor_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

GM.Jobs:Register( Job )