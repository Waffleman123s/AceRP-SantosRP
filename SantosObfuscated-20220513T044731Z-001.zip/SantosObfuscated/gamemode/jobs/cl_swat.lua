--[[
Original Creators: MazeRP Development Team
Modified and reworked by: GNetRP Development Team
Legal Information: Legal@gnetrp.com
Extra Information: www.gnetrp.com or www.gnetrp.gg | https://discord.gg/2Mnk937aMn | @Tylr#9999 STEAM_0:1:71010553 @Krusty STEAM_0:1:164681911 @Meaty STEAM_0:1:151895828 | https://github.com/TylrDevs | https://github.com/gnetrp |
]]--

GM.Net:AddProtocol( "police", 51 )

local Job = {}
Job.ID = 170
Job.Enum = "JOB_SWAT"
Job.Receives911Messages = true
Job.TeamColor = Color( 55, 55, 200, 255 )
Job.Name = "SWAT"
Job.WhitelistName = "swat"
Job.PlayerModel = {
	Male_Fallback = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	Female_Fallback = "models/serc/faced_pmcs/female/f6/4/pmc.mdl",

	Male = {
	["male_01"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_02"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_03"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_04"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_05"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_06"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_07"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_08"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	["male_09"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl"
	},
	Female = {
		["female_01"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
		["female_02"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
		["female_03"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
		["female_04"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
		["female_06"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
		["female_07"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
	},
}
Job.CanWearCivClothing = true
Job.PlayerCap = { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.PoliceGaragePos = GM.Config.CopParkingZone
Job.CarSpawns = GM.Config.CopCarSpawns

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

function Job:GetPlayerModel( pPlayer, bUnModified )
	if pPlayer.m_bJobCivModelOverload and not bUnModified then
		return GAMEMODE.Jobs:GetJobByID( JOB_CIVILIAN ):GetPlayerModel( pPlayer )
	end

	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)

	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end

function GM.Net:RequestSpawnCopCar( strJobCarID, colColor, intSkin, tblBodygroups )
	self:NewEvent( "police", "sp_c" )
		net.WriteString( strJobCarID )
		net.WriteColor( colColor or Color(255, 255, 255, 255) )
		net.WriteUInt( intSkin or 0, 8 )
		net.WriteTable( tblBodygroups or {} )
	self:FireEvent()
end

function GM.Net:RequestStowSwatCar()
	self:NewEvent( "swat", "st" )
	self:FireEvent()
end

function GM.Net:SendSwatImpoundRequest( pPlayer )
	self:NewEvent( "swat", "gid" )
		net.WriteEntity( pPlayer )
	self:FireEvent()
end

function GM.Net:SendSwatImpoundRelRequest( pPlayer, strCarUID )
	self:NewEvent( "police", "rid" )
		net.WriteEntity( pPlayer )
		net.WriteString( strCarUID )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "Swat", "sid", function( intMsgLen, pPlayer )
	local target = net.ReadEntity()
	local len = net.ReadUInt( 16 )
	local lst = {}
	if len > 0 then
		for i = 1, len do
			lst[#lst+1] = net.ReadString()
		end
	end
	hook.Call( "GamemodeOnGetCopImpoundRecords", GAMEMODE, target, lst )
end )

GM.Jobs:Register( Job )