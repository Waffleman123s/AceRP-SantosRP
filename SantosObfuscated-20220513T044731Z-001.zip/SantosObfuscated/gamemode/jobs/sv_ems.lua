--[[
	Name: ems.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "ems", 53 )

local Job = {}
Job.ID = 3
Job.HasMasterKeys = true
Job.Receives911Messages = true
Job.Enum = "JOB_EMS"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Paramedic"
Job.PlayerModel = {
	Male_Fallback = "models/player/portal/male_09_medic.mdl",
	Female_Fallback = "models/player/portal/male_09_medic.mdl",
	
	Male = {
		["male_01"] = "models/player/portal/male_01_medic.mdl",
		["male_02"] = "models/player/portal/male_02_medic.mdl",
		["male_03"] = "models/player/portal/male_03_medic.mdl",
		["male_04"] = "models/player/portal/male_04_medic.mdl",
		["male_05"] = "models/player/portal/male_05_medic.mdl",
		["male_06"] = "models/player/portal/male_06_medic.mdl",
		["male_07"] = "models/player/portal/male_07_medic.mdl",
		["male_08"] = "models/player/portal/male_08_medic.mdl",
		["male_09"] = "models/player/portal/male_09_medic.mdl",
	},
	Female = {
		["female_01"] = "models/player/portal/male_02_medic.mdl",
		["female_02"] = "models/player/portal/male_02_medic.mdl",
		["female_03"] = "models/player/portal/male_02_medic.mdl",
		["female_04"] = "models/player/portal/male_04_medic.mdl",
		["female_05"] = "models/player/portal/male_05_medic.mdl",
		["female_06"] = "models/player/portal/male_06_medic.mdl",
		["female_07"] = "models/player/portal/male_07_medic.mdl",
		["female_08"] = "models/player/portal/male_08_medic.mdl",
		["female_09"] = "models/player/portal/male_09_medic.mdl",
	},
}
Job.PlayerCap = GM.Config.Job_EMS_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarLimit = math.ceil( Job.PlayerCap.Max *0.66 )
Job.ParkingLotPos = GM.Config.EMSParkingZone
Job.CarSpawns = GM.Config.EMSCarSpawns
Job.FirstRespondID = "ems_firstrespond"
--Job.FirstResponderID = "ford_explorer_2013_ems"
Job.AmbulanceID = "ems_ambulance"
Job.BedModel = "models/custommodels/stretcher.mdl"

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 50 },
		{ PlayTime = 12 *(60 *60), Pay = 55 },
		{ PlayTime = 24 *(60 *60), Pay = 60 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 70 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 125 },
		{ PlayTime = (24 *(60 *60)) *14, Pay = 150 },
		{ PlayTime = (24 *(60 *60)) *30, Pay = 190 },
		{ PlayTime = (24 *(60 *60)) *365, Pay = 420 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 50 },
		{ PlayTime = 12 *(60 *60), Pay = 55 },
		{ PlayTime = 24 *(60 *60), Pay = 60 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 70 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 125 },
		{ PlayTime = (24 *(60 *60)) *14, Pay = 150 },
		{ PlayTime = (24 *(60 *60)) *30, Pay = 190 },
		{ PlayTime = (24 *(60 *60)) *365, Pay = 420 },
	}
end

--[[if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 18 },
		{ PlayTime = 4 *(60 *60), Pay = 22 },
		{ PlayTime = 12 *(60 *60), Pay = 27 },
		{ PlayTime = 24 *(60 *60), Pay = 34 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 42 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 52 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 65 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 81 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 100 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 125 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 18 },
		{ PlayTime = 4 *(60 *60), Pay = 22 },
		{ PlayTime = 12 *(60 *60), Pay = 27 },
		{ PlayTime = 24 *(60 *60), Pay = 34 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 42 },
		{ PlayTime = (24 *(60 *60)) *3, Pay = 52 },
		{ PlayTime = (24 *(60 *60)) *4, Pay = 65 },
		{ PlayTime = (24 *(60 *60)) *5, Pay = 81 },
		{ PlayTime = (24 *(60 *60)) *6, Pay = 100 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 125 },
	}
end]]

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_EMS", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 5, "EMS", false )
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 6, "EMS Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 5
		Job.ChannelKeys = {
			[2] = true, --Police Encrypted
			[4] = true, --Fire Encrypted
			[6] = true, --EMS Encrypted
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_EMS then
		curCar:Remove()
	end
end

function Job:PlayerSetModel( pPlayer )
	local charData = GAMEMODE.Char:GetPlayerCharacter( pPlayer )
	if not charData then return end

	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( pPlayer, "char_model_base", "" ),
		charData.Sex == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)

	if valid then
		pPlayer:SetModel( mdl )
	else
		if charData.Sex == GAMEMODE.Char.SEX_MALE then
			pPlayer:SetModel( self.PlayerModel.Male_Fallback )
		elseif charData.Sex == GAMEMODE.Char.SEX_FEMALE then
			pPlayer:SetModel( self.PlayerModel.Female_Fallback )
		end
	end

	pPlayer:SetSkin( 0 )
end

function Job:PlayerLoadout( pPlayer )
	pPlayer:Give( "weapon_defib" )

	if PRIVATE_SERVER then
		pPlayer:Give( "weapon_gspeak_radio_ems" )
	end
end

function Job:OnPlayerSpawnFirstRespondCar( pPlayer, entCar )
	entCar:SetSkin( 7 )
	--[[entCar:SetBodygroup( 2, 3 )
	entCar:SetBodygroup( 4, 1 )
	entCar:SetBodygroup( 5, 1 )
	entCar:SetBodygroup( 6, 2 )
	entCar:SetBodygroup( 7, 4 )
	entCar:SetBodygroup( 9, 3 )
	entCar:SetBodygroup( 10, 2 )
	entCar:SetBodygroup( 11, 1 )
	entCar:SetBodygroup( 12, 1 )
	entCar:SetBodygroup( 15, 1 )
	entCar:SetBodygroup( 16, 2 )]]--

	pPlayer:AddNote( "Your spawned your first responder vehicle!" )
end

function Job:OnPlayerSpawnAmbulance( pPlayer, entCar )
	entCar:SetSkin( 7 )
	entCar.IsAmbulance = true
	
	local btn = ents.Create( "ent_button" )
	btn:SetModel( "models/maxofs2d/button_06.mdl" )
	btn:SetIsToggle( true )
	btn:SetPos( entCar:LocalToWorld(Vector(55, -158, 60)) )
	btn:SetAngles( entCar:GetAngles() +Angle(90, 0, 0) )
	btn:SetParent( entCar )
	btn:Spawn()
	btn:SetLabel( "Open/Close Door" )
	btn.BlockPhysGun = true
	btn:SetCanUseCallback( function( entBtn, pPlayer )
		return GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_EMS
	end )

	function btn:Toggle( bEnable, pPlayer )
		local toggle = entCar:GetPoseParameter( "doors_opening" )
		entCar:SetPoseParameter( "doors_opening", toggle == 1 and 0 or 1 )
		self:SetOn( entCar:GetPoseParameter("doors_opening") == 1 )
	end
	
	local bed = ents.Create( "ent_stretcher" )
	bed:SetPos( entCar:LocalToWorld(Vector(46.100838, -89.551132, 65.100494)) )
	bed:SetAngles( entCar:LocalToWorldAngles(Angle(0, 180, 0)) )
	bed:Spawn()
	bed:GetPhysicsObject():SetMass( 5 )
	bed:SetParent( entCar )
	
	local index = entCar:EntIndex()
	timer.Create( "AmbulanceAdd".. index, 3, 0, function()
		if not IsValid( entCar ) then timer.Destroy( "AmbulanceAdd".. index ) return end
		
		local snapto = entCar:LocalToWorld( Vector(20, -160, 38) )
		for k, prop in pairs( ents.FindByClass("ent_stretcher") ) do
			if not IsValid( prop ) then continue end
			if prop:GetModel() ~= self.BedModel then continue end
			if prop:GetParent() == veh then continue end

			if not prop.LastReleased then continue end
			if prop.LastReleased > CurTime() -5 then continue end
			if prop:GetPos():Distance( snapto ) < 100 then
				prop:SetPos( entCar:LocalToWorld(Vector(46.100838, -89.551132, 65.100494)) )
				prop:SetAngles( entCar:LocalToWorldAngles(Angle(0, 180, 0)) )
				prop:SetParent( entCar )
				prop:EmitSound( Sound("weapons/crossbow/hit1.wav") )
				prop.LastReleased = nil
			end
		end
	end )
	
	entCar:DeleteOnRemove( btn )
	entCar:DeleteOnRemove( bed )
	pPlayer:AddNote( "Your spawned your ambulance!" )
end

hook.Add( "CanExitVehicle", "EMS_Stretcher", function( entCar, pPlayer )
	if entCar.IsStretcher then
		local parent = entCar:GetMoveParent()
		if IsValid( parent ) then parent = parent:GetParent() end
		
		return not pPlayer:IsUncon() and not IsValid( parent )
	end
end )

hook.Add( "PlayerLeaveVehicle", "EMS_Stretcher_ReUnconscious", function( pPlayer, entCar )
	if entCar.IsStretcher then
		if IsValid( entCar:GetMoveParent() ) and IsValid( entCar:GetMoveParent():GetParent() ) then
			pPlayer:SetPos( entCar:GetMoveParent():GetParent():LocalToWorld(Vector(-20, -200, 10)) )
		end
		
		if pPlayer:IsUncon() then
			entCar.m_intLastTouch = CurTime() +5
			GAMEMODE.Util:NextTick( function()
				if not IsValid( pPlayer ) then return end
				pPlayer:BecomeRagdoll()
			end )
		end
	end
end )

function Job:OnPlayerSpawnEMSCar( pPlayer, entCar )
	if not entCar.UID then return end
	if entCar.UID == self.AmbulanceID then
		self:OnPlayerSpawnAmbulance( pPlayer, entCar )
	elseif entCar.UID == self.FirstRespondID then
		self:OnPlayerSpawnFirstRespondCar( pPlayer, entCar )
	else
		pPlayer:AddNote( "Your spawned your EMS vehicle!" )
	end

	local color, groups = net.ReadColor(), net.ReadTable()
	entCar:SetColor( color )
	for k, v in pairs( groups ) do
		entCar:SetBodygroup( k, v )
	end
end

function GM.Net:SendPlayerEMSClipboardData( pPlayer, pAbout )
	self:NewEvent( "ems", "clip" )
		net.WriteEntity( pAbout )
		net.WriteUInt( pAbout:Health(), 8 )

		for k, v in pairs( GAMEMODE.PlayerDamage:GetLimbs() ) do
			net.WriteUInt( k, 8 )
			net.WriteUInt( GAMEMODE.PlayerDamage:GetPlayerLimbHealth(pAbout, k), 8 )
			net.WriteBool( GAMEMODE.PlayerDamage:IsPlayerLimbBleeding(pAbout, k) )
			net.WriteBool( GAMEMODE.PlayerDamage:IsPlayerLimbBroken(pAbout, k) )
		end
	self:FireEvent( pPlayer )
end

function Job:CalcHealPay( tblClipData )
	local total = 100--Max player health
	local cur = tblClipData.health
	for k, v in pairs( GAMEMODE.PlayerDamage:GetLimbs() ) do --Add up limb health, account for broken and bleeding limbs
		if not tblClipData.limbs[k] then continue end
		total = total +v.MaxHealth
		total = total +20 --10 for bleeding, 10 for broken

		cur = cur +tblClipData.limbs[k].health
		cur = cur +(tblClipData.limbs[k].bleeding and 0 or 10)
		cur = cur +(tblClipData.limbs[k].broken and 0 or 10)
	end

	local scalar = math.Clamp( (total -cur) /total, 0, 1 ) --amount of damage, 0 - 1

	local pay = math.ceil( GAMEMODE.Config.EMSMaxHealPay *scalar )
	return pay
end

hook.Add( "GamemodeBuildPlayerComputerApps", "AutoInstallEMSApps", function( pPlayer, entComputer, tblApps )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_EMS then return end
	if not entComputer.IsEMSComputer then return end
	tblApps["admissions.exe"] = GAMEMODE.Apps:GetComputerApp( "admissions.exe" )
	tblApps["meddb.exe"] = GAMEMODE.Apps:GetComputerApp( "meddb.exe" )
end )

GM.Net:RegisterEventHandle( "ems", "sp_c", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_EMS then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "ems_spawn_car" then return end

	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, net.ReadString(), Job.CarSpawns, Job.ParkingLotPos )
	if IsValid( car ) then
		Job:OnPlayerSpawnEMSCar( pPlayer, car )
	end
end )

GM.Net:RegisterEventHandle( "ems", "st", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_EMS then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "ems_spawn_car" then return end

	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, Job.ParkingLotPos )
end )

function GM.Net:ResetPlayerClipboardData( pPlayer )
	self:NewEvent( "ems", "clipr" )
	self:FireEvent( pPlayer )
end

GM.Net:RegisterEventHandle( "ems", "billp", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["admissions.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_EMS then return end
	if not pPlayer.m_tblLastClipData or not IsValid( pPlayer.m_tblLastClipData.player ) then return end
	if (pPlayer.m_intLastMedBillP or 0) > CurTime() then return end
	pPlayer.m_intLastMedBillP = CurTime() +5

	local target = pPlayer.m_tblLastClipData.player
	if pPlayer == target then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( target )
	if not saveTable then return end

	local healed = true
	if target:Health() < 100 then healed = false end
	if GAMEMODE.PlayerDamage:PlayerHasDamagedLimbs( target ) then healed = false end
	
	if not healed then
		pPlayer:AddNote( "This player is not yet fully healed!" )
		return
	end

	local pay = GAMEMODE.Jobs:GetJobByID( JOB_EMS ):CalcHealPay( pPlayer.m_tblLastClipData )
	if pay <= 0 then
		pPlayer:AddNote( "No damage was recorded for this player!" )
		return
	end

	local notes = net.ReadString()
	if isstring( notes ) and notes:len() > GAMEMODE.Config.MaxEMSNoteLen then
		pPlayer:AddNote( "Your notes exceed the maximum allowable length!" )
		return
	end

	local time = os.time()
	local billUID = tostring( time +CurTime() )

	saveTable.EMSRecords = saveTable.EMSRecords or {}
	table.insert( saveTable.EMSRecords, {
		doctor_name = pPlayer:Nick(),
		doctor_sid = pPlayer:SteamID64(),
		doctor_cid = pPlayer:GetCharacterID(),
		notes = (notes or "N/A"):Replace("\\", "/"):Replace( "\n", "\\n" ),
		charge = pay,
		time = time,
		clipdata = pPlayer.m_tblLastClipData,
		uid = billUID,
	} )

	if #saveTable.EMSRecords > GAMEMODE.Config.MaxMedicalRecords then
		repeat
			table.remove( saveTable.EMSRecords, 1 )
		until #saveTable.EMSRecords <= GAMEMODE.Config.MaxMedicalRecords
	end
	GAMEMODE.SQL:MarkDiffDirty( target, "data_store", "EMSRecords" )

	pPlayer:AddMoney( pay, "EMS billing services" )
	GAMEMODE.Econ:IssuePlayerBill( target, "medical", "Medical Services", pay, 0, {
		bill_from = { sid = pPlayer:SteamID64(), cid = pPlayer:GetCharacterID(), name = pPlayer:Nick() },
		time = time,
		uid = billUID,
	} )

	target:AddNote( ("You have been billed $%s for medical treatment."):format(string.Comma(pay)) )
	pPlayer:AddNote( ("You were paid $%s for providing medical services!"):format(string.Comma(pay)) )

	--Invalidation time
	for k, v in pairs( player.GetAll() ) do
		if v.m_tblLastClipData and v.m_tblLastClipData.player == target then
			v.m_tblLastClipData = nil
			GAMEMODE.Net:ResetPlayerClipboardData( v )
		end
	end
end )

GM.Net:RegisterEventHandle( "ems", "rdbd", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["meddb.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_EMS then return end
	if (pPlayer.m_intLastMedDBR or 0) > CurTime() then return end
	pPlayer.m_intLastMedDBR = CurTime() +3

	local target = net.ReadEntity()
	if not IsValid( target ) or not target:IsPlayer() or (target:GetCharacterID() or 0) < 1  then return end
	
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( target )
	if not saveTable or not saveTable.EMSRecords then saveTable.EMSRecords = {} end

	local billData = {} --collect unpaid medical bills
	local totalBillCost = 0
	for k, v in pairs( GAMEMODE.Econ:GetPlayerBills(target) ) do
		if v.Type ~= "medical" or not v.MetaData or not v.MetaData.uid then continue end
		billData[#billData +1] = v.MetaData.uid
		totalBillCost = totalBillCost +v.Cost
	end

	local data = util.Compress( util.TableToJSON(saveTable.EMSRecords) )
	GAMEMODE.Net:NewEvent( "ems", "sdbd" )
		net.WriteEntity( target )
		net.WriteUInt( #data, 32 )
		net.WriteData( data, #data )

		net.WriteUInt( totalBillCost, 32 )

		net.WriteUInt( #billData, 16 )
		for k, v in pairs( billData ) do
			net.WriteString( v )
		end
	GAMEMODE.Net:FireEvent( pPlayer )
end )

GM.Jobs:Register( Job )