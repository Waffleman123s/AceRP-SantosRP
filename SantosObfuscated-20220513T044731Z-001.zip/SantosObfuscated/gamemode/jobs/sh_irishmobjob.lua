--[[
	Name: irishmobjob.lua
	For: ProjectSteele.Com
	By: Christopher Steele + Fern
]]--

local Job = {}
Job.ID = 888
Job.Enum = "JOB_IRISH"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Irish Mob"
Job.WhitelistName = "irishmob"
Job.Name = "Irish Mob"
Job.ParkingGaragePos = GM.Config.IrishParkingZone
Job.Pay = {
	{ PlayTime = 0, Pay = 15 },
}
Job.PlayerCap = { Min = 5, MinStart = 8, Max = 10, MaxEnd = 60 }
Job.HasChatRadio = false
Job.DefaultChatRadioChannel = 666
Job.ChannelKeys = {}
Job.CarSpawns = GM.Config.IrishCarSpawns
Job.SUVID = "irish_car"

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )

	if curCar and curCar.Job and curCar.Job == JOB_IRISH then
		curCar:Remove()
	end
end

-- function Job:GetPlayerModel( pPlayer, bUnModified )
-- 	if pPlayer.m_bJobCivModelOverload and not bUnModified then
-- 		return GAMEMODE.Jobs:GetJobByID( JOB_CIVILIAN ):GetPlayerModel( pPlayer )
-- 	end

-- 	local valid, mdl
-- 	if SERVER then
-- 		valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
-- 			GAMEMODE.Player:GetGameVar( pPlayer, "char_model_base", "" ),
-- 			GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
-- 			self.PlayerModel
-- 		)
-- 	else
-- 		valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
-- 			GAMEMODE.Player:GetGameVar( "char_model_base", "" ),
-- 			GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
-- 			self.PlayerModel
-- 		)
-- 	end

-- 	if valid then
-- 		return mdl
-- 	else
-- 		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
-- 			return self.PlayerModel.Male_Fallback
-- 		else
-- 			return self.PlayerModel.Female_Fallback
-- 		end
-- 	end
-- end

-- if SERVER then
-- 	function Job:PlayerSetModel( pPlayer )
-- 		pPlayer:SetModel( self:GetPlayerModel(pPlayer) )
-- 		pPlayer:SetSkin( not pPlayer.m_bJobCivModelOverload and
-- 			(pPlayer.m_intSelectedJobModelSkin or 0) or
-- 			GAMEMODE.Player:GetGameVar( pPlayer, "char_skin", 0 )
-- 		)

-- 		if pPlayer.m_tblSelectedJobModelBGroups then
-- 			for k, v in pairs( pPlayer:GetBodyGroups() ) do
-- 				if pPlayer.m_tblSelectedJobModelBGroups[v.id] then
-- 					if pPlayer.m_tblSelectedJobModelBGroups[v.id] > pPlayer:GetBodygroupCount( v.id ) -1 then continue end
-- 					pPlayer:SetBodygroup( v.id, pPlayer.m_tblSelectedJobModelBGroups[v.id] )
-- 				end
-- 			end
-- 		end
-- 	end
-- end

if SERVER then
	function Job:PlayerLoadout( pPlayer )
	end

	function Job:OnPlayerSpawnSUVCar( pPlayer, entCar )
		pPlayer:AddNote( "You spawned your SUV!" )
		entCar:SetColor(Color(33, 33, 33))
	end

	--Player wants to spawn a SUV
	function Job:PlayerSpawnSUVCar( pPlayer )
		local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.SUVID, self.CarSpawns, self.ParkingGaragePos )
		if IsValid( car ) then
			self:OnPlayerSpawnSUVCar( pPlayer, car )
		end
	end

	--Player wants to stow their SUV
	function Job:PlayerStowSUV( pPlayer )
		GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingGaragePos )
	end
end

GM.Jobs:Register( Job )