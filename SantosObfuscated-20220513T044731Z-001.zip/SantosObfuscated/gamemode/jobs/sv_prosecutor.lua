--[[
	Name: prosecutor.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 11
Job.Enum = "JOB_PROSECUTOR"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Prosecutor"
Job.WhitelistName = "Prosecutor"
Job.PlayerCap = GM.Config.Job_Prosecutor_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 800 },
		{ PlayTime = 4 *(60 *60), Pay = 1000 },
		{ PlayTime = 12 *(60 *60), Pay = 1200 },
		{ PlayTime = 24 *(60 *60), Pay = 1500 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 800 },
		{ PlayTime = 4 *(60 *60), Pay = 1000 },
		{ PlayTime = 12 *(60 *60), Pay = 1200 },
		{ PlayTime = 24 *(60 *60), Pay = 1500 },
	}
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

function Job:PlayerLoadout( pPlayer )
end

GM.Jobs:Register( Job )