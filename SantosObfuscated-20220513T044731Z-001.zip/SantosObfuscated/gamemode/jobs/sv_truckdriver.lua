local Job = {}
Job.ID = 17
Job.Enum = "JOB_TRUCKDRIVER"
Job.TeamColor = Color(255, 100, 160, 255)
Job.Name = "Truck Driver"

Job.PlayerCap = {
	Min = 2,
	MinStart = 8,
	Max = 2,
	MaxEnd = 60
}

Job.ParkingLotPos = GM.Config.TowParkingZone
Job.TruckSpawns = GM.Config.TowCarSpawns
Job.TruckID = "peterbilt_379"
Job.m_tblTrailers = JOB_TRUCKDRIVER and GAMEMODE.Jobs:GetJobByID(JOB_TRUCKDRIVER).m_tblTrailers or {}

Job.Pay = {
	{
		PlayTime = 0,
		Pay = 35
	},
	{
		PlayTime = 4 * (60 * 60),
		Pay = 40
	},
	{
		PlayTime = 12 * (60 * 60),
		Pay = 45
	},
	{
		PlayTime = 24 * (60 * 60),
		Pay = 50
	},
	{
		PlayTime = (24 * (60 * 60)) * 2,
		Pay = 75
	},
	{
		PlayTime = (24 * (60 * 60)) * 7,
		Pay = 90
	}
}

Job.TruckJobs = {
	{
		DropOffName = "The Skatgit Casino", --Done Riverden
		PickupPlace = "Lumber Mill",
		DropOffPosition = Vector(-6190.838379, 13368.272461, 56.226406),
		TrailerModel = "models/sentry/trailers/stortrailer.mdl",
		TrailerScript = "scripts/vehicles/sentry/stortrailer.txt",
		Spawns = {{Vector(768.955017, -10311.767578, -197.838684), Angle(0, 0, 0)}, {Vector(1211.522949, -10315.021484, -197.838684), Angle(0, 0, 0)}, {Vector(1229.205200, -11157.569336, -197.707092), Angle(0, 0, 0)}},
		Payout = math.random(500, 1000),
		TrailerType = "regular"
	},
	{
		DropOffName = "7-Twelve", --Done Riverden
		PickupPlace = "Lumber Mill",
		DropOffPosition = Vector(-10153.000000, 2087.720703, -184.415390),
		TrailerModel = "models/sentry/trailers/stortrailer.mdl",
		TrailerScript = "scripts/vehicles/sentry/stortrailer.txt",
		Spawns = {{Vector(768.955017, -10311.767578, -160.838684), Angle(0, 0, 0)}, {Vector(1211.522949, -10315.021484, -197.838684), Angle(0, 0, 0)}, {Vector(1229.205200, -11157.569336, -197.707092), Angle(0, 0, 0)}},
		Payout = math.random(500, 1000),
		TrailerType = "regular"
	},
	{
		DropOffName = "Keystone Park Gas Station", --Done Riverden
		PickupPlace = "Lumber Mill",
		DropOffPosition = Vector(6678.463379, -13586.392578, 843.239075),
		TrailerModel = "models/sentry/trailers/stortrailer.mdl",
		TrailerScript = "scripts/vehicles/sentry/stortrailer.txt",
		Spawns = {{Vector(768.955017, -10311.767578, -197.838684), Angle(0, 0, 0)}, {Vector(1211.522949, -10315.021484, -197.838684), Angle(0, 0, 0)}, {Vector(1229.205200, -11157.569336, -197.707092), Angle(0, 0, 0)}},
		Payout = math.random(500, 1000),
		TrailerType = "regular"
	},
	{
		DropOffName = "7-Twelve", --Done Riverden
		PickupPlace = "Old Town Radio Tower",
		DropOffPosition = Vector(-10153.000000, 2087.720703, -184.415390),
		TrailerModel = "models/sentry/trailers/bevtrailer.mdl",
		TrailerScript = "scripts/vehicles/sentry/bevtrailer.txt",
		Spawns = {{Vector(13786.279297, -8915.547852, 839.676514), Angle(0, 90, 0)}, {Vector(12445.986328, -8553.523438, 841.323608), Angle(0, 90, 0)}, {Vector(12357.947266, -7956.346680, 836.094666), Angle(0, 90, 0)}},
		Payout = math.random(500, 1000),
		TrailerType = "regular"
	},
	{
		DropOffName = "GM Dealership", --Done Riverden
		PickupPlace = "Old Town Radio Tower",
		DropOffPosition = Vector(-3037.410156, 11151.016602, 57.608585),
		TrailerModel = "models/sentry/trailers/carcarrier.mdl",
		TrailerScript = "scripts/vehicles/sentry/trailer.txt",
		Spawns = {{Vector(13786.279297, -8915.547852, 839.676514), Angle(0, 90, 0)}, {Vector(12445.986328, -8553.523438, 841.323608), Angle(0, 90, 0)}, {Vector(12357.947266, -7956.346680, 836.094666), Angle(0, 90, 0)}},
		Payout = math.random(500, 1000),
		TrailerType = function(ent)
			local Cars = {}

			Cars["models/tdmcars/aud_rs4avant.mdl"] = {
				Pos = ent:LocalToWorld(Vector(-0.785796, -42.994804, 152.545029)),
				Ang = Angle(0, 90, -12)
			}

			Cars["models/lonewolfie/bugatti_veyron_grandsport.mdl"] = {
				Pos = ent:LocalToWorld(Vector(0, -40, 40)),
				Ang = Angle(0, 90, -9)
			}

			Cars["models/tdmcars/dod_challenger70.mdl"] = {
				Pos = ent:LocalToWorld(Vector(0, -258, 132)),
				Ang = Angle(0, 90, 20)
			}

			Cars["models/tdmcars/lam_gallardospyd.mdl"] = {
				Pos = ent:LocalToWorld(Vector(0, 140, 73)),
				Ang = Angle(0, 90, -5)
			}

			Cars["models/tdmcars/bug_veyron.mdl"] = {
				Pos = ent:LocalToWorld(Vector(0, -250, 55)),
				Ang = Angle(0, 90, 15)
			}

			for k, v in pairs(Cars) do
				local x = ents.Create("prop_physics")
				x:SetModel(k)
				x:SetPos(v.Pos)
				x:SetAngles(v.Ang)
				x:SetParent(ent)
				x:Spawn()
				x:Activate()
				x:SetColor(Color(math.random(1, 255), math.random(1, 255), math.random(1, 255)))
				ent.ChildrenENTS = ent.ChildrenENTS or {}
				ent.ChildrenENTS[x] = true
			end
		end
	}
}

function Job:OnPlayerJoinJob(pPlayer)
	pPlayer:SetNWBool("InTruckJob", false)
end

function Job:OnPlayerQuitJob(pPlayer)
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer)
	pPlayer:SetNWBool("InTruckJob", false)

	if curCar and curCar.Job and curCar.Job == JOB_TRUCKDRIVER then
		curCar:Remove()
	end
end

function Job:PlayerLoadout(pPlayer)
end

function Job:OnPlayerSpawnTruck(pPlayer, entTruck)
	pPlayer:SetNWBool("InTruckJob", false)
	entTruck:SetColor(Color(33, 33, 33))
	entTruck.IsTrailerTruck = true
	entTruck.TowBlocked = true
	pPlayer:AddNote("You spawned your truck!")
end

function Job:PlayerSpawnTruck(pPlayer)
	local car = GAMEMODE.Cars:PlayerSpawnJobCar(pPlayer, self.TruckID, self.TruckSpawns, self.ParkingLotPos)

	if IsValid(car) then
		self:OnPlayerSpawnTruck(pPlayer, car)
	end
end

function Job:PlayerStowTruck(pPlayer)
	GAMEMODE.Cars:PlayerStowJobCar(pPlayer, self.ParkingLotPos)
end

function Job:CreateTrailer(pPlayer, tJob)
	local truck = GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer)
	if not IsValid(truck) then return end
	local pos, ang = GAMEMODE.Util:FindSpawnPoint(tJob.Spawns, 80)

	if not pos then
		pPlayer:AddNote("Unable to find a spawn point for your trailer.")
		pPlayer:AddNote("Wait for the area to clear and try again.")

		return
	end

	local e = ents.Create("prop_vehicle_jeep")
	e:SetModel(tJob.TrailerModel)
	e:SetKeyValue("vehiclescript", tJob.TrailerScript)
	e:SetPos(pos)
	e:SetAngles(ang)
	e.AdminPhysGun = true
	e:Spawn()
	e:Activate()
	e:SetPlayerOwner(pPlayer)
	e.CurrentJob = tJob
	e.IsTrailer = true
	pPlayer.m_eActiveTrailer = e
	e.ParentTruck = truck
	truck.CurrentTrailer = e
	e.IsLocked = true

	if isfunction(tJob.TrailerType) then
		tJob.TrailerType(e)
	end

	self.m_tblTrailers[e] = true

	return e
end

function Job:StartDelivery(pPlayer)
	if GAMEMODE.Jobs:GetPlayerJobID(pPlayer) ~= JOB_TRUCKDRIVER then return end

	if pPlayer:GetNWBool("InTruckJob") then
		pPlayer:AddNote("You cannot start another delivery job with one already active!")

		return
	end

	local job = table.Random(self.TruckJobs)
	if pPlayer.CurrentJob == job then return self:StartDelivery(pPlayer) end
	local ent = self:CreateTrailer(pPlayer, job)
	if not IsValid(ent) then return end
	pPlayer:SetNWBool("InTruckJob", true)
	pPlayer:SetNWEntity("Trailer", ent)
	pPlayer:SetNWString("TrailerDropoff", job.DropOffName)
	pPlayer:SetNWString("TrailerPickup", job.PickupPlace)
	pPlayer:SetNWVector("TrailerDropPos", job.DropOffPosition)
	pPlayer:AddNote("Pickup your trailer at " .. job.PickupPlace)
	pPlayer:AddNote("Once you have picked up your trailer, deliver it to " .. job.DropOffName)
end

function Job:CancelDelivery(pPlayer)
	pPlayer:SetNWBool("InTruckJob", false)

	if IsValid(pPlayer.m_eActiveTrailer) then
		pPlayer.m_eActiveTrailer:Remove()
	end
end

function Job:TrailerFix()
	for k, v in pairs(self.m_tblTrailers) do
		if not IsValid(k) or not k.CurrentJob then continue end
		if not IsValid(k.ParentTruck) then continue end

		for _, ent in pairs(ents.FindInSphere(k:LocalToWorld(k:OBBCenter()) + k:GetForward() * 340, 50)) do
			if ent == k.ParentTruck then
				k._NoCollide = ent
			end
		end
	end

	if not self.m_intLastCollisionThink then
		self.m_intLastCollisionThink = 0
	end

	if CurTime() < self.m_intLastCollisionThink then return end
	self.m_intLastCollisionThink = CurTime() + 10

	for k, v in pairs(self.m_tblTrailers) do
		if not IsValid(k) or not k.CurrentJob then continue end
		if not IsValid(k.ParentTruck) then continue end

		if k._NoCollide then
			k._NoCollide = nil
		end
	end
end

function Job:ThinkDeliveryPoints()
	if not self.m_intLastPointThink then
		self.m_intLastPointThink = 0
	end

	if CurTime() < self.m_intLastPointThink then return end
	self.m_intLastPointThink = CurTime() + 1

	for k, v in pairs(self.m_tblTrailers) do
		if not IsValid(k) or not k.CurrentJob then continue end

		for _, ent in pairs(ents.FindInSphere(k.CurrentJob.DropOffPosition, 64)) do
			if not IsValid(ent) or not ent.ParentTruck then continue end

			if ent == k then
				k:GetPlayerOwner():AddMoney(k.CurrentJob.Payout, "Trailer delivery commission")
				k:GetPlayerOwner():AddNote("You earned $" .. k.CurrentJob.Payout .. " for delivering a trailer!")
				ent:Remove()
			end
		end
	end
end

hook.Add("EntityRemoved", "RemoveTrailer", function(eEnt)
	if IsValid(eEnt) and eEnt.IsTrailerTruck then
		if IsValid(eEnt:GetPlayerOwner()) then
			local trailer = eEnt.CurrentTrailer

			if IsValid(trailer) then
				trailer:Remove()
				eEnt:GetPlayerOwner():SetNWBool("InTruckJob", false)
			end
		end
	end

	if not IsValid(eEnt) or not eEnt:IsVehicle() or not eEnt.IsTrailer then return end

	if IsValid(eEnt:GetPlayerOwner()) then
		eEnt:GetPlayerOwner():SetNWBool("InTruckJob", false)
	end

	if eEnt.ChildrenENTS then
		for k, v in pairs(eEnt.ChildrenENTS) do
			if IsValid(k) then
				k:Remove()
			end
		end
	end

	Job.m_tblTrailers[eEnt] = nil
end)

hook.Add("Think", "ThinkTruckDriver", function()
	Job:ThinkDeliveryPoints()
	Job:TrailerFix()
end)

hook.Add("ShouldCollide", "ShouldCollideTruckDriver", function(eEnt, oEnt)
	if IsValid(eEnt._NoCollide) and eEnt._NoCollide == oEnt then return false end
	if IsValid(oEnt._NoCollide) and oEnt._NoCollide == eEnt then return false end
end)

GM.Jobs:Register(Job)