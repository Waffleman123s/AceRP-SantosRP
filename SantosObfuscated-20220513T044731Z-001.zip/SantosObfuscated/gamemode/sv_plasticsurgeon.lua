--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--
util.AddNetworkString"UpdateCharSF"

net.Receive("UpdateCharSF", function(len, ply)
    -- if not ply:WithinTalkingRange() then return end
    -- if not IsValid(ply:GetTalkingNPC()) then return end
    -- if ply:GetTalkingNPC().UID ~= "plastic_surgeon" then return end
    local canChange = true
    if ply:IsIncapacitated() then return end
    local cost = 10000
    local jobID = GAMEMODE.Jobs:GetPlayerJobID(ply); -- Get the job id from player.
    if table.HasValue({2}, jobID) then cost = 0; end; -- Cost replacement.
    -- if GAMEMODE.Player:Ge

    local first_name = net.ReadString()
    local last_name = net.ReadString()
    local model = net.ReadString()
    local sex = net.ReadInt(32)
    local skin = net.ReadInt(32)

    -- if sex ~= 

    GAMEMODE.SQL:CheckCharacterNameTaken(first_name, last_name, function(bNameTaken)
        if first_name .. " " .. last_name == ply:GetName() or first_name .. last_name == ply:GetName() then
            bNameTaken = false
        end

        canChange = not bNameTaken

        if not canChange then
            ply:AddNote("This name is already in use!")

            return
        end

        if ply:CanAfford(cost) then
            ply:TakeMoney(cost)
            ply:SetModel(model)
            GAMEMODE.Player:SetSharedGameVar(ply, "name_first", first_name)
            GAMEMODE.Player:SetSharedGameVar(ply, "name_last", last_name)
            GAMEMODE.Player:SetSharedGameVar(ply, "char_sex", sex)
            GAMEMODE.Player:SetGameVar(ply, "char_skin", skin, true)
            GAMEMODE.Player:SetGameVar(ply, "char_model_base", model, true)
            GAMEMODE.Player:SetGameVar(ply, "char_model_overload", nil, true)
            local id = GAMEMODE.SQL:GetPlayerPoolID(ply:SteamID64())
            GAMEMODE.SQL:UpdateCharacterFirstName(id, ply:GetCharacterID(), first_name)
            GAMEMODE.SQL:UpdateCharacterLastName(id, ply:GetCharacterID(), last_name)
            GAMEMODE.SQL:UpdateCharacterModel(id, ply:GetCharacterID(), model)
            GAMEMODE.SQL:UpdateCharacterSex(id, ply:GetCharacterID(), sex)
            -- GAMEMODE.SQL:GetQuery_UpdateCharacterSkin(id, ply:GetCharacterID(), skin)
            GAMEMODE.SQL:UpdateCharacterModelOverload(id, ply:GetCharacterID(), nil)
            ply:AddNote("The surgery was a success!")
        else
            ply:AddNote("You cannot afford $" .. string.Comma(cost))
        end
    end)
end)