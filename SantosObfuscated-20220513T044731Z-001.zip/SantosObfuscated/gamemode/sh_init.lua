--[[
	Name: sh_init.lua
	For: santosrp
	By: Ultra
]]
--
GM.Name = "SantosRP"
GM.Author = ""
GM.Email = ""
GM.Website = ""
collectgarbage("setstepmul", 400)

if game.SinglePlayer() then
	debug.getregistry().Player.SteamID64 = function() return "1234567890" end
end

function GM:PrintDebug(intLevel, ...)
	if intLevel > 0 then
		local str = table.concat({...}, " ")

		if SERVER then
			ServerLog("[GM:PrintDebug] " .. str)
		else
			print("[GM:PrintDebug] " .. str)
		end
	else
		--verbose core
		--print( ... )
	end
end

function GM:LogDebug(...)
	local str = table.concat({...}, " ")

	if SERVER then
		ServerLog("[GM:LogDebug] " .. str .. "\n")

		if serverguard then
			serverguard.plugin.FindByID("logs"):Log(str)
		end
	else
		print("[GM:LogDebug] " .. str)
	end
end

function GM:PrecachePlayerModels()
	--Precache models
	for k, v in pairs(GM.Config.PlayerModels.Male) do
		util.PrecacheModel(k)
	end

	for k, v in pairs(GM.Config.PlayerModels.Female) do
		util.PrecacheModel(k)
	end

	for k, v in pairs(GM.Config.PlayerModelOverloads.Male or {}) do
		util.PrecacheModel(k)
	end

	for k, v in pairs(GM.Config.PlayerModelOverloads.Female or {}) do
		util.PrecacheModel(k)
	end
end

if SERVER then
	util.AddNetworkString"gm_onupdate"
	_ghasupdated = false

	function StopAllVehicles()
		for k, v in pairs(player.GetAll()) do
			if IsValid(v:GetVehicle()) and IsValid(v:GetVehicle():GetPhysicsObject()) then
				v:GetVehicle():GetPhysicsObject():SetVelocity(Vector(0, 0, 0))
			end
		end
	end

	net.Receive("gm_onupdate", function()
		if _ghasupdated then return end
		StopAllVehicles()
		_ghasupdated = true
	end)
end

_GLastRefresh = _GLastRefresh or 0

function GM:OnReloaded()
	if _GLastRefresh > CurTime() then return end
	_GLastRefresh = CurTime() + 3

	if SERVER then
		StopAllVehicles()

		for k, v in pairs(player.GetAll()) do
			v:AddNote("Updating serverside, you may experience some lag")
		end

		self.NPC:Initialize()
	else
		GAMEMODE.HUD:AddNote("Updating clientside, you may experience some lag", 0, 10)
		net.Start("gm_onupdate")
		net.SendToServer()
		--self.NPC:Initialize() duplicate
	end
end

hook.Remove("PlayerTick", "TickWidgets")
include(SERVER and "santosrp/gamemode/sv_manifest.lua" or "santosrp/gamemode/cl_manifest.lua")
GM:PrecachePlayerModels()

function GM:StartCommand(pPlayer, pUserCmd)
	if (pUserCmd:GetSideMove() ~= 0 or pUserCmd:GetForwardMove() < 0) and pUserCmd:KeyDown(IN_SPEED) and pUserCmd:GetForwardMove() <= 0 then
		pUserCmd:RemoveKey(IN_SPEED)
	end
end

do
	--functions
	local pmeta = debug.getregistry().Player

	function pmeta:InCWMenu()
		if not IsValid(self:GetActiveWeapon()) then return false end
		if not self:GetActiveWeapon().dt then return false end

		return self:GetActiveWeapon().dt.State == 4
	end

	local emeta = debug.getregistry().Entity
	local wmeta = debug.getregistry().Weapon
	local getMoveType = emeta.GetMoveType
	local isOnGround = emeta.IsOnGround
	local animRestartGesture = pmeta.AnimRestartGesture
	local animRestartMainSequence = pmeta.AnimRestartMainSequence
	local inVehicle = pmeta.InVehicle
	local getVehicle = pmeta.GetVehicle
	local lookupSequence = emeta.LookupSequence
	local getAllowWeaponsInVehicle = pmeta.GetAllowWeaponsInVehicle
	local getActiveWeapon = pmeta.GetActiveWeapon
	local crouching = pmeta.Crouching
	local getClass = emeta.GetClass
	local getModel = emeta.GetModel
	local getWaterLevel = emeta.WaterLevel
	local getTable = emeta.GetTable
	local getHoldType = wmeta.GetHoldType
	--CalcMainActivity
	local calcIdeal, calcSeqOverride
	local movType, onGround, wasOnGround
	--HandlePlayerDriving
	local inVeh, pVehicle, c, t, class, seq, use_anims, holdtype, seqid
	--HandlePlayerJumping
	local velLen
	local ptable

	function GM:CalcMainActivity(pPlayer, vecVel)
		calcIdeal = ACT_MP_STAND_IDLE
		calcSeqOverride = -1
		pTable = getTable(pPlayer)
		movType = getMoveType(pPlayer)
		onGround = isOnGround(pPlayer)
		wasOnGround = pTable.m_bWasOnGround
		velLen = vecVel:Length2DSqr()

		--Begin HandlePlayerLanding
		if movType ~= MOVETYPE_NOCLIP then
			if onGround and not wasOnGround then
				animRestartGesture(pPlayer, GESTURE_SLOT_JUMP, ACT_LAND, true)
			end
		end

		goto driving
		--End HandlePlayerLanding
		::unhandled::

		if velLen > 22500 then
			calcIdeal = ACT_MP_RUN
		elseif velLen > 0.25 then
			calcIdeal = ACT_MP_WALK
		end

		goto handled
		::handled::

		do
			pTable.m_bWasOnGround = onGround
			pTable.m_bWasNoclipping = (movType == MOVETYPE_NOCLIP and not inVeh)

			return calcIdeal, calcSeqOverride
		end

		--Being HandlePlayerDucking
		::ducking::

		if not crouching(pPlayer) then
			goto unhandled
		end

		if velLen > 0.25 then
			calcIdeal = ACT_MP_CROUCHWALK
		else
			calcIdeal = ACT_MP_CROUCH_IDLE
		end

		goto handled
		--End HandlePlayerDucking
		--Begin HandlePlayerSwimming
		::swimming::

		if waterLevel < 2 or onGround then
			pTable.m_bInSwim = false
			goto ducking
		end

		calcIdeal = ACT_MP_SWIM
		pTable.m_bInSwim = true
		goto handled
		--End HandlePlayerSwimming
		--Begin HandlePlayerJumping
		::jumping::
		waterLevel = getWaterLevel(pPlayer) --Might need this later in HandlePlayerSwimming!

		if movType == MOVETYPE_NOCLIP then
			pTable.m_bJumping = false
			goto swimming
		end

		-- airwalk more like hl2mp, we airwalk until we have 0 velocity, then it's the jump animation
		-- underwater we're alright we airwalking
		if not pTable.m_bJumping and not onGround and waterLevel <= 0 then
			if not pTable.m_fGroundTime then
				pTable.m_fGroundTime = CurTime()
			elseif (CurTime() - pTable.m_fGroundTime) > 0 and velLen < 0.25 then
				pTable.m_bJumping = true
				pTable.m_bFirstJumpFrame = false
				pTable.m_flJumpStartTime = 0
			end
		end

		if pTable.m_bJumping then
			if pTable.m_bFirstJumpFrame then
				pTable.m_bFirstJumpFrame = false
				--pPlayer:AnimRestartMainSequence()
				animRestartMainSequence(pPlayer)
			end

			if waterLevel >= 2 or (CurTime() - pTable.m_flJumpStartTime) > 0.2 and onGround then
				pTable.m_bJumping = false
				pTable.m_fGroundTime = nil
				--pPlayer:AnimRestartMainSequence()
				animRestartMainSequence(pPlayer)
			end

			if pTable.m_bJumping then
				calcIdeal = ACT_MP_JUMP
				goto handled
			end
		end

		goto swimming
		--End HandlePlayerJumping
		--Begin HandlePlayerDriving
		::driving::
		inVeh = inVehicle(pPlayer)

		if not inVeh then
			goto jumping
		end

		pVehicle = getVehicle(pPlayer)

		if not pVehicle.HandleAnimation and pVehicle.GetVehicleClass then
			c = pVehicle:GetVehicleClass()
			t = list.Get("Vehicles")[c]

			if t and t.Members and t.Memebers.HandleAnimation then
				pVehicle.HandleAnimation = t.Members.HandleAnimation
			else
				pVehicle.HandleAnimation = true --Prevent this if block from trying to assign HandleAnimation again.
			end
		end

		class = getClass(pVehicle)

		if isfunction(pVehicle.HandleAnimation) then
			seq = pVehicle:HandleAnimation(pPlayer)

			if seq ~= nil then
				calcSeqOverride = seq
			end
		end

		--pVehicle.HandleAnimation did not give us an animation
		if calcSeqOverride == -1 then
			if class == "prop_vehicle_jeep" then
				calcSeqOverride = lookupSequence(pPlayer, "drive_jeep")
			elseif class == "prop_vehicle_airboat" then
				calcSeqOverride = lookupSequence(pPlayer, "drive_airboat")
			elseif class == "prop_vehicle_prisoner_pod" and getModel(pVehicle) == "models/vehicles/prisoner_pod_inner.mdl" then
				-- HACK!!
				calcSeqOverride = lookupSequence(pPlayer, "drive_pd")
			else
				calcSeqOverride = lookupSequence(pPlayer, "sit_rollercoaster")
			end
		end

		use_anims = calcSeqOverride == lookupSequence(pPlayer, "sit_rollercoaster") or calcSeqOverride == lookupSequence(pPlayer, "sit")

		if use_anims and getAllowWeaponsInVehicle(pPlayer) and IsValid(getActiveWeapon(pPlayer)) then
			holdtype = getHoldType(getActiveWeapon(pPlayer))

			if holdtype == "smg" then
				holdtype = "smg1"
			end

			seqid = lookupSequence(pPlayer, "sit_" .. holdtype)

			if seqid ~= -1 then
				calcSeqOverride = seqid
			end
		end

		goto handled
		--End HandlePlayerDriving
	end
end
DarkRP = DarkRP or {}
local function attachCurrency(str)
    local config = "$"
    return config and config .. str or str .. config
end

function DarkRP.formatMoney(n)
    if not n then return attachCurrency("0") end

    if n >= 1e14 then return attachCurrency(tostring(n)) end
    if n <= -1e14 then return "-" .. attachCurrency(tostring(math.abs(n))) end

    local negative = n < 0

    n = tostring(math.abs(n))
    local dp = string.find(n, "%.") or #n + 1

    for i = dp - 4, 1, -3 do
        n = n:sub(1, i) .. "," .. n:sub(i + 1)
    end

    -- Make sure the amount is padded with zeroes
    if n[#n - 1] == "." then
        n = n .. "0"
    end

    return (negative and "-" or "") .. attachCurrency(n)
end
