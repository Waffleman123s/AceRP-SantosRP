--[[
	Name: drugs_weed.lua
	For: SantosRP
	By: Ultra
]]--

local cornGrowModels = {
	[1] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
	},

	[2] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
	},

	[3] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
	},

	[4] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
	},

	[5] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
	},
}

-- ----------------------------------------------------------------
-- Low Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Corn Seeds"
Item.Desc = "A box of corn seed"
Item.Type = "type_drugs"
Item.Model = "models/craphead_scripts/ch_farming/seeds/corn.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = false

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = cornGrowModels, --Models for each growth stage
	GrowStageTime = 150, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Fresh Corn",
	GiveItemAmount = 6,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Fresh Corn"
Item.Desc = "Harvested Corn."
Item.Type = "type_food"
Item.Model = "models/craphead_scripts/ch_farming/crops/corn.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = false
Item.Weight = 1
Item.Volume = 2
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 7
Item.ThirstDrainLen = 2
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem
GM.Inv:RegisterItem( Item )