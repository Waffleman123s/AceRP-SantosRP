--[[
	Name: minerals.lua
	For: SantosRP
	By: Xrayhunter
]]--

-- local Item = {}
-- Item.Name = "Pickaxe"
-- Item.Desc = "A pickaxe to go mining!"
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/melee/w_fireaxe.mdl" -- Weird default mdl?
-- Item.Weight = 4
-- Item.Volume = 7
-- Item.CanDrop = true
-- Item.CanEquip = true
-- Item.EquipSlot = "AltWeapon"
-- Item.EquipGiveClass = "weapon_pickaxe"
-- Item.CraftingEntClass = "ent_crafting_table"
-- Item.CraftingTab = "Weapons"
-- Item.CraftSkill = "Crafting"
-- Item.CraftSkillLevel = 7
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Wood Plank"] = 2,
--     ["Metal Bar"] = 1,
--     ["Metal Plate"] = 3,
-- }
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Mining Drill"
Item.Desc = "A mining drill to drill faster!"
Item.Type = "type_weapon"
Item.Model = "models/geralts/preda/w_bur.mdl" -- Weird default mdl?
Item.Weight = 4
Item.Volume = 7
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "cms_drill"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Mineral Stone"
Item.Desc = "Mineral that is found in rocks."
Item.Model = "models/props_junk/rock001a.mdl"
Item.Weight = 20
Item.Volume = 15
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Mineral Iron"
Item.Desc = "Mineral that is found in rocks."
Item.Model = "models/props_junk/rock001a.mdl"
Item.Weight = 20
Item.Volume = 15
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Iron Ingot"
Item.Desc = "Mineral that was refined."
Item.Model = "models/bar_iron/bar_iron.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Mineral Gold"
Item.Desc = "Mineral that is found in rocks."
Item.Model = "models/props_junk/rock001a.mdl"
Item.Weight = 20
Item.Volume = 15
Item.CanDrop = true
Item.clr = Color(204, 204, 0)
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Gold Ingot"
Item.Desc = "Mineral that was refined."
Item.Model = "models/bar_gold/bar_gold.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Mineral Diamond"
Item.Desc = "Mineral that is found in rocks."
Item.Model = "models/props_junk/rock001a.mdl"
Item.Weight = 20
Item.Volume = 15
Item.CanDrop = true
Item.clr = Color(0, 204, 204)
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Cut Diamond"
Item.Desc = "Mineral that was refined."
Item.Model = "models/bar_iron/bar_iron.mdl"
Item.clr = Color(0, 204, 204)
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "Refinery"
-- Item.Desc = "Refinery to refine all your goodies from the mine."
-- Item.Model = "models/crusher/crusher.mdl"
-- Item.HealthOverride = 3000
-- Item.Weight = 50
-- Item.Volume = 45
-- Item.CanDrop = true
-- Item.LimitID = "crafting table"
-- Item.DropClass = "ent_refinery"
-- Item.CraftingEntClass = "ent_crafting_table"
-- Item.CraftingTab = "Weapons"
-- Item.CraftSkill = "Crafting"
-- Item.CraftSkillLevel = 7
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Engine Block"] = 1,
--     ["Metal Bracket"] = 12,
--     ["Metal Plate"] = 6,
--     ["Metal Pipe"] = 2,
-- }
-- GM.Inv:RegisterItem( Item )
-- GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 2, ["vip_t3"] = 3 } )

-- --Plants(Corn)
-- ---------------------------------

-- local cornGrowModels = {
-- 	[1] = {
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 0, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, 8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 0, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, -8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 0, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(-8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 0, },
-- 		},
-- 	},

-- 	[2] = {
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 1, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, 8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 1, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, -8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 1, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(-8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.25,
-- 			bgroups = { [1] = 1, },
-- 		},
-- 	},

-- 	[3] = {
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.5,
-- 			bgroups = { [1] = 2, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, 8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.5,
-- 			bgroups = { [1] = 2, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, -8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.5,
-- 			bgroups = { [1] = 2, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(-8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.5,
-- 			bgroups = { [1] = 2, },
-- 		},
-- 	},

-- 	[4] = {
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.75,
-- 			bgroups = { [1] = 3, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, 8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.75,
-- 			bgroups = { [1] = 3, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, -8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.75,
-- 			bgroups = { [1] = 3, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(-8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 0.75,
-- 			bgroups = { [1] = 3, },
-- 		},
-- 	},

-- 	[5] = {
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 1,
-- 			bgroups = { [1] = 4, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, 8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 1,
-- 			bgroups = { [1] = 4, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(0, -8.5, 7),
-- 			ang = "random_yaw",
-- 			scale = 1,
-- 			bgroups = { [1] = 4, },
-- 		},
-- 		{
-- 			mdl = "models/craphead_scripts/ch_farming/plants/corn.mdl",
-- 			pos = Vector(-8.5, 0, 7),
-- 			ang = "random_yaw",
-- 			scale = 1,
-- 			bgroups = { [1] = 4, },
-- 		},
-- 	},
-- }

-- ----------------------------------------------------------------
-- Low Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Corn Seeds"
Item.Desc = "A box of corn seed"
Item.Type = "type_drugs"
Item.Model = "models/craphead_scripts/ch_farming/seeds/seeds_package.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = false

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = cornGrowModels, --Models for each growth stage
	GrowStageTime = 10, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Fresh Corn",
	GiveItemAmount = 6,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Fresh Corn"
Item.Desc = "Harvested Corn."
Item.Type = "type_food"
Item.Model = "models/craphead_scripts/ch_farming/crops/corn.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 7
Item.ThirstDrainLen = 2
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem
GM.Inv:RegisterItem( Item )

--Plants(Lettuce)
---------------------------------

local lettuceGrowModels = {
	[1] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
	},

	[2] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
	},

	[3] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
	},

	[4] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
	},

	[5] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/lettuce.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
	},
}

-- ----------------------------------------------------------------
-- Low Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Lettuce Seeds"
Item.Desc = "A box of lettuce seed"
Item.Type = "type_drugs"
Item.Model = "models/craphead_scripts/ch_farming/seeds/seeds_package.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = false

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = lettuceGrowModels, --Models for each growth stage
	GrowStageTime = 120, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Lettuce",
	GiveItemAmount = 6,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )

--Plants(Pepper)
---------------------------------

local pepperGrowModels = {
	[1] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
	},

	[2] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
	},

	[3] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
	},

	[4] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
	},

	[5] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/pepper.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
	},
}

-- ----------------------------------------------------------------
-- Low Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Pepper Seeds"
Item.Desc = "A box of pepper seed"
Item.Type = "type_drugs"
Item.Model = "models/craphead_scripts/ch_farming/seeds/seeds_package.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = false

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = pepperGrowModels, --Models for each growth stage
	GrowStageTime = 120, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Green Pepper",
	GiveItemAmount = 6,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )

--Plants(Tomato)
---------------------------------

local tomatoGrowModels = {
	[1] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 0, },
		},
	},

	[2] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.25,
			bgroups = { [1] = 1, },
		},
	},

	[3] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.5,
			bgroups = { [1] = 2, },
		},
	},

	[4] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 0.75,
			bgroups = { [1] = 3, },
		},
	},

	[5] = {
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/craphead_scripts/ch_farming/plants/tomato.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 1,
			bgroups = { [1] = 4, },
		},
	},
}

-- ----------------------------------------------------------------
-- Low Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Tomato Seeds"
Item.Desc = "A box of tomato seed"
Item.Type = "type_drugs"
Item.Model = "models/craphead_scripts/ch_farming/seeds/seeds_package.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = false

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = tomatoGrowModels, --Models for each growth stage
	GrowStageTime = 120, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Tomato",
	GiveItemAmount = 6,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )