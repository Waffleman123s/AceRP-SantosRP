--[[
	Name: job_weapons_police.lua
	For: SantosRP
	By: Ultra
]]--

local Item = {}
Item.Name = "Pole Cam"
Item.Desc = "A camera on the end of a long pole. Used to look around corners safely."
Item.Type = "type_weapon"
Item.Model = "models/weapons/custom/w_polecam.mdl"
Item.Weight = 4
Item.Volume = 8
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "pole cam"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_polecam"
Item.DropClass = "weapon_polecam"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Night Stick"
Item.Desc = "A night stick."
Item.Type = "type_weapon"
Item.Model = "models/sal/nightstick.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "night stick"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_nightstick"
Item.DropClass = "weapon_nightstick"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Radar Gun"
Item.Desc = "A radar gun. Used to determine the speed of a moving vehicle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_toolgun.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "radar gun"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_radargun"
Item.DropClass = "weapon_radargun"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Spike Strip"
Item.Desc = "A deployable spike strip."
Item.Type = "type_weapon"
Item.Model = "models/myproject/SpikeStrip001.mdl"
Item.Weight = 10
Item.Volume = 15
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "spike strip"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_roadspikes"
Item.DropClass = "weapon_roadspikes"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Battering Ram"
Item.Desc = "A ram used to force open doors for players with warrants."
Item.Type = "type_weapon"
Item.Model = "models/weapons/custom/w_batram.mdl"
Item.Weight = 8
Item.Volume = 15
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "battering ram"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_doorram"
Item.DropClass = "weapon_doorram"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Taser"
Item.Desc = "A taser."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_pistol.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "taser"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_taser"
Item.DropClass = "weapon_taser"
Item.PacOutfit = "taser_belt"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end

GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(-0.00036541512235999, -90, -0.00027235379093327),
									["ClassName"] = "clip",
									["UniqueID"] = "4162125740",
									["Position"] = Vector(-2.06103515625, 3.232421875, 0.734375),
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Event"] = "weapon_class",
									["UniqueID"] = "1467435601",
									["Operator"] = "equal",
									["ClassName"] = "event",
									["Arguments"] = "weapon_taser@@1",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2086877014",
							["Scale"] = Vector(1, 0.89999997615814, 1),
							["Angles"] = Angle(-4.3115571315866e-005, -90, -86.656455993652),
							["Size"] = 0.775,
							["ClassName"] = "model",
							["Position"] = Vector(-0.9697265625, 0.0517578125, 2.33056640625),
							["Bone"] = "spine",
							["Model"] = "models/sal/stungun.mdl",
							["EditorExpand"] = true,
						},
					},
				},
				["self"] = {
					["UniqueID"] = "2403179842",
					["Model"] = "models/weapons/w_eq_eholster.mdl",
					["Scale"] = Vector(1, 1.3999999761581, 1),
					["EditorExpand"] = true,
					["Angles"] = Angle(-57.896198272705, -37.184963226318, -132.74348449707),
					["Size"] = 0.575,
					["Position"] = Vector(-2.6552734375, 7.5830078125, 4.28369140625),
					["Color"] = Vector(136, 136, 136),
					["Bone"] = "spine",
					["Brightness"] = 0.9,
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "464675880",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Police Issue Flash Grenade"
Item.Desc = "A Flash Grenade."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_eq_flashbang.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "flashgern"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "cw_flash_grenade"
Item.DropClass = "cw_flash_grenade"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "S.W.A.T. Issue Breach Charge"
Item.Desc = "A breach charge."
Item.Type = "type_weapon"
Item.Model = "models/weapons/cstrike/c_c4.mdl"
Item.Weight = 10
Item.Volume = 15
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "spike strip"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_sh_doorcharge"
Item.DropClass = "weapon_sh_doorcharge"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Police Badge"
Item.Desc = "A police badge."
Item.Type = "type_weapon"
Item.Model = "models/freeman/policebadge.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "policebadgebelt"
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "policebadge"
Item.DropClass = "policebadge"
Item.PacOutfit = "badge_swep"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end

GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Event"] = "weapon_class",
						["UniqueID"] = "2504900514",
						["Operator"] = "equal",
						["ClassName"] = "event",
						["Arguments"] = "policebadge@@1",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.935546875, 7.64453125, -2.5904235839844),
				["Angles"] = Angle(19.057590484619, 100.15154266357, 91.137382507324),
				["UniqueID"] = "1311205654",
				["Size"] = 0.775,
				["EditorExpand"] = true,
				["Bone"] = "spine",
				["Model"] = "models/freeman/policebadge.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1469844187",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
} )
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Police Shield"
Item.Desc = "A riot shield."
Item.Type = "type_weapon"
Item.Model = "models/bshields/rshield.mdl"
Item.Weight = 6
Item.Volume = 12
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "policeshield"
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "riot_shield"
Item.DropClass = "riot_shield"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )


-- CW Guns
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Police Issue AR-15"
Item.Desc = "An AR-15 rifle. Ammo Type: 5.56x45MM"
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_rif_m4a1.mdl"
Item.Weight = 45
Item.Volume = 70
Item.CanDrop = false
Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_ar15"
Item.NoDefaultClip = true
Item.IsCW = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.PacOutfit = "police_riotshield"
Item.LimitID = "police issue AR-15"

GM.PacModels:Register( Item.PacOutfit, {
    [1] = {
    	["children"] = {
    		[1] = {
    			["children"] = {
    			},
    			["self"] = {
    				["Angles"] = Angle(-7.9470517277969e-08, -7.6757879257202, -2.4827388642734e-06),
    				["UniqueID"] = "1702162216",
    				["Position"] = Vector(-12.185180664063, -2.16650390625, -5.7138671875),
    				["Bone"] = "spine 4",
    				["Model"] = "models/weapons/w_her_m27ia.mdl",
    				["ClassName"] = "model",
    			},
    		},
    	},
    	["self"] = {
    		["EditorExpand"] = true,
    		["UniqueID"] = "221333685",
    		["ClassName"] = "group",
    		["Name"] = "ar15",
    		["Description"] = "add parts to me!",
    	},
    },
} )
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )


local Item = {}
Item.Name = "Police Issue Glock 17"
Item.Desc = "A Glock 17 pistol. Ammo Type: 9x19MM"
Item.Type = "type_weapon"
Item.Model = "models/weapons/NeN/Glock 17/w_pist_glock17.mdl"
Item.Weight = 15
Item.Volume = 30
Item.CanDrop = false
Item.CanEquip = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_nen_glock17"
Item.NoDefaultClip = true
Item.IsCW = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "police issue Glock 17"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "SWAT Issue HK416"
Item.Desc = "An HK416 rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cwkk_hk416.mdl"
Item.Weight = 18
Item.Volume = 15
Item.CanDrop = false
Item.DropClass = "cw_kk_hk416"
Item.CanEquip = true
Item.JobItem = "JOB_SWAT" --This item can only be possessed by by players with this job
Item.IsCW = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_kk_hk416"
Item.PacOutfit = "w cwkk hk"

GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Arguments"] = "cw_kk_hk416",
						["UniqueID"] = "1137486923",
						["Event"] = "weapon_class",
						["Operator"] = "equal",
						["Name"] = "weapon class equal\"cw_kk_hk416\"",
						["ClassName"] = "event",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.9097290039063, -4.6875, -8.3095703125),
				["Angles"] = Angle(3.3602318763733, 2.2610514861299e-05, -0.00069575849920511),
				["UniqueID"] = "1484483537",
				["Size"] = 1.025,
				["EditorExpand"] = true,
				["Bone"] = "spine 2",
				["Model"] = "models/weapons/w_cwkk_hk416.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "239303487",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Police Issue L115"
Item.Desc = "An L115 rifle. Ammo Type: .338 Lapua"
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cstm_l96.mdl"
Item.Weight = 45
Item.Volume = 70
Item.CanDrop = false
Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_l115"
Item.NoDefaultClip = true
Item.IsCW = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "police issue L115"
Item.PacOutfit = "L115"
GM.PacModels:Register( Item.PacOutfit, {
    [1] = {
    	["children"] = {
    		[1] = {
    			["children"] = {
    			},
    			["self"] = {
    				["Angles"] = Angle(10.531007766724, -2.2578424250241e-05, 4.3420044676168e-05),
    				["UniqueID"] = "3392910895",
    				["Position"] = Vector(-15.174194335938, -3.06640625, -1.9775390625),
    				["Bone"] = "spine 4",
    				["Model"] = "models/weapons/w_cstm_l96.mdl",
    				["ClassName"] = "model",
    			},
    		},
    	},
    	["self"] = {
    		["EditorExpand"] = true,
    		["UniqueID"] = "1908006934",
    		["ClassName"] = "group",
    		["Name"] = "L115",
    		["Description"] = "add parts to me!",
    	},
    },
} )
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )


local Item = {}
Item.Name = "Police Issue HK MP5"
Item.Desc = "An MP5 sub-machine gun. Ammo Type: 9x19MM"
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_smg_mp5.mdl"
Item.Weight = 45
Item.Volume = 70
Item.CanDrop = false
Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_mp5"
Item.NoDefaultClip = true
Item.IsCW = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "police issue MP5"
Item.PacOutfit = "mp5"
GM.PacModels:Register( Item.PacOutfit, {
    [1] = {
    	["children"] = {
    		[1] = {
    			["children"] = {
    			},
    			["self"] = {
    				["Angles"] = Angle(-2.2375309072231e-07, -4.2011070251465, -2.3566177333123e-05),
    				["UniqueID"] = "37399429",
    				["Position"] = Vector(-6.3148193359375, -2.5390625, -10.5751953125),
    				["Size"] = 0.775,
    				["Bone"] = "spine 4",
    				["Model"] = "models/weapons/w_smg_mp5.mdl",
    				["ClassName"] = "model",
    			},
    		},
    	},
    	["self"] = {
    		["EditorExpand"] = true,
    		["UniqueID"] = "1452933623",
    		["ClassName"] = "group",
    		["Name"] = "mp5",
    		["Description"] = "add parts to me!",
    	},
    },
} )
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )


-- CW Ammo
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Police Issue 5.56x45MM 10 Rounds"
Item.Desc = "10 rounds of 5.56x45MM ammunition."
Item.Type = "type_ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 10
Item.Volume = 15
Item.CanDrop = false
Item.CanUse = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "5.56x45MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "5.56x45MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Police Issue .338 Lapua 5 Rounds"
Item.Desc = "5 rounds of .338 Lapua ammunition."
Item.Type = "type_ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 10
Item.Volume = 15
Item.CanDrop = false
Item.CanUse = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 5, ".338 Lapua" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".338 Lapua" ) > 20 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Police Issue 9x19MM 10 Rounds"
Item.Desc = "10 rounds of 9x19MM ammunition."
Item.Type = "type_ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 10
Item.Volume = 15
Item.CanDrop = false
Item.CanUse = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "9x19MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "9x19MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Police Issue 9x19MM 40 Rounds"
Item.Desc = "40 rounds of 9x19MM ammunition. Intended for MP5"
Item.Type = "type_ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 10
Item.Volume = 15
Item.CanDrop = false
Item.CanUse = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 40, "9x19MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "9x19MM" ) > 120 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Police Issue Spare Tire Kit"
Item.Desc = "A replacement set of tires for any vehicle."
Item.Model = "models/props_vehicles/carparts_wheel01a.mdl"
Item.Weight = 60
Item.Volume = 80
Item.CanDrop = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "car repair kit"
Item.DropClass = "ent_carfix_wheels"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )


local Item = {}
Item.Name = "Police Issue Engine Overhaul"
Item.Desc = "A complete engine overhaul kit. Used on vehicles that have 0 health."
Item.Model = "models/props_c17/TrapPropeller_Engine.mdl"
Item.Weight = 120
Item.Volume = 100
Item.CanDrop = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "car repair kit"
Item.DropClass = "ent_carfix_high"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )