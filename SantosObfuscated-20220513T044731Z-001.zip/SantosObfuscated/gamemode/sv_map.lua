--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--

GM.Map = {}
GM.Map.DT_IS_MAP_PROP = 30
GM.Map.m_tblPropRegister = {}
GM.Map.m_tblNPCRegister = {}
GM.Map.m_tblMapProps = {}
GM.Map.m_tblGameNPCs = {}

function GM.Map:Load()
	self:LoadMapCode()
	self:LoadMapProps()
	self:LoadMapNPCs()
end

function GM.Map:Initialize()
end

function GM.Map:InitPostEntity()
	self:SpawnMapProps()
	self:SpawnNPCs()
end

--[[ Map props ]]--
function GM.Map:LoadMapProps()
	GM:PrintDebug( 0, "->LOADING MAP PROPS" )

	local map = game.GetMap():gsub(".bsp", "")
	local path = GM.Config.GAMEMODE_PATH.. "maps/".. map.. "/map_props/"

	local foundFiles, foundFolders = file.Find( path.. "*", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )

		local ext = v:GetExtensionFromFilename()
		if v:sub( 1, 3 ) == "sv_" then
			if GM.PRECOMPILED then
				if ext ~= "dat" then continue end
				GM.loadChunk( path.. v )
			else
				if ext ~= "lua" then continue end
				include( path.. v )
			end
		elseif v:sub( 1, 3 ) == "sh_" then
			include( path.. v )
			AddCSLuaFile( path.. v )		
		else
			AddCSLuaFile( path.. v )
		end
	end

	GM:PrintDebug( 0, "->MAP PROPS LOADED" )
end

function GM.Map:RegisterMapProp( tblMapProp )
	self.m_tblPropRegister[tblMapProp.ID] = tblMapProp
end

function GM.Map:GetMapProp( strID )
	return self.m_tblPropRegister[strID]
end

function GM.Map:SpawnMapProps()
	for id, data in pairs( self.m_tblPropRegister ) do
		self.m_tblMapProps[id] = {}

		for _, propData in pairs( data.m_tblSpawn ) do
			local ent = ents.Create( "prop_dynamic" )
			ent:SetPos( propData.pos )
			ent:SetAngles( propData.ang )
			ent:SetModel( propData.mdl )
			if propData.skin then
				ent:SetSkin( propData.skin )
			end
			if propData.mat then
				ent:SetMaterial( propData.mat )
			end
			ent:SetCollisionGroup( COLLISION_GROUP_NONE )
			ent:SetMoveType( MOVETYPE_NONE )
			ent:SetSolid( SOLID_VPHYSICS )
			ent.IsMapProp = true
			ent.MapPropID = id
			ent:SetDTBool( self.DT_IS_MAP_PROP, true ) --Let the client know we are spawned by the map
			ent:Spawn()
			ent:Activate()

			--ent:PhysicsInitStatic( SOLID_VPHYSICS )
			if not propData.nofade then
				ent:SetSaveValue( "fademindist", propData.fademin or GAMEMODE.Config.DetailPropFadeMin )
				ent:SetSaveValue( "fademaxdist", propData.fademax or GAMEMODE.Config.DetailPropFadeMax )
			end
			
			--local phys = ent:GetPhysicsObject()
			--if IsValid( phys ) then
			--	phys:EnableMotion( false )
			--end
		end

		if data.CustomSpawn then
			data:CustomSpawn()
		end
	end
end

function GM.Map:EntityTakeDamage( eEnt, pDamageInfo )
	if eEnt.IsMapProp and not eEnt:IsNPC() then return true end
end

function GM.Map:PhysgunPickup( pPlayer, eEnt )
	if eEnt.IsMapProp then
		return false
	end
end

--[[ Map NPCs ]]--
function GM.Map:LoadMapNPCs()
	GM:PrintDebug( 0, "->LOADING MAP NPCs" )

	local map = game.GetMap():gsub(".bsp", "")
	local path = GM.Config.GAMEMODE_PATH.. "maps/".. map.. "/map_npcs/"

	local foundFiles, foundFolders = file.Find( path.. "*", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )

		local ext = v:GetExtensionFromFilename()
		if v:sub( 1, 3 ) == "sv_" then
			if GM.PRECOMPILED then
				if ext ~= "dat" then continue end
				GM.loadChunk( path.. v )
			else
				if ext ~= "lua" then continue end
				include( path.. v )
			end
		elseif v:sub( 1, 3 ) == "sh_" then
			include( path.. v )
			AddCSLuaFile( path.. v )		
		else
			AddCSLuaFile( path.. v )
		end
	end

	GM:PrintDebug( 0, "->MAP NPCs LOADED" )
end

function GM.Map:RegisterNPCSpawn( tblNPC )
	self.m_tblNPCRegister[#self.m_tblNPCRegister +1] = tblNPC
end

function GM.Map:SpawnNPCs()
	for k, data in pairs( self.m_tblNPCRegister ) do
		local npcMeta = GAMEMODE.NPC:GetNPCMeta( data.UID )
		if not npcMeta then continue end
		
		for k, v in pairs( data.pos ) do
			local ent = ents.Create( "ent_npc_interactive" )
			ent:SetPos( v )
			ent:SetAngles( data.angs[k] )
			ent.UID = npcMeta.UID
			ent.UID_IDX = k
			ent.ParentNPC_UID = data.parentid and data.parentid[k] or nil
			ent.ParentNPC_IDX = data.parentidx and data.parentidx[k] or nil
			ent:SetNPCData( npcMeta )
			ent.IsMapProp = true
			ent.BlockPhysGun = true
			ent:SetDTBool( self.DT_IS_MAP_PROP, true ) --Let the client know we are spawned by the map

			ent:Spawn()
			ent:Activate()
			ent:SetModel( npcMeta.Model )
			self.m_tblGameNPCs[ent.UID] = self.m_tblGameNPCs[ent.UID] or {}
			self.m_tblGameNPCs[ent.UID][ent.UID_IDX] = ent

			if npcMeta.OnSpawn then
				npcMeta:OnSpawn( ent )
			end
		end
	end

	for uid, data in pairs( self.m_tblGameNPCs ) do
		for npc_idx, npc in pairs( data ) do
			if npc.ParentNPC_UID then
				local ent = self.m_tblGameNPCs[npc.ParentNPC_UID][npc.ParentNPC_IDX]
				ent.m_tblPartnerNPCs = ent.m_tblPartnerNPCs or {}
				npc.m_entParentNPC = ent

				table.insert( ent.m_tblPartnerNPCs, npc )
			end
		end
	end
end

--[[ Map Code ]]--
function GM.Map:LoadMapCode()
	GM:PrintDebug( 0, "->LOADING MAP CODE" )

	local map = game.GetMap():gsub(".bsp", "")
	local path = GM.Config.GAMEMODE_PATH.. "maps/".. map.. "/map_code/"

	local foundFiles, foundFolders = file.Find( path.. "*", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )

		local ext = v:GetExtensionFromFilename()
		if v:sub( 1, 3 ) == "sv_" then
			if GM.PRECOMPILED then
				if ext ~= "dat" then continue end
				GM.loadChunk( path.. v )
			else
				if ext ~= "lua" then continue end
				include( path.. v )
			end
		elseif v:sub( 1, 3 ) == "sh_" then
			include( path.. v )
			AddCSLuaFile( path.. v )		
		else
			AddCSLuaFile( path.. v )
		end
	end

	GM:PrintDebug( 0, "->MAP CODE LOADED" )
end