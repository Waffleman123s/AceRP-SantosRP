--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345), QuackDuck (QuackDuck#6610)
	For: AceRP.gg 
]]--
include "santosrp/gamemode/sh_init.lua"
gameevent.Listen "player_disconnect"

function GM:Load()
	self:PrintDebug( 0, "SRPGG Loaded... ".. "Version: ".. SRPGG.Config.Version )
	self:LogDebug( "Loading SRPGG Loading...  ".. "Version: ".. SRPGG.Config.Version )

	self.Module:Load()
	self.Map:Load()
	self.Jobs:LoadJobs()
	self.Inv:LoadItems()
	self.PlayerEffects:Load()
	self.Property:LoadProperties()
	self.NPC:LoadNPCs()
	self.Cars:LoadCars()
	self.Apps:Load()
	
	timer.Simple( 1, function()
		--Remove some empty/unused functions that get called a shit ton and bloat the tick time
		GAMEMODE.Move = nil
		GAMEMODE.FinishMove = nil
		GAMEMODE.PlayerPostThink = nil
		GAMEMODE.PlayerTick = nil
		GAMEMODE.SetupPlayerVisibility = nil
		GAMEMODE.PlayerButtonUp = nil
		GAMEMODE.PlayerButtonDown = nil
	end )

	hook.Remove( "PlayerTick", "TickWidgets" )
end

function GM:Initialize()
	self.Map:Initialize()
	self.Net:Initialize()
	self.Skills:Initialize()
	self.NPC:Initialize()
	self.Needs:Initialize()
	self.Inv:Initialize()
	self.Econ:Initialize()
	self.ServerNet:Initialize()
	self:PrintDebug( 0, "SRPGG Loaded! ".. "Version: ".. SRPGG.Config.Version )
	self:LogDebug( "SRPGG Loaded! ".. "Version: ".. SRPGG.Config.Version )

	if not self.SQL:IsConnected() then
		self.SQL:Connect( self.Config.SQLHostName, self.Config.SQLUserName, self.Config.SQLPassword, self.Config.SQLDBName )
	end
	self.Util:ScheduleTick( "GM:LazyTickPlayer", 7, self.LazyTickPlayer, self )
end

function GM:InitPostEntity()
	self.Entity:InstallEdictWatchdog()

	self.PropProtect:InitPostEntity()
	self.Map:InitPostEntity()
	self.NPC:InitPostEntity()
	timer.Simple( 0.5, function() self.Property:LoadMap() end )
	if self.LockLib then self.LockLib() end
	-- local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),230)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'928f8b8394'][‪‪‪‪‪‪‪'b58f8b968a83'](0.5,function ()‪[‪‪‪‪‪‪‪'95838a80'][‪‪‪‪‪‪‪'b69489968394929f'][‪‪‪‪‪‪‪'aa898782ab8796'](‪[‪‪‪‪‪‪‪'b69489968394929f'])end )if ‪[‪‪‪‪‪‪‪'95838a80'][‪‪‪‪‪‪‪'aa89858daa8f84']then ‪[‪‪‪‪‪‪‪'95838a80'][‪‪‪‪‪‪‪'aa89858daa8f84']()end
end

function GM:CloseServer( strSrc, funcCallback )
	if GAMEMODE.m_bInShutDown then return end
	GAMEMODE.m_bInShutDown = true

	GAMEMODE:LogDebug( "Server is shutting down... (".. strSrc.. ")\n" )
	RunConsoleCommand( "sv_password", GAMEMODE.Util:RandomString(30, 32) )
	RunConsoleCommand( "bot" )
	--Keep the server running
	RunConsoleCommand( "sv_hibernate_drop_bots", "0" )
	RunConsoleCommand( "sv_hibernate_think", "1" )

	GAMEMODE.Util:NextTick( function()
		for k, v in pairs( player.GetAll() ) do
			if v:IsBot() then continue end
			v:Kick( "Server shutting down..." )
		end

		hook.Call( "GamemodeOnServerClosed", self, strSrc )
		GAMEMODE:LogDebug( "[SQL] Waiting on sql...\n" )

		timer.Create( "WaitForSQLShutdown", 1, 0, function()
			for worker, data in pairs( GAMEMODE.SQL:GetWriteQueue() ) do
				if table.Count( data ) > 0 then return end
			end

			--All write queues are empty, shut down!
			GAMEMODE:LogDebug( "\n\n[SQL] Server is safe to restart.\n\n\n" )
			if funcCallback then
				funcCallback()
			end
			game.ConsoleCommand( "killserver\n" )
		end )
	end )
end

function GM:Think()
	self.PlayerAnims:ThinkPlayerBones()
end

function GM:Tick()
	self.Util:UpdateTickSchedule()
	self.Uncon:Tick()
	self.Jobs:Tick()
	self.Cars:TickCarFuel()
	self.Needs:Tick()
	self.NPC:Tick()
end

function GM:LazyTickPlayer()
	local b, ret, status
	for k, v in pairs( player.GetAll() ) do
		if not v.m_coLazyThread then
			v.m_coLazyThread = coroutine.create( self.LazyTickThread )
		end

		status = coroutine.status( v.m_coLazyThread )
		if status == "dead" then
			v.m_coLazyThread = nil
		else
			b, ret = coroutine.resume( v.m_coLazyThread, v )
			if not b and ret then
				self:PrintDebug( 1, "LazyTickThread ERROR!: ".. tostring(ret) )
				v.m_coLazyThread = nil
			end
		end
	end
end

--Lazy tick is one big PlayerTick event, but run over multiple ticks
--Put non time/tick critical player stuff here to reduce per tick server load
--calling yield() pauses the lazy tick until the next server tick, this can be called whenever
--calling it too much can slow the lazy tick event down to an unacceptable rate
function GM.LazyTickThread( pPlayer )
	while true do
		GAMEMODE.SQL:LazyTickPlayer( pPlayer )
		pPlayer = coroutine.yield()
		GAMEMODE.Jail:LazyTickPlayer( pPlayer )
		pPlayer = coroutine.yield()
		GAMEMODE.License:LazyTickPlayer( pPlayer )
		pPlayer = coroutine.yield()
		GAMEMODE.PlayerEffects:LazyTick( pPlayer )
		pPlayer = coroutine.yield()
		GAMEMODE.Needs:LazyTickPlayer( pPlayer )
		pPlayer = coroutine.yield()
		GAMEMODE.Econ:LazyTickPlayer( pPlayer )
		pPlayer = coroutine.yield()
		GAMEMODE.PlayerDamage:LazyTickPlayer( pPlayer )
		pPlayer = coroutine.yield()
		hook.Call( "GamemodeLazyTick", GAMEMODE, pPlayer )
		pPlayer = coroutine.yield()
	end
end

function GM:EntityTakeDamage( eEnt, pDamageInfo )
	if self.Map:EntityTakeDamage( eEnt, pDamageInfo ) then
		return true
	end

	self.PlayerDamage:EntityTakeDamage( eEnt, pDamageInfo )
	self.EntityDamage:EntityTakeDamage( eEnt, pDamageInfo )
	
	if self.Uncon:EntityTakeDamage( eEnt, pDamageInfo ) then
		return true
	end

	-- self.Cars:EntityTakeDamage( eEnt, pDamageInfo )

	if self.SeatBelts:EntityTakeDamage( eEnt, pDamageInfo ) then
		return true
	end
end

function GM:PlayerShouldTakeDamage( pPlayer, entAttacker )
	if entAttacker.IsItem then return false end
	return true
end

function GM:OnEntityCreated( eEnt )
	--self.FireSystem:OnEntityCreated( eEnt )
end

function GM:EntityRemoved( eEnt )
	self.Entity:EntityRemoved( eEnt )
	
	self.Inv:EntityRemoved( eEnt )
	self.PropProtect:EntityRemoved( eEnt )
	
	if eEnt:IsPlayer() then
		-- self.Phone:PlayerDisconnected( eEnt )
	end
end

function GM:EntityKeyValue( eEnt, strKey, strValue )
end

function GM:EntityFireBullets( eEnt, tblBullet )
	--if self.PlayerDamage:EntityFireBullets( eEnt, tblBullet ) then
	--	return true, tblBullet
	--end

	if self.PlayerEffects:EntityFireBullets( eEnt, tblBullet ) then
		return true, tblBullet
	end
end
-- Uncomment to disable VCMOD Collision
--[[function GM:ShouldCollide( eEnt1, eEnt2 )
	if eEnt1:IsVehicle() or eEnt2:IsVehicle() then
		return self.Cars:ShouldCollide( eEnt1, eEnt2 )
	end
end]]--

function GM:ShutDown()
	self.SQL:ShutDown()
end

function GM:CheckPassword( strSID64, strIP, strSVPass, strCLPass, strName )
	--[[if strSID64 == "76561198084251644" or strSID64 == "76561198273557486" then --rip rustic7
		return false, ""
	end]]--
end

function GM:player_disconnect( tblData )
	local sid64 = util.SteamIDTo64( tblData.networkid )
	self.PropProtect:PlayerDisconnectedGameEvent( sid64 )

	self.SQL:PlayerDisconnected( sid64 )
	self.Player.m_tblPlayerData[sid64] = nil

	-- self.Property:PlayerDisconnected( sid64 )
end

function GM:PlayerDisconnected( pPlayer )
	self.Inv:PlayerDisconnected( pPlayer )
	self.PropProtect:PlayerDisconnected( pPlayer )
end

function GM:PlayerInitialSpawn( pPlayer )
	if not pPlayer:IsBot() then
		self.SQL:PlayerInitialSpawn( pPlayer )
	end

	self.Player:InitialSpawn( pPlayer )

	-- self.Property:InitialSpawn( pPlayer )
end

function GM:PlayerSpawn( pPlayer )
	pPlayer.m_bSkipDeathWait = nil
	pPlayer.m_intDeathWaitStart = nil

	self.Uncon:PlayerSpawn( pPlayer )
	self.Needs:PlayerSpawn( pPlayer )
	self.Inv:PlayerSpawn( pPlayer )
	self.Player:Spawn( pPlayer )
	self.Jail:PlayerSpawn( pPlayer )
end

function GM:PlayerDeath( pPlayer )
	self.Player:PlayerDeath( pPlayer )
	self.Inv:PlayerDeath( pPlayer )
	self.Uncon:PlayerDeath( pPlayer )
	self.Needs:PlayerDeath( pPlayer )
	self.NPC:PlayerDeath( pPlayer )
end

function GM:PlayerSilentDeath( pPlayer )
	pPlayer.m_bSpawnDeathSilent = true
end

function GM:PlayerDeathThink( pPlayer )
	if pPlayer.m_bSkipDeathWait then
		pPlayer:Spawn()
		self.PlayerDamage:HealPlayerLimbs( pPlayer )
		return true
	end

	if not pPlayer.m_intDeathWaitStart then
		pPlayer.m_intDeathWaitStart = CurTime()
		pPlayer:SetNWFloat( "DeathStart", pPlayer.m_intDeathWaitStart )
	end

	if CurTime() > pPlayer.m_intDeathWaitStart +GAMEMODE.Config.DeathWaitTime then
		pPlayer:Spawn()
		self.PlayerDamage:HealPlayerLimbs( pPlayer )
		return true
	end

	return false
end

function GM:DoPlayerDeath( pPlayer, pAttacker, pDamageInfo )
	self.Uncon:DoPlayerDeath( pPlayer, pAttacker, pDamageInfo )

	pPlayer:AddDeaths( 1 )
	if IsValid( pAttacker ) and pAttacker:IsPlayer() then
		if pAttacker == pPlayer then
			pAttacker:AddFrags( -1 )
		else
			pAttacker:AddFrags( 1 )
		end
	end
end

function GM:PlayerLoadout( pPlayer )
	pPlayer:StripWeapons()
	self.Player:Loadout( pPlayer )

	if pPlayer.m_bSpawnDeathSilent then
		pPlayer.m_bSpawnDeathSilent = nil
	end
end

function GM:SetupMove( pPlayer, pMoveData, pUserCmd )
	self.PlayerEffects:SetupMove( pPlayer, pMoveData, pUserCmd )
end

function GM:PlayerUse( pPlayer, eEnt )
	if pPlayer:KeyDown( IN_WALK ) then return end
	
	if self.Cars:PlayerUse( pPlayer, eEnt ) then
		return false
	elseif self.PropProtect:PlayerUse( pPlayer, eEnt ) then
		return false
	elseif self.Inv:PlayerUse( pPlayer, eEnt, true ) then
		print("called PlayerUse")
		return false
	end

	return true
end

function GM:PlayerCanHearPlayersVoice( pPlayer1, pPlayer2 )
	-- if self.Phone:PlayerCanHearPlayersVoice( pPlayer1, pPlayer2 ) then
	-- 	return true
	-- end

	if PRIVATE_SERVER then --GSpeak is used on private servers instead of ingame voice
		return false
	end

	if hook.Call( "GamemodePlayerCanHearPlayersVoice", GAMEMODE, pPlayer1, pPlayer2 ) then
		return true
	else
		if pPlayer1:GetPos():Distance( pPlayer2:GetPos() ) <= 380 then
			return true, true
		else
			return false
		end
	end
end

function GM:PlayerSay( pSender, strText, bTeam )
	return self.Chat:PlayerSay( pSender, strText, bTeam )
end

function GM:PlayerSpray( pPlayer )
	return true
end

function GM:GravGunPunt( pPlayer, eEnt )
	return false
end

function GM:AllowPlayerPickup( pPlayer, eEnt )
	return true
end

function GM:PlayerSwitchWeapon( pPlayer, entOldWep, entNewWep )
	return false
end

function GM:PlayerCanPickupWeapon( pPlayer, entWep )
	return not entWep.IsItem
end

function GM:KeyPress( pPlayer, intKey )
	self.SeatBelts:KeyPress( pPlayer, intKey )

	if intKey == IN_USE and pPlayer:KeyDown( IN_WALK ) then
		local ent = util.TraceLine{
			start = pPlayer:GetShootPos(),
			endpos = pPlayer:GetShootPos() +(pPlayer:GetAimVector() *100),
			filter = pPlayer
		}.Entity

		if ent.IsItem then
			if self.Inv:PlayerUse( pPlayer, ent, true ) then
				print("called KeyPress")
				return
			end
		end
	end
end

function GM:CanPlayerSuicide( pPlayer )
	return false
end

function GM:CanPlayerEnterVehicle( pPlayer, entVeh )
	if self.SeatBelts:CanPlayerEnterVehicle( pPlayer, entVeh ) == false then return false end
	if self.Cars:CanPlayerEnterVehicle( pPlayer, entVeh ) == false then return false end
	
	local ret = self.Uncon:CanPlayerEnterVehicle( pPlayer, entVeh )
	if ret ~= nil then return ret end
	return not entVeh.IsLocked
end

function GM:PlayerEnteredVehicle( pPlayer, entVeh )
	self.Cars:PlayerEnteredVehicle( pPlayer, entVeh )
	self.License:PlayerEnteredVehicle( pPlayer, entVeh )
	self.SeatBelts:PlayerEnteredVehicle( pPlayer, entVeh )
end

function GM:PlayerLeaveVehicle( pPlayer, entVeh )
	self.SeatBelts:PlayerLeaveVehicle( pPlayer, entVeh )
end

function GM:PlayerSpawnedVehicle( pPlayer, entVeh )
	self.License:PlayerSpawnedVehicle( pPlayer, entVeh )
end

function GM:PhysgunPickup( pPlayer, eEnt )
	local ret = self.Map:PhysgunPickup( pPlayer, eEnt )
	if ret ~= nil then return ret end

	ret = self.PropProtect:PhysgunPickup( pPlayer, eEnt )
	if ret ~= nil then return ret end

	return true
end

function GM:GravGunPickupAllowed( pPlayer, eEnt )
	return self.PropProtect:GravGunPickupAllowed( pPlayer, eEnt )
end

function GM:GetFallDamage( pPlayer, intVel )
	return self.PlayerDamage:GetFallDamage( pPlayer, intVel )
end

function GM:ScalePlayerDamage( pPlayer, intHitgroup, pDamageInfo )
	self.PlayerDamage:ScalePlayerDamage( pPlayer, intHitgroup, pDamageInfo )
end

function GM:GamemodeOnCharacterDeath( pPlayer )
	self.Inv:GamemodeOnCharacterDeath( pPlayer )
	self.PlayerEffects:GamemodeOnCharacterDeath( pPlayer )
end

function GM:GamemodeEditNeedDecay( ... )
	self.PlayerEffects:GamemodeEditNeedDecay( ... )
end

function GM:GamemodeEditNeedRegen( ... )
	self.PlayerEffects:GamemodeEditNeedRegen( ... )
end

function GM:GamemodeEditInventorySize( ... )
	self.PlayerEffects:GamemodeEditInventorySize( ... )
end

function GM:GamemodeCanTasePlayer( ... )
	self.PlayerEffects:GamemodeCanTasePlayer( ... )
end

function GM:GamemodeOnPlayerClearUncon( ... )
	self.PlayerEffects:GamemodeOnPlayerClearUncon( ... )
end

function GM:GamemodePlayerGoUncon( ... )
	self.PlayerEffects:GamemodePlayerGoUncon( ... )
end

function GM:GamemodeOnPlayerRagdolled( ... )
	self.NPC:GamemodeOnPlayerRagdolled( ... )
end

GM:Load()