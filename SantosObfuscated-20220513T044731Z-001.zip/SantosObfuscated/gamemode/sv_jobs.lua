--[[
	Name: sv_jobs.lua
	For: SantosRP
	By: Ultra
	Edited By: QuackDuck (QuackDuck#6610)
	For: AceRP.gg
]]
--
GM.Jobs = (GAMEMODE or GM).Jobs or {}
GM.Jobs.m_tblJobs = (GAMEMODE or GM).Jobs.m_tblJobs or {}
local jobTable = {}
local bJobTable = {}

function GM.Jobs:LoadJobs()
	GM:PrintDebug(0, "->LOADING JOBS")
	local foundFiles, foundFolders = file.Find(GM.Config.GAMEMODE_PATH .. "jobs/*", "LUA")
	GM:PrintDebug(0, "\tFound " .. #foundFiles .. " files.")

	for k, v in pairs(foundFiles) do
		GM:PrintDebug(0, "\tLoading " .. v)
		local ext = v:GetExtensionFromFilename()

		if v:sub(1, 3) == "sv_" then
			if GM.PRECOMPILED then
				if ext ~= "dat" then continue end
				GM.loadChunk(GM.Config.GAMEMODE_PATH .. "jobs/" .. v)
			else
				if ext ~= "lua" then continue end
				include(GM.Config.GAMEMODE_PATH .. "jobs/" .. v)
			end
		elseif v:sub(1, 3) == "sh_" then
			include(GM.Config.GAMEMODE_PATH .. "jobs/" .. v)
			AddCSLuaFile(GM.Config.GAMEMODE_PATH .. "jobs/" .. v)
		else
			AddCSLuaFile(GM.Config.GAMEMODE_PATH .. "jobs/" .. v)
		end
	end

	GM:PrintDebug(0, "->JOBS LOADED")

end
/*
	GM.Jobs:Register(tblJob)
	GM.Jobs:GetNumPlayers(intJobID)
		ret: int count
	GM.Jobs:IsPlayerWhitelisted(pPlayer, intJobID)
		ret: bool true
	GM.Jobs:WhitelistPlayer(pPlayer, intJobID)
	GM.Jobs:UnWhitelistPlayer(pPlayer, intJobID)
*/
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),207)) end return ‪‪‪‪‪ end local false‪‪={}local elseif‪={}local ‪‪else=‪[‪‪‪‪‪‪‪'ac85a0ad9baeada3aa']or {}‪[‪‪‪‪‪‪‪'a7a0a0a4'][‪‪‪‪‪‪‪'8eabab'](‪‪‪‪‪‪‪'88aea2aaa2a0abaa9fa3aeb6aabd9caabb85a0ad',‪‪‪‪‪‪‪'beabe1bcaea1bba0bcbfa3aeb6aabda5a0adbcacaeaca7aa',function (true‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪end)if true‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']then ‪‪else[true‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']][true‪‪‪‪‪‪‪‪‪‪‪‪]=nil true‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']=nil end ‪‪else[‪‪‪‪‪‪‪‪end]=‪‪else[‪‪‪‪‪‪‪‪end]or {}‪‪else[‪‪‪‪‪‪‪‪end][true‪‪‪‪‪‪‪‪‪‪‪‪]=true true‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']=‪‪‪‪‪‪‪‪end end )‪[‪‪‪‪‪‪‪'a7a0a0a4'][‪‪‪‪‪‪‪'8eabab'](‪‪‪‪‪‪‪'9fa3aeb6aabd8ba6bcaca0a1a1aaacbbaaab',‪‪‪‪‪‪‪'beabe1bcaea1bba0bcbfa3aeb6aabda3aaaeb9aaacaeaca7aa',function (not‪‪‪‪‪‪‪‪‪‪‪)local ‪else=‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'88aabb9fa3aeb6aabd85a0ad868b'](‪[‪‪‪‪‪‪‪'85a0adbc'],not‪‪‪‪‪‪‪‪‪‪‪)if ‪else then if ‪‪else[‪else]then ‪‪else[‪else][not‪‪‪‪‪‪‪‪‪‪‪]=nil end else if not‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']then if ‪‪else[not‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']]then ‪‪else[not‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'90a683aebcbb85a0ad868b']][not‪‪‪‪‪‪‪‪‪‪‪]=nil end else for do‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'bfaea6bdbc'](‪‪else)do for ‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪if,then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'bfaea6bdbc'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)do if ‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪if==not‪‪‪‪‪‪‪‪‪‪‪ or then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪==not‪‪‪‪‪‪‪‪‪‪‪ then ‪‪else[do‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪][not‪‪‪‪‪‪‪‪‪‪‪]=nil end end end end end end )‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'9daaa8a6bcbbaabd']=function (function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,function‪‪‪)function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a290bbada385a0adbc'][function‪‪‪[‪‪‪‪‪‪‪'868b']]=function‪‪‪ ‪[‪‪‪‪‪‪‪'9088'][function‪‪‪[‪‪‪‪‪‪‪'8aa1baa2']]=function‪‪‪[‪‪‪‪‪‪‪'868b']‪[‪‪‪‪‪‪‪'bbaaaea2'][‪‪‪‪‪‪‪'9caabb9abf'](function‪‪‪[‪‪‪‪‪‪‪'868b'],function‪‪‪[‪‪‪‪‪‪‪'81aea2aa'],function‪‪‪[‪‪‪‪‪‪‪'9baaaea28ca0a3a0bd']or ‪[‪‪‪‪‪‪‪'8ca0a3a0bd'](255,255,255,255))if ‪[‪‪‪‪‪‪‪'a6bcbbaeada3aa'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'])then if ‪[‪‪‪‪‪‪‪'a6bcbbaeada3aa'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'82aea3aa'])then for until‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪until in ‪[‪‪‪‪‪‪‪'bfaea6bdbc'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'82aea3aa'])do ‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9fbdaaacaeaca7aa82a0abaaa3'](‪‪‪‪‪‪‪‪‪‪‪‪until)end end if ‪[‪‪‪‪‪‪‪'a6bcbbaeada3aa'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'89aaa2aea3aa'])then for true‪‪‪‪,break‪‪‪‪‪‪‪‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'bfaea6bdbc'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'89aaa2aea3aa'])do ‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9fbdaaacaeaca7aa82a0abaaa3'](break‪‪‪‪‪‪‪‪‪‪‪‪‪‪)end end if ‪[‪‪‪‪‪‪‪'a6bcbcbbbda6a1a8'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'82aea3aa9089aea3a3adaeaca4'])then ‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9fbdaaacaeaca7aa82a0abaaa3'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'82aea3aa9089aea3a3adaeaca4'])end if ‪[‪‪‪‪‪‪‪'a6bcbcbbbda6a1a8'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'89aaa2aea3aa9089aea3a3adaeaca4'])then ‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9fbdaaacaeaca7aa82a0abaaa3'](function‪‪‪[‪‪‪‪‪‪‪'9fa3aeb6aabd82a0abaaa3'][‪‪‪‪‪‪‪'89aaa2aea3aa9089aea3a3adaeaca4'])end end if function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']then local false‪‪‪‪‪‪=‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'859c80819ba09baeada3aa'](‪[‪‪‪‪‪‪‪'a9a6a3aa'][‪‪‪‪‪‪‪'9daaaeab'](‪‪‪‪‪‪‪'a2aeb5aabdbfe0a5a0ad90b8a7a6bbaaa3a6bcbbbce0a3a6bcbb90'..function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']..‪‪‪‪‪‪‪'e1bbb7bb',‪‪‪‪‪‪‪'8b8e9b8e')or ‪‪‪‪‪‪‪'')false‪‪[function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]=false‪‪‪‪‪‪ if !false‪‪‪‪‪‪ or ‪[‪‪‪‪‪‪‪'bbaeada3aa'][‪‪‪‪‪‪‪'86bc8aa2bfbbb6'](false‪‪‪‪‪‪)or false‪‪‪‪‪‪==‪‪‪‪‪‪‪'' then false‪‪[function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]={}end local if‪=‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'859c80819ba09baeada3aa'](‪[‪‪‪‪‪‪‪'a9a6a3aa'][‪‪‪‪‪‪‪'9daaaeab'](‪‪‪‪‪‪‪'a2aeb5aabdbfe0a5a0ad90ada3aeaca4a3a6bcbbe0a3a6bcbb90'..function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']..‪‪‪‪‪‪‪'e1bbb7bb',‪‪‪‪‪‪‪'8b8e9b8e')or ‪‪‪‪‪‪‪'')elseif‪[function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]=if‪ if !if‪ or ‪[‪‪‪‪‪‪‪'bbaeada3aa'][‪‪‪‪‪‪‪'86bc8aa2bfbbb6'](if‪)or if‪==‪‪‪‪‪‪‪'' then elseif‪[function‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]={}end end end ‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'88aabb81baa29fa3aeb6aabdbc']=function (end‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,if‪‪‪‪‪‪‪)local ‪‪do=0 if #‪‪else<=0 then return 0 end if ‪‪else[if‪‪‪‪‪‪‪]then ‪‪do=‪[‪‪‪‪‪‪‪'bbaeada3aa'][‪‪‪‪‪‪‪'8ca0baa1bb'](‪‪else[if‪‪‪‪‪‪‪])return ‪‪do end end ‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'86bc9fa3aeb6aabd8da3aeaca4a3a6bcbbaaab']=function (‪‪‪‪‪‪‪‪‪‪until,if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪return)local in‪‪‪‪‪=‪[‪‪‪‪‪‪‪'a7a0a0a4'][‪‪‪‪‪‪‪'8caea3a3'](‪‪‪‪‪‪‪'88aea2aaa2a0abaa86bc9fa3aeb6aabd85a0ad8da3aeaca4a3a6bcbbaaab',‪[‪‪‪‪‪‪‪'888e828a82808b8a'],if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪return)if in‪‪‪‪‪~=nil then return in‪‪‪‪‪ end local ‪‪‪‪‪‪in=‪‪‪‪‪‪‪‪‪‪until[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](‪‪‪‪‪‪‪‪‪‪until,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪return)if not ‪‪‪‪‪‪in[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']then return true end if elseif‪[‪‪‪‪‪‪in[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]then if elseif‪[‪‪‪‪‪‪in[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)]then return true end end return false end ‪[‪‪‪‪‪‪‪'bfbda6a1bb'](‪‪‪‪‪‪‪'878a838380ef8a818c9d969f9b8a8bef838083')‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'8da3aeaca4a3a6bcbb9fa3aeb6aabd']=function (‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪nil,break‪‪‪‪,then‪‪‪‪‪‪‪‪‪‪‪‪‪‪)local goto‪‪=‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪nil[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪nil,then‪‪‪‪‪‪‪‪‪‪‪‪‪‪)if elseif‪[goto‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]then if elseif‪[goto‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][break‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](break‪‪‪‪)]then return true else elseif‪[goto‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][break‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](break‪‪‪‪)]=break‪‪‪‪[‪‪‪‪‪‪‪'81a6aca4'](break‪‪‪‪)end end ‪[‪‪‪‪‪‪‪'a9a6a3aa'][‪‪‪‪‪‪‪'98bda6bbaa'](‪‪‪‪‪‪‪'a2aeb5aabdbfe0a5a0ad90ada3aeaca4a3a6bcbbe0a3a6bcbb90'..goto‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']..‪‪‪‪‪‪‪'e1bbb7bb',‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9baeada3aa9ba0859c8081'](elseif‪[goto‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]))break‪‪‪‪[‪‪‪‪‪‪‪'8eabab81a0bbaa'](break‪‪‪‪,‪‪‪‪‪‪‪'96a0baefb8aabdaaefada3aeaca4a3a6bcbbaaabefa9bda0a2ef'..‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪nil[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪nil,then‪‪‪‪‪‪‪‪‪‪‪‪‪‪)[‪‪‪‪‪‪‪'81aea2aa']..‪‪‪‪‪‪‪'ee')end ‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'9aa18da3aeaca4a3a6bcbb9fa3aeb6aabd']=function (end‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for,elseif‪‪‪‪‪‪‪‪‪‪‪‪)local and‪‪‪‪‪=end‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](end‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,elseif‪‪‪‪‪‪‪‪‪‪‪‪)if elseif‪[and‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]then if elseif‪[and‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for[‪‪‪‪‪‪‪'9cbbaaaea2868b'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for)]then elseif‪[and‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for[‪‪‪‪‪‪‪'9cbbaaaea2868b'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for)]=nil else end end ‪[‪‪‪‪‪‪‪'a9a6a3aa'][‪‪‪‪‪‪‪'98bda6bbaa'](‪‪‪‪‪‪‪'a2aeb5aabdbfe0a5a0ad90ada3aeaca4a3a6bcbbe0a3a6bcbb90'..and‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']..‪‪‪‪‪‪‪'e1bbb7bb',‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9baeada3aa9ba0859c8081'](elseif‪[and‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]))‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for[‪‪‪‪‪‪‪'8eabab81a0bbaa'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for,‪‪‪‪‪‪‪'96a0baefb8aabdaaefbaa1ada3aeaca4a3a6bcbbaaabefa9bda0a2ef'..end‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](end‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,elseif‪‪‪‪‪‪‪‪‪‪‪‪)[‪‪‪‪‪‪‪'81aea2aa']..‪‪‪‪‪‪‪'ee')if ‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'88aabb9fa3aeb6aabd85a0ad868b'](‪[‪‪‪‪‪‪‪'85a0adbc'],‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for)==elseif‪‪‪‪‪‪‪‪‪‪‪‪ and ‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'88aabb9fa3aeb6aabd85a0ad868b'](‪[‪‪‪‪‪‪‪'85a0adbc'],‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for)~=‪[‪‪‪‪‪‪‪'85808d908c86998683868e81']then ‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'9caabb9fa3aeb6aabd85a0ad'](‪[‪‪‪‪‪‪‪'85a0adbc'],‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪for,‪[‪‪‪‪‪‪‪'85808d908c86998683868e81'])end end ‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'86bc9fa3aeb6aabd98a7a6bbaaa3a6bcbbaaab']=function (elseif‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪until,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪then)local ‪‪‪‪‪‪or=‪[‪‪‪‪‪‪‪'a7a0a0a4'][‪‪‪‪‪‪‪'8caea3a3'](‪‪‪‪‪‪‪'88aea2aaa2a0abaa86bc9fa3aeb6aabd85a0ad98a7a6bbaaa3a6bcbbaaab',‪[‪‪‪‪‪‪‪'888e828a82808b8a'],‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪until,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪then)if ‪‪‪‪‪‪or~=nil then return ‪‪‪‪‪‪or end local while‪‪‪‪‪‪‪‪‪‪=elseif‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](elseif‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪then)if not while‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']then return true end if false‪‪[while‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]then if false‪‪[while‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪until[‪‪‪‪‪‪‪'9cbbaaaea2868b'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪until)]then return true end end return false end ‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb9fa3aeb6aabd']=function (‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪continue)local while‪‪‪‪=‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,‪‪‪‪‪‪‪‪‪‪‪continue)if false‪‪[while‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]then if false‪‪[while‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)]then return true else false‪‪[while‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)]=function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'81a6aca4'](function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)end end local ‪‪‪‪‪‪‪‪‪‪‪function=‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9baeada3aa9ba0859c8081'](false‪‪[while‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']])‪[‪‪‪‪‪‪‪'a9a6a3aa'][‪‪‪‪‪‪‪'98bda6bbaa'](‪‪‪‪‪‪‪'a2aeb5aabdbfe0a5a0ad90b8a7a6bbaaa3a6bcbbbce0a3a6bcbb90'..while‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']..‪‪‪‪‪‪‪'e1bbb7bb',‪‪‪‪‪‪‪‪‪‪‪function)function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8eabab81a0bbaa'](function‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪'96a0baefb8aabdaaefb8a7a6bbaaa3a6bcbbaaabefa9a0bdef'..while‪‪‪‪[‪‪‪‪‪‪‪'81aea2aa']..‪‪‪‪‪‪‪'ee')end ‪[‪‪‪‪‪‪‪'8882'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'9aa198a7a6bbaaa3a6bcbb9fa3aeb6aabd']=function (break‪,if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪if)local then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪=break‪[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](break‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪if)if false‪‪[then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]then if false‪‪[then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)]then false‪‪[then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']][if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9cbbaaaea2868b'](if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)]=nil else end end ‪[‪‪‪‪‪‪‪'a9a6a3aa'][‪‪‪‪‪‪‪'98bda6bbaa'](‪‪‪‪‪‪‪'a2aeb5aabdbfe0a5a0ad90b8a7a6bbaaa3a6bcbbbce0a3a6bcbb90'..then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']..‪‪‪‪‪‪‪'e1bbb7bb',‪[‪‪‪‪‪‪‪'babba6a3'][‪‪‪‪‪‪‪'9baeada3aa9ba0859c8081'](false‪‪[then‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'98a7a6bbaaa3a6bcbb81aea2aa']]))if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8eabab81a0bbaa'](if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪'96a0baefb8aabdaaefbaa1b8a7a6bbaaa3a6bcbbaaabefa9a0bdef'..break‪[‪‪‪‪‪‪‪'88aabb85a0ad8db6868b'](break‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪if)[‪‪‪‪‪‪‪'81aea2aa']..‪‪‪‪‪‪‪'ee')if ‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'88aabb9fa3aeb6aabd85a0ad868b'](‪[‪‪‪‪‪‪‪'85a0adbc'],if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)==‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪if and ‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'88aabb9fa3aeb6aabd85a0ad868b'](‪[‪‪‪‪‪‪‪'85a0adbc'],if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)~=‪[‪‪‪‪‪‪‪'85808d908c86998683868e81']then ‪[‪‪‪‪‪‪‪'888e828a82808b8a'][‪‪‪‪‪‪‪'85a0adbc'][‪‪‪‪‪‪‪'9caabb9fa3aeb6aabd85a0ad'](‪[‪‪‪‪‪‪‪'85a0adbc'],if‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪[‪‪‪‪‪‪‪'85808d908c86998683868e81'])end end



function GM.Jobs:GetJobs()
	return self.m_tblJobs
end

function GM.Jobs:GetJobByID(intJobID)
	return self.m_tblJobs[intJobID]
end

function GM.Jobs:SetPlayerJob(pPlayer, intJobID, bNoNote, bNoLoadout)
	if self:GetJobByID(intJobID).WhitelistName then
		if not self:IsPlayerWhitelisted(pPlayer, intJobID) then
			pPlayer:AddNote("You are not in the whitelist for this job.")

			return
		end
	end

	if hook.Call("GamemodeCanPlayerSetJob", GAMEMODE, pPlayer, intJobID) == false then return end

	--Player already has a job, call the switch job event on the old job first
	if pPlayer.m_intJobID then
		self:GetJobByID(pPlayer.m_intJobID):OnPlayerQuitJob(pPlayer)
		hook.Call("GamemodePlayerQuitJob", GAMEMODE, pPlayer, pPlayer.m_intJobID)
	end

	pPlayer.m_intJobID = intJobID
	pPlayer:SetTeam(intJobID)
	pPlayer.m_intJobTime = RealTime()
	self:GetJobByID(intJobID):OnPlayerJoinJob(pPlayer) --Call the switch job event on the new job

	if self:GetJobByID(intJobID).PlayerSetModel then
		self:GetJobByID(intJobID):PlayerSetModel(pPlayer)
	else --fallback to civ
		GAMEMODE.Jobs:GetJobByID(JOB_CIVILIAN):PlayerSetModel(pPlayer)
	end

	hook.Call("GamemodePlayerSetJob", GAMEMODE, pPlayer, intJobID)

	if not bNoNote then
		pPlayer:AddNote("You are now a " .. self:GetJobByID(intJobID).Name .. "!")
	end

	if not bNoLoadout then
		pPlayer:StripWeapons()
		GAMEMODE.Inv:RemoveJobItems(pPlayer)
		hook.Call("PlayerLoadout", GAMEMODE, pPlayer)
	end
end

function GM.Jobs:GetPlayerJob(pPlayer)
	return self.m_tblJobs[pPlayer.m_intJobID]
end

function GM.Jobs:GetPlayerJobID(pPlayer)
	return pPlayer and pPlayer.m_intJobID or nil
end

function GM.Jobs:GetPlayerJobEnum(pPlayer)
	return self:GetPlayerJob(pPlayer).Enum
end

function GM.Jobs:PlayerHasJob(pPlayer)
	return pPlayer.m_intJobID and true or false
end

function GM.Jobs:PlayerIsJob(pPlayer, intJobID)
	return pPlayer.m_intJobID == intJobID
end


function GM.Jobs:GetPlayerPay(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return 0 end
	local jobData = self:GetPlayerJob(pPlayer)
	local pay = 0

	for k, v in ipairs(jobData.Pay) do
		if v.PlayTime > (saveTable.JobTimes and saveTable.JobTimes[jobData.ID] or 0) then continue end

		if v.Pay > pay then
			pay = v.Pay
		end
	end

	local mod = {
		pay = pay
	}

	hook.Call("GamemodeEditPlayerJobPay", GAMEMODE, pPlayer, mod)
	pay = mod.pay
	local data = GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "pay_boost")
	pay = (data and data.PrecentBoost) and pay + (pay * data.PrecentBoost) or pay

	return math.ceil(pay)
end

function GM.Jobs:UpdateSavedPlayTime(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.JobTimes = saveTable.JobTimes or {}
	local jobID = self:GetPlayerJobID(pPlayer)
	saveTable.JobTimes[jobID] = saveTable.JobTimes[jobID] or 0
	local lastPay = self:GetPlayerPay(pPlayer)
	saveTable.JobTimes[jobID] = saveTable.JobTimes[jobID] + (RealTime() - pPlayer.m_intJobTime)
	local newPay = self:GetPlayerPay(pPlayer)
	pPlayer.m_intJobTime = RealTime()

	if newPay ~= lastPay then
		pPlayer:AddNote("You have played this job for over " .. math.Round(saveTable.JobTimes[jobID] / 60) .. " minutes!")
		pPlayer:AddNote("You have been promoted for your hard work! You now make $" .. string.Comma(newPay) .. " working this job.")
	end

	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "JobTimes")
	GAMEMODE.Player:SetGameVar(pPlayer, "playtime", GAMEMODE.Jobs:GetTotalSavedPlayTime(pPlayer, true))
end

function GM.Jobs:GetTotalSavedPlayTime(pPlayer, bNoCache)
	if bNoCache then
		local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
		if not saveTable or not saveTable.JobTimes then return 0 end
		local ret = 0

		for k, v in pairs(saveTable.JobTimes) do
			ret = ret + v
		end

		return ret
	else
		local time = GAMEMODE.Player:GetGameVar(pPlayer, "playtime", 0)

		return time ~= 0 and time or GAMEMODE.Jobs:GetTotalSavedPlayTime(pPlayer, true)
	end
end

function GM.Jobs:GetSavedPlayTime(pPlayer, intJobID)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.JobTimes then return 0 end

	return saveTable.JobTimes[intJobID] or 0
end

function GM.Jobs:CalcJobPlayerCap(intJobID)
	local data = self.m_tblJobs[intJobID]
	if not data then return end
	local curPlayers = #player.GetAll()
	local minP, maxP = data.PlayerCap.Min, data.PlayerCap.Max
	local minS, maxE = data.PlayerCap.MinStart, data.PlayerCap.MaxEnd

	if curPlayers <= minS then
		return minP
	elseif curPlayers >= maxE then
		return maxP
	else
		local scalar = (curPlayers - minS) / (maxE - minS)

		return math.ceil((maxP - minP) * scalar + minP)
	end
end

function GM.Jobs:Tick()
	if not self.m_intLastPlayTimeThink then
		self.m_intLastPlayTimeThink = CurTime() + 5
	end

	if CurTime() > self.m_intLastPlayTimeThink then
		for k, v in pairs(player.GetAll()) do
			if not self:GetPlayerJobID(v) then continue end
			self:UpdateSavedPlayTime(v)
		end

		self.m_intLastPlayTimeThink = CurTime() + 5
	end

	if not self.m_intLastPayThink then
		self.m_intLastPayThink = CurTime() + GAMEMODE.Config.JobPayInterval
	end

	if CurTime() < self.m_intLastPayThink then return end
	self.m_intLastPayThink = CurTime() + GAMEMODE.Config.JobPayInterval

	for k, v in pairs(player.GetAll()) do
		if not self:PlayerHasJob(v) then continue end
		if GAMEMODE.Jail:IsPlayerInJail(v) then continue end
		local pay = self:GetPlayerPay(v)
		local payt = GAMEMODE.Econ:ApplyTaxToSum("income_" .. self:GetPlayerJobID(v), pay, true)
		v:AddBankMoney(payt, "Job paycheck")
		v:AddNote("You received a paycheck from your job!")
		v:AddNote("$" .. string.Comma(payt) .. " (" .. 100 * GAMEMODE.Econ:GetTaxRate("income_" .. self:GetPlayerJobID(v)) .. "% tax) was transfered to your bank account.")
		hook.Call("GamemodePlayerGetJobPay", GAMEMODE, v, payt, pay)
	end
end

hook.Add("GamemodeDefineGameVars", "DefineJobVars", function(pPlayer)
	GAMEMODE.Player:DefineGameVar(pPlayer, "playtime", 0, "UInt32", true)
end)

hook.Add("GamemodePlayerSelectCharacter", "ApplyJobVars", function(pPlayer, intID, tblChar)
	GAMEMODE.Player:SetGameVar(pPlayer, "playtime", GAMEMODE.Jobs:GetTotalSavedPlayTime(pPlayer), true)
end)

hook.Add("GamemodeEditPlayerJobPay", "AddNonCivBonus", function(pPlayer, tblPay)
	if GAMEMODE.Jobs:GetPlayerJobID(pPlayer) ~= JOB_CIVILIAN then
		tblPay.pay = tblPay.pay + 40
	end
end)

