--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--


GM.Chat = {}

if SERVER then
	function GM.Chat:PlayerSay( pPlayer, strText, bTeamOnly )
		return strText or ""
	end
else
	function GM.Chat:ModifyForChatTypes( tblArgs, pPlayer, strText )
		local text, rad, noName = hook.Call( "GamemodeModifyForChatTypes", GAMEMODE, tblArgs, pPlayer, strText )
		if text and rad then
			return text, rad, noName
		end

		return strText, 500
	end
	
	function GM.Chat:OnPlayerChat( pPlayer, strText, bTeamOnly, bIsDead )
		if not IsValid( LocalPlayer() ) then return end
		local pos = LocalPlayer():GetPos()
		local otherpos = IsValid( pPlayer ) and pPlayer:GetPos() or Vector( 0 )
		local chatdist = 500

		local tab = {}
		strText, chatdist, noName = self:ModifyForChatTypes( tab, pPlayer, strText )
		
		if bTeamOnly then
			if pPlayer == LocalPlayer() then
				chat.AddText( Color(255, 100, 100), "Please speak in regular chat." )
			end

			return true
		end
		
		if chatdist > 0 then 
			if pos:Distance( otherpos ) > chatdist then
				return true
			end
		end
		
		if bIsDead then
			if not noName then
				table.insert( tab, Color(255, 30, 40) )
				table.insert( tab, "*DEAD* " )
			end
		end

		if IsValid( pPlayer ) then
			if not noName then
				table.insert( tab, pPlayer )
			end
		else
			table.insert( tab, Color(0, 0, 0) )
			table.insert( tab, "Console" )
		end

		table.insert( tab, Color(255, 255, 255) )
		table.insert( tab, (noName and "" or ": ")..strText )
		chat.AddText( unpack( tab ) )

		return true
	end
end