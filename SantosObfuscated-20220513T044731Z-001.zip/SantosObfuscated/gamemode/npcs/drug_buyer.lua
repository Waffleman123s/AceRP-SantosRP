--[[
	Name: drug_buyer.lua
	For: CityRP
	By: Ultra
]]--

local NPCMeta = {}
NPCMeta.Name = "Drug Dealer"
NPCMeta.UID = "drug_buyer"
NPCMeta.SubText = "Buy and sell drugs here"
NPCMeta.Model = "models/smalls_civilians/pack1/puffer_male_04_f_npc.mdl"
NPCMeta.NoSalesTax = true
NPCMeta.Sounds = {
	StartDialog = {
		"vo/npc/male01/question05.wav", 
		"vo/npc/male01/question07.wav", 
		"vo/npc/male01/question17.wav", 
		"vo/npc/male01/question30.wav",
	},
	EndDialog = {
		"vo/npc/male01/littlecorner01.wav", 
		"vo/npc/male01/question02.wav", 
		"vo/npc/male01/question28.wav",
	}
}
NPCMeta.ItemsForSale = {
	--["Cannabis Seeds (Low Quality)"] = 5,
	--["Cannabis Seeds (Medium Quality)"] = 10,
	["Cannabis Seeds (High Quality)"] = 100,
	["Coca Seeds (High Quality)"] = 150,

	["Phenylacetic Acid"] = 45,
	["Cannabis (Low Quality)"] = 100,
	["Methamphetamine (Low Quality)"] = 400,
	-- ["HNO3"] = 250,
	-- ["Ergot Alkaloids"] = 500
}
NPCMeta.ItemsCanBuy = {
	["Cannabis (Low Quality)"] = 50,
	["Cannabis (Medium Quality)"] = 70,
	["Cannabis (High Quality)"] = 125,
	["Moonshine"] = 45,
	["Methamphetamine (Low Quality)"] = 325,
	["Methamphetamine (Medium Quality)"] = 720,
	["Methamphetamine (High Quality)"] = 950,
	["Cocaine"] = 600,
	["Crack Cocaine"] = 720,
	["Special Brownies (Disgusting Quality)"] = 54,
	["Special Brownies (Average Quality)"] = 69,
	["Special Brownies (Delicious Quality)"] = 82,
	-- ["LSD"] = 5500
}

function NPCMeta:OnPlayerTalk(entNPC, pPlayer)
	GAMEMODE.Net:ShowNPCDialog(pPlayer, "drug_buyer")

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random(self.Sounds.StartDialog)
		entNPC:EmitSound(snd, 54)
		entNPC.m_intLastSoundTime = CurTime() + 2
	end
end

function NPCMeta:OnPlayerEndDialog(pPlayer)
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random(self.Sounds.EndDialog)
		pPlayer.m_entTalkingNPC:EmitSound(snd, 54)
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() + 2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
	end

	function NPCMeta:OnSpawn( entNPC )
		local moveNPC
		moveNPC = function()
			timer.Simple( math.random(GAMEMODE.Config.DrugNPCMoveTime_Min, GAMEMODE.Config.DrugNPCMoveTime_Max), function()
				if not IsValid( entNPC ) then return end

				local pos = table.Random( GAMEMODE.Config.DrugNPCPositions )
				entNPC:SetPos( pos[1] )
				entNPC:SetAngles( pos[2] )
				moveNPC()
			end )
		end

		moveNPC()
	end
elseif CLIENT then
	NPCMeta.RandomGreetings = {"I've got the best stuff around!", "You selling? I'm looking to re-up.", "Always need to keep moving. The police never let up."}

	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog("drug_buyer", self.StartDialog, self)
	end

	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel(self.Model)
		GAMEMODE.Dialog:SetTitle(self.Name)
		GAMEMODE.Dialog:SetPrompt(table.Random(self.RandomGreetings))

		GAMEMODE.Dialog:AddOption("Show me what you have for sale.", function()
			GAMEMODE.Gui:ShowNPCShopMenu(self.UID)
			GAMEMODE.Dialog:HideDialog()
		end)

		GAMEMODE.Dialog:AddOption("I've got drugs I'd like to sell.", function()
			GAMEMODE.Gui:ShowNPCSellMenu(self.UID)
			GAMEMODE.Dialog:HideDialog()
		end)

		GAMEMODE.Dialog:AddOption("Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent(self.UID .. "_end_dialog")
			GAMEMODE.Dialog:HideDialog()
		end)
	end
end

GM.NPC:Register(NPCMeta)