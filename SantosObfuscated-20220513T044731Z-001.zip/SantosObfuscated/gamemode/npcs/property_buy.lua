--[[
	Name: property_buy.lua
	For: SantosRP
	By: Ultra
]]--

local NPCMeta = {}
NPCMeta.Name = "Realtor"
NPCMeta.UID = "property_buy"
NPCMeta.SubText = "Purchase a property here"
NPCMeta.Model = "models/Humans/Group02/male_08.mdl"
NPCMeta.Sounds = {
	StartDialog = {
		"vo/npc/male01/answer30.wav",
		"vo/npc/male01/gordead_ans01.wav",
		"vo/npc/male01/gordead_ques16.wav",
		"vo/npc/male01/hi01.wav",
		"vo/npc/male01/hi02.wav",
	},
	EndDialog = {
		"vo/npc/male01/finally.wav",
		"vo/npc/male01/pardonme01.wav",
		"vo/npc/male01/vanswer01.wav",
		"vo/npc/male01/vanswer13.wav",
	}
}

function NPCMeta:OnPlayerTalk( entNPC, pPlayer )
	GAMEMODE.Net:ShowNPCDialog( pPlayer, "property_buy" )

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.StartDialog )
		entNPC:EmitSound( snd, 60 )
		entNPC.m_intLastSoundTime = CurTime() +2
	end
end

function NPCMeta:OnPlayerEndDialog( pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.EndDialog )
		pPlayer.m_entTalkingNPC:EmitSound( snd, 60 )
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() +2
	end

	pPlayer.m_entTalkingNPC = nil
end

function NPCMeta:ShowBuyMenu( pPlayer, ... )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end
	GAMEMODE.Net:ShowNWMenu( pPlayer, "property_buy" )
end

local function secondsToTime(iSecs)
	local floor,mod,format = math.floor, math.mod, string.format
	local days = floor(iSecs/86400)
	local hours = floor(mod(iSecs, 86400)/3600)
	local minutes = floor(mod(iSecs,3600)/60)
	local seconds = floor(mod(iSecs,60))
	-- return days,hours,minutes
	return format("%d:%02d:%02d",days,hours,minutes)
end

function NPCMeta:ShowRentInfo( pPlayer, ... )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end
	local ownerProps = GAMEMODE.Property:GetPropertiesByOwner(pPlayer)
	for k,v in pairs(ownerProps) do
		local prop = GAMEMODE.Property:GetPropertyByName(v)
		if prop.RentOwned then
			pPlayer:AddNote("You have " .. v .. " for ("..secondsToTime(prop.RentOwned - os.time()).." Remaining) ")
		end

	end
	-- GAMEMODE.Net:ShowNWMenu( pPlayer, "property_buy" )
end


if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialogEvent( "property_buy_menu", self.ShowBuyMenu, self )
		GM.Dialog:RegisterDialogEvent( "property_rent_info", self.ShowRentInfo, self )
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog( "property_buy", self.StartDialog, self )
		GM.Dialog:RegisterDialog( "property_rent_info", self.StartDialog, self )
	end
	
	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "How can I help you?" )

		GAMEMODE.Dialog:AddOption( "I would like to purchase/sell a property.", function()
			GAMEMODE.Net:SendNPCDialogEvent( "property_buy_menu" )
			GAMEMODE.Dialog:HideDialog()
		end )

		local ownerProps = GAMEMODE.Property:GetPropertiesByOwner(pPlayer)
		if #ownerProps >= 1 then
			GAMEMODE.Dialog:AddOption( "I would like to see my lease information.", function()
				GAMEMODE.Net:SendNPCDialogEvent( "property_rent_info" )
				GAMEMODE.Dialog:HideDialog()
			end )
		end

		GAMEMODE.Dialog:AddOption( "Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
end

GM.NPC:Register( NPCMeta )