--[[
	Name: prison_contact.lua
	For: SantosRP
	By: Pcwizdan
]]--



--[[TODO: TO FINISH
DONE - bbox must tp player back to jail (rejail) if not in the 2minute window when lockoutcontrols is active in the jailbreak (successful jailbreak locks out controls for 2 mins and unlocks doors)
DONE - Hacker terminal needs png image 16x16 and distance displayed on screen 2d for waypoint direction to the terminal (terminal needs to be placed in the PD in the conference room on the right (big table))
DONE - Need to have 4 police on the job to start a prison break
DONE - alarm sounds when begin hacking + notify police a hack is in progress
DONE - dont forget to move terminal into pd station.


]]

local NPCMeta = {}
NPCMeta.Name = "Prison Contact"
NPCMeta.UID = "prisoncontact"
NPCMeta.SubText = "Prison Contact NPC"
NPCMeta.Model = "models/odessa.mdl"
NPCMeta.Sounds = {
	StartDialog = {
		"vo/coast/odessa/nlo_cub_hello.wav"
	},
	EndDialog = {
		"vo/coast/odessa/nlo_cub_farewell.wav",
	}
}

function NPCMeta:OnPlayerTalk( entNPC, pPlayer )
--TODO: NO POLICE
	if GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_POLICE then return end --no police

	GAMEMODE.Net:ShowNPCDialog( pPlayer, "prisoncontact_dialog" )

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.StartDialog )
		entNPC:EmitSound( snd, 60 )
		entNPC.m_intLastSoundTime = CurTime() +2
	end
end

function NPCMeta:OnPlayerEndDialog( pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end
	
	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.EndDialog )
		pPlayer.m_entTalkingNPC:EmitSound( snd, 60 )
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() +2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then

	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
		--GM.Dialog:RegisterDialogEvent( "prisoncontact_instruction", self.InstructPrisonBreak, self )
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog("prisoncontact_dialog",self.StartDialog,self)
		GM.Dialog:RegisterDialog("prisoncontact_instruction",self.StartDialog_Instruction,self)
		--GM.Dialog:RegisterDialog("prisoncontact_sendmail",self.StartDialog_SendMail,self) --send message to inmates
		--GM.Dialog:RegisterDialog("prisoncontact_recvmail",self.StartDialog_RecvMail,self) --recv inmate messages
		--GM.Dialog:RegisterDialog("prisoncontact_placehit",self.StartDialog_PlaceHit,self) --hits
	end
	
	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "What do you need?" )

		GAMEMODE.Dialog:AddOption( "I'm here to break out my friends.", function()
			--GAMEMODE.Net:SendNPCDialogEvent( "prisoncontact_instruction" )
			
			GAMEMODE.Dialog:HideDialog()
			--GAMEMODE.Net:SendNPCDialogEvent( LocalPlayer(), "prisoncontact_instruction" )
			self:StartDialog_Instruction()
			
		end )
		GAMEMODE.Dialog:AddOption( "I think I have something I need to do, bye.", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
	
	function NPCMeta:StartDialog_Instruction()
		HackerTerminalVisibleNotice = true --esp guide
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "The terminal is in the Police Department" )
		--Send informatoin to the querying player about hacker terminal for prison break sequence.
		--LocalPlayer():PrintMessage(HUD_PRINTTALK,"Go to the hacker terminal to break your friends out. It will take some time...") --generic message
		GAMEMODE.Dialog:AddOption( "Ok, thank you for the information...", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
end

GM.NPC:Register( NPCMeta )