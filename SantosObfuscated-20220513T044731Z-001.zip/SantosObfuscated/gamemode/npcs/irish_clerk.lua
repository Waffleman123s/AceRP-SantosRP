--[[
	Name: irish_clerk.lua
	For: ProjectSteele.Com
	By: Christopher Steele + Fern
]]
--
local NPCMeta = {}
NPCMeta.Name = "Irish Mob Dealer"
NPCMeta.UID = "irish_clerk"
NPCMeta.SubText = "Purchase items here"
NPCMeta.Model = "models/gman_high.mdl"

NPCMeta.Sounds = {
	StartDialog = {"vo/npc/male01/answer30.wav", "vo/npc/male01/gordead_ans01.wav", "vo/npc/male01/gordead_ques16.wav", "vo/npc/male01/hi01.wav", "vo/npc/male01/hi02.wav"},
	EndDialog = {"vo/npc/male01/finally.wav", "vo/npc/male01/pardonme01.wav", "vo/npc/male01/vanswer01.wav", "vo/npc/male01/vanswer13.wav"}
}

--[itemID] = priceToBuy,
NPCMeta.ItemsForSale = {
	--guns
	["The Irish .500"] = 35000,
	[".500 Magnum 10 Rounds"] = 500
}

--[itemID] = priceToSell,
NPCMeta.ItemsCanBuy = {
	["Cannabis (Medium Quality)"] = 550,
	["Cannabis (High Quality)"] = 950,
	["Moonshine"] = 500,
	["Methamphetamine (Medium Quality)"] = 1025,
	["Methamphetamine (High Quality)"] = 1450,
	["Cocaine"] = 1225,
	["Crack Cocaine"] = 1550,
	["LSD"] = 7500
}

for k, v in pairs(NPCMeta.ItemsForSale) do
	NPCMeta.ItemsCanBuy[k] = math.ceil(v * 0.66)
end

function NPCMeta:OnPlayerTalk(entNPC, pPlayer)
	if GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_IRISH) then
		GAMEMODE.Net:ShowNPCDialog(pPlayer, "irish_clerk")
	else
		GAMEMODE.Net:ShowNPCDialog(pPlayer, "irish_not")
	end

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random(self.Sounds.StartDialog)
		entNPC:EmitSound(snd, 60)
		entNPC.m_intLastSoundTime = CurTime() + 2
	end
end

function NPCMeta:OnPlayerEndDialog(pPlayer)
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random(self.Sounds.EndDialog)
		pPlayer.m_entTalkingNPC:EmitSound(snd, 60)
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() + 2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog("irish_clerk", self.StartDialog, self)
		GM.Dialog:RegisterDialog("irish_not", self.StartDialog_NotIrish, self)
	end

	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel(self.Model)
		GAMEMODE.Dialog:SetTitle(self.Name)
		GAMEMODE.Dialog:SetPrompt("You gonna buy something pal?")

		GAMEMODE.Dialog:AddOption("Show me what you have for sale.", function()
			GAMEMODE.Gui:ShowNPCShopMenu(self.UID)
			GAMEMODE.Dialog:HideDialog()
		end)

		GAMEMODE.Dialog:AddOption("I would like to return some items.", function()
			GAMEMODE.Gui:ShowNPCSellMenu(self.UID)
			GAMEMODE.Dialog:HideDialog()
		end)

		GAMEMODE.Dialog:AddOption("Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent(self.UID .. "_end_dialog")
			GAMEMODE.Dialog:HideDialog()
		end)
	end

	function NPCMeta:StartDialog_NotIrish()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel(self.Model)
		GAMEMODE.Dialog:SetTitle(self.Name)
		GAMEMODE.Dialog:SetPrompt("How can I help you?")

		GAMEMODE.Dialog:AddOption("Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent(self.UID .. "_end_dialog")
			GAMEMODE.Dialog:HideDialog()
		end)
	end
end

GM.NPC:Register(NPCMeta)