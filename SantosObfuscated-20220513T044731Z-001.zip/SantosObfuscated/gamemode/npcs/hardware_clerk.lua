--[[
	Name: hardware_clerk.lua
	For: SantosRP
	By: Ultra
]]--

local NPCMeta = {}
NPCMeta.LocationName = "Hardware Store"
NPCMeta.Name = "Store Clerk"
NPCMeta.UID = "hardware_clerk"
NPCMeta.SubText = "Purchase hardware here"
NPCMeta.Model = "models/odessa.mdl"
NPCMeta.Sounds = {
	StartDialog = {
		"vo/streetwar/sniper/ba_hearcat.wav",
		"vo/streetwar/rubble/ba_illbedamned.wav",
		"vo/k_lab/ba_hesback01.wav",
		"vo/k_lab/ba_thingaway01.wav",
	},
	EndDialog = {
		"vo/k_lab/ba_geethanks.wav",
		"vo/streetwar/nexus/ba_done.wav",
		"vo/k_lab/ba_itsworking04.wav",
	}
}
--[itemID] = priceToBuy,
NPCMeta.ItemsForSale = {
	--ents
	-- ["First Aid Kit"] = 500,
	["Broken Electronics"] = 5,
	["Crafting Table"] = 500,
	["Assembly Table"] = 500,
	["Gun Smithing Table"] = 875,
	["Road Flare"] = 50,
	["Engine Overhaul"] = 5000,
	["Vehicle Repair Kit"] = 3500,
	["Terracotta Pot"] = 75,
	["Stove"] = 375,
	["Propane Cylinder"] = 20,

	--fluids
	["Cleaning Solution"] = 20,
	["Bucket of Fertilizer"] = 7,
	["Potting Soil"] = 5,

	-- Tools/weapons
	["Crowbar"] = 50,
	-- ["Pickaxe"] = 85,
	["Wrench"] = 75,

	--crafting items
	["Wood Plank"] = 100,
	["Paint Bucket"] = 25,
	["Metal Bracket"] = 19,
	["Metal Bar"] = 14,
	["Metal Plate"] = 17,
	["Metal Pipe"] = 28,
	["Metal Hook"] = 35,
	["Metal Bucket"] = 60,
	["Plastic Bucket"] = 40,
	["Pliers"] = 75,
	["Car Battery"] = 250,
	["Circular Saw"] = 210,
	["Cinder Block"] = 10,
	["Bleach"] = 15,
	["Radiator"] = 200,
	["Engine Block"] = 525,
	["Large Cardboard Box"] = 15,
	["Plastic Crate"] = 60,
	["Chunk of Plastic"] = 10,
	["Cloth"] = 15,
	["Rubber Tire"] = 250,

	--misc building items
	["Concrete Barrier"] = 100,
	["Wire Fence 01"] = 125,
	["Wire Fence 02"] = 125,
	["Wire Fence 03"] = 125,
	["Large Blast Door"] = 225,
	["Blast Door"] = 175,
	["Large Wood Plank"] = 51,
	["Large Wood Fence"] = 125,
	["Wood Fence"] = 90,
}
--[itemID] = priceToSell,
NPCMeta.ItemsCanBuy = {
    ["Engine Overhaul"] = 2000,
	["Vehicle Repair Kit"] = 1000,
}
for k, v in pairs( NPCMeta.ItemsForSale ) do
	NPCMeta.ItemsCanBuy[k] = math.ceil( v *0.66 )
end

function NPCMeta:OnPlayerTalk( entNPC, pPlayer )
	GAMEMODE.Net:ShowNPCDialog( pPlayer, "hardware_clerk" )
	
	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.StartDialog )
		entNPC:EmitSound( snd, 60 )
		entNPC.m_intLastSoundTime = CurTime() +2
	end
end

function NPCMeta:OnPlayerEndDialog( pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.EndDialog )
		pPlayer.m_entTalkingNPC:EmitSound( snd, 60 )
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() +2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog( "hardware_clerk", self.StartDialog, self )
	end
	
	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "You gonna buy something pal?" )

		GAMEMODE.Dialog:AddOption( "Show me what you have for sale.", function()
			GAMEMODE.Gui:ShowNPCShopMenu( self.UID )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "I would like to return some items.", function()
			GAMEMODE.Gui:ShowNPCSellMenu( self.UID )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
end

GM.NPC:InstallRobberyFunctions( NPCMeta )
GM.NPC:Register( NPCMeta )