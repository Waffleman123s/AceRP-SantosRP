--[[
	Name: home_items_clerk.lua
	For: SantosRP
	By: Ultra
]]--

local NPCMeta = {}
NPCMeta.LocationName = "Furniture Store"
NPCMeta.Name = "Store Clerk"
NPCMeta.UID = "home_items_clerk"
NPCMeta.SubText = "Purchase items here"
NPCMeta.Model = "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_02_hoodiepulloverjeans_npc.mdl"
NPCMeta.Sounds = {
	StartDialog = {
		"vo/npc/female01/hi01.wav",
		"vo/npc/female01/hi02.wav",
		"vo/npc/female01/gordead_ques16.wav",
		"vo/npc/female01/answer30.wav",
	},
	EndDialog = {
		"vo/npc/female01/pardonme01.wav",
		"vo/npc/female01/pardonme02.wav",
		"vo/npc/female01/answer15.wav",
		"vo/npc/female01/excuseme02.wav",
		"vo/npc/female01/excuseme01.wav",
	}
}
--[itemID] = priceToBuy,
NPCMeta.ItemsForSale = {
	--Furniture
	-- ["Sofa 1"] = 120,
	-- ["Sofa 2"] = 120,
	-- ["Sofa 3"] = 120,
	-- ["Chair 1"] = 25,
	-- ["Chair 2"] = 25,
	-- ["Chair 3"] = 25,
	-- ["Chair 4"] = 25,
	-- ["Chair 5"] = 25,
	-- ["Desk Chair 1"] = 75,
	-- ["Desk Chair 2"] = 75,
	["Round Table"] = 50,
	-- ["Table"] = 50,
	["Coffee Table"] = 40,
	["Shelf Unit 1"] = 140,
	["Shelf Unit 2"] = 140,

	-- Storage
	["Desk"] = 75,
	["Fancy Desk"] = 150,
	["Drawer Set 1"] = 120,
	["Drawer Set 2"] = 120,
	["Dresser"] = 75,
	["Cupboard"] = 75,
	["File Cabinet"] = 75,
	["Large File Cabinet"] = 130,
	["Storage Chest"] = 200,

	--New Furniture
	-- ["Elegant Dining Chair"] = 150,
	-- ["Elegant Dining Table"] = 200,
	-- ["Fancy Modern Chair"] = 100,
	-- ["Fancy End Table"] = 100,
	["Leather Couch"] = 70,
	-- ["Leather Chair"] = 50,
	-- ["Leather Office Chair"] = 40,
	["Derelict Couch"] = 15,
	["Wooden Bar Stool"] = 10,
	["Large Wooden Bar"] = 160,
	-- ["Metal Patio Chair"] = 35,
	["Metal Shelf"] = 50,
	-- ["Patio Table with Umbrella"] = 75,
	["Sturdy Wooden Table"] = 60,
	["Wooden Display Table"] = 80,
	["Metal Office Desk"] = 90,

	--Decorative
	["Wall Clock"] = 75,
	["Flower Planter"] = 15,
	-- ["Small Potted Plant"] = 10,
	["Large Potted Plant"] = 20,
	["Wild Monkey Flowers"] = 5,

	--Ents
	["Large Sign"] = 120,
	
	--Tylr
	["Blue Chair"] = 25,
	["Wood Chair"] = 25,
	["Office Chair"] = 35,
	["Metal Chair"] = 35,
	["Old Office Chair"] = 20,
	["Plastic Chair"] = 10,
	-- ["Hill Billy Chair"] = 10,

	["Stool"] = 40,
	["Red Stool"] = 40,

	["Wood Bench"] = 150,
	
	["Red Sofa"] = 175,
	["Yellow Sofa"] = 175,
	
	["Fancy Sofa"] = 275,
	["Kings Sofa"] = 300,
	
	["School Desk"] = 75,
	
	["Bed"] = 290,
	["Bathtub"] = 500,
	["Toilet"] = 50,
	["Gaming Chair"] = 99,
	["Sunbathing Chair"] = 55,
	["Arm Chair"] = 275,

}
--[itemID] = priceToSell,
NPCMeta.ItemsCanBuy = {}
for k, v in pairs( NPCMeta.ItemsForSale ) do
	NPCMeta.ItemsCanBuy[k] = math.ceil( v *0.66 )
end

function NPCMeta:OnPlayerTalk( entNPC, pPlayer )
	GAMEMODE.Net:ShowNPCDialog( pPlayer, "home_items_clerk" )

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.StartDialog )
		entNPC:EmitSound( snd, 60 )
		entNPC.m_intLastSoundTime = CurTime() +2
	end
end

function NPCMeta:OnPlayerEndDialog( pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.EndDialog )
		pPlayer.m_entTalkingNPC:EmitSound( snd, 60 )
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() +2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog( "home_items_clerk", self.StartDialog, self )
	end
	
	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "You gonna buy something pal?" )

		GAMEMODE.Dialog:AddOption( "Show me what you have for sale.", function()
			GAMEMODE.Gui:ShowNPCShopMenu( self.UID )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "I would like to return some items.", function()
			GAMEMODE.Gui:ShowNPCSellMenu( self.UID )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
end

GM.NPC:InstallRobberyFunctions( NPCMeta )
GM.NPC:Register( NPCMeta )