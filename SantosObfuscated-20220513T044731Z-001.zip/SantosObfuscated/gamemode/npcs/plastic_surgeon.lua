local NPCMeta = {}
NPCMeta.Name = "Plastic Surgeon"
NPCMeta.UID = "plastic_surgeon"
NPCMeta.SubText = "Change your name or face"
NPCMeta.Model = "models/Kleiner.mdl"

NPCMeta.Sounds = {
	StartDialog = {"vo/npc/male01/hi01.wav", "vo/npc/male01/hi02.wav", "vo/npc/male01/gordead_ques16.wav", "vo/npc/male01/answer30.wav"},
	EndDialog = {"vo/npc/male01/answer01.wav", "vo/npc/male01/answer32.wav", "vo/npc/male01/question03.wav", "vo/npc/male01/answer03.wav"}
}

function NPCMeta:Initialize()
end

function NPCMeta:OnPlayerTalk(entNPC, pPlayer)
	GAMEMODE.Net:ShowNPCDialog(pPlayer, "plastic_surgeon")

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random(self.Sounds.StartDialog)
		entNPC:EmitSound(snd, 60)
		entNPC.m_intLastSoundTime = CurTime() + 2
	end
end

function NPCMeta:OnPlayerEndDialog(pPlayer)
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random(self.Sounds.EndDialog)
		pPlayer.m_entTalkingNPC:EmitSound(snd, 60)
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() + 2
	end

	pPlayer.m_entTalkingNPC = nil
end

function NPCMeta:ShowCreationMenu(pPlayer)
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end
	if not GAMEMODE.Jobs:PlayerIsJob( pPlayer, JOB_CIVILIAN ) then
		pPlayer:AddNote("You must not be on a job to use the Plastic Surgeon!")
	 return 
	end
	--if pPlayer:GetUserGroup() == 'vip' or pPlayer:IsAdmin() then
	pPlayer:SendLua('ShowUpdateCharacterMenu()')
	--else
	--	pPlayer:AddNote("You are not VIP")
	--end
end

if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialogEvent("plastic_surgeon_openmenu", self.ShowCreationMenu, self)
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog("plastic_surgeon", self.StartDialog, self)
	end

	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel(self.Model)
		GAMEMODE.Dialog:SetTitle(self.Name)
		GAMEMODE.Dialog:SetPrompt("How can I help you?")

		GAMEMODE.Dialog:AddOption("I would like to change my person.", function()
			GAMEMODE.Net:SendNPCDialogEvent("plastic_surgeon_openmenu")
			GAMEMODE.Dialog:HideDialog()
		end)

		GAMEMODE.Dialog:AddOption("Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent(self.UID .. "_end_dialog")
			GAMEMODE.Dialog:HideDialog()
		end)
	end
end

GM.NPC:Register(NPCMeta)