--[[
	Name: food_clerk.lua
	For: SantosRP
	By: Ultra
]]--

local NPCMeta = {}
NPCMeta.LocationName = "Food Store"
NPCMeta.Name = "Store Clerk"
NPCMeta.UID = "food_clerk"
NPCMeta.SubText = "Purchase items here"
NPCMeta.Model = "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_06_hoodiepulloverjeans_npc.mdl"
NPCMeta.Sounds = {
	StartDialog = {
		"vo/npc/female01/hi01.wav",
		"vo/npc/female01/hi02.wav",
		"vo/npc/female01/gordead_ques16.wav",
		"vo/npc/female01/answer30.wav",
	},
	EndDialog = {
		"vo/npc/female01/pardonme01.wav",
		"vo/npc/female01/pardonme02.wav",
		"vo/npc/female01/answer15.wav",
		"vo/npc/female01/excuseme02.wav",
		"vo/npc/female01/excuseme01.wav",
	}
}
--[itemID] = priceToBuy,
NPCMeta.ItemsForSale = {
	--ents
	-- ["Empty Honey Jar"] = 25,
	["Cooking Pot"] = 100,
	["Drain Cleaner"] = 50,
	["Coffee Maker"] = 225,
	["Food-Prep Table"] = 375,

	--fluids
	["Vinegar"] = 15,
	["Filtered Water"] = 7,
	["Jo Jo's Cola"] = 15,
	["Sprunk Cola"] = 15,
	["Orange Juice"] = 10,
	["Milk"] = 10,
	["Salt"] = 5,
	["Cooking Oil"] = 5,
	["Ground Coffee"] = 15,
	["Sugar"] = 15,
	["Red Wine"] = 20,
	["White Wine"] = 20,
	["Champagne"] = 35,

	--items
	["Aluminum Foil"] = 25,
	["Uncooked Beef"] = 5,
	["Uncooked Bacon"] = 8,
	["Uncooked Steak"] = 12,
	["Uncooked Bass"] = 350,
	["Uncooked Catfish"] = 350,
	["Uncooked Rainbow Trout"] = 350,
	["Uncooked Lobster"] = 450,
	["Uncooked Golden Trout"] = 350,
	["Uncooked Sunfish"] = 200,
	["Uncooked Gold Fish"] = 250,

	["Doritos - Nacho Cheese"] = 5,
	["Fritos - Original"] = 5,
	["Fritos - BBQ"] = 5,
	["Fritos - BBQ Hoops"] = 5,
	["Lays - Classic"] = 10,
	["Lays - Salt & Vinegar"] = 10,
	["Lays - Barbecue"] = 10,
	["Lays - Sour Cream & Onion"] = 10,
	["Lays - Dill Pickle"] = 10,
	["Lays - Flamin' Hot"] = 10,
	["Apple Jacks"] = 20,
	-- ["Honey Nut Cheerios"] = 20,
	-- ["Corn Flakes"] = 25,
	["Panda Puffs"] = 15,
	["Frosted Mini-Wheats"] = 7,
	["Toblerone"] = 10,
	["Jar of Pickles"] = 10,
	["Kinder Surprise"] = 5,
	["Cookies"] = 5,
	["Watermelon"] = 10,
	["Orange"] = 10,
	["Banana"] = 2,
	["Bunch of Bananas"] = 35,
	["Wheat Bread"] = 5,
	["Potato"] = 2,
	["Egg"] = 5,
	["Cheese"] = 5,
	["Lettuce"] = 15,
	["Box of Flour"] = 20,
	["Tomato"] = 5,
	["Carrot"] = 5,
	["Red Apple"] = 5,
	["Green Apple"] = 5,
	["Pear"] = 10,
	["Pineapple"] = 10,
	["Baguette"] = 10,
	["Baking Soda"] = 10,
	["Tomato Paste"] = 10,
	["Pumpkin"] = 20,
	["Coconut"] = 25,
	["Pineapple"] = 15,
	["Green Pepper"] = 4,
	["Peanut Butter"] = 5,
}
--[itemID] = priceToSell,
NPCMeta.ItemsCanBuy = {
	["Filled Honey Jar"] = 300,

	["Toast (Disgusting Quality)"] = 10,
	["Toast (Average Quality)"] = 50,
	["Toast (Delicious Quality)"] = 80,
	 
	["Cake (Disgusting Quality)"] = 300,
	["Cake (Average Quality)"] = 550,
	["Cake (Delicious Quality)"] = 1000,
	 
	["Cooked Bacon (Disgusting Quality)"] = 80,
	["Cooked Bacon (Average Quality)"] = 130,
	["Cooked Bacon (Delicious Quality)"] = 200,
	 
	["Cooked Lobster (Disgusting Quality)"] = 150,
	["Cooked Lobster (Average Quality)"] = 350,
	["Cooked Lobster (Delicious Quality)"] = 650,
	 
	["Cooked Bass (Disgusting Quality)"] = 100,
	["Cooked Bass (Average Quality)"] = 300,
	["Cooked Bass (Delicious Quality)"] = 500,
	 
	["Cooked Gold Fish (Disgusting Quality)"] = 50,
	["Cooked Gold Fish (Average Quality)"] = 150,
	["Cooked Gold Fish (Delicious Quality)"] = 300,
	 
	["Cooked Sunfish (Disgusting Quality)"] = 50,
	["Cooked Sunfish (Average Quality)"] = 150,
	["Cooked Sunfish (Delicious Quality)"] = 300,
	 
	["Cooked Golden Trout (Disgusting Quality)"] = 100,
	["Cooked Golden Trout (Average Quality)"] = 300,
	["Cooked Golden Trout (Delicious Quality)"] = 500,
	 
	["Cooked Catfish (Disgusting Quality)"] = 100,
	["Cooked Catfish (Average Quality)"] = 300,
	["Cooked Catfish (Delicious Quality)"] = 500,
	 
	["Cooked Rainbow Trout (Disgusting Quality)"] = 100,
	["Cooked Rainbow Trout (Average Quality)"] = 300,
	["Cooked Rainbow Trout (Delicious Quality)"] = 500,
	 
	["Cheese Burger (Disgusting Quality)"] = 200,
	["Cheese Burger (Average Quality)"] = 250,
	["Cheese Burger (Delicious Quality)"] = 350,
	 
	["Double Cheese Burger (Disgusting Quality)"] = 300,
	["Double Cheese Burger (Average Quality)"] = 350,
	["Double Cheese Burger (Delicious Quality)"] = 450,
	 
	["Cheese Steak (Disgusting Quality)"] = 300,
	["Cheese Steak (Average Quality)"] = 600,
	["Cheese Steak (Delicious Quality)"] = 100,
	 
	["French Fries (Disgusting Quality)"] = 50,
	["French Fries (Average Quality)"] = 150,
	["French Fries (Delicious Quality)"] = 200,
	
	-- ["Jar of Honey"] = 250,
}
for k, v in pairs( NPCMeta.ItemsForSale ) do
	NPCMeta.ItemsCanBuy[k] = math.ceil( v *0.66 )
end

function NPCMeta:OnPlayerTalk( entNPC, pPlayer )
	GAMEMODE.Net:ShowNPCDialog( pPlayer, "club_foods_clerk" )
	
	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.StartDialog )
		entNPC:EmitSound( snd, 60 )
		entNPC.m_intLastSoundTime = CurTime() +2
	end
end

function NPCMeta:OnPlayerEndDialog( pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.EndDialog )
		pPlayer.m_entTalkingNPC:EmitSound( snd, 60 )
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() +2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then
	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
	end
elseif CLIENT then
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog( "club_foods_clerk", self.StartDialog, self )
	end
	
	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "You gonna buy something pal?" )

		GAMEMODE.Dialog:AddOption( "Show me what you have for sale.", function()
			GAMEMODE.Gui:ShowNPCShopMenu( self.UID )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "I would like to return some items.", function()
			GAMEMODE.Gui:ShowNPCSellMenu( self.UID )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
end

GM.NPC:InstallRobberyFunctions( NPCMeta )
GM.NPC:Register( NPCMeta )