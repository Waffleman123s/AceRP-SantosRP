--[[
	Name: black_market.lua
	For: SantosRP
	By: Ultra
]]--

local NPCMeta = {}
NPCMeta.Name = "Black Market"
NPCMeta.UID = "black_market"
NPCMeta.SubText = "Access illegal services here"
NPCMeta.Model = "models/Eli.mdl"
NPCMeta.NoSalesTax = true
NPCMeta.MinCops = 2
NPCMeta.Sounds = {
	StartDialog = {
		"vo/ravenholm/engage06.wav",
		"vo/ravenholm/engage08.wav",
		"vo/ravenholm/pyre_anotherlife.wav",
	},
	EndDialog = {
		"vo/ravenholm/cartrap_better.wav",
		"vo/ravenholm/exit_goquickly.wav",
	}
}

NPCMeta.ItemsCanBuy = {
	["Sterling Watch"] = 3750,
	["Valuable Necklace"] = 5250,
	["Box of Rings"] = 6425,
}

function NPCMeta:OnPlayerTalk( entNPC, pPlayer )
	if GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < self.MinCops and not DEV_SERVER then
		GAMEMODE.Net:ShowNPCDialog( pPlayer, "black_market_nocops" )
	else
		GAMEMODE.Net:ShowNPCDialog( pPlayer, "black_market" )
	end

	if (entNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.StartDialog )
		entNPC:EmitSound( snd, 54 )
		entNPC.m_intLastSoundTime = CurTime() +2
	end
end

function NPCMeta:OnPlayerEndDialog( pPlayer )
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= self.UID then return end

	if (pPlayer.m_entTalkingNPC.m_intLastSoundTime or 0) < CurTime() then
		local snd, _ = table.Random( self.Sounds.EndDialog )
		pPlayer.m_entTalkingNPC:EmitSound( snd, 54 )
		pPlayer.m_entTalkingNPC.m_intLastSoundTime = CurTime() +2
	end

	pPlayer.m_entTalkingNPC = nil
end

if SERVER then
	function NPCMeta:PlayerLaunderMoney( pPlayer, ... )
		if not pPlayer:WithinTalkingRange() then return end
		if pPlayer:GetTalkingNPC().UID ~= self.UID then return end
		self:OnPlayerEndDialog( pPlayer )

		if not DEV_SERVER and GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < self.MinCops then return false end
		local num = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, "Stolen Money" )
		if not num or num <= 0 then
			GAMEMODE.Net:ShowNPCDialog( pPlayer, "black_market_nomoney" )
			return
		end

		local total = 0
		for i = 1, num do
			total = total +math.random(
				GAMEMODE.Config.BlackMarketNPC_MinMoneyValue,
				GAMEMODE.Config.BlackMarketNPC_MaxMoneyValue
			)
		end

		if GAMEMODE.Inv:TakePlayerItem( pPlayer, "Stolen Money", num ) then
			pPlayer:AddMoney( total, "Black market transaction" )
			pPlayer:AddNote( ("You received $%s from the black market!"):format(string.Comma(total)) )
		end
	end

	function NPCMeta:PlayerOpenDepositBox( pPlayer, ... )
		if not pPlayer:WithinTalkingRange() then return end
		if pPlayer:GetTalkingNPC().UID ~= self.UID then return end
		self:OnPlayerEndDialog( pPlayer )

		if not DEV_SERVER and GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < self.MinCops then return false end
		local num = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, "Stolen Safety Deposit Box" )
		if not num or num <= 0 then
			GAMEMODE.Net:ShowNPCDialog( pPlayer, "black_market_noboxes" )
			return
		end

		if not pPlayer:CanAfford( GAMEMODE.Config.BankRobbery_DepositBoxOpenCost ) then
			GAMEMODE.Net:ShowNPCDialog( pPlayer, "black_market_box_cost" )
			return
		end
		
		local obj = table.Random( GAMEMODE.Config.BankRobbery_DepositBoxLoot )
		local amount = math.random( obj.range.min, obj.range.max )

		if GAMEMODE.Inv:TakePlayerItem( pPlayer, "Stolen Safety Deposit Box", 1 ) then
			if obj.type == "Item" then
				GAMEMODE.Inv:GivePlayerItem( pPlayer, obj.value, amount, true )
				pPlayer:AddNote( "You got ".. amount.. "x ".. obj.value.. " from a deposit box!" )
			elseif obj.type == "Money" then
				pPlayer:AddMoney( amount, "Black market transaction" )
				pPlayer:AddNote( ("You received $%s from a deposit box!"):format(string.Comma(amount)) )
			end
		end
	end

	--RegisterDialogEvents is called when the npc is registered! This is before the gamemode loads so GAMEMODE is not valid yet.
	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialogEvent( "black_market_launder", self.PlayerLaunderMoney, self )
		GM.Dialog:RegisterDialogEvent( "black_market_open_deposit_box", self.PlayerOpenDepositBox, self )
	end

	function NPCMeta:OnSpawn( entNPC )
		local moveNPC
		moveNPC = function()
			timer.Simple( math.random(GAMEMODE.Config.BlackMarketNPCMoveTime_Min, GAMEMODE.Config.BlackMarketNPCMoveTime_Max), function()
				if not IsValid( entNPC ) then return end

				local pos = table.Random( GAMEMODE.Config.BlackMarketNPCPositions )
				entNPC:SetPos( pos[1] )
				entNPC:SetAngles( pos[2] )
				moveNPC()
			end )
		end

		moveNPC()
	end

	function NPCMeta:CanPlayerBuy( pPlayer, strItemID, intAmount )
		if GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < self.MinCops then return false end
	end
	
	function NPCMeta:CanPlayerSell( pPlayer, strItemID, intAmount )
		if GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < self.MinCops then return false end
	end
elseif CLIENT then
	NPCMeta.RandomGreetings = {
		"Looking to make a deal?",
		"Got some dirty money for me? I offer good deals.",
		"Always need to keep moving. The police never let up.",
	}

	function NPCMeta:RegisterDialogEvents()
		GM.Dialog:RegisterDialog( "black_market", self.StartDialog, self )
		GM.Dialog:RegisterDialog( "black_market_nocops", self.StartDialog_NoCops, self )
		GM.Dialog:RegisterDialog( "black_market_nomoney", self.StartDialog_NoMoney, self )
		GM.Dialog:RegisterDialog( "black_market_noboxes", self.StartDialog_NoBoxes, self )
		GM.Dialog:RegisterDialog( "black_market_box_cost", self.StartDialog_BoxCantAfford, self )
	end
	
	function NPCMeta:StartDialog()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( table.Random(self.RandomGreetings) )

		GAMEMODE.Dialog:AddOption( "I've got stolen money for you to launder.", function()
			GAMEMODE.Net:SendNPCDialogEvent( "black_market_launder" )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption("I've got jewelry I'd like to sell.", function()
			GAMEMODE.Gui:ShowNPCSellMenu(self.UID)
			GAMEMODE.Dialog:HideDialog()
		end)
		GAMEMODE.Dialog:AddOption( "I have a safety deposit box for you to open. ($".. string.Comma(GAMEMODE.Config.BankRobbery_DepositBoxOpenCost).. ")", function()
			GAMEMODE.Net:SendNPCDialogEvent( "black_market_open_deposit_box" )
			GAMEMODE.Dialog:HideDialog()
		end )
		GAMEMODE.Dialog:AddOption( "Never mind, I have to go.", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
	
	function NPCMeta:StartDialog_NoCops()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "Sorry, not looking to make a deal right now." )

		GAMEMODE.Dialog:AddOption( "Oh, Alright then...", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end

	function NPCMeta:StartDialog_NoMoney()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "You don't have any stolen money!" )

		GAMEMODE.Dialog:AddOption( "Oh, I knew that...", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end

	function NPCMeta:StartDialog_NoBoxes()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "You don't have any safety deposit boxes!" )

		GAMEMODE.Dialog:AddOption( "Oh, I knew that...", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end

	function NPCMeta:StartDialog_BoxCantAfford()
		GAMEMODE.Dialog:ShowDialog()
		GAMEMODE.Dialog:SetModel( self.Model )
		GAMEMODE.Dialog:SetTitle( self.Name )
		GAMEMODE.Dialog:SetPrompt( "You can't afford that! I charge $".. string.Comma(GAMEMODE.Config.BankRobbery_DepositBoxOpenCost).. " per box." )

		GAMEMODE.Dialog:AddOption( "Well then...", function()
			GAMEMODE.Net:SendNPCDialogEvent( self.UID.. "_end_dialog" )
			GAMEMODE.Dialog:HideDialog()
		end )
	end
end

GM.NPC:Register( NPCMeta )