--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--

RunConsoleCommand( "sv_playerpickupallowed", "0" )

GM.Config.ServerRegion = "US" --US, EU
GM.Config.MaxEntityEdicts = 7200

--[[ SQL Settings ]]--
if DEV_SERVER then
	GM.Config.SQLHostName = "DB IP GOES HERE"
	GM.Config.SQLUserName = "DB USERNAME"
	GM.Config.SQLPassword = "DB PASSWORD"
	GM.Config.SQLDBName = "DB_NAME"

	GM.Config.SQLIPBHostName = "localhost"
	GM.Config.SQLIPBUserName = "santos_devserver"
	GM.Config.SQLIPBPassword = "1234"
	GM.Config.SQLIPBDBName = "santosrp"
else
	if PRIVATE_SERVER then
	GM.Config.SQLHostName = "DB IP GOES HERE"
	GM.Config.SQLUserName = "DB USERNAME"
	GM.Config.SQLPassword = "DB PASSWORD"
	GM.Config.SQLDBName = "DB_NAME"

		GM.Config.SQLIPBHostName = "66.70.176.2" --158.69.234.75
		GM.Config.SQLIPBUserName = "ultra"
		GM.Config.SQLIPBPassword = "6vlLgd48418UWe9wLruI"
		GM.Config.SQLIPBDBName = "santosforum"
	elseif PUBLIC_SERVER then
		if false then
			GM.Config.SQLHostName = "51.178.9.34"
			GM.Config.SQLUserName = "acerpgg1"
			GM.Config.SQLPassword = "l0ez~4tPlo~="
			GM.Config.SQLDBName = "acerpgg1_santos"
		else
			GM.Config.SQLHostName = "51.178.9.34"
			GM.Config.SQLUserName = "acerpgg1"
			GM.Config.SQLPassword = "l0ez~4tPlo~="
			GM.Config.SQLDBName = "acerpgg1_santos"
		end

		GM.Config.SQLIPBHostName = "mysql.hexaneweb.net"
		GM.Config.SQLIPBUserName = "acerpgg1"
		GM.Config.SQLIPBPassword = "l0ez~4tPlo~="
		GM.Config.SQLIPBDBName = "acerpgg1_ipb"
	end
end

GM.Config.SQLSnapshotRate = 5 *60 --Lower = less time between updates to sql. This value should be set with respect to the number of workers in use!
GM.Config.SQLReconnectInterval = 1 *60 --Time to wait before retrying a lost sql connection
GM.Config.SQLNumWriteWorkers = 10 --Number of connections to open to the sql server for writing player data with

--[[ Queue Server Broker ]]--
GM.Config.EnableQueueBroker = false --PRIVATE_SERVER == true
GM.Config.QueueServerEnable = 60 --Number of player slots taken before enabling the queue broker

--[[ IPB Settings ]]--
GM.Config.VIPRanks = {
	"vip_t1",
}

if PRIVATE_SERVER then
	GM.Config.IPBJobWhitelist = {
		["JOB_POLICE"] = { 4, 13, 23, 43 },
-- 		["JOB_FIREFIGHTER"] = { 4, 25, 31 },
-- 		["JOB_EMS"] = { 4, 14, 26 },
		["JOB_MAYOR"] = { 39 },
		["JOB_DEPUTY_MAYOR"] = { 42 },
		["JOB_SSERVICE"] = { 4, 51 },
	}
	GM.Config.IPBServerGuardGroups = {
		{ group = "superadmin", ids = {4} },
		{ group = "community_manager", ids = {29} },
		{ group = "sysadmin", ids = {58} },
		{ group = "senior admin", ids = {60} },
		{ group = "admin", ids = {7} },
		{ group = "moderator", ids = {9} },
		{ group = "vip_t1", ids = {48} },
		{ group = "vip_t2", ids = {49} },
		{ group = "vip_t3", ids = {50} },
		{ group = "rustic7", ids = {59} }, --noclip, invis, kick
		{ group = "user", ids = {12} },
		{ group = "community_advsr", ids = {62} }, --copy manager
	}
elseif PUBLIC_SERVER then
	GM.Config.IPBJobWhitelist = {
		["JOB_POLICE"] = { 4, 13, 23, 43 },
		["JOB_MAYOR"] = { 39 },
		["JOB_DEPUTY_MAYOR"] = { 42 },
		["JOB_SSERVICE"] = { 4, 51 },
		--["JOB_FIREFIGHTER"] = {},
		--["JOB_EMS"] = {},
		--["JOB_PROSECUTOR"] = { 4, 41 },
		--["JOB_LAWYER"] = { 4, 38 },
		--["JOB_JUDGE"] = { 4, 40 },
	}
	GM.Config.IPBServerGuardGroups = {
		{ group = "superadmin", ids = {4} },
		{ group = "community_manager", ids = {29} },
		{ group = "sysadmin", ids = {58} },
		{ group = "senior admin", ids = {60} },
		{ group = "admin", ids = {7} },
		{ group = "moderator", ids = {9} },
		{ group = "user", ids = {12} },
	}
end

--[[ ServerNet Settings ]]--
GM.Config.ServerNetPort = (DEV_SERVER or SANTOS_CONTENT_DEV_SERVER) and 37050 or (g_SantosSocketPort or 37015)
GM.Config.ServerNetPool = {
	"127.0.0.1",
}

--[[ Global Loadout Settings ]]--
GM.Config.GlobalLoadout = {
	"weapon_physgun",
	"weapon_tg_fists",
	"weapon_keys",
	-- "weapon_srphands",
	"weapon_idcard_v2",
}

--[[ Car Settings ]]--
GM.Config.BaseCarFuelConsumption = 35
GM.Config.MaxCivCars = 50

--[[ Property Settings ]]--
GM.Config.GovernemtDoorJobs = { --List of jobs that can lock government doors
	["JOB_MARSHAL"] = true,
	["JOB_POLICE"] = true,
	["JOB_EMS"] = true,
	["JOB_FIREFIGHTER"] = true,
	["JOB_MAYOR"] = true,
	["JOB_DEPUTY_MAYOR"] = true,
	["JOB_SSERVICE"] = true,
	["JOB_JUDGE"] = true,
	["JOB_PROSECUTOR"] = true,
	["JOB_SWAT"] = true,


}
GM.Config.JoshDoorJobs = { --List of jobs that can lock josh doors
	["JOB_JOSH"] = true,
	["JOB_POLICE"] = true,
}


--[[ Damage Settings ]]--
GM.Config.BleedDamage = 1
GM.Config.BleedInterval = 30
GM.Config.BleedBandageDuration = 60 *2 --Time a bandage should stop bleeding for
GM.Config.ItemDamageTakeCooldown = 45 --Time following a damage event to an item that a player should be blocked from picking the item back up

--[[ Fire System Settings ]]--
GM.Config.MaxFires = 256
GM.Config.MaxChildFires = 40
GM.Config.FireSpreadDistance = 80
GM.Config.FireNodeCount = 4
GM.Config.FireSpreadCount = 2
GM.Config.FireBurnEverything = true
GM.Config.FireSimRate = 6

--[[ Impound Settings ]]--
GM.Config.ImpoundBillCost = 200
GM.Config.ImpoundBillInterval = 6 *60 *60
GM.Config.ImpoundBillMaxInterval = 7
GM.Config.TowImpoundBonus = 100

--[[ Driving Test Questions ]]--
--Note: The questions table must be the same in the shared config, but without the answers!
GM.Config.DrivingTestRetakeDelay = 5 *60
GM.Config.MinCorrectDrivingTestQuestions = 5
GM.Config.DrivingTestQuestions_Answers = {
	{ Question = "What do you do when its a green light?", Options = { ["You begin to move"] = true, ["You stop"] = false, ["You turn off your engine"] = false } },
	{ Question = "What button do you hold to activate turn signals.", Options = { ["Shift + MB"] = false, ["Control + MB"] = false, ["Alt + MB"] = true } },
	{ Question = "Someone has just crashed into you and damaged your car.", Options = { ["Pull a weapon on him"] = false, ["Exchange insurance information"] = true, ["Talk shit to him while ramming his car"] = false } },
	{ Question = "Your car seems to be not functioning properly, what do you do?", Options = { ["Call the cops"] = true, ["Stand on the road to get someones attention"] = false, ["Phone up mechanical services"] = false } },
	{ Question = "You encounter a police road block and the officer tells you to turn around, do you", Options = { ["Ignore the officer and continue driving"] = false, ["Sit in your car and do nothing"] = false, ["Carefully turn around and drive"] = true } },
	{ Question = "You see a another driver driving recklessly, what do you do?", Options = { ["Inform the police"] = true, ["Drive recklessly yourself"] = false, ["Message your friend"] = false } },
	{ Question = "You have just accidentally crashed into a pole and you have injured yourself, what do you do?", Options = { ["Lie on the road and wait for someone to help"] = false, ["Follow someone until they help you"] = false, ["Call EMS"] = true } },
}

--[[ NPC Bank Item Storage Settings ]]--
GM.Config.BankStorage_MAX_UNIQUE_ITEMS = 10
GM.Config.BankStorage_MAX_NUM_ITEM = 25
GM.Config.BankStorage_VIP_MAX_UNIQUE_ITEMS = 50
GM.Config.BankStorage_VIP_MAX_NUM_ITEM = 100

--[[ NPC Drug Dealer Settings ]]--
GM.Config.DrugNPCMoveTime_Min = 15 *60
GM.Config.DrugNPCMoveTime_Max = 40 *60

--[[ NPC Jail Warden Settings ]]--
GM.Config.CopLawyerRequestCooldownTime = 60 --Time a player must wait after requesting a lawyer before they may do so again

--[[ NPC Black Market Settings ]]--
GM.Config.BlackMarketNPCMoveTime_Min = 15 *60
GM.Config.BlackMarketNPCMoveTime_Max = 40 *60
GM.Config.BlackMarketNPC_MinMoneyValue = 5000
GM.Config.BlackMarketNPC_MaxMoneyValue = 17000

--[[ NPC Robbery Settings ]]--
GM.Config.NPCRobbery_NPCAutoReviveTime = 60 *5 --Time before an npc will auto-revive if no ems are playing
GM.Config.NPCRobbery_Cooldown1 = 60 *5 --Time after an npc was robbed to deny services to players
GM.Config.NPCRobbery_Cooldown2 = 60 *30 --Time after an npc was robbed before it can be robbed again
GM.Config.NPCRobbery_Cooldown3 = 60 *15 --Time a player must wait before they can rob another store
GM.Config.NPCRobbery_MinAlarmDelay = 0.05 --Min % time to wait before setting off store alarm
GM.Config.NPCRobbery_MaxAlarmDelay = 0.5 --Max % time to wait before setting off store alarm
GM.Config.NPCRobbery_MinMoneyCollectTime = 60 *1.66
GM.Config.NPCRobbery_MaxMoneyCollectTime = 60 *3
GM.Config.NPCRobbery_MinCops = 4

--[[ Bank Robbery Settings ]]--
GM.Config.BankRobbery_MoneyTakeTime = 12 --Time it takes to collect a bag of stolen money
GM.Config.BankRobbery_MinCops = 0
GM.Config.BankRobbery_CashSpawnAmount = { min = 2, max = 4 } --Amount of stolen money per cash pallet
GM.Config.BankRobbery_DepositBoxSpawnAmount = { min = 3, max = 6 } --Amount of deposit boxes to spawn
GM.Config.BankRobbery_DepositBoxLoot = { --List of possible loot for a safety deposit box
	--Money
	--{ type="Item", value="Casino Chips", range={min=1, max=2000} },
	--{ type="Item", value="Casino Chips", range={min=250, max=1350} },
	{ type="Money", range={min=1, max=2000} },
	{ type="Money", range={min=500, max=2000} },
	{ type="Money", range={min=750, max=1250} },
	{ type="Money", range={min=350, max=1500} },

	--Guns
	{ type="Item", value="Glock 17", range={min=1, max=1} },
	{ type="Item", value="M1911", range={min=1, max=1} },

	--Misc
	{ type="Item", value="Cellular Phone", range={min=1, max=8} },

	--Joke items
	{ type="Item", value="Cinder Block", range={min=1, max=1} },
	{ type="Item", value="Moonshine", range={min=1, max=8} },
	{ type="Item", value="Whiskey", range={min=1, max=8} },
	{ type="Item", value="Cigar Box", range={min=1, max=6} },
}

--[[ Prison Break ]]--
GM.Config.PrisonBreak_MinCops = 4;
GM.Config.PrisonBreak_ShouldPayTerminator = true;
GM.Config.PrisonBreak_Payment = {2000, 15000};

--[[ Map Settings ]]--
--The smaller the fade min and max are, the sooner map props will stop drawing
GM.Config.DetailPropFadeMin = 1024
GM.Config.DetailPropFadeMax = 1700

--[[ Job Settings ]]--
GM.Config.JobPayInterval = 12 *60 --How often players should get paid
GM.Config.EMSReviveBonus = 100 --How much money to give an EMS player when they revive someone
GM.Config.FireBonus = 1000 --How much money to give a firefighter player when they put out enough fires
GM.Config.FireExtinguishBonusCount = 20 --How many fires a player must put out before they get paid the bonus

--[[ Weather ]]--
GM.Config.WeatherRandomizer_MinTime = 60 *8
GM.Config.WeatherRandomizer_MaxTime = 60 *10
GM.Config.WeatherTable = {
	{ ID = "thunder_storm", MinTime = 60 *3.5, MaxTime = 60 *12, Chance = function() return math.random(1, 8) == 1 end },
	{ ID = "thunder_storm", MinTime = 60 *6, MaxTime = 60 *15, Chance = function() return math.random(1, 8) == 1 end },
	{ ID = "light_rain", MinTime = 60 *3.5, MaxTime = 60 *8, Chance = function() return math.random(1, 5) == 1 end },
	{ ID = "light_rain", MinTime = 60 *3.5, MaxTime = 60 *8, Chance = function() return math.random(1, 5) == 1 end },
	{ ID = "light_rain", MinTime = 60 *6, MaxTime = 60 *15, Chance = function() return math.random(1, 10) == 1 end },
}

--[[ Misc Settings ]]--
GM.Config.CharacterDeleteCooldown = ((60 *60 *24) *7) *2
GM.Config.AdvertPrice = 75
GM.Config.MinDrugConfiscatePrice = 50
GM.Config.MaxDrugConfiscatePrice = 120
GM.Config.DefWalkSpeed = 85
GM.Config.DefRunSpeed = 200
GM.Config.MaxRunSpeed = 220