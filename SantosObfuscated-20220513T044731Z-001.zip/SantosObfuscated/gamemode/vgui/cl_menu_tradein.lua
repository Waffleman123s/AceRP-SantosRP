--[[
  Name: cl_menu_tradein.lua
  For: SantosRP
  By: Ultra
]]
--
local Panel = {}

function Panel:Init()
  self:SetTitle("Item Trade In")
  self:SetDeleteOnClose(false)
  self.m_pnlInvLabel = vgui.Create("DLabel", self)
  self.m_pnlInvLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
  self.m_pnlInvLabel:SetTextColor(Color(255, 255, 255, 255))
  self.m_pnlInvLabel:SetFont("Trebuchet24")
  self.m_pnlInvLabel:SetText("Trade In's Available")
  self.m_pnlInvLabel:SizeToContents()
  self.m_pnlInventoryList = vgui.Create("SRP_ScrollPanel", self)

  self.m_pnlInventoryList.Paint = function(_, intW, intH)
    surface.SetDrawColor(50, 50, 50, 100)
    surface.DrawRect(0, 0, intW, intH)
  end

  self.m_tblInvItems = {}

  hook.Add("GamemodeOnInventoryUpdated", "UpdatePanel", function(inv)
    if not ValidPanel(self) or not self:IsVisible() then return end
    self:Refresh()
  end)
end

-- GAMEMODE.Config.TradeIns = {}
-- GAMEMODE.Config.TradeIns["AK-47"] = {
-- From = 1,
-- GiveItem = "AK-74",
-- GiveAmount = 2
-- }
function Panel:Refresh()
  local tradeIns = GAMEMODE.Config.TradeIns or {}

  for k, v in pairs(self.m_tblInvItems or {}) do
    if ValidPanel(v) then
      v:Remove()
    end
  end

  self.m_tblInvItems = {}

  for k, v in pairs(inv or LocalPlayer():GetInventory()) do
    if not GAMEMODE.Inv:GetItem(k) then continue end
    if not GAMEMODE.Inv:GetItem(k).IsDeprecated then continue end
    local pnl = vgui.Create("SRPTradeInCard", self.m_pnlInventoryList)

    if tradeIns[k] and tradeIns[k].From > LocalPlayer():GetInventory()[k] then
      pnl.m_pnlTradeBtn:SetEnabled(false)
      pnl.m_pnlTradeBtn:SetText("Not Enough")
    elseif tradeIns[k] and tradeIns[k].From <= LocalPlayer():GetInventory()[k] then
      pnl.m_pnlTradeBtn:SetEnabled(true)
      pnl.m_pnlTradeBtn:SetText("Trade In")
    elseif not tradeIns[k] then
      pnl.m_pnlTradeBtn:SetText("Destory Item")
    end

    pnl.m_pnlTradeBtn.DoClick = function()
      GAMEMODE.Net:TradeInItem(k, 1)
    end

    pnl:SetItemData(k, tradeIns[k] or {})
    pnl:SetItemAmount(v)
    table.insert(self.m_tblInvItems, pnl)
  end
end

function Panel:PerformLayout(intW, intH)
  DFrame.PerformLayout(self, intW, intH)
  local padding = 0
  self.m_pnlInvLabel:SetPos(5, 28)
  self.m_pnlInventoryList:SetSize(intW - (padding * 2), intH - 28 - self.m_pnlInvLabel:GetTall() - padding)
  self.m_pnlInventoryList:SetPos(padding, 28 + self.m_pnlInvLabel:GetTall() + padding)

  for _, pnl in pairs(self.m_tblInvItems) do
    pnl:DockMargin(0, 0, 0, 5)
    pnl:SetTall(48)
    pnl:Dock(TOP)
  end
end

function Panel:Open()
  self:Refresh()
  self:SetVisible(true)
  self:MakePopup()
end

function Panel:OnClose()
  GAMEMODE.Net:SendNPCDialogEvent("item_tradein_end_dialog")
end

vgui.Register("SRPTradeInMenu", Panel, "SRP_Frame")