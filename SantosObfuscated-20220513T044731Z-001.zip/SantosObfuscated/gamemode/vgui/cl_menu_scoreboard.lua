--[[
    Name: cl_menu_scoreboard.lua
    For: SantosRP
    By: Ultra
]]
--
function FormatTime(intTime, bHours)
	local time = os.date("!*t", intTime) or {
		min = 0,
		sec = 0
	}

	if time.sec < 10 then
		time.sec = "0" .. time.sec
	end

	if not bHours then
		return ("%s:%s"):format(time.min, time.sec)
	else
		if time.min < 10 then
			time.min = "0" .. time.min
		end

		return ("%s:%s:%s"):format(time.hour + (time.day > 1 and (time.day - 1) * 24 or 0), time.min, time.sec)
	end
end

local function secondsToTime(iSecs)
	local floor,mod,format = math.floor, math.mod, string.format
	local days = floor(iSecs/86400)
	local hours = floor(mod(iSecs, 86400)/3600)
	local minutes = floor(mod(iSecs,3600)/60)
	local seconds = floor(mod(iSecs,60))
	-- return days,hours,minutes
	return format("%d:%02d:%02d",days,hours,minutes)
end

surface.CreateFont("Scoreboard_Trebuchet18", {
	size = 18,
	weight = 550,
	font = "Trebuchet24"
})

surface.CreateFont("Scoreboard_Trebuchet20", {
	size = 20,
	weight = 550,
	font = "Trebuchet24"
})

surface.CreateFont("Scoreboard_Trebuchet24", {
	size = 24,
	weight = 550,
	font = "Trebuchet24"
})

surface.CreateFont("Scoreboard_Trebuchet38", {
	size = 38,
	weight = 550,
	font = "Trebuchet24"
})

local TEX_GRADIENT_LEFT = surface.GetTextureID("gui/gradient")
local TEX_GRADIENT_DOWN = surface.GetTextureID("gui/gradient_down")
local Panel = {}
SCOREBOARD = Panel
local drawCol = Color(200, 200, 200, 255)

function Panel:Init()
	self.m_pnlAvatar = vgui.Create("SRP_AvatarImg", self)
	self.m_pnlAvatar:SetSize(64, 64)
end

function Panel:SetPlayer(pPlayer)
	self.m_pPlayer = pPlayer
	self.m_pnlAvatar:SetPlayer(pPlayer)
	self:InvalidateLayout()
end

function Panel:TranslateGroupName(strGroup)
	local data = GAMEMODE.Config.UserGroupConfig[strGroup]
	if not data then return strGroup end

	return data.Name
end

function Panel:TranslateGroupColor(strGroup)
	local data = GAMEMODE.Config.UserGroupConfig[strGroup]
	if not data then return color_white end
	if data.Rainbow then return data.Color() end

	return data.Color
end

function Panel:Paint(intW, intH)
	surface.SetDrawColor(self.r or 50, 50, 50, 150)
	surface.DrawRect(intH - 14, (intH / 2) - ((intH * 0.6) / 2), intW - 1, intH * 0.6)
	surface.SetTexture(TEX_GRADIENT_LEFT)
	surface.SetDrawColor(0, 0, 0, 100)
	surface.DrawTexturedRect(intH - 14, (intH / 2) - ((intH * 0.6) / 2), intW - 1, intH * 0.6)
	if not IsValid(self.m_pPlayer) then return end
	local prefix = ""
	local char_id = GAMEMODE.Player:GetSharedGameVar(self.m_pPlayer, "char_id")

	if not char_id or char_id < 1 then
		prefix = prefix .. "(Loading) "
	else
		if not self.m_pPlayer:Alive() then
			prefix = prefix .. "(Not Alive) "
		end

		if GAMEMODE.Buddy:IsBuddyWith(self.m_pPlayer) then
			prefix = prefix .. "(Buddy) "
		end
	end

	local name, jobP
	local job = GAMEMODE.Jobs:GetPlayerJob(self.m_pPlayer)
	local rname = self.m_pPlayer:GetName()

	if LocalPlayer():IsStaff() and job then
		jobP = "(" .. job.Name .. ")"
		name = rname .. " (" .. self.m_pPlayer:RealNick() .. ")"
	elseif LocalPlayer():IsStaff() then
		name = rname .. " (" .. self.m_pPlayer:RealNick() .. ")"
		job = nil
	else
		name = rname
	end

	if LocalPlayer():IsStaff() and job then
		surface.SetFont("Scoreboard_Trebuchet20")
		local padding, _ = surface.GetTextSize(jobP)
		padding = padding + 5
		draw.SimpleText(jobP, "Scoreboard_Trebuchet20", intH - 5, (intH / 2) - 1, job.TeamColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(prefix .. name, "Scoreboard_Trebuchet20", intH - 5 + padding, (intH / 2) - 1, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	elseif LocalPlayer():IsStaff() and not job then
		draw.SimpleText(prefix .. name, "Scoreboard_Trebuchet20", intH - 5, (intH / 2) - 1, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText(prefix .. name, "Scoreboard_Trebuchet20", intH - 5, (intH / 2) - 1, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	draw.SimpleText(self.m_pPlayer:Ping() .. "ms", "Scoreboard_Trebuchet20", intW - 5, (intH / 2) - 1, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	local usergroup = self.m_pPlayer:GetUserGroup() or "user"
	draw.SimpleText(self:TranslateGroupName(usergroup), "Scoreboard_Trebuchet20", intW - 100, (intH / 2) - 1, self:TranslateGroupColor(usergroup), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

function Panel:OnMouseReleased(mc)
	local ply = self.m_pPlayer
	local nick = ply:Nick()
	local rnick = ply:RealNick()

	if mc == 109 then
		RunConsoleCommand("ulx", "goto", nick)

		return
	end

	local name = ply:GetName()
	local steamid = ply:SteamID()
	local steamid64 = ply:SteamID64()

	if mc == MOUSE_LEFT then
		local a = DermaMenu()

		a:AddOption(rnick, function()
			SetClipboardText(rnick)
		end)

		a:AddSpacer()

		a:AddOption("Open Profile URL", function()
			local url = "http://steamcommunity.com/profiles/" .. tostring(ply:SteamID64())
			gui.OpenURL(url)
		end):SetImage'icon16/transmit.png'

		a:AddOption("Copy Profile URL", function()
			SetClipboardText("http://steamcommunity.com/profiles/" .. tostring(ply:SteamID64()))
		end):SetImage'icon16/link.png'

		a:AddSpacer()

		a:AddOption("Copy SteamID", function()
			SetClipboardText(tostring(ply:SteamID()))
		end):SetImage'icon16/book_edit.png'

		a:AddOption("Copy Community ID", function()
			SetClipboardText(tostring(ply:SteamID64()))
		end):SetImage'icon16/book_link.png'

		a:AddOption("Copy Name", function()
			if LocalPlayer():IsStaff() then
				SetClipboardText("RP Name: " .. ply:Nick() .. " | Steam Name: " .. rnick)
			else
				SetClipboardText("Steam Name: " .. rnick)
			end
		end):SetImage'icon16/user_suit.png'

		a:AddSpacer()

		if not ply.Muted or ply.Muted == nil then
			a:AddOption("Mute", function()
				ply:SetMuted(true)
				ply.Muted = true
			end):SetImage'icon16/sound.png'
		else
			a:AddOption("Unmute", function()
				ply:SetMuted(false)
				ply.Muted = false
			end):SetImage'icon16/sound_mute.png'
		end

		if ply == LocalPlayer() then
			a:AddOption("Disconnect", function()
				RunConsoleCommand("disconnect")
			end):SetImage'icon16/stop.png'
		end

		a:Open()
	end

	if mc == MOUSE_RIGHT then
		local a = DermaMenu()

		if LocalPlayer():IsStaff() then
			a:AddOption(name, function()
				SetClipboardText(name)
			end)

			a:AddOption(nick, function()
				SetClipboardText(nick)
			end)

			a:AddOption(steamid, function()
				SetClipboardText(steamid)
			end)

			a:AddOption(steamid64, function()
				SetClipboardText(steamid64)
			end)

			local adminmenu, b = a:AddSubMenu("Admin Menu", function() end)
			b:SetImage'icon16/lock_open.png'

			local m, b = adminmenu:AddSubMenu("Kick", function()
				RunConsoleCommand("ulx", "kick", "$" .. ply:SteamID())
			end)

			b:SetImage'icon16/door_out.png'

			m:AddOption(("%s (%s)"):format("kick", "Posting pornographic content"), function()
				RunConsoleCommand("ulx", "kick", "$" .. ply:SteamID() .. " ", "Posting pornographic content")
			end):SetImage('icon16/door_out.png')

			m:AddOption(("%s (%s)"):format("kick", "Chat Spam"), function()
				RunConsoleCommand("ulx", "kick", "$" .. ply:SteamID() .. " ", "Chat Spam")
			end):SetImage('icon16/door_out.png')

			m:AddOption(("%s (%s)"):format("kick", "Prop Spam"), function()
				RunConsoleCommand("ulx", "kick", "$" .. ply:SteamID() .. " ", "Prop Spam")
			end):SetImage('icon16/door_out.png')

			m:AddOption(("%s (%s)"):format("kick", "Annoying other players"), function()
				RunConsoleCommand("ulx", "kick", "$" .. ply:SteamID() .. " ", "Annoying other players")
			end):SetImage('icon16/door_out.png')

			m:AddSpacer()

			m:AddOption(("%s (%s)"):format("kick", "Custom Reason"), function()
				Derma_StringRequest("Kick with custom reason", "Type in a custom kick reason", "", function(txt)
					RunConsoleCommand("ulx", "kick", "$" .. ply:SteamID() .. " ", txt)
				end, function(txt) return false end)
			end):SetImage('icon16/door_out.png')

			if LocalPlayer():IsStaff() then
				local m, b = adminmenu:AddSubMenu("Ban", function()
					RunConsoleCommand("ulx", "banid ", ply:SteamID())
				end)

				b:SetImage'icon16/stop.png'

				m:AddOption(("%s (%s)"):format("Ban", "Posting pornographic content"), function()
					RunConsoleCommand("ulx", "ban", "$" .. ply:SteamID() .. " ", 30, "Posting pornographic content")
				end):SetImage('icon16/stop.png')

				m:AddOption(("%s (%s)"):format("Ban", "Chat Spam"), function()
					RunConsoleCommand("ulx", "banid ", ply:SteamID() .. " ", 30, "Chat Spam")
				end):SetImage('icon16/stop.png')

				m:AddOption(("%s (%s)"):format("Ban", "Prop Spam"), function()
					RunConsoleCommand("ulx", "banid ", ply:SteamID() .. " ", 30, "Prop Spam")
				end):SetImage('icon16/stop.png')

				m:AddOption(("%s (%s)"):format("Ban", "Annoying other players"), function()
					RunConsoleCommand("ulx", "banid ", ply:SteamID() .. " ", 30, "Annoying other players")
				end):SetImage('icon16/stop.png')

				m:AddSpacer()

				m:AddOption(("%s (%s)"):format("Ban", "Custom Reason"), function()
					Derma_StringRequest("Ban with custom reason", "Type in a custom ban reason", "", function(txt)
						RunConsoleCommand("ulx", "banid ", ply:SteamID() .. " ", 1440, txt)
					end, function(txt) return false end)
				end):SetImage('icon16/stop.png')
			else
				adminmenu:AddOption("UnBan", function()
					RunConsoleCommand("ulx", "unban", '_' .. eid)
				end):SetImage'icon16/weather_sun.png'
			end

			if LocalPlayer():IsStaff() then
				local m, b = adminmenu:AddSubMenu("Teleportation", function() end)
				b:SetImage'icon16/shield_go.png'

				m:AddOption(("%s (%s)"):format("Return", "Return The Player To Their Previous Position"), function()
					RunConsoleCommand("ulx", "return", "$" .. ply:SteamID())
				end):SetImage('icon16/shield_go.png')

				m:AddOption(("%s (%s)"):format("Goto", "Goto The Player"), function()
					RunConsoleCommand("ulx", "goto", "$" .. ply:SteamID())
				end):SetImage('icon16/shield_go.png')

				m:AddOption(("%s (%s)"):format("Bring", "Bring The Player To You"), function()
					RunConsoleCommand("ulx", "bring", "$" .. ply:SteamID())
				end):SetImage('icon16/shield_go.png')

				m:AddOption(("%s (%s)"):format("TP", "Teleport The Player Infront of You"), function()
					RunConsoleCommand("ulx", "teleport", "$" .. ply:SteamID())
				end):SetImage('icon16/shield_go.png')
			end

			a:Open()
		end
	end
end

function Panel:DoClose()
	CloseDermaMenus()
end

function Panel:PerformLayout(intW, intH)
	self.m_pnlAvatar:SetSize(intH - 22, intH - 22)
	self.m_pnlAvatar:SetPos(1, 10)
end

function Panel:Think()
	if LocalPlayer():IsStaff() and not self.m_pnlAvatar.StaffOnly then
		self.m_pnlAvatar:Remove()

		self.m_pnlAvatar = vgui.Create("AvatarImage", self)
		self.m_pnlAvatar:SetSize(64, 64)
		self.m_pnlAvatar:SetPlayer(self.m_pPlayer)
		self.m_pnlAvatar.StaffOnly = true
	elseif not LocalPlayer():IsStaff() and self.m_pnlAvatar.StaffOnly then
		self.m_pnlAvatar:Remove()

		self.m_pnlAvatar = vgui.Create("SRP_AvatarImg", self)
		self.m_pnlAvatar:SetSize(64, 64)
		self.m_pnlAvatar:SetPlayer(self.m_pPlayer)
		self.m_pnlAvatar.StaffOnly = nil
	end
end

vgui.Register("SRPScoreboard_PlayerCard", Panel, "EditablePanel")
local Panel = {}

function Panel:Init()
	self.m_tblPlayersLeft = {}
	self.m_tblPlayersRight = {}
	self.m_pnlLeftList = vgui.Create("SRP_ScrollPanel", self)
	self.m_pnlRightList = vgui.Create("SRP_ScrollPanel", self)
	self.m_matLogo = Material("ss3/ace.png", "smooth")
end

local groupsSorted = {}
local number = 1

local function sortGroups(t)
	for k, v in pairs(t) do
		sortGroups(v)
		groupsSorted[k] = number
		number = number + 1
	end
end

local function GetPlayers()
	groupsSorted = {}
	sortGroups(ULib.ucl.getInheritanceTree())
	local sort = {}

	for k, v in pairs(player.GetAll()) do
		if IsValid(v) then
			table.insert(sort, v)
		end
	end

	-- Sort that shit
	local rankSort = function(a, b)
		-- member hack
		local ausergroup = a:GetUserGroup() or "user"
		-- if a:GetEVar("disguise_group") then
		-- ausergroup = a:GetEVar("disguise_group")
		-- end
		-- member hack
		local busergroup = b:GetUserGroup() or "user"
		-- if b:GetEVar("disguise_group") then
		-- busergroup = b:GetEVar("disguise_group")
		-- end
		local arank = groupsSorted[ausergroup] or number
		local brank = groupsSorted[busergroup] or number

		return arank < brank
	end

	table.sort(sort, rankSort)

	return sort
end

function Panel:Refresh()
	for k, v in pairs(self.m_tblPlayersLeft) do
		if ValidPanel(v) then
			v:Remove()
		end
	end

	for k, v in pairs(self.m_tblPlayersRight) do
		if ValidPanel(v) then
			v:Remove()
		end
	end

	self.m_pnlLeftList:Clear()
	self.m_pnlRightList:Clear()
	self.m_tblPlayersLeft = {}
	self.m_tblPlayersRight = {}
	local players = GetPlayers()
	local numPlayers = #players

	if self:GetWide() >= 1024 then
		for i = 1, numPlayers do
			if i - 1 < numPlayers / 2 then
				table.insert(self.m_tblPlayersLeft, self:CreatePlayerCard(players[i], self.m_pnlLeftList))
			else
				table.insert(self.m_tblPlayersRight, self:CreatePlayerCard(players[i], self.m_pnlRightList))
			end
		end
	else
		for i = 1, numPlayers do
			table.insert(self.m_tblPlayersLeft, self:CreatePlayerCard(players[i], self.m_pnlLeftList))
		end
	end

	self:InvalidateLayout()
end

function Panel:CreatePlayerCard(pPlayer, pnlParent)
	local card = vgui.Create("SRPScoreboard_PlayerCard", pnlParent)
	card:SetPlayer(pPlayer)
	pnlParent:AddItem(card)

	return card
end

function Panel:GetJobCounts()
	local ret = {
		[2] = 0,
		[3] = 0,
		[4] = 0
	}

	for k, v in pairs(player.GetAll()) do
		if not GAMEMODE.Jobs:GetPlayerJobID(v) then continue end
		local id = GAMEMODE.Jobs:GetPlayerJobID(v)
		if not ret[id] then continue end
		ret[id] = ret[id] + 1
	end

	return ret
end

-- function Panel:GetJobCounts2()
--     local ret = {
--         [10] = 0,
--         [9] = 0,
--         [6] = 0,
--         [7] = 0
--     }
--     for k, v in pairs(player.GetAll()) do
--         if not GAMEMODE.Jobs:GetPlayerJobID(v) then continue end
--         local id = GAMEMODE.Jobs:GetPlayerJobID(v)
--         if not ret[id] then continue end
--         ret[id] = ret[id] + 1
--     end
--     return ret
-- end
-- function Panel:GetJobCounts3()
--     local ret = {
--         [5] = 0,
--         [23] = 0
--     }
--     for k, v in pairs(player.GetAll()) do
--         if not GAMEMODE.Jobs:GetPlayerJobID(v) then continue end
--         local id = GAMEMODE.Jobs:GetPlayerJobID(v)
--         if not ret[id] then continue end
--         ret[id] = ret[id] + 1
--     end
--     return ret
-- end
function Panel:PaintOver(intW, intH)
	surface.SetDrawColor(0, 0, 0, 255)
	surface.DrawRect(0, 0, intW, 1) --top
	surface.DrawRect(0, 0, 1, intH) --left side
	surface.DrawRect(intW - 1, 0, 1, intH) --right side
	surface.DrawRect(0, intH - 1, intW, 1) --bottom
	surface.SetTexture(TEX_GRADIENT_DOWN)
	surface.SetDrawColor(0, 0, 0, 125)
	surface.DrawTexturedRect(0, 0, intW, 500)
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.SetMaterial( self.m_matLogo )
	surface.DrawTexturedRect( 0, 20, 500, 90 )
	draw.SimpleText(GetHostName(), "Scoreboard_Trebuchet38", intW - 5, 0, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
	draw.SimpleText(#player.GetAll() .. "/" .. game.MaxPlayers() .. " Players", "Scoreboard_Trebuchet24", intW - 5, 38 + 24, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
	local y = 77

	for k, v in pairs(self:GetJobCounts()) do
		draw.SimpleText(GAMEMODE.Jobs:GetJobByID(k).Name .. ": " .. v, "Scoreboard_Trebuchet18", intW - 5, y, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
		y = y + 18
	end

	local y2 = 77
	-- for k2, v2 in pairs(self:GetJobCounts2()) do
	--     draw.SimpleText(GAMEMODE.Jobs:GetJobByID(k2).Name .. ": " .. v2, "Scoreboard_Trebuchet18", intW - 100, y2, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
	--     y2 = y2 + 18
	-- end
	-- local y3 = 77
	-- for k3, v3 in pairs(self:GetJobCounts3()) do
	--     draw.SimpleText(GAMEMODE.Jobs:GetJobByID(k3).Name .. ": " .. v3, "Scoreboard_Trebuchet18", intW - 240, y3, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
	--     y3 = y3 + 18
	-- end
	draw.SimpleText("Server Uptime: "..secondsToTime(CurTime()), "Scoreboard_Trebuchet38", intW - 5, intH-50, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)

end

function Panel:PerformLayout(intW, intH)
	local headerTall = 155
	local listPaddingW = 0
	local listPaddingH = 0

	if intW < 1024 then
		self.m_pnlLeftList:SetPos(listPaddingW, listPaddingH + headerTall)
		self.m_pnlLeftList:SetSize(intW - (listPaddingW * 2), intH - (listPaddingH * 2) - headerTall)
		self.m_pnlRightList:SetVisible(false)

		for k, v in pairs(self.m_tblPlayersLeft) do
			v:SetTall(48)
			v:DockMargin(5, 0, 5, -18)
			v:Dock(TOP)
		end
	else
		self.m_pnlRightList:SetVisible(true)
		local wide = (intW - (listPaddingW * 3)) / 2
		self.m_pnlLeftList:SetPos(listPaddingW, listPaddingH + headerTall)
		self.m_pnlLeftList:SetSize(wide, intH - (listPaddingH * 2) - headerTall)
		self.m_pnlRightList:SetPos(wide + (listPaddingW * 2), listPaddingH + headerTall)
		self.m_pnlRightList:SetSize(wide, intH - (listPaddingH * 2) - headerTall)

		for k, v in pairs(self.m_tblPlayersLeft) do
			v:SetTall(48)
			v:DockMargin(5, 0, 5, -18)
			v:Dock(TOP)
		end

		for k, v in pairs(self.m_tblPlayersRight) do
			v:SetTall(48)
			v:DockMargin(5, 0, 5, -18)
			v:Dock(TOP)
		end
	end
end

function Panel:DoClose()
	CloseDermaMenus()
end

vgui.Register("SRPScoreboard", Panel, "SRP_FramePanel")