local Panel = {}

function Panel:Init()
  self.m_colItemName = Color(255, 255, 255, 255)
  self.m_colAmount = Color(120, 230, 110, 255)
  self.m_pnlIcon = vgui.Create("ModelImage", self)
  self.m_pnlNameLabel = vgui.Create("DLabel", self)
  self.m_pnlNameLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
  self.m_pnlNameLabel:SetTextColor(self.m_colItemName)
  self.m_pnlNameLabel:SetFont("ItemCardFont2")
  self.m_pnlNumLabel = vgui.Create("DLabel", self)
  self.m_pnlNumLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
  self.m_pnlNumLabel:SetTextColor(self.m_colAmount)
  self.m_pnlNumLabel:SetFont("Trebuchet24")
  self.m_pnlNumLabel:SetText(" ")
  self.m_pnlTradeBtn = vgui.Create("SRP_Button", self)
  self.m_pnlTradeBtn:SetSize(50, 50)
  self.m_pnlTradeBtn:SetText("Trade In")
  self.m_pnlContainer = vgui.Create("EditablePanel", self)
  self.m_pnlDescLabel = vgui.Create("DLabel", self.m_pnlContainer)
  self.m_pnlDescLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
  self.m_pnlDescLabel:SetTextColor(self.m_colItemName)
  self.m_pnlDescLabel:SetFont("ItemCardDescFont")
  self.m_intItemAmount = 1
  self.m_pnlNumLabel:MoveToFront()
end

function Panel:SetItemData(strItemID, toItem)
  self.m_strItemID = strItemID
  local isDeprecated = false

  if GAMEMODE.Inv:GetItem(strItemID) and GAMEMODE.Inv:GetItem(strItemID).IsDeprecated then
    isDeprecated = true
  elseif not GAMEMODE.Inv:GetItem(strItemID) then
    isDeprecated = true
  end

  self.m_pnlNameLabel:SetText(strItemID .. (not isDeprecated and "" or " (Deprecated Item)"))
  self.m_pnlIcon:SetModel(GAMEMODE.Inv:GetItem(strItemID).Model)

  if istable(toItem) and toItem.From then
    self.m_pnlDescLabel:SetText("Trade (x" .. toItem.From .. ") " .. strItemID .. " for (x" .. toItem.GiveAmount .. ") " .. toItem.GiveItem)
  else
    self.m_pnlDescLabel:SetText("Unfortunately there is no trade in available for this item. You may delete it if you want.")
  end
    self:InvalidateLayout()
    -- self:BuildTrayButtons()
  end

  function Panel:SetItemAmount(intAmount)
    self.m_intItemAmount = intAmount
    self.m_pnlNumLabel:SetText("x" .. string.Comma(intAmount))

    if intAmount > 999 then
      self.m_pnlNumLabel:SetFont("Trebuchet18")
      self.m_pnlNumLabel:InvalidateLayout(true)
    else
      self.m_pnlNumLabel:SetFont("Trebuchet24")
      self.m_pnlNumLabel:InvalidateLayout(true)
    end

    self:InvalidateLayout()
  end

  function Panel:SetItemPrice(intAmount)
    self.m_intItemPrice = intAmount
  end

  function Panel:Paint(intW, intH)
    surface.SetDrawColor(50, 50, 50, 200)
    surface.DrawRect(0, 0, intW, intH)
  end

  function Panel:PerformLayout(intW, intH)
    local padding = 5
    self.m_pnlIcon:SetPos(0, 0)
    self.m_pnlIcon:SetSize(intH, intH)
    self.m_pnlNameLabel:SizeToContents()
    self.m_pnlNameLabel:SetPos((padding * 2) + intH, (intH / 2) - self.m_pnlNameLabel:GetTall())
    self.m_pnlNumLabel:SizeToContents()
    self.m_pnlTradeBtn:SizeToContents()
    self.m_pnlTradeBtn:SetTall(intH)
    self.m_pnlTradeBtn:SetPos(intW - self.m_pnlTradeBtn:GetWide(), intH - self.m_pnlTradeBtn:GetTall())

    if self.m_pnlNumLabel:GetWide() > self.m_pnlIcon:GetWide() then
      self.m_pnlNumLabel:SetPos(0, intH - self.m_pnlNumLabel:GetTall())
    else
      self.m_pnlNumLabel:SetPos(self.m_pnlIcon:GetWide() - self.m_pnlNumLabel:GetWide(), intH - self.m_pnlNumLabel:GetTall())
    end

    self.m_pnlDescLabel:SizeToContents()
    self.m_pnlContainer:SetPos((padding * 2) + intH, (intH / 2))
    self.m_pnlContainer:SetSize(intW - (padding * 2) + intH, self.m_pnlDescLabel:GetTall())
  end

  vgui.Register("SRPTradeInCard", Panel, "EditablePanel")