local PANEL = {}

AccessorFunc( PANEL, "m_bInitialized", "Initialized" )

--[[---------------------------------------------------------
	Name: Paint
-----------------------------------------------------------]]
function PANEL:Init()
	self:SetInitialized( false )
end

--[[---------------------------------------------------------
	Name: ClearControls
-----------------------------------------------------------]]
function PANEL:ClearControls()
	self:Clear()
end

--[[---------------------------------------------------------
	Name: GetEmbeddedPanel
-----------------------------------------------------------]]
function PANEL:GetEmbeddedPanel()

	return self

end

--[[---------------------------------------------------------
	Name: AddPanel
-----------------------------------------------------------]]
function PANEL:AddPanel( pnl )

	self:AddItem( pnl, nil )
	self:InvalidateLayout()

end

--[[---------------------------------------------------------
	Name: FillViaTable
-----------------------------------------------------------]]
function PANEL:FillViaTable( Table )

	self:SetInitialized( true )

	self:SetName( Table.Text )

	--
	-- If we have a function to create the control panel, use that
	--
	if ( Table.ControlPanelBuildFunction ) then

		self:FillViaFunction( Table.ControlPanelBuildFunction )

	end

end

--[[---------------------------------------------------------
	Name: FillViaFunction
-----------------------------------------------------------]]
function PANEL:FillViaFunction( func )

	func( self )

end

--[[---------------------------------------------------------
	Name: ControlValues
-----------------------------------------------------------]]
function PANEL:ControlValues( data )
	if ( data.label) then
		self:SetLabel( data.label )
	end
	if ( data.closed ) then
		self:SetExpanded( false )
	end
end

--[[---------------------------------------------------------
	Name: AddControl
-----------------------------------------------------------]]
function PANEL:AddControl( control, data )

	local data = table.LowerKeyNames( data )
	local original = control
	control = string.lower( control )

	-- Retired
	if ( control == "header" ) then

		if ( data.description ) then
			local ctrl = self:Help( data.description )
			return ctrl
		end

		return
	end

	if ( control == "textbox" ) then

		local ctrl = self:TextEntry( data.label or "Untitled", data.command )
		return ctrl

	end

	if ( control == "label" ) then

		local ctrl = self:Help( data.text )
		return ctrl

	end

	if ( control == "checkbox" or control == "toggle" ) then

		local ctrl = self:CheckBox( data.label or "Untitled", data.command )

		if ( data.help ) then
			self:ControlHelp( data.label .. ".help" )
		end

		return ctrl

	end

	if ( control == "slider" ) then

		local Decimals = 0
		if ( data.type and string.lower(data.type) == "float" ) then Decimals = 2 end

		local ctrl = self:NumSlider( data.label or "Untitled", data.command, data.min or 0, data.max or 100, Decimals )

		if ( data.help ) then
			self:ControlHelp( data.label .. ".help" )
		end

		return ctrl

	end

	if ( control == "button" ) then

		local ctrl = vgui.Create( "DButton", self )

		-- Note: Buttons created this way use the old method of calling commands,
		-- via LocalPlayer:ConCommand. This way is flawed. This way is legacy.
		-- The new way is to make buttons via controlpanel:Button( name, command, commandarg1, commandarg2 ) etc
		if ( data.command ) then
			function ctrl:DoClick() LocalPlayer():ConCommand( data.command ) end
		end

		ctrl:SetText( data.label or data.text or "No Label" )
		self:AddPanel( ctrl )
		return ctrl

	end

	local ctrl = vgui.Create( original, self )
	-- Fallback for scripts that relied on the old behaviour
	if ( not ctrl ) then
		ctrl = vgui.Create( control, self )
	end
	if ( ctrl ) then

		if ( ctrl.ControlValues ) then
			ctrl:ControlValues( data )
		end

		self:AddPanel( ctrl )
		return ctrl

	end

	MsgN( "UNHANDLED CONTROL: ", control )
	PrintTable( data )
	MsgN( "\n\n" )
end

vgui.Register( "SRP_SBox_ControlPanel", PANEL, "DForm" )