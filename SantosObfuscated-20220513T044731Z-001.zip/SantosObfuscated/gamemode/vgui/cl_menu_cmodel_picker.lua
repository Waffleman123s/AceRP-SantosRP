--[[
	Name: cl_menu_cmodel_picker.lua
	For: SantosRP
	By: Ultra
]]--

local Panel = {}
function Panel:Init()
	self.m_pnlIcon = vgui.Create( "ModelImage", self )
	self.m_pnlIcon:SetMouseInputEnabled( false )

	self.m_pnlNameLabel = vgui.Create( "DLabel", self )
	self.m_pnlNameLabel:SetExpensiveShadow( 2, Color(0, 0, 0, 255) )
	self.m_pnlNameLabel:SetTextColor( Color(255, 255, 255, 255) )
	self.m_pnlNameLabel:SetFont( "CarMenuFont" )

	self.m_pnlBtn = vgui.Create( "SRP_Button", self )
	self.m_pnlBtn:SetFont( "CarMenuFont" )
	self.m_pnlBtn:SetText( "Set Model" )
	self.m_pnlBtn:SetAlpha( 150 )
	self.m_pnlBtn.DoClick = function()
		self.m_pnlParentMenu:OnModelSelected( self.m_strMdl )
	end
end

function Panel:SetModel( strMdl )
	self.m_strMdl = strMdl
	self.m_pnlNameLabel:SetText( strMdl )
	self.m_pnlIcon:SetModel( self.m_strMdl )
	self:InvalidateLayout()
end

function Panel:Paint( intW, intH )
	surface.SetDrawColor( 50, 50, 50, 200 )
	surface.DrawRect( 0, 0, intW, intH )
end

function Panel:PerformLayout( intW, intH )
	local padding = 5

	self.m_pnlIcon:SetPos( 0, 0 )
	self.m_pnlIcon:SetSize( intH, intH )

	self.m_pnlNameLabel:SizeToContents()
	self.m_pnlNameLabel:SetWide( intW )
	self.m_pnlNameLabel:SetPos( (padding *2) +intH, (intH /2) -(self.m_pnlNameLabel:GetTall() /2) )

	self.m_pnlBtn:SetSize( 110, intH )
	self.m_pnlBtn:SetPos( intW -self.m_pnlBtn:GetWide(), 0 )
end
vgui.Register( "SRPCModelCard", Panel, "EditablePanel" )

-- ----------------------------------------------------------------

local Panel = {}
function Panel:Init()
	self:SetDeleteOnClose( false )
	self:SetTitle( "Admin Character Model Picker" )
	self.m_pnlCanvas = vgui.Create( "SRP_ScrollPanel", self )
	self.m_tblCards = {}
end

function Panel:Populate( strKey )
	self.m_pnlCanvas:Clear( true )
	self.m_tblCards = {}

	for k, v in pairs( GAMEMODE.Config.PlayerModels[strKey] ) do
		self:CreateCard( k )
	end

	self:InvalidateLayout()
end

function Panel:CreateCard( strMdl )
	local pnl = vgui.Create( "SRPCModelCard" )
	pnl.m_pnlParentMenu = self
	pnl:SetModel( strMdl )
	self.m_pnlCanvas:AddItem( pnl )
	self.m_tblCards[#self.m_tblCards +1] = pnl
	return pnl
end

function Panel:PerformLayout( intW, intH )
	DFrame.PerformLayout( self, intW, intH )

	self.m_pnlCanvas:SetPos( 0, 24 )
	self.m_pnlCanvas:SetSize( intW, intH -24 )

	for _, pnl in pairs( self.m_tblCards ) do
		pnl:DockMargin( 0, 0, 0, 5 )
		pnl:SetTall( 64 )
		pnl:Dock( TOP )
	end
end

function Panel:OnModelSelected( strMdl )
	if IsValid( self.m_entTarget ) then
		local target = self.m_entTarget
		self.m_entTarget = nil
		serverguard.command.Run( "changemodel", false, target:SteamID64(), strMdl )
		self:Close()
	end
end

function Panel:Open( pPlayer )
	if not IsValid( pPlayer ) then self:Close() return end
	self.m_entTarget = pPlayer
	self:Populate( GAMEMODE.Player:GetSharedGameVar(pPlayer, "char_sex") == 0 and "Male" or "Female" )
	self:SetVisible( true )
	self:MakePopup()
end

function Panel:OnClose()
	self.m_entTarget = nil
end
vgui.Register( "SRPCModelPicker", Panel, "SRP_Frame" )