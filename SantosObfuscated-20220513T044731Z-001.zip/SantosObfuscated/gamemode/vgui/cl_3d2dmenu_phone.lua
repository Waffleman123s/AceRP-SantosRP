--[[
    Name: cl_3d2dmenu_phone.lua
    For: SantosRP
    By: Ultra
]]
--
--Phone
surface.CreateFont("PhoneClockFont", {
    size = 18,
    weight = 250,
    font = "DermaLarge"
})

surface.CreateFont("PhoneIconFont", {
    size = 17,
    weight = 500,
    font = "Trebuchet"
})

surface.CreateFont("SRPToolbarTitle", {
    size = 28,
    weight = 400,
    font = "DermaLarge"
})

--Messages
surface.CreateFont("SRPTextMessageFontSmall", {
    size = 22,
    weight = 400,
    font = "DermaLarge"
})

surface.CreateFont("SRPTextMessageFont", {
    size = 23,
    weight = 400,
    font = "DermaLarge"
})

--Contacts
surface.CreateFont("SRPContactFont", {
    size = 22,
    weight = 400,
    font = "DermaLarge"
})

surface.CreateFont("SRPContactFontSmall", {
    size = 22,
    weight = 400,
    font = "DermaLarge"
})

hook.Add("Think", "Think3D2DTextPanels", function()
    local pnl = vgui.GetKeyboardFocus()

    if ValidPanel(pnl) and pnl.Is3D2DTextInput then
        if not pnl.m_pnlParent:IsVisible() then
            pnl.m_pnlParent:Hide2DInput(pnl)
        end
    end
end)

local Panel = {}

function Panel:Init()
    DTextEntry.Init(self)
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
end

function Panel:SetRoot(pnlRoot)
    self.m_pnlRoot = pnlRoot
end

function Panel:RootOffset()
    local parent = self:GetParent()
    local x, y = self:GetPos()

    while ValidPanel(parent) and parent ~= (self.m_pnlRoot or GAMEMODE.Gui.m_pnlPhone:GetParent()) do
        local px, py = parent:GetPos()
        x, y = x + px, y + py
        parent = parent:GetParent()
    end

    return x, y
end

function Panel:Show2DInput()
    --Source engine doesn't like it when a text entry is off the screen... or not visible... or something
    --Dumb hack incoming
    if ValidPanel(self.m_pnlTextEntry) then return end
    local x, y = self:RootOffset()
    self.m_pnlTextEntry = vgui.Create("DTextEntry")
    self.m_pnlTextEntry:SetSize(self:GetWide(), self:GetTall())
    self.m_pnlTextEntry:SetPos(x, y)
    self.m_pnlTextEntry:SetMultiline(self.m_bMultiline)
    self.m_pnlTextEntry:SetFont(self:GetFont())
    self.m_pnlTextEntry:SetValue(self:GetValue())
    self.m_pnlTextEntry.AllowInput = self.AllowInput
    self.m_pnlTextEntry:SetNumeric(self:GetNumeric())

    self.m_pnlTextEntry.OnChange = function()
        self:SetValue(self.m_pnlTextEntry:GetValue())
        self:OnChange()
    end

    self.m_pnlTextEntry.OnKeyCodeTyped = self.OnKeyCodeTyped
    self:OnShowFakeInput(self.m_pnlTextEntry)
    self.m_pnlTextEntry:MakePopup()
    self.m_pnlTextEntry:RequestFocus()
    --Can't get selected text start+end positions, can't get the clipboard, this is the only way
    self.m_pnlTextEntry:SetPaintedManually(true)
    self.m_pnlTextEntry.m_pnlParent = self
    self.m_pnlTextEntry.Is3D2DTextInput = true

    self.m_pnlTextEntry.Think = function(this)
        if not ValidPanel(self) then
            this:Remove()

            return
        end

        DTextEntry.Think(this)

        if vgui.GetKeyboardFocus() ~= this then
            self:Hide2DInput(this)
        else
            if input.IsMouseDown(MOUSE_LEFT) and not this.m_bMLDeBounce then
                if not self.Hovered then
                    self:Hide2DInput(this)
                end
            elseif not input.IsMouseDown(MOUSE_LEFT) and this.m_bMLDeBounce then
                this.m_bMLDeBounce = nil
            end
        end
    end

    if input.IsMouseDown(MOUSE_LEFT) then
        self.m_pnlTextEntry.m_bMLDeBounce = true
    end
end

function Panel:OnShowFakeInput()
end

function Panel:Hide2DInput(pnl)
    self = pnl or self.m_pnlTextEntry
    self:KillFocus()
    self:Remove()
    self = nil
end

function Panel:PaintOver(intW, intH)
    if not ValidPanel(self.m_pnlTextEntry) then return end
    self.m_pnlTextEntry:PaintManual()
end

function Panel:SetMultiline(b)
    self.m_bMultiline = b
    DTextEntry.SetMultiline(self, b)
    if not ValidPanel(self.m_pnlTextEntry) then return end
    self.m_pnlTextEntry:SetMultiline(b)
end

function Panel:OnMousePressed(...)
    DTextEntry.OnMousePressed(self, ...)
    self:Show2DInput()
end

function Panel:OnFocusChanged(b)
    if b then return end

    if ValidPanel(self.m_pnlTextEntry) then
        self:Hide2DInput(self.m_pnlTextEntry)
    end
end

function Panel:PerformLayout(intW, intH)
    DTextEntry.PerformLayout(self, intW, intH)

    if ValidPanel(self.m_pnlTextEntry) then
        self.m_pnlTextEntry:SetSize(intW, intH)
        self.m_pnlTextEntry:SetPos(self:RootOffset())
    end
end

vgui.Register("SRPPhone_TextEntry", Panel, "DTextEntry")
-- --------------------------------------------------------------------------
local Panel = {}

function Panel:Init()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self.m_tblBtns = {}
    self.m_pnlBtnContainer = vgui3D.Create("EditablePanel", self)

    self.m_pnlBtnContainer.Paint = function(_, intW, intH)
        for k, v in pairs(self.m_tblBtns) do
            local x, y = v:GetPos()
            local w, h = v:GetSize()
            draw.SimpleText(v.m_strText, "HudHintTextSmall", x + (w / 2), y + h, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
        end
    end

    self.m_pnlBtnBack = vgui3D.Create("DImageButton", self)
    self.m_pnlBtnBack:SetImage("santosrp/phone_v2/srp_phone_back_button.png")

    self.m_pnlBtnBack.DoClick = function()
        self:OnPageBack()
    end
end

function Panel:OnPageBack()
    GAMEMODE.Gui.m_pnlPhone:BackPage()
end

function Panel:AddButton(strName, strMat, funcDoClick)
    local iconSize = 24
    local pnl = vgui3D.Create("DButton", self.m_pnlBtnContainer)
    pnl:SetSize(48, 32)
    pnl:SetText(" ")
    pnl.m_strText = strName
    pnl.m_matIcon = Material(strMat)
    pnl.DoClick = funcDoClick

    pnl.Paint = function(p, intW, intH)
        if p.Hovered then
            draw.RoundedBox(4, 0, 0, intW, intH, Color(255, 255, 255, 50))
        end

        surface.SetMaterial(p.m_matIcon)
        surface.SetDrawColor(255, 255, 255, 255)
        surface.DrawTexturedRect((intW / 2) - (iconSize / 2), (intH / 2) - (iconSize / 2), iconSize, iconSize)
    end

    table.insert(self.m_tblBtns, pnl)

    return pnl
end

function Panel:SetIcon(strIcon)
    self.m_matIcon = Material(strIcon)
end

function Panel:SetAppName(strName)
    self.m_strAppName = strName
end

function Panel:GetAppName()
    return self.m_strAppName
end

function Panel:SetAppPanel(strPanel)
    self.m_pnlApp = vgui3D.Create(strPanel)
    self.m_pnlApp:SetVisible(false)
end

function Panel:SetTitle(strText)
    self.m_strTitle = strText
end

function Panel:GetTitle()
    return self.m_strTitle
end

function Panel:Paint(intW, intH)
    local col = (ValidPanel(self:GetParent()) and self:GetParent().GetTitleBarColor) and self:GetParent():GetTitleBarColor() or GAMEMODE.Gui.m_pnlPhone.m_pnlContent.m_pnlTitleBar:GetColor()
    local h, s, v = ColorToHSV(col)
    local shade = HSVToColor(h, s, v + 0.026)
    surface.SetDrawColor(shade.r, shade.g, shade.b, 255)
    surface.DrawRect(0, 0, intW, intH)

    if self.m_strTitle then
        draw.SimpleText(self.m_strTitle, "SRPToolbarTitle", intW / 2, intH / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

function Panel:PerformLayout(intW, intH)
    local x = 0

    for k, v in pairs(self.m_tblBtns) do
        v:SetSize(48, 24)
        v:SetPos(x, (intH / 2) - (v:GetTall() / 2))
        x = x + v:GetWide()
    end

    self.m_pnlBtnContainer:SetPos((intW / 2) - (x / 2), 0)
    self.m_pnlBtnContainer:SetSize(x, intH)
    self.m_pnlBtnBack:SetSize(18, 18)
    self.m_pnlBtnBack:SetPos(9, (intH / 2) - (self.m_pnlBtnBack:GetTall() / 2))
end

vgui.Register("SRPPhone_AppToolbar", Panel, "EditablePanel")
-- --------------------------------------------------------------------------
local Panel = {}

function Panel:Init()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self:SetText(" ")
end

function Panel:SetIcon(strIcon)
    self.m_strIcon = strIcon
    self.m_matIcon = Material(strIcon, "noclamp smooth")
end

function Panel:SetWebIcon(bIsWebIcon)
    self.m_bIsWebIcon = bIsWebIcon
end

function Panel:SetAppName(strName)
    self.m_strAppName = strName
end

function Panel:GetAppName()
    return self.m_strAppName
end

function Panel:SetAppPanel(strPanel)
    self.m_pnlApp = vgui3D.Create(strPanel, self:GetParent():GetParent())
    self.m_pnlApp:SetVisible(false)
end

function Panel:GetAppPanel()
    return self.m_pnlApp
end

function Panel:DoClick()
    self:GetParent():ShowMenu(self.m_pnlApp)
end

function Panel:Paint(intW, intH)
    if self.m_bIsWebIcon and not GAMEMODE.Module:GetModule("Web Materials") then
        print("bad")
        self.m_matIcon = Material("error")
        self.m_bIsWebIcon = false
    end

    surface.SetMaterial(self.m_bIsWebIcon and GAMEMODE.Module:GetModule("Web Materials"):FetchMaterial(self.m_strIcon) or self.m_matIcon)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.DrawTexturedRect(0, 0, intW, intH)
end

function Panel:PerformLayout(intW, intH)
end

vgui.Register("SRPPhone_AppIcon", Panel, "DButton")
-- --------------------------------------------------------------------------
local days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}
local Panel = {}

function Panel:Init()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self.m_matSignal = Material("santosrp/phone_v2/srp_phone_network.png", "noclamp")
    self.m_matWifi = Material("santosrp/phone_v2/srp_phone_wifi.png", "noclamp")
    self.m_pnlClockLabel = vgui3D.Create("DLabel", self)
    self.m_pnlClockLabel:SetTextColor(Color(255, 255, 255, 255))
    self.m_pnlClockLabel:SetFont("PhoneClockFont")
    self.m_colColor = color_white
end

function Panel:SetColor(col)
    self.m_colColor = col
end

function Panel:GetColor()
    return self.m_colColor
end

function Panel:Think()
    local mod = GAMEMODE.Module:GetModule("daynight")

    if mod then
        local min = math.floor(mod:GetTime() % 60)
        local hour = math.floor(mod:GetTime() / 60)
        local pm = hour >= 12 and "PM" or "AM"

        if hour >= 12 then
            hour = hour - 12
        end

        if hour == 0 then
            hour = 12
        end

        if min < 10 then
            min = "0" .. min
        end

        self.m_pnlClockLabel:SetText((hour .. ":" .. min .. " " .. pm) .. " - " .. days[mod:GetDay() or 1])
    else
        self.m_pnlClockLabel:SetText(os.date())
    end

    self.m_pnlClockLabel:SizeToContents()
end

function Panel:Paint(intW, intH)
    surface.SetDrawColor(self.m_colColor.r, self.m_colColor.g, self.m_colColor.b, 255)
    surface.DrawRect(0, 0, intW, intH)
    local x, y = self.m_pnlClockLabel:GetPos()
    surface.SetMaterial(self.m_matSignal)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.DrawTexturedRect(x - 23, y + 1, 16, 16)
    surface.SetMaterial(self.m_matWifi)
    surface.DrawTexturedRect(x - 23 - 18, y + 1, 16, 16)
end

function Panel:PerformLayout(intW, intH)
    self.m_pnlClockLabel:SizeToContents()
    self.m_pnlClockLabel:SetPos(intW - self.m_pnlClockLabel:GetWide() - 5, 0)
end

vgui.Register("SRPPhoneTitleBar", Panel, "EditablePanel")
-- --------------------------------------------------------------------------
local Panel = {}

function Panel:Init()
    self.m_colTitleColor = Color(0, 0, 0)
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self.m_tblApps = {}
    self.m_intAppLabelTall = 5
end

function Panel:GetTitleBarColor()
    return self.m_colTitleColor
end

function Panel:ShowMenu(...)
    self:GetParent():ShowMenu(...)
end

function Panel:Refresh()
    for k, v in pairs(self.m_tblApps) do
        if ValidPanel(v) then
            v:Remove()
        end
    end

    self.m_tblApps = {}

    for k, v in pairs(GAMEMODE.Gui.m_tblDefPhoneApps) do
        local app = vgui3D.Create("SRPPhone_AppIcon", self)
        app:SetIcon(v.Icon)
        app:SetWebIcon(v.WebIcon)
        app:SetAppPanel(v.Panel)
        app:SetAppName(v.Name)
        table.insert(self.m_tblApps, app)
    end

    self:InvalidateLayout()
end

function Panel:Paint()
    for k, v in pairs(self.m_tblApps) do
        local x, y = v:GetPos()
        local w, h = v:GetSize()
        surface.SetFont("PhoneIconFont")
        local tW, tH = surface.GetTextSize(v:GetAppName())

        if v.Hovered then
            draw.RoundedBox(4, x, y, w, h + self.m_intAppLabelTall + tH, Color(255, 255, 255, 50))
        end

        draw.SimpleText(v:GetAppName(), "PhoneIconFont", x + (w / 2), y + h, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
    end
end

function Panel:PerformLayout(intW, intH)
    local x, y = 0, 0
    local perRow, count = 4, 0
    local paddingW = intH * 0.025
    local paddingH = intH * 0.045
    local sizeW = (intW - (paddingW * perRow) - paddingW) / perRow
    x = paddingW

    for k, v in pairs(self.m_tblApps) do
        v:SetPos(x, y)
        v:SetSize(sizeW, sizeW)
        count = count + 1

        if count < perRow then
            x = x + sizeW + paddingW
        else
            x = paddingW
            count = 0
            y = y + sizeW + paddingH + self.m_intAppLabelTall
        end
    end
end

vgui.Register("SRPAppList", Panel, "EditablePanel")
-- --------------------------------------------------------------------------
local Panel = {}

function Panel:Init()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self.m_pnlTitleBar = vgui3D.Create("SRPPhoneTitleBar", self)
    self.m_pnlAppList = vgui3D.Create("SRPAppList", self)
    self.m_pnlAppList:Refresh()
    self.m_tblPageBuffer = {}
    self.m_pnlTitleBar:SetColor(color_black)
end

function Panel:HomePage()
    local cur = self.m_tblPageBuffer[#self.m_tblPageBuffer]
    if not cur then return end
    self.m_bAnim = true
    cur:SetPos(0, self.m_pnlTitleBar:GetTall())

    cur:MoveTo(self:GetWide(), self.m_pnlTitleBar:GetTall(), 0.25, 0, 2, function()
        cur:SetVisible(false)
    end)

    self.m_pnlAppList:SetVisible(true)
    self.m_pnlAppList:SetPos(-self:GetWide(), 30)

    self.m_pnlAppList:MoveTo(0, 30, 0.25, 0, 2, function()
        self.m_pnlAppList:SetVisible(true)
        self.m_bAnim = false
    end)

    self.m_tblPageBuffer = {}
end

function Panel:ShowMenu(pnlMenu, funcCallback)
    if self.m_bAnim then return end
    self.m_bAnim = true
    pnlMenu:SetParent(self)
    pnlMenu:SetSize(self:GetWide(), self:GetTall() - self.m_pnlTitleBar:GetTall())
    pnlMenu:InvalidateLayout()
    local old = self.m_tblPageBuffer[#self.m_tblPageBuffer]
    old = old or self.m_pnlAppList
    old:SetPos(0, old ~= self.m_pnlAppList and self.m_pnlTitleBar:GetTall() or 30)

    old:MoveTo(-self:GetWide(), old ~= self.m_pnlAppList and self.m_pnlTitleBar:GetTall() or 30, 0.25, 0, 2, function()
        old:SetVisible(false)

        if funcCallback then
            funcCallback()
        end
    end)

    pnlMenu:SetVisible(true)
    pnlMenu:SetPos(self:GetWide(), self.m_pnlTitleBar:GetTall())

    pnlMenu:MoveTo(0, self.m_pnlTitleBar:GetTall(), 0.25, 0, 2, function()
        pnlMenu:SetVisible(true)
        pnlMenu:MoveToFront()
        pnlMenu:RequestFocus()
        self.m_bAnim = false

        if funcCallback then
            funcCallback()
        end
    end)

    if pnlMenu.OnShowPage then
        pnlMenu:OnShowPage()
    end

    table.insert(self.m_tblPageBuffer, pnlMenu)
    self.m_pnlTitleBar:SetColor(pnlMenu.GetTitleBarColor and pnlMenu:GetTitleBarColor() or color_white)
end

function Panel:GetCurrentMenu()
    return self.m_tblPageBuffer[#self.m_tblPageBuffer]
end

function Panel:BackPage()
    if self.m_pnlAppList:IsVisible() then return end
    if #self.m_tblPageBuffer == 0 then return end
    if self.m_bAnim then return end
    self.m_bAnim = true
    local old = self.m_tblPageBuffer[#self.m_tblPageBuffer]
    local new = self.m_tblPageBuffer[#self.m_tblPageBuffer - 1]

    if not new then
        new = self.m_pnlAppList
    end

    local oldIDX = #self.m_tblPageBuffer

    old:MoveTo(self:GetWide(), self.m_pnlTitleBar:GetTall(), 0.25, 0, 2, function()
        old:SetVisible(false)

        if old.OnPageBack then
            old:OnPageBack()
        end

        self.m_tblPageBuffer[oldIDX] = nil
    end)

    new:SetPos(-self:GetWide(), new ~= self.m_pnlAppList and self.m_pnlTitleBar:GetTall() or 30)
    new:MoveToFront()
    new:RequestFocus()
    new:SetVisible(true)

    new:MoveTo(0, new ~= self.m_pnlAppList and self.m_pnlTitleBar:GetTall() or 30, 0.25, 0, 2, function()
        new:SetVisible(true)
        self.m_bAnim = false
    end)

    self.m_pnlTitleBar:SetColor(new.GetTitleBarColor and new:GetTitleBarColor() or color_white)
end

function Panel:NumberTyped(int)
    if #self.m_tblPageBuffer == 0 then return end
    if not self.m_tblPageBuffer[#self.m_tblPageBuffer].NumberTyped then return end
    self.m_tblPageBuffer[#self.m_tblPageBuffer]:NumberTyped(int)
end

function Panel:Paint(intW, intH)
end

function Panel:PerformLayout(intW, intH)
    self.m_pnlTitleBar:SetPos(0, 0)
    self.m_pnlTitleBar:SetSize(intW, 19)
    self.m_pnlAppList:SetPos(5, 30)
    self.m_pnlAppList:SetSize(intW - 10, intH - 35)
end

vgui.Register("SRPPhoneHomeMenu", Panel, "EditablePanel")
-- --------------------------------------------------------------------------
local Panel = {}

function Panel:Init()
    vgui3D.SetCustomMouse(self, true)
    self.m_func3DCustomMouseFunc = self.Get3DCursorPos
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self.m_pnlContent = vgui3D.Create("SRPPhoneHomeMenu", self)
end

function Panel:Think()
    if self.m_tblModule then
        if self.m_matWallpaper ~= self.m_tblModule:GetCurrentWallpaper() then
            self.m_matWallpaper = self.m_tblModule:GetCurrentWallpaper()
        end
    else
        self.m_tblModule = GAMEMODE.Module:GetModule("phone")
    end

    if not self.m_bHasInput then
        self.m_bLeftMouseDown = false
        self.m_bRightMouseDown = false

        return
    end

    if input.IsMouseDown(MOUSE_LEFT) and not self.m_bLeftMouseDown then
        self.m_bLeftMouseDown = true
        vgui3D.PostPanelEvent(self, "OnMousePressed", MOUSE_LEFT)
    elseif not input.IsMouseDown(MOUSE_LEFT) and self.m_bLeftMouseDown then
        self.m_bLeftMouseDown = false
        vgui3D.PostPanelEvent(self, "OnMouseReleased", MOUSE_LEFT)
    end

    if input.IsMouseDown(MOUSE_RIGHT) and not self.m_bRightMouseDown then
        self.m_bRightMouseDown = true
        vgui3D.PostPanelEvent(self, "OnMousePressed", MOUSE_RIGHT)
    elseif not input.IsMouseDown(MOUSE_RIGHT) and self.m_bRightMouseDown then
        self.m_bRightMouseDown = false
        vgui3D.PostPanelEvent(self, "OnMouseReleased", MOUSE_RIGHT)
    end
end

function Panel:Get3DCursorPos(vecOrigin, vecNormal, angAngles, intScale)
    local p = util.IntersectRayWithPlane(LocalPlayer():EyePos(), gui.ScreenToVector(vgui3D.GetRealMouseX(), vgui3D.GetRealMouseY()), vecOrigin, vecNormal) --start pos --aim dir --plane pos --plane angs 
    if not p then return 0, 0 end
    local offset = (p - vecOrigin)
    offset:Rotate(Angle(0, -angAngles.y, 0))
    offset:Rotate(Angle(-angAngles.p, 0, 0))
    offset:Rotate(Angle(0, 0, -angAngles.r))

    return offset.x, -offset.y
end

function Panel:GetMousePos()
    vgui3D.SetCustomMouseFunc(self.m_func3DCustomMouseFunc)
    local x, y = self.m_func3DCustomMouseFunc(self, self.Origin, self.Normal, self.Angle, self.Scale)
    x = x / (self.Scale or 1)
    y = y / (self.Scale or 1)
    vgui3D.SetCustomMouseFunc()

    return x, y
end

function Panel:OnInputGained()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)
    self.m_bHasInput = true
end

function Panel:OnInputLost()
    self:SetMouseInputEnabled(false)
    self:SetKeyboardInputEnabled(false)
    self.m_bHasInput = false
    self.m_bHangInput = false
end

function Panel:InputHanging()
    return self.m_bHangInput
end

function Panel:SetHangInput(bHang)
    self.m_bHangInput = bHang
end

function Panel:HomePage()
    self.m_pnlContent:HomePage()
end

function Panel:GetApp(strAppName)
    for k, v in pairs(self.m_pnlContent.m_pnlAppList.m_tblApps) do
        if v:GetAppName() == strAppName then return v end
    end
end

function Panel:ShowApp(strAppName, funcCallback)
    self.m_pnlContent:ShowMenu(self:GetApp(strAppName):GetAppPanel(), funcCallback)
end

function Panel:ShowMenu(pnlMenu, funcCallback)
    self.m_pnlContent:ShowMenu(pnlMenu, funcCallback)
end

function Panel:GetCurrentMenu()
    return self.m_pnlContent:GetCurrentMenu()
end

function Panel:BackPage()
    self.m_pnlContent:BackPage()
end

function Panel:NumberTyped(int)
    self.m_pnlContent:NumberTyped(int)
end

function Panel:Paint(intW, intH)
    if not self.m_matWallpaper then return end
    surface.SetMaterial(self.m_matWallpaper)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.DrawTexturedRect(0, 0, intW, intH)
end

--[[function Panel:PaintOver( intW, intH )
    if gui.MouseX() < 0 or gui.MouseX() > intW then return end
    if gui.MouseY() < 0 or gui.MouseY() > intH then return end

    local wide, thick = 16, 2
    surface.SetDrawColor( 250, 50, 50, 255 )
    surface.DrawRect( gui.MouseX() -(wide /2), gui.MouseY(), wide +thick, thick )
    surface.DrawRect( gui.MouseX(), gui.MouseY() -(wide /2), thick, wide +thick )
end]]
--
function Panel:PerformLayout(intW, intH)
    self.m_pnlContent:SetPos(0, 0)
    self.m_pnlContent:SetSize(intW, intH)
end

vgui.Register("SRPPhoneMenu", Panel, "EditablePanel")

hook.Add("GamemodeDefineGameVars", "DefinePhoneData", function(pPlayer)
    GAMEMODE.Player:DefineGameVar("phone_number", "", "String", true)
end)