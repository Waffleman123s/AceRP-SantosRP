--[[
	Name: cl_qmenu_tab_rules.lua
	For: SantosRP
	By: Ultra
]]--

local Panel = {}
function Panel:Init()
end

function Panel:PerformLayout( intW, intH )
    gui.OpenURL("https://projectsteele.com/forums/index.php?/topic/6-santos-rp-rules/")
    
end
vgui.Register( "SRPQMenu_Rules", Panel, "EditablePanel" )