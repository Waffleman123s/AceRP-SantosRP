local Panel = {}

function Panel:Init()
    self.m_strFirstName = GAMEMODE.Player:GetSharedGameVar(LocalPlayer(), "name_first", "")
    self.m_strLastName = GAMEMODE.Player:GetSharedGameVar(LocalPlayer(), "name_last", "")
    self.m_intSex = GAMEMODE.Player:GetSharedGameVar(LocalPlayer(), "char_sex", 0)
    self.m_intSkin = LocalPlayer():GetSkin()
    self.m_strModel = LocalPlayer():GetModel()
    --Right side buttons
    self.m_pnlBtnContainer = vgui.Create("EditablePanel", self)

    self.m_pnlBtnContainer.Paint = function(_, intW, intH)
        surface.SetDrawColor(50, 50, 50, 100)
        surface.DrawRect(0, 0, intW, intH)
    end

    self.m_pnlBtnBack = vgui.Create("SRP_Button", self.m_pnlBtnContainer)
    self.m_pnlBtnBack:SetText("Back")

    self.m_pnlBtnBack.DoClick = function()
        self:Remove()
    end

    self.m_pnlBtnSex = vgui.Create("SRP_Button", self.m_pnlBtnContainer)
    self.m_pnlBtnSex:SetText("Male")

    self.m_pnlBtnSex.DoClick = function()
        self.m_intSex = self.m_intSex == 1 and 0 or 1
        self.m_pnlBtnSex:SetText(self.m_intSex == 0 and "Male" or "Female")
        self:ChangeSex()
    end

    local cost = 10000
    
    if LocalPlayer():CheckGroup("vip") then
        cost = 7500
    end
    
    local jobID = GAMEMODE.Jobs:GetPlayerJobID(ply); -- Get the job id from player.
    if table.HasValue({2}, jobID) then cost = 0; end; -- Cost replacement.

    self.m_pnlBtnOk = vgui.Create("SRP_Button", self.m_pnlBtnContainer)
    self.m_pnlBtnOk:SetText("Done($" .. string.Comma(cost) .. ")")

    self.m_pnlBtnOk.DoClick = function()
        net.Start("UpdateCharSF")
        net.WriteString(string.Trim(self.m_strFirstName))
        net.WriteString(string.Trim(self.m_strLastName))
        net.WriteString(self.m_strModel)
        net.WriteInt(self.m_intSex, 32)
        net.WriteInt(self.m_intSkin, 32)
        net.SendToServer()
        self:Remove()
    end

    --Left side character display
    self.m_pnlCharDisplay = vgui.Create("SRPCharacterPreview", self)
    self.m_pnlCharDisplay:SetName(self.m_strFirstName, self.m_strLastName)
    self.m_pnlCharDisplay:SetModel(self.m_strModel)
    --Center options
    self.m_pnlNameFLabel = vgui.Create("DLabel", self)
    self.m_pnlNameFLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
    self.m_pnlNameFLabel:SetTextColor(Color(255, 255, 255, 255))
    self.m_pnlNameFLabel:SetFont("DermaLarge")
    self.m_pnlNameFLabel:SetText("First Name")
    self.m_pnlNameLLabel = vgui.Create("DLabel", self)
    self.m_pnlNameLLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
    self.m_pnlNameLLabel:SetTextColor(Color(255, 255, 255, 255))
    self.m_pnlNameLLabel:SetFont("DermaLarge")
    self.m_pnlNameLLabel:SetText("Last Name")
    self.m_pnlNameFirst = vgui.Create("DTextEntry", self)
    self.m_pnlNameFirst:SetText(self.m_strFirstName)
    self.m_pnlNameLast = vgui.Create("DTextEntry", self)
    self.m_pnlNameLast:SetText(self.m_strLastName)

    self.m_pnlNameFirst.OnTextChanged = function()
        self.m_strFirstName = self.m_pnlNameFirst:GetText()
        self.m_pnlCharDisplay:SetName(self.m_strFirstName, self.m_strLastName)
    end

    self.m_pnlNameLast.OnTextChanged = function()
        self.m_strLastName = self.m_pnlNameLast:GetText()
        self.m_pnlCharDisplay:SetName(self.m_strFirstName, self.m_strLastName)
    end

    self.m_pnlSkinLabel = vgui.Create("DLabel", self)
    self.m_pnlSkinLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
    self.m_pnlSkinLabel:SetTextColor(Color(255, 255, 255, 255))
    self.m_pnlSkinLabel:SetFont("DermaLarge")
    self.m_pnlSkinLabel:SetText("Character Skin (0)")
    self.m_pnlBtnSkinNext = vgui.Create("SRP_Button", self)
    self.m_pnlBtnSkinNext:SetText("Next ->")

    self.m_pnlBtnSkinNext.DoClick = function()
        self:NextSkin()
    end

    self.m_pnlBtnSkinLast = vgui.Create("SRP_Button", self)
    self.m_pnlBtnSkinLast:SetText("<- Last")

    self.m_pnlBtnSkinLast.DoClick = function()
        self:LastSkin()
    end

    self.m_pnlModelLabel = vgui.Create("DLabel", self)
    self.m_pnlModelLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
    self.m_pnlModelLabel:SetTextColor(Color(255, 255, 255, 255))
    self.m_pnlModelLabel:SetFont("DermaLarge")
    self.m_pnlModelLabel:SetText("Character Model")
    self.m_pnlModelList = vgui.Create("DPanelList", self)
    self.m_pnlModelList:SetSpacing(5)
    self.m_pnlModelList:SetPadding(10)
    self.m_pnlModelList:EnableHorizontal(true)
    self.m_pnlModelList:EnableVerticalScrollbar(false)

    self.m_pnlModelList.Paint = function(_, intW, intH)
        surface.SetDrawColor(50, 50, 50, 125)
        surface.DrawRect(0, 0, intW, intH)
    end

    self.m_pnlErrorLabel = vgui.Create("DLabel", self)
    self.m_pnlErrorLabel:SetExpensiveShadow(2, Color(0, 0, 0, 255))
    self.m_pnlErrorLabel:SetTextColor(Color(255, 50, 50, 255))
    self.m_pnlErrorLabel:SetFont("Trebuchet24")
    self.m_pnlErrorLabel:SetText("")
    self:PopulateModelList()
end

function Panel:NextSkin()
    self.m_intSkin = self.m_intSkin + 1

    if self.m_intSkin > self.m_pnlCharDisplay:SkinCount() - 1 then
        self.m_intSkin = 0
    end

    if not GAMEMODE.Util:ValidPlayerSkin(self.m_strModel, self.m_intSkin) then
        self:NextSkin()

        return
    end

    self.m_pnlSkinLabel:SetText("Character Skin (" .. self.m_intSkin .. ")")
    self.m_pnlCharDisplay:SetSkin(self.m_intSkin)
    self:InvalidateLayout()
end

function Panel:LastSkin()
    self.m_intSkin = self.m_intSkin - 1

    if self.m_intSkin < 0 then
        self.m_intSkin = self.m_pnlCharDisplay:SkinCount() - 1
    end

    if not GAMEMODE.Util:ValidPlayerSkin(self.m_strModel, self.m_intSkin) then
        self:LastSkin()

        return
    end

    self.m_pnlSkinLabel:SetText("Character Skin (" .. self.m_intSkin .. ")")
    self.m_pnlCharDisplay:SetSkin(self.m_intSkin)
    self:InvalidateLayout()
end

function Panel:ChangeSex()
    self:PopulateModelList()
    --Pick a random model
    local models = GAMEMODE.Config.PlayerModels[self.m_intSex == 0 and "Male" or "Female"]
    local count = table.Count(models)
    local randomIDX = math.random(1, count)
    local i = 0

    for k, v in pairs(models) do
        i = i + 1

        if i == randomIDX then
            self.m_strModel = k
            break
        end
    end

    self.m_intSkin = 0
    self.m_pnlSkinLabel:SetText("Character Skin (0)")
    self.m_pnlCharDisplay:SetModel(self.m_strModel)
    self.m_pnlCharDisplay:SetSkin(self.m_intSkin)
    self:InvalidateLayout()
end

function Panel:PopulateModelList()
    local models = GAMEMODE.Config.PlayerModels[self.m_intSex == 0 and "Male" or "Female"]
    self.m_pnlModelList:Clear(true)

    for k, v in pairs(models) do
        local modelIcon = vgui.Create("SpawnIcon")
        modelIcon:SetSize(64, 64)
        modelIcon:SetModel(k)
        modelIcon:RebuildSpawnIcon()
        modelIcon:SetToolTip(nil)
        modelIcon.PaintOver = function() end

        modelIcon.DoClick = function()
            self.m_strModel = k
            self.m_pnlCharDisplay:SetModel(k)
            self.m_intSkin = 0
            self.m_pnlSkinLabel:SetText("Character Skin (0)")
            self.m_pnlCharDisplay:SetSkin(self.m_intSkin)
            self:InvalidateLayout()
        end

        self.m_pnlModelList:AddItem(modelIcon)
    end

    self:InvalidateLayout()
end

function Panel:PerformLayout(intW, intH)
    if not self.m_pnlCharDisplay then return end
    --Left side
    self.m_pnlCharDisplay:SetPos(0, 0)
    self.m_pnlCharDisplay:SetSize(intW * 0.25, intH)
    --Right side
    self.m_pnlBtnContainer:SetSize(intW * 0.15, intH)
    self.m_pnlBtnContainer:SetPos(intW - self.m_pnlBtnContainer:GetWide(), 0)
    local btnY, btnPadding = 0, 0
    self.m_pnlBtnBack:SetPos(0, btnY)
    self.m_pnlBtnBack:SetSize(self.m_pnlBtnContainer:GetWide(), 64)
    btnY = btnY + self.m_pnlBtnBack:GetTall() + btnPadding
    self.m_pnlBtnSex:SetPos(0, btnY)
    self.m_pnlBtnSex:SetSize(self.m_pnlBtnContainer:GetWide(), self.m_pnlBtnContainer:GetWide())
    btnY = btnY + self.m_pnlBtnSex:GetTall() + btnPadding
    self.m_pnlBtnOk:SetSize(self.m_pnlBtnContainer:GetWide(), 64)
    self.m_pnlBtnOk:SetPos(0, intH - self.m_pnlBtnOk:GetTall())
    --Center
    local w, h = self.m_pnlCharDisplay:GetSize()
    local cW = intW - w - self.m_pnlBtnContainer:GetWide()
    local curH = 5
    self.m_pnlErrorLabel:SizeToContents()
    self.m_pnlErrorLabel:SetPos(w + 5, curH)
    self.m_pnlErrorLabel:SetVisible(self.m_pnlErrorLabel:GetText() ~= "")

    if self.m_pnlErrorLabel:IsVisible() then
        curH = curH + self.m_pnlErrorLabel:GetTall() + 5
    end

    self.m_pnlNameFLabel:SizeToContents()
    self.m_pnlNameFLabel:SetPos(w + 5, curH)
    curH = curH + self.m_pnlNameFLabel:GetTall() + 5
    self.m_pnlNameFirst:SetPos(w + 5, curH)
    self.m_pnlNameFirst:SetSize(cW - 10, 30)
    curH = curH + self.m_pnlNameFirst:GetTall() + 5
    self.m_pnlNameLLabel:SizeToContents()
    self.m_pnlNameLLabel:SetPos(w + 5, curH)
    curH = curH + self.m_pnlNameLLabel:GetTall() + 5
    self.m_pnlNameLast:SetPos(w + 5, curH)
    self.m_pnlNameLast:SetSize(cW - 10, 30)
    curH = curH + self.m_pnlNameLLabel:GetTall() + 5
    self.m_pnlModelList:SetSize(cW, 155)
    self.m_pnlModelList:SetPos(w, intH - self.m_pnlModelList:GetTall())
    self.m_pnlModelLabel:SizeToContents()
    self.m_pnlModelLabel:SetPos(w + 5, intH - self.m_pnlModelList:GetTall() - self.m_pnlModelLabel:GetTall())
    local x, y = self.m_pnlModelLabel:GetPos()
    self.m_pnlSkinLabel:SizeToContents()
    self.m_pnlSkinLabel:SetPos(w + 5 + ((cW / 2) - self.m_pnlSkinLabel:GetWide() / 2), y - self.m_pnlSkinLabel:GetTall())
    self.m_pnlBtnSkinLast:SetSize(96, self.m_pnlSkinLabel:GetTall())
    self.m_pnlBtnSkinLast:SetPos(w + 5, y - self.m_pnlSkinLabel:GetTall())
    self.m_pnlBtnSkinNext:SetSize(96, self.m_pnlSkinLabel:GetTall())
    self.m_pnlBtnSkinNext:SetPos(w + cW - self.m_pnlBtnSkinNext:GetWide() - 5, y - self.m_pnlSkinLabel:GetTall())
end

vgui.Register("SRPUpdateCharacterPanel", Panel, "SRP_FramePanel")