--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--

if g_ServerNetSock then
	g_ServerNetSock:Close()
	g_ServerNetSock = nil
end

require( "bromsock" )

GM.ServerNet = (GAMEMODE or GM).ServerNet or {}
GM.ServerNet.m_tblIPList = (GAMEMODE or GM).ServerNet.m_tblIPList or {}
GM.ServerNet.m_tblProtocols = (GAMEMODE or GM).ServerNet.m_tblProtocols or {}
GM.ServerNet.m_intClientTimeout = 10 *1000
GM.ServerNet.m_intPort = GM.Config.ServerNetPort or 37015
GM.ServerNet.null = string.char( 0 )

local function readNTString( packet )
	local str = packet:ReadStringNT()
	print( str )
	return str:sub(0, str:len() -1)
end

function GM.ServerNet:Initialize()
	if GAMEMODE.Config and GAMEMODE.Config.ServerNetPool then
		for _, ip in pairs( GAMEMODE.Config.ServerNetPool ) do
			self:AddServerToPool( ip )
		end
	end

	if GAMEMODE.Config and GAMEMODE.Config.ServerNetPort then
		self:Listen( GAMEMODE.Config.ServerNetPort )
	end
end

function GM.ServerNet:AddServerToPool( strIP )
	self.m_tblIPList[strIP] = strIP
end

function GM.ServerNet:GetServerPool()
	return self.m_tblIPList
end

function GM.ServerNet:RegisterEventHandle( strProtocol, strEvent, funcHandle )
	self.m_tblProtocols[strProtocol] = self.m_tblProtocols[strProtocol] or {}
	self.m_tblProtocols[strProtocol][strEvent] = funcHandle
end

function GM.ServerNet:Listen( intPort )
	if not BromSock then return end
	if self.m_pSocket then self.m_pSocket:Close() end

	self.m_pSocket = BromSock()
	self.m_pSocket:Create()

	g_ServerNetSock = self.m_pSocket
	--self.m_pSocket:SetOption( 0x6, 0x0001, 0 )
	--self.m_pSocket:SetOption( 0xffff, 0x0004, 1 )

	self.m_pSocket:SetCallbackAccept( function( pSocket, pClientSocket )
		local ip, port = pClientSocket:GetIP(), pClientSocket:GetPort()

		print( "ASD!!!", ip, port, SysTime() )

		if not self.m_tblIPList[ip] then --Deny this client
			print( "[ServerNet] IP not in whitelist! ".. ip )
			pClientSocket:Close()
		else
			print("FSD!!", SysTime())
			--Client is sending us an event packet
			pClientSocket:SetCallbackReceive( function( pClient, packet )
				print("AAAAA!!", SysTime())

				local proto, event = packet:ReadStringNT(), packet:ReadStringNT()
				if proto:len() == 0 or event:len() == 0 then pClient:Close() packet:Clear() return print "ER1" end
				proto = proto:sub(0, proto:len()-1) --remove null
				event = event:sub(0, event:len()-1) --remove null
				if proto:len() == 0 or event:len() == 0 then pClient:Close() packet:Clear() return print "ER2" end

				print( proto, event, SysTime() )

				if proto == "session" and event == "disconnect" then
					if ip ~= "127.0.0.1" then
						ErrorNoHalt( "Foreign API request!\n" )
						pClient:Close()
						packet:Clear()
						return
					end

					pClient:Close()
					packet:Clear()
					packet = nil
					pClientSocket = nil
					return
				elseif proto == "session" and event == "keepalive" then
					if ip ~= "127.0.0.1" then
						ErrorNoHalt( "Foreign API request!\n" )
						pClient:Close()
						packet:Clear()
						return
					end

					local pPacket = BromPacket()
					pPacket:WriteLine( "keep-alive" )
					pClient:Send( pPacket, true )

					--nothing
					packet:Clear()
					packet = nil
					pClientSocket:ReceiveUntil( "\r\n\r\n" )
					return
				elseif self.m_tblProtocols[proto] then
					if proto == "api" and ip ~= "127.0.0.1" then
						ErrorNoHalt( "Foreign API request!\n" )
						pClient:Close()
						packet:Clear()
						return
					end

					print( "API Func selected!", proto, event, SysTime() )
					local func = self.m_tblProtocols[proto][event]
					if func then
						packet.ReadNTString = readNTString

						local b, args = pcall( func, pClient, packet )
						if not b then
							print( "ServerNet: Event handle error!", args )
						end
						print( "API Func run!", proto, event, SysTime() )
					end
				else
					print( "Bad API Func!", proto, event, SysTime() )
					print "ER3"
				end

				packet:Clear()
				packet = nil

				pClientSocket:ReceiveUntil( "\r\n\r\n" )
			end )

			pClientSocket:SetCallbackDisconnect( function( pClient )
				
			end )

			local pPacket = BromPacket()
			pPacket:WriteLine( "connect_ack" )
			pClientSocket:Send( pPacket, true )

			pClientSocket:SetTimeout( self.m_intClientTimeout )
			pClientSocket:ReceiveUntil( "\r\n\r\n" )
		end

		self.m_pSocket:Accept()
	end )

	if self.m_pSocket:Listen( "127.0.0.1", intPort ) then
		print( "ServerNet: Listening on port ".. intPort )
	else
		print( "ServerNet: Failed to listen on port ".. intPort )
	end

	self.m_pSocket:Accept()
end

function GM.ServerNet:NewEvent( strProto, strName, intType )
	if not BromPacket then return end
	self.m_pNewPacket = BromPacket( intType )
	self.m_pNewPacket:WriteStringNT( strProto )
	self.m_pNewPacket:WriteStringNT( strName )
	return self.m_pNewPacket
end

function GM.ServerNet:FireEvent( strIP, intPort )
	local outSock = BromSock( BROMSOCK_TCP )
	local packet = self.m_pNewPacket
	outSock:SetCallbackConnect( function()
		outSock:SetCallbackSend( function()
			outSock:Close()
			packet:Clear()
			packet = nil
			outSock = nil
		end )

		outSock:Send( packet )
	end )

	outSock:Connect( strIP, intPort or self.m_intPort )
	self.m_pNewPacket = nil
end

-- ----------------------------------------------------------------

-- Economy
-- ----------------------------------------------------------------
function GM.ServerNet:BroadcastTaxesChanged()
	--for _, ip in pairs( self:GetServerPool() ) do
	--	local packet = self:NewEvent( "econ", "taxes_changed" )
	--	if not packet then continue end
	--	self:FireEvent( ip )
	--end
end

GM.ServerNet:RegisterEventHandle( "econ", "taxes_changed", function( pClientSocket, packet )
	--fetch the new tax data from sql!
	--GAMEMODE.Econ:LoadSavedTaxData()
end )