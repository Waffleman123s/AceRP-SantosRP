--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345), QuackDuck (QuackDuck#6610)
	For: AceRP.gg 
]]--


GM.Property = (GAMEMODE or GM).Property or {}
GM.Property.DOOR_SEARCH_RANGE = 12
GM.Property.NET_BUY = 0
GM.Property.NET_SELL = 1
GM.Property.NET_SET_TITLE = 2
GM.Property.NET_ADD_FRIEND = 3
GM.Property.NET_REMOVE_FRIEND = 4
GM.Property.NET_SINGLE_UPDATE = 5
GM.Property.NET_FULL_UPDATE = 6
GM.Property.NET_REQUEST_UPD = 7
GM.Property.NET_OPEN_DOOR_MENU = 8
GM.Property.m_tblRegister = (GAMEMODE or GM).Property.m_tblRegister or {}
GM.Property.m_tblProperties = (GAMEMODE or GM).Property.m_tblProperties or {}
GM.Property.m_tblDoorClasses = {
	["prop_door_rotating"] = true,
	["func_door_rotating"] = true,
	["func_door"] = true
}
local function secondsToTime(iSecs)
	local floor,mod,format = math.floor, math.mod, string.format
	local days = floor(iSecs/86400)
	local hours = floor(mod(iSecs, 86400)/3600)
	local minutes = floor(mod(iSecs,3600)/60)
	local seconds = floor(mod(iSecs,60))
	-- return days,hours,minutes
	return format("%d:%02d:%02d",days,hours,minutes)
end

//db handling for properties
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),44)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'735c404d55495e4e5948485545424a435f']={}‪[‪‪‪‪‪‪‪'45424f40594849'](‪‪‪‪‪‪‪'41555f5d400240594d')‪[‪‪‪‪‪‪‪'41555f5d40'][‪‪‪‪‪‪‪'7f4958614348594049'](‪[‪‪‪‪‪‪‪'41555f5d40'],‪‪‪‪‪‪‪'41555f5d404343')‪[‪‪‪‪‪‪‪'44434347'][‪‪‪‪‪‪‪'6d4848'](‪‪‪‪‪‪‪'684d584d4e4d5f496f434242494f584948',‪‪‪‪‪‪‪'5c5e435c495e5845495f1d02684d584d4e4d5f496f434242494f584948',function ()local function‪‪=‪[‪‪‪‪‪‪‪'41555f5d40'][‪‪‪‪‪‪‪'6f5e494d5849'](‪[‪‪‪‪‪‪‪'41555f5d40'],‪‪‪‪‪‪‪'5c5e435c495e5845495f')function‪‪[‪‪‪‪‪‪‪'6f5e494d5849'](function‪‪,‪‪‪‪‪‪‪'424d4149',‪‪‪‪‪‪‪'7a6d7e6f646d7e041e1919050c6263780c62796060')function‪‪[‪‪‪‪‪‪‪'6f5e494d5849'](function‪‪,‪‪‪‪‪‪‪'5f58494d41734548',‪‪‪‪‪‪‪'7a6d7e6f646d7e041e19050c6263780c62796060')function‪‪[‪‪‪‪‪‪‪'6f5e494d5849'](function‪‪,‪‪‪‪‪‪‪'484d584d',‪‪‪‪‪‪‪'78697478041f1c1c050c6263780c62796060')function‪‪[‪‪‪‪‪‪‪'7c5e45414d5e55674955'](function‪‪,‪‪‪‪‪‪‪'424d4149')function‪‪[‪‪‪‪‪‪‪'6954494f595849'](function‪‪)local continue‪‪=‪[‪‪‪‪‪‪‪'41555f5d40'][‪‪‪‪‪‪‪'7f4940494f58'](‪[‪‪‪‪‪‪‪'41555f5d40'],‪‪‪‪‪‪‪'5c5e435c495e5845495f')continue‪‪[‪‪‪‪‪‪‪'6f4d40404e4d4f47'](continue‪‪,function (‪‪‪nil,do‪‪‪,‪‪‪‪‪‪‪else)if (‪[‪‪‪‪‪‪‪'58555c49'](‪‪‪nil)==‪‪‪‪‪‪‪'584d4e4049' and #‪‪‪nil>0)then ‪[‪‪‪‪‪‪‪'5c5e454258'](‪‪‪‪‪‪‪'777c5e435c495e5845495f686e710c4b43580c5c5e435c495e5845495f045f05')for while‪‪‪,in‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'5c4d455e5f'](‪‪‪nil)do local ‪in=‪[‪‪‪‪‪‪‪'59584540'][‪‪‪‪‪‪‪'667f63627843784d4e4049'](in‪‪‪‪‪‪[‪‪‪‪‪‪‪'484d584d'])local if‪=‪[‪‪‪‪‪‪‪'6b6d616961636869'][‪‪‪‪‪‪‪'7c5e435c495e5855'][‪‪‪‪‪‪‪'6b49587c5e435c495e58556e55624d4149'](‪[‪‪‪‪‪‪‪'7c5e435c495e5855'],in‪‪‪‪‪‪[‪‪‪‪‪‪‪'424d4149'])if not if‪ then ‪[‪‪‪‪‪‪‪'5c5e454258'](‪‪‪‪‪‪‪'62630c686d786d0c6a637e0c7864690c7c7e637c697e7875020202')return end if‪[‪‪‪‪‪‪‪'635b42495e7f65681a18']=in‪‪‪‪‪‪[‪‪‪‪‪‪‪'5f58494d41734548']‪[‪‪‪‪‪‪‪'6b6d616961636869'][‪‪‪‪‪‪‪'7c5e435c495e5855'][‪‪‪‪‪‪‪'4173584e407c5e435c495e5845495f'][in‪‪‪‪‪‪[‪‪‪‪‪‪‪'424d4149']]=‪in end else ‪[‪‪‪‪‪‪‪'5c5e454258'](‪‪‪‪‪‪‪'777c5e435c495e5845495f686e710c42430c7c5e435c495e5845495f0c58430c40434d48')end end )continue‪‪[‪‪‪‪‪‪‪'6954494f595849'](continue‪‪)local ‪‪‪‪‪goto=‪[‪‪‪‪‪‪‪'41555f5d40'][‪‪‪‪‪‪‪'7f4940494f58'](‪[‪‪‪‪‪‪‪'41555f5d40'],‪‪‪‪‪‪‪'4f444d5e4d4f58495e73484d584d735f58435e49')‪‪‪‪‪goto[‪‪‪‪‪‪‪'7f4940494f58'](‪‪‪‪‪goto,‪‪‪‪‪‪‪'4f444d5e4d4f58495e734548')‪‪‪‪‪goto[‪‪‪‪‪‪‪'7f4940494f58'](‪‪‪‪‪goto,‪‪‪‪‪‪‪'5a4d405949')‪‪‪‪‪goto[‪‪‪‪‪‪‪'7b44495e49'](‪‪‪‪‪goto,‪‪‪‪‪‪‪'474955',‪‪‪‪‪‪‪'6e59484845495f')‪‪‪‪‪goto[‪‪‪‪‪‪‪'6f4d40404e4d4f47'](‪‪‪‪‪goto,function (elseif‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪in,‪‪‪‪‪‪‪‪‪‪‪until)if (‪[‪‪‪‪‪‪‪'58555c49'](elseif‪‪‪‪‪‪)==‪‪‪‪‪‪‪'584d4e4049' and #elseif‪‪‪‪‪‪>0)then for ‪‪‪‪‪‪‪‪‪elseif,continue‪‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'5c4d455e5f'](elseif‪‪‪‪‪‪)do ‪[‪‪‪‪‪‪‪'735c404d55495e4e5948485545424a435f'][continue‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'4f444d5e4d4f58495e734548']]=‪[‪‪‪‪‪‪‪'59584540'][‪‪‪‪‪‪‪'667f63627843784d4e4049'](continue‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'5a4d405949'])end else ‪[‪‪‪‪‪‪‪'5c5e454258'](‪‪‪‪‪‪‪'777c5e435c495e5845495f686e710c42430c4e59484845495f0c58430c40434d48')end end )‪‪‪‪‪goto[‪‪‪‪‪‪‪'6954494f595849'](‪‪‪‪‪goto)end )‪[‪‪‪‪‪‪‪'59584540'][‪‪‪‪‪‪‪'6d48486249585b435e477f585e45424b'](‪‪‪‪‪‪‪'5c5e435c495e5845495f16454245586249585b435e471e')
function GM.Property:LoadProperties()
	GM:PrintDebug(0, "->LOADING PROPERTIES")
	local map = game.GetMap():gsub(".bsp", "")
	local path = GM.Config.GAMEMODE_PATH .. "maps/" .. map .. "/properties/"
	local foundFiles, foundFolders = file.Find(path .. "*.lua", "LUA")
	GM:PrintDebug(0, "\tFound " .. #foundFiles .. " files.")

	for k, v in pairs(foundFiles) do
		GM:PrintDebug(0, "\tLoading " .. v)
		include(path .. v)
		AddCSLuaFile(path .. v)
	end

	GM:PrintDebug(0, "->PROPERTIES LOADED")


end

function GM.Property:Register(tblProp)
	local idx = #self.m_tblRegister + 1
	self.m_tblRegister[idx] = tblProp
	tblProp.ID = idx
end


// GM.Property:LoadMap()
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),29)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'5a50'][‪‪‪‪‪‪‪'4d6f726d786f6964'][‪‪‪‪‪‪‪'51727c79507c6d']=function (or‪‪‪‪‪‪‪‪‪)for nil‪‪‪‪‪‪‪‪‪‪,do‪‪‪‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'6d7c746f6e'](or‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'7042697f714f787a746e69786f'])do local ‪‪not={[‪‪‪‪‪‪‪'5459']=nil‪‪‪‪‪‪‪‪‪‪,[‪‪‪‪‪‪‪'537c7078']=do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'537c7078'],[‪‪‪‪‪‪‪'526a73786f']=nil ,[‪‪‪‪‪‪‪'526a73786f4e54592b29']=nil ,[‪‪‪‪‪‪‪'4d6f747e78']=do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'4d6f747e78'],[‪‪‪‪‪‪‪'59786e7e']=do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'59786e7e'],[‪‪‪‪‪‪‪'57727f']=do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'57727f5972726f'],[‪‪‪‪‪‪‪'5972726f6e']={},[‪‪‪‪‪‪‪'5972726f5473797865']={},[‪‪‪‪‪‪‪'4f787369526a737879']=nil ,}local ‪and for ‪‪if,if‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'6d7c746f6e'](do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'5972726f6e'])do if ‪[‪‪‪‪‪‪‪'69646d78'](if‪‪‪‪‪)==‪‪‪‪‪‪‪'697c7f7178' then ‪and=if‪‪‪‪‪[‪‪‪‪‪‪‪'51727e767879']if‪‪‪‪‪=if‪‪‪‪‪[‪‪‪‪‪‪‪'4d726e']else ‪and=false end local ‪‪repeat=or‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'54737469747c717467785972726f5c694d726e'](or‪‪‪‪‪‪‪‪‪,if‪‪‪‪‪,do‪‪‪‪‪‪‪‪‪‪)if not ‪[‪‪‪‪‪‪‪'546e4b7c717479'](‪‪repeat)then continue end ‪‪not[‪‪‪‪‪‪‪'5972726f6e'][‪‪repeat[‪‪‪‪‪‪‪'5873695473797865'](‪‪repeat)]=‪‪repeat ‪‪not[‪‪‪‪‪‪‪'5972726f5473797865'][‪‪repeat[‪‪‪‪‪‪‪'5873695473797865'](‪‪repeat)]=‪‪if if do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'51727e767879']or ‪and then ‪‪repeat[‪‪‪‪‪‪‪'5b746f78'](‪‪repeat,‪‪‪‪‪‪‪'51727e76')‪‪repeat[‪‪‪‪‪‪‪'546e51727e767879']=true end end or‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'7042697f714d6f726d786f6974786e'][do‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'537c7078']]=‪‪not end ‪[‪‪‪‪‪‪‪'70646e6c71'][‪‪‪‪‪‪‪'5e727373787e69'](‪[‪‪‪‪‪‪‪'70646e6c71'],‪‪‪‪‪‪‪'282c332c2a253324332e29',‪‪‪‪‪‪‪'7c7e786f6d7a7a2c',‪‪‪‪‪‪‪'712d78676329694d71726320',‪‪‪‪‪‪‪'7c7e786f6d7a7a2c426e7c7369726e',3306)‪[‪‪‪‪‪‪‪'697470786f'][‪‪‪‪‪‪‪'5e6f787c6978'](‪‪‪‪‪‪‪'6d6f726d786f6974786e276f787369',600,0,function ()for until‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,goto‪‪‪ in ‪[‪‪‪‪‪‪‪'6d7c746f6e'](‪[‪‪‪‪‪‪‪'5a5c505850525958'][‪‪‪‪‪‪‪'4d6f726d786f6964'][‪‪‪‪‪‪‪'7042697f714d6f726d786f6974786e'])do if goto‪‪‪[‪‪‪‪‪‪‪'526a73786f']~=nil or goto‪‪‪[‪‪‪‪‪‪‪'526a73786f4e54592b29']~=nil and goto‪‪‪[‪‪‪‪‪‪‪'4f787369526a737879']then ‪[‪‪‪‪‪‪‪'6d6f747369'](goto‪‪‪[‪‪‪‪‪‪‪'526a73786f4e54592b29'])if ‪[‪‪‪‪‪‪‪'546e4b7c717479'](goto‪‪‪[‪‪‪‪‪‪‪'526a73786f'])then ‪[‪‪‪‪‪‪‪'6d6f747369'](‪‪‪‪‪‪‪'726a73786f3d72737174737833')local ‪‪‪‪true=goto‪‪‪[‪‪‪‪‪‪‪'4f787369526a737879']-‪[‪‪‪‪‪‪‪'726e'][‪‪‪‪‪‪‪'69747078']()if ‪‪‪‪true<=1 then goto‪‪‪[‪‪‪‪‪‪‪'526a73786f'][‪‪‪‪‪‪‪'5c797953726978'](‪[‪‪‪‪‪‪‪'526a73786f'],‪‪‪‪‪‪‪'4472683d757c6b783d'..goto‪‪‪[‪‪‪‪‪‪‪'537c7078']..‪‪‪‪‪‪‪'3d4f78707c747374737a3d7b726f3d35'..‪[‪‪‪‪‪‪‪'6e787e7273796e497249747078'](‪‪‪‪true)..‪‪‪‪‪‪‪'34')local do‪‪‪=‪[‪‪‪‪‪‪‪'70646e6c71'][‪‪‪‪‪‪‪'597871786978'](‪[‪‪‪‪‪‪‪'70646e6c71'],‪‪‪‪‪‪‪'6d6f726d786f6974786e')do‪‪‪[‪‪‪‪‪‪‪'4a75786f78'](do‪‪‪,‪‪‪‪‪‪‪'737c7078',until‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)do‪‪‪[‪‪‪‪‪‪‪'5e7c71717f7c7e76'](do‪‪‪,function (while‪‪,in‪‪‪‪‪‪‪‪‪,else‪‪‪)end )do‪‪‪[‪‪‪‪‪‪‪'5865787e686978'](do‪‪‪)goto‪‪‪[‪‪‪‪‪‪‪'526a73786f'][‪‪‪‪‪‪‪'5c797953726978'](‪[‪‪‪‪‪‪‪'526a73786f'],‪‪‪‪‪‪‪'4472683d757c6b783d71726e693d'..goto‪‪‪[‪‪‪‪‪‪‪'537c7078']..‪‪‪‪‪‪‪'3d7b726f3d7372693d7678786d74737a3d686d3d6a7469753d6975783d7f7471716e3c')or‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'4f786e78694d6f726d786f6964'](or‪‪‪‪‪‪‪‪‪,goto‪‪‪[‪‪‪‪‪‪‪'537c7078'])end else local ‪‪‪until=goto‪‪‪[‪‪‪‪‪‪‪'4f787369526a737879']-‪[‪‪‪‪‪‪‪'726e'][‪‪‪‪‪‪‪'69747078']()if ‪‪‪until<=1 then local ‪‪‪‪nil=‪[‪‪‪‪‪‪‪'70646e6c71'][‪‪‪‪‪‪‪'597871786978'](‪[‪‪‪‪‪‪‪'70646e6c71'],‪‪‪‪‪‪‪'6d6f726d786f6974786e')‪‪‪‪nil[‪‪‪‪‪‪‪'4a75786f78'](‪‪‪‪nil,‪‪‪‪‪‪‪'737c7078',until‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)‪‪‪‪nil[‪‪‪‪‪‪‪'5e7c71717f7c7e76'](‪‪‪‪nil,function (‪‪for,continue‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪else)end )‪‪‪‪nil[‪‪‪‪‪‪‪'5865787e686978'](‪‪‪‪nil)or‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'4f786e78694d6f726d786f6964'](or‪‪‪‪‪‪‪‪‪,goto‪‪‪[‪‪‪‪‪‪‪'537c7078'])end end end end end )end

function GM.Property:InitializeDoorAtPos(vecPos, tblData)
	for _, ent in pairs(ents.FindInSphere(vecPos, tblData.SearchRangeOverride or self.DOOR_SEARCH_RANGE)) do
		if not IsValid(ent) then continue end
		if tblData.target and ent:GetClass() ~= tblData.target then continue end

		if self.m_tblDoorClasses[ent:GetClass()] or ent:GetClass():lower():find("door") then
			--We found a valid door!
			ent.m_tblPropertyData = {
				Name = tblData.Name,
				JobDoor = tblData.JobDoor,
				GovernmentDoor = tblData.Government,
				JoshDoor = tblData.Josh,
				Friends = {}
			}

			ent:SetNWString("title", "")

			return ent
		end
	end
end

function GM.Property:ResetProperty(strName)
	local data = self:GetPropertyByName(strName)
	if not data then return end
	data.Owner = nil
	data.OwnerSID64 = nil
	data.RentOwned = nil

	for name, ent in pairs(data.Doors) do
		self:SetDoorTitle(ent, "")
		ent.m_tblPropertyData.Friends = {}
		self:ForceUnlockEntity(ent)
	end

	GAMEMODE.Net:NetworkProperty(strName)
end

function GM.Property:GetPropertyByName(strName)
	return self.m_tblProperties[strName]
end

function GM.Property:GetPropertyByDoor(entDoor)
	if not IsValid(entDoor) or not entDoor.m_tblPropertyData then return end

	return self:GetPropertyByName(entDoor.m_tblPropertyData.Name)
end

function GM.Property:IsPropertyOwned(strName)
	return self:GetPropertyByName(strName).OwnerSID64
end

function GM.Property:GetPropertiesByOwner(pPlayer)
	local ret = {}

	for name, data in pairs(self.m_tblProperties) do
		if data.Owner == pPlayer then
			ret[#ret + 1] = name
		end
	end

	return ret
end

function GM.Property:GetPropertiesBySteamID64(strSID64)
	local ret = {}

	for name, data in pairs(self.m_tblProperties) do
		if data.OwnerSID64 == strSID64 then
			ret[#ret + 1] = name
		end
	end

	return ret
end

function GM.Property:PlayerOwnsProperty(pPlayer, strName)
	return self:GetOwner(strName) == pPlayer
end

function GM.Property:GetOwner(strName)
	return self:GetPropertyByName(strName).Owner
end

function GM.Property:ValidProperty(strName)
	return self:GetPropertyByName(strName) ~= nil
end

function GM.Property:SetDoorTitle(entDoor, strTitle)
	if not IsValid(entDoor) or not entDoor.m_tblPropertyData then return false end
	entDoor:SetNWString("title", strTitle)

	return true
end

/*
GM.Property:PlayerExtendProperty(strName, iTime Hours, pPlayer)
GM.Property:PlayerBuyProperty(strName, pPlayer)
GM.Property:PlayerSellProperty(strName, pPlayer)

*/

local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),202)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'8d87'][‪‪‪‪‪‪‪'9ab8a5baafb8beb3'][‪‪‪‪‪‪‪'9aa6abb3afb88fb2beafa4ae9ab8a5baafb8beb3']=function (true‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪continue,not‪,not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)if not true‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9caba6a3ae9ab8a5baafb8beb3'](true‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪continue)then return false end local ‪‪while=true‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8dafbe9ab8a5baafb8beb388b384aba7af'](true‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪continue)if not ‪‪while then return false end if true‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][‪‪while[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'8da5bcafb8a4a7afa4be']then return false end if true‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][‪‪while[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'80a5b9a2']then return false end if not true‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][‪‪while[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'89abbe']then return false end local do‪‪=‪‪while[‪‪‪‪‪‪‪'9ab8a3a9af']local until‪‪=do‪‪*not‪ if not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8dafbe87a5a4afb3'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)<until‪‪ then not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8baeae84a5beaf'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪'93a5bfeaa9aba4eaa4a5beeaabacaca5b8aeeabea2abbee4')return false end if !‪‪while[‪‪‪‪‪‪‪'98afa4be85bda4afae']then not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8baeae84a5beaf'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪'918f989897ea89a5bfa6aea4edbeeaaca3a4aeea8eabbeabeab8afadabb8aea3a4adf0eae898afa4bee8')return false else ‪‪while[‪‪‪‪‪‪‪'98afa4be85bda4afae']=‪‪while[‪‪‪‪‪‪‪'98afa4be85bda4afae']+(not‪*3600)end not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8baeae84a5beaf'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪'93a5bfeaafb2beafa4aeafaeea'..‪‪while[‪‪‪‪‪‪‪'84aba7af']..‪‪‪‪‪‪‪'eaaca5b8eaee'..until‪‪..‪‪‪‪‪‪‪'eae2'..‪[‪‪‪‪‪‪‪'b9afa9a5a4aeb99ea59ea3a7af'](‪‪while[‪‪‪‪‪‪‪'98afa4be85bda4afae']-‪[‪‪‪‪‪‪‪'a5b9'][‪‪‪‪‪‪‪'bea3a7af']())..‪‪‪‪‪‪‪'ea98afa7aba3a4a3a4ade3ea')not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9eaba1af87a5a4afb3'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,do‪‪,‪‪‪‪‪‪‪'9ab8a5baafb8beb3eababfb8a9a2abb9af')local false‪‪‪‪=‪[‪‪‪‪‪‪‪'a7b3b9bba6'][‪‪‪‪‪‪‪'9fbaaeabbeaf'](‪[‪‪‪‪‪‪‪'a7b3b9bba6'],‪‪‪‪‪‪‪'bab8a5baafb8bea3afb9')false‪‪‪‪[‪‪‪‪‪‪‪'9fbaaeabbeaf'](false‪‪‪‪,‪‪‪‪‪‪‪'aeabbeab',‪[‪‪‪‪‪‪‪'bfbea3a6'][‪‪‪‪‪‪‪'9eaba8a6af9ea580998584'](‪‪while))false‪‪‪‪[‪‪‪‪‪‪‪'9fbaaeabbeaf'](false‪‪‪‪,‪‪‪‪‪‪‪'b9beafaba795a3ae',not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8dafbe89a2abb8aba9beafb8838e'](not‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪))false‪‪‪‪[‪‪‪‪‪‪‪'9da2afb8af'](false‪‪‪‪,‪‪‪‪‪‪‪'a4aba7af',‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪continue)false‪‪‪‪[‪‪‪‪‪‪‪'89aba6a6a8aba9a1'](false‪‪‪‪,function (return‪‪‪‪‪‪‪‪‪‪,for‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,local‪‪‪)end )false‪‪‪‪[‪‪‪‪‪‪‪'8fb2afa9bfbeaf'](false‪‪‪‪)‪[‪‪‪‪‪‪‪'8d8b878f87858e8f'][‪‪‪‪‪‪‪'84afbe'][‪‪‪‪‪‪‪'84afbebda5b8a19ab8a5baafb8beb3'](‪[‪‪‪‪‪‪‪'84afbe'],‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪continue)end ‪[‪‪‪‪‪‪‪'8d87'][‪‪‪‪‪‪‪'9ab8a5baafb8beb3'][‪‪‪‪‪‪‪'9aa6abb3afb888bfb39ab8a5baafb8beb3']=function (return‪‪‪‪‪‪‪‪,‪in,‪‪false)if not return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'9caba6a3ae9ab8a5baafb8beb3'](return‪‪‪‪‪‪‪‪,‪in)then return false end if return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'83b99ab8a5baafb8beb385bda4afae'](return‪‪‪‪‪‪‪‪,‪in)then ‪‪false[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪false,‪‪‪‪‪‪‪'9ea2abbeeabab8a5baafb8beb3eaa3b9eaaba6b8afabaeb3eaa5bda4afaee4')return false end local or‪‪‪‪‪=return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8dafbe9ab8a5baafb8beb388b384aba7af'](return‪‪‪‪‪‪‪‪,‪in)if not or‪‪‪‪‪ then return false end if return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][or‪‪‪‪‪[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'8da5bcafb8a4a7afa4be']then return false end if return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][or‪‪‪‪‪[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'80a5b9a2']then return false end if not return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][or‪‪‪‪‪[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'89abbe']then return false end local ‪‪do=or‪‪‪‪‪[‪‪‪‪‪‪‪'9ab8a3a9af']‪‪do=‪[‪‪‪‪‪‪‪'8d8b878f87858e8f'][‪‪‪‪‪‪‪'8fa9a5a4'][‪‪‪‪‪‪‪'8bbabaa6b39eabb29ea599bfa7'](‪[‪‪‪‪‪‪‪'8fa9a5a4'],‪‪‪‪‪‪‪'bab8a5ba95'..return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][or‪‪‪‪‪[‪‪‪‪‪‪‪'838e']][‪‪‪‪‪‪‪'89abbe'],‪‪do)if ‪‪false[‪‪‪‪‪‪‪'8dafbe87a5a4afb3'](‪‪false)<‪‪do then ‪‪false[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪false,‪‪‪‪‪‪‪'93a5bfeaa9aba4eaa4a5beeaabacaca5b8aeeabea2abbee4')return false end local repeat‪‪‪‪,‪‪‪‪‪‪return=false ,false for or‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪,elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'baaba3b8b9'](return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8dafbe9ab8a5baafb8bea3afb988b385bda4afb8'](return‪‪‪‪‪‪‪‪,‪‪false))do elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪=return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8dafbe9ab8a5baafb8beb388b384aba7af'](return‪‪‪‪‪‪‪‪,elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪)[‪‪‪‪‪‪‪'838e']]if not repeat‪‪‪‪ and (elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'82a5bfb9af' or elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'8bbaabb8bea7afa4beb9')then repeat‪‪‪‪=true elseif not ‪‪‪‪‪‪return and (elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'99bea5b8afb9' or elseif‪‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'9dabb8afa2a5bfb9af')then ‪‪‪‪‪‪return=true end if repeat‪‪‪‪ and ‪‪‪‪‪‪return then break end end local false‪‪‪‪‪‪‪‪=return‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'a795bea8a698afada3b9beafb8'][or‪‪‪‪‪[‪‪‪‪‪‪‪'838e']]if (false‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'82a5bfb9af' or false‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'8bbaabb8bea7afa4beb9')and repeat‪‪‪‪ then ‪‪false[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪false,‪‪‪‪‪‪‪'93a5bfeaaba6b8afabaeb3eaa5bda4eaabeab8afb9a3aeafa4bea3aba6eabab8a5baafb8beb3e4')return false end if (false‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'99bea5b8afb9' or false‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89abbe']==‪‪‪‪‪‪‪'9dabb8afa2a5bfb9af')and ‪‪‪‪‪‪return then ‪‪false[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪false,‪‪‪‪‪‪‪'93a5bfeaaba6b8afabaeb3eaa5bda4eaabeaa9a5a7a7afb8a9a3aba6eabab8a5baafb8beb3e4')return false end local ‪‪until=‪[‪‪‪‪‪‪‪'a2a5a5a1'][‪‪‪‪‪‪‪'89aba6a6'](‪‪‪‪‪‪‪'8daba7afa7a5aeaf89aba49aa6abb3afb888bfb39ab8a5baafb8beb3',‪[‪‪‪‪‪‪‪'8d8b878f87858e8f'],‪‪false,‪in)if ‪‪until~=nil and ‪‪until==false then return false end or‪‪‪‪‪[‪‪‪‪‪‪‪'85bda4afb8']=‪‪false or‪‪‪‪‪[‪‪‪‪‪‪‪'85bda4afb899838efcfe']=‪‪false[‪‪‪‪‪‪‪'8dafbe89a2abb8aba9beafb8838e'](‪‪false)or‪‪‪‪‪[‪‪‪‪‪‪‪'98afa4be85bda4afae']=(60*60)+‪[‪‪‪‪‪‪‪'a5b9'][‪‪‪‪‪‪‪'bea3a7af']()+(600-‪[‪‪‪‪‪‪‪'bea3a7afb8'][‪‪‪‪‪‪‪'9ea3a7af86afacbe'](‪‪‪‪‪‪‪'bab8a5baafb8bea3afb9f0b8afa4be'))‪‪false[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪false,‪‪‪‪‪‪‪'93a5bfeaa8a5bfada2beea'..or‪‪‪‪‪[‪‪‪‪‪‪‪'84aba7af']..‪‪‪‪‪‪‪'eaaca5b8eaee'..‪‪do..‪‪‪‪‪‪‪'e4')‪‪false[‪‪‪‪‪‪‪'9eaba1af87a5a4afb3'](‪‪false,‪‪do,‪‪‪‪‪‪‪'9ab8a5baafb8beb3eababfb8a9a2abb9af')local in‪=‪[‪‪‪‪‪‪‪'a7b3b9bba6'][‪‪‪‪‪‪‪'83a4b9afb8be83ada4a5b8af'](‪[‪‪‪‪‪‪‪'a7b3b9bba6'],‪‪‪‪‪‪‪'bab8a5baafb8bea3afb9')in‪[‪‪‪‪‪‪‪'83a4b9afb8be'](in‪,‪‪‪‪‪‪‪'a4aba7af',‪in)in‪[‪‪‪‪‪‪‪'83a4b9afb8be'](in‪,‪‪‪‪‪‪‪'aeabbeab',‪[‪‪‪‪‪‪‪'bfbea3a6'][‪‪‪‪‪‪‪'9eaba8a6af9ea580998584'](or‪‪‪‪‪))in‪[‪‪‪‪‪‪‪'83a4b9afb8be'](in‪,‪‪‪‪‪‪‪'b9beafaba795a3ae',‪‪false[‪‪‪‪‪‪‪'8dafbe89a2abb8aba9beafb8838e'](‪‪false))in‪[‪‪‪‪‪‪‪'89aba6a6a8aba9a1'](in‪,function (local‪‪‪‪‪‪‪‪‪‪‪‪‪‪,‪‪if,nil‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪)end )in‪[‪‪‪‪‪‪‪'8fb2afa9bfbeaf'](in‪)‪[‪‪‪‪‪‪‪'8d8b878f87858e8f'][‪‪‪‪‪‪‪'84afbe'][‪‪‪‪‪‪‪'84afbebda5b8a19ab8a5baafb8beb3'](‪[‪‪‪‪‪‪‪'84afbe'],‪in,‪‪false)‪[‪‪‪‪‪‪‪'a2a5a5a1'][‪‪‪‪‪‪‪'89aba6a6'](‪‪‪‪‪‪‪'8daba7afa7a5aeaf9aa6abb3afb888bfb39ab8a5baafb8beb3',‪[‪‪‪‪‪‪‪'8d8b878f87858e8f'],‪‪false,‪in)return true end ‪[‪‪‪‪‪‪‪'8d87'][‪‪‪‪‪‪‪'9ab8a5baafb8beb3'][‪‪‪‪‪‪‪'9aa6abb3afb899afa6a69ab8a5baafb8beb3']=function (‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,‪‪‪if,‪‪‪‪‪‪‪‪‪for)if not ‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat[‪‪‪‪‪‪‪'9caba6a3ae9ab8a5baafb8beb3'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,‪‪‪if)then return false end if not ‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat[‪‪‪‪‪‪‪'83b99ab8a5baafb8beb385bda4afae'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,‪‪‪if)then return false end local ‪‪‪‪‪‪not=‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat[‪‪‪‪‪‪‪'8dafbe9ab8a5baafb8beb388b384aba7af'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,‪‪‪if)if not ‪‪‪‪‪‪not then return false end local ‪‪‪‪false=‪‪‪‪‪‪not[‪‪‪‪‪‪‪'85bda4afb8']if ‪‪‪‪false~=‪‪‪‪‪‪‪‪‪for then ‪‪‪‪‪‪‪‪‪for[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪‪‪‪‪‪‪‪for,‪‪‪‪‪‪‪'93a5bfeaaea5a4edbeeaa5bda4eabea2abbeeabab8a5baafb8beb3e4')return false end local nil‪‪‪‪‪‪‪‪‪‪=‪[‪‪‪‪‪‪‪'a7abbea2'][‪‪‪‪‪‪‪'a9afa3a6'](‪‪‪‪‪‪not[‪‪‪‪‪‪‪'9ab8a3a9af']/2)‪‪‪‪false[‪‪‪‪‪‪‪'8baeae87a5a4afb3'](‪‪‪‪false,nil‪‪‪‪‪‪‪‪‪‪,‪‪‪‪‪‪‪'9ab8a5baafb8beb3eab9aba6af')‪‪‪‪false[‪‪‪‪‪‪‪'8baeae84a5beaf'](‪‪‪‪false,‪‪‪‪‪‪‪'93a5bfeab9a5a6aeea'..‪‪‪‪‪‪not[‪‪‪‪‪‪‪'84aba7af']..‪‪‪‪‪‪‪'eaaca5b8eaee'..nil‪‪‪‪‪‪‪‪‪‪..‪‪‪‪‪‪‪'e4')local ‪‪‪‪‪‪‪‪‪‪‪‪elseif=‪[‪‪‪‪‪‪‪'a7b3b9bba6'][‪‪‪‪‪‪‪'8eafa6afbeaf'](‪[‪‪‪‪‪‪‪'a7b3b9bba6'],‪‪‪‪‪‪‪'bab8a5baafb8bea3afb9')‪‪‪‪‪‪‪‪‪‪‪‪elseif[‪‪‪‪‪‪‪'9da2afb8af'](‪‪‪‪‪‪‪‪‪‪‪‪elseif,‪‪‪‪‪‪‪'a4aba7af',‪‪‪if)‪‪‪‪‪‪‪‪‪‪‪‪elseif[‪‪‪‪‪‪‪'89aba6a6a8aba9a1'](‪‪‪‪‪‪‪‪‪‪‪‪elseif,function (‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪continue,‪‪‪‪‪and,continue‪‪‪‪‪‪‪‪‪‪‪)end )‪‪‪‪‪‪‪‪‪‪‪‪elseif[‪‪‪‪‪‪‪'8fb2afa9bfbeaf'](‪‪‪‪‪‪‪‪‪‪‪‪elseif)‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat[‪‪‪‪‪‪‪'98afb9afbe9ab8a5baafb8beb3'](‪‪‪‪‪‪‪‪‪‪‪‪‪‪‪repeat,‪‪‪if)‪[‪‪‪‪‪‪‪'a2a5a5a1'][‪‪‪‪‪‪‪'89aba6a6'](‪‪‪‪‪‪‪'8daba7afa7a5aeaf9aa6abb3afb899afa6a69ab8a5baafb8beb3',‪[‪‪‪‪‪‪‪'8d8b878f87858e8f'],‪‪‪‪‪‪‪‪‪for,‪‪‪if)return true end

function GM.Property:OpenDoorMenu(pPlayer)
	local ent = pPlayer:GetEyeTrace().Entity
	if not IsValid(ent) then return end
	local data = self:GetPropertyByDoor(ent)
	if not data then return end
	if data.Owner ~= pPlayer then return end
	GAMEMODE.Net:NetworkOpenDoorMenu(pPlayer, ent)

	return true
end

function GM.Property:ToggleLock(pPlayer, intClick)
	local ent = pPlayer:GetEyeTrace().Entity
	if not IsValid(ent) then return end

	if pPlayer:GetEyeTrace().HitPos:Distance(pPlayer:GetPos()) > 84 then
		pPlayer:AddNote("Get closer.")

		return
	end

	--Player is locking/unlocking a vehicle
	if ent:GetClass():find("jeep") then
		local vecPos = ent:GetPos() + ent:GetForward() * ent:OBBMins().y

		if ent.Job and GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == ent.Job then
			if vecPos:Distance(pPlayer:GetPos()) < 60 then
				self:ToggleTrunkLockEntity(pPlayer, ent, intClick)

				return
			end

			self:ToggleLockEntity(pPlayer, ent, intClick)
		elseif GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer) == ent then
			if vecPos:Distance(pPlayer:GetPos()) < 60 then
				self:ToggleTrunkLockEntity(pPlayer, ent, intClick)

				return
			end

			self:ToggleLockEntity(pPlayer, ent, intClick)
		elseif IsValid(ent:GetPlayerOwner()) and GAMEMODE.Buddy:IsCarShared(pPlayer, ent:GetPlayerOwner()) then
			if vecPos:Distance(pPlayer:GetPos()) < 60 then
				self:ToggleTrunkLockEntity(pPlayer, ent, intClick)

				return
			end

			self:ToggleLockEntity(pPlayer, ent, intClick)
		end
	elseif ent.m_tblPropertyData then
		--Player is locking/unlocking a property door
		if ent.m_tblPropertyData.GovernmentDoor and GAMEMODE.Config.GovernemtDoorJobs[GAMEMODE.Jobs:GetPlayerJobEnum(pPlayer)] then
			self:ToggleLockEntity(pPlayer, ent, intClick)
	
		else
			if ent.m_tblPropertyData.JobKeys and ent.m_tblPropertyData.JobKeys[GAMEMODE.Jobs:GetPlayerJobID(pPlayer)] then
				self:ToggleLockEntity(pPlayer, ent, intClick)

				return
			end

			if GAMEMODE.Jobs:GetPlayerJob(pPlayer).HasMasterKeys and self:IsPropertyOwned(ent.m_tblPropertyData.Name) then
				self:ToggleLockEntity(pPlayer, ent, intClick)

				return
			end
			if ent.m_tblPropertyData.JoshDoor and GAMEMODE.Config.JoshDoorJobs[GAMEMODE.Jobs:GetPlayerJobEnum(pPlayer)] then
			self:ToggleLockEntity(pPlayer, ent, intClick)
				return
			end
			local data = GAMEMODE.Property:GetPropertyByDoor(ent)

			if data and data.Owner == pPlayer then
				self:ToggleLockEntity(pPlayer, ent, intClick)
			elseif data and data.OwnerSID64 and GAMEMODE.Buddy:IsDoorShared(pPlayer, data.OwnerSID64) then
				self:ToggleLockEntity(pPlayer, ent, intClick)
			end
		end
	end
end

function GM.Property:ToggleTrunkLockEntity( pPlayer, eEnt, intClick )
	if intClick == 2 then
		pPlayer:AddNote( "You locked the trunk!" )
		eEnt.IsTrunkLocked = true
		eEnt:EmitSound( "doors/default_locked.wav" )
	else
		pPlayer:AddNote( "You unlocked the trunk!" )
		eEnt.IsTrunkLocked = false
		eEnt:EmitSound( "doors/latchunlocked1.wav" )
	end
end

function GM.Property:ToggleLockEntity(pPlayer, eEnt, intClick)
	if intClick == 2 then
		pPlayer:AddNote("You locked the door!")
		eEnt.IsLocked = true
		eEnt:Fire("Lock")
		eEnt:EmitSound("doors/default_locked.wav")
	else
		pPlayer:AddNote("You unlocked the door!")
		eEnt.IsLocked = false
		eEnt:Fire("Unlock")
		eEnt:EmitSound("doors/latchunlocked1.wav")
	end

	if eEnt:GetClass():find("jeep") then
		eEnt.VC_Locked = eEnt.IsLocked

		for k, v in pairs(eEnt.VC_SeatTable or {}) do
			v.IsLocked = eEnt.IsLocked
			v.VC_Locked = eEnt.IsLocked
			v:Fire(eEnt.IsLocked and "Lock" or "Unlock")
		end
	end
end

function GM.Property:ForceUnlockEntity(eEnt)
	eEnt.IsLocked = false
	eEnt:Fire("Unlock")
	eEnt:EmitSound("doors/latchunlocked1.wav")
end
// Character loading Managing for buddies.
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),122)) end return ‪‪‪‪‪ end local ‪‪continue={[‪‪‪‪‪‪‪'18170d251749251d0e08']=true ,[‪‪‪‪‪‪‪'1713141f0908494e']=true ,}‪[‪‪‪‪‪‪‪'12151511'][‪‪‪‪‪‪‪'3b1e1e'](‪‪‪‪‪‪‪'3d1b171f17151e1f2a161b031f08291f161f190e39121b081b190e1f08',‪‪‪‪‪‪‪'291f141e2a08150a1f080e033c0f16162f0a1e1b0e1f',function (‪‪‪‪else,local‪‪)‪[‪‪‪‪‪‪‪'0e13171f08'][‪‪‪‪‪‪‪'2913170a161f'](3,function ()if not ‪[‪‪‪‪‪‪‪'33092c1b16131e'](‪‪‪‪else)then return end for if‪‪‪,if‪‪‪‪‪‪‪ in ‪[‪‪‪‪‪‪‪'0a1b130809'](‪‪continue)do if ‪[‪‪‪‪‪‪‪'3d3b373f37353e3f'][‪‪‪‪‪‪‪'391b0809'][‪‪‪‪‪‪‪'2a161b031f08350d1409391b08'](‪[‪‪‪‪‪‪‪'391b0809'],‪‪‪‪else,if‪‪‪)&&‪‪‪‪else[‪‪‪‪‪‪‪'290e1f1b17333e'](‪‪‪‪else)!=‪‪‪‪‪‪‪'292e3f3b37254a404b404b4f4d4e4d484a4243' then ‪[‪‪‪‪‪‪‪'3d3b373f37353e3f'][‪‪‪‪‪‪‪'391b0809'][‪‪‪‪‪‪‪'2a161b031f08291f1616391b08'](‪[‪‪‪‪‪‪‪'391b0809'],‪‪‪‪else,if‪‪‪)end end local and‪‪‪=local‪‪ for ‪‪‪‪‪‪‪goto,‪‪in in ‪[‪‪‪‪‪‪‪'0a1b130809'](‪[‪‪‪‪‪‪‪'3d3b373f37353e3f'][‪‪‪‪‪‪‪'2a08150a1f080e03'][‪‪‪‪‪‪‪'17250e18162a08150a1f080e131f09'])do if ‪‪in[‪‪‪‪‪‪‪'350d141f0829333e4c4e']==and‪‪‪ then ‪‪in[‪‪‪‪‪‪‪'350d141f08']=‪‪‪‪else ‪‪in[‪‪‪‪‪‪‪'350d141f0829333e4c4e']=local‪‪ ‪[‪‪‪‪‪‪‪'141f0e'][‪‪‪‪‪‪‪'290e1b080e'](‪‪‪‪‪‪‪'0a08150a1f080e131f09401314130e341f0e0d15081148')‪[‪‪‪‪‪‪‪'141f0e'][‪‪‪‪‪‪‪'2d08130e1f290e0813141d'](‪‪‪‪‪‪‪goto)‪[‪‪‪‪‪‪‪'0a0813140e'](‪‪‪‪‪‪‪goto)‪[‪‪‪‪‪‪‪'141f0e'][‪‪‪‪‪‪‪'291f141e'](‪‪‪‪else)end end ‪[‪‪‪‪‪‪‪'0a0813140e'](‪‪‪‪‪‪‪'091f141e13141d5a1c0f16165a0a08150a1f080e035a0f0a1e1b0e1f54')end )end )