--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--

GM.Util = {}
GM.Util.m_vecWorldMins = Vector(1, 1, 1) * -99999
GM.Util.m_vecWorldMaxs = Vector(1, 1, 1) * 16384

GM.Util.m_tblIgnoreSpawnEnts = {
	["keyframe_rope"] = true,
	["physgun_beam"] = true,
	["phys_spring"] = true,
	["ent_map_trigger"] = true,
	["predicted_viewmodel"] = true
}

GM.Util.m_tblDoorClasses = {
	["prop_door_rotating"] = true,
	["func_door_rotating"] = true,
	["func_door"] = true
}

GM.Util.m_tblPlayerSounds = {
	Male = {
		Death = {Sound("vo/npc/male01/startle01.wav"), Sound("vo/npc/male01/startle02.wav")},
		Pain = {Sound("vo/npc/male01/imhurt01.wav"), Sound("vo/npc/male01/imhurt02.wav"), Sound("vo/npc/male01/pain01.wav"), Sound("vo/npc/male01/pain02.wav"), Sound("vo/npc/male01/pain03.wav"), Sound("vo/npc/male01/pain04.wav"), Sound("vo/npc/male01/pain05.wav"), Sound("vo/npc/male01/pain06.wav"), Sound("vo/npc/male01/pain07.wav"), Sound("vo/npc/male01/pain08.wav"), Sound("vo/npc/male01/pain09.wav")},
		Fall = {Sound("vo/npc/male01/no02.wav"), Sound("vo/npc/male01/no01.wav"), Sound("vo/npc/male01/help01.wav"), Sound("vo/npc/male01/watchout.wav"), Sound("vo/npc/male01/uhoh.wav")},
		Hello = {Sound("vo/npc/male01/hi01.wav"), Sound("vo/npc/male01/hi02.wav")}
	},
	Female = {
		Death = {Sound("vo/npc/female01/startle01.wav"), Sound("vo/npc/female01/startle02.wav")},
		Pain = {Sound("vo/npc/female01/imhurt01.wav"), Sound("vo/npc/female01/imhurt02.wav"), Sound("vo/npc/female01/pain01.wav"), Sound("vo/npc/female01/pain02.wav"), Sound("vo/npc/female01/pain03.wav"), Sound("vo/npc/female01/pain04.wav"), Sound("vo/npc/female01/pain05.wav"), Sound("vo/npc/female01/pain06.wav"), Sound("vo/npc/female01/pain07.wav"), Sound("vo/npc/female01/pain08.wav"), Sound("vo/npc/female01/pain09.wav")},
		Fall = {Sound("vo/npc/female01/no02.wav"), Sound("vo/npc/female01/no01.wav"), Sound("vo/npc/female01/help01.wav"), Sound("vo/npc/female01/watchout.wav"), Sound("vo/npc/female01/uhoh.wav")},
		Hello = {Sound("vo/npc/female01/hi01.wav"), Sound("vo/npc/female01/hi02.wav")}
	}
}

do
	g_OldEntityIgnite = g_OldEntityIgnite or debug.getregistry().Entity.Ignite

	debug.getregistry().Entity.Ignite = function(eEnt, ...)
		hook.Call("GamemodeOnEntityIgnite", GAMEMODE, eEnt, ...)

		return g_OldEntityIgnite(eEnt, ...)
	end

	g_OldEntityExtinguish = g_OldEntityExtinguish or debug.getregistry().Entity.Extinguish

	debug.getregistry().Entity.Extinguish = function(eEnt, ...)
		hook.Call("GamemodeOnEntityExtinguish", GAMEMODE, eEnt, ...)

		return g_OldEntityExtinguish(eEnt, ...)
	end
end

--For bromsocket HTTPRequest example code
function GM.Util:IndexOf(needle, haystack)
	for i = 1, #haystack do
		if (haystack[i] == needle) then return i end
	end

	return -1
end

function GM.Util:IsDoor(eEnt)
	return self.m_tblDoorClasses[eEnt:GetClass()] or eEnt:GetClass():lower():find("door")
end

function GM.Util:RandomString(intMin, intMax)
	local s = ""

	if intMax then
		for i = 1, math.random(intMin, intMax) do
			s = s .. string.char(math.random(48, 126))
		end
	else
		for i = 1, intMin do
			s = s .. string.char(math.random(48, 126))
		end
	end

	return s
end

function GM.Util:VectorInRange(vecCheck, vecMin, vecMax)
	if not vecCheck or not vecMin or not vecMax then return end
	-- local bOutBounds = false
	-- if vecCheck.x >= vecMin.x and vecCheck.x <= vecMax.x then else
	-- 	bOutBounds = true
	-- end
	-- if vecCheck.y >= vecMin.y and vecCheck.y <= vecMax.y then else
	-- 	bOutBounds = true
	-- end
	-- if vecCheck.z >= vecMin.z and vecCheck.z <= vecMax.z then else
	-- 	bOutBounds = true
	-- end
	-- return not bOutBounds
	--[[Better method of checking]]
	--

	return vecCheck:WithinAABox(vecMin, vecMax)
end

function GM.Util:VectorInRangeSet(vecCheck, tblMinMax)
	for k, v in pairs(tblMinMax) do
		if self:VectorInRange(vecCheck, v.Min, v.Max) then return true end
	end

	return false
end

function GM.Util:AngleInRange(angCheck, angMin, angMax)
	if not angCheck or not angMin or not angMax then return end
	local bOutBounds = false

	if angCheck.p >= angMin.p and angCheck.p <= angMax.p then
	else
		bOutBounds = true
	end

	if angCheck.y >= angMin.y and angCheck.y <= angMax.y then
	else
		bOutBounds = true
	end

	if angCheck.r >= angMin.r and angCheck.r <= angMax.r then
	else
		bOutBounds = true
	end

	return not bOutBounds
end

function GM.Util:ValidWorldPos(vecPos)
	return self:VectorInRange(vecPos, self.m_vecWorldMins, self.m_vecWorldMaxs)
end

function GM.Util:CartesianToSpherical(vecFrom)
	local rho = math.sqrt(vecFrom.x ^ 2 + vecFrom.y ^ 2 + vecFrom.z ^ 2)
	local theta = math.acos(vecFrom.z / rho)
	local phi = math.atan2(vecFrom.y, vecFrom.x)

	return rho, theta, phi
end

function GM.Util:SphericalToCartesian(intRho, intTheta, intPhi)
	return Vector(intRho * math.sin(intTheta) * math.cos(intPhi), intRho * math.sin(intTheta) * math.sin(intPhi), intRho * math.cos(intTheta))
end

function GM.Util:ColorToByte(col)
	return bit.bor(bit.lshift(col.r, 16), bit.lshift(col.g, 8), col.b, bit.lshift(col.a, 24))
end

function GM.Util:ByteToColor(int)
	return Color(bit.band(bit.rshift(int, 16), 0xff), bit.band(bit.rshift(int, 8), 0xff), bit.band(int, 0xff), bit.band(bit.rshift(int, 24), 0xff))
end

function GM.Util:EnumToKey(intKeyEnum, intOffset, bChar)
	intKeyEnum = intKeyEnum - intOffset

	if bChar then
		intKeyEnum = string.char(intOffset + intKeyEnum)
	end

	return intKeyEnum
end

function GM.Util:FormatTime(intTime, bHours, bAppendUnit)
	local time = os.date("!*t", intTime) or {
		min = 0,
		sec = 0
	}

	if time.sec < 10 then
		time.sec = "0" .. time.sec
	end

	if not bHours then
		if bAppendUnit then
			return ("%s minutes %s seconds"):format(time.min, time.sec)
		else
			return ("%s:%s"):format(time.min, time.sec)
		end
	else
		if time.min < 10 then
			time.min = "0" .. time.min
		end

		if bAppendUnit then
			return ("%s hours %s minutes %s seconds"):format(time.hour + (time.day > 1 and (time.day - 1) * 24 or 0), time.min, time.sec)
		else
			return ("%s:%s:%s"):format(time.hour + (time.day > 1 and (time.day - 1) * 24 or 0), time.min, time.sec)
		end
	end
end

function GM.Util:ValidPlayerSkin(strModel, intSkin)
	local model = GAMEMODE.Config.BlockedModelSkins[strModel]
	if not model then return true end
	if table.HasValue(model, intSkin) then return false end

	return true
end

function GM.Util:FaceMatchPlayerModel(strModel, bIsMale, tblLookForMatch)
	local valid, matchedTo = false, strModel

	for k, v in pairs(tblLookForMatch[bIsMale and "Male" or "Female"]) do
		if strModel:find(k) then
			valid = true
			matchedTo = v
			break
		end
	end

	return valid, matchedTo
end

function GM.Util:GetModelFaceID(strModel)
	strModel = strModel:lower()
	local id = strModel:match("female_[0-9][0-9]")

	if not id then
		id = strModel:match("male_[0-9][0-9]")
	end

	return id
end

function GM.Util:PlayerEmitSound(pPlayer, strKey)
	local male = true

	if pPlayer:GetModel():find("alyx.mdl") or pPlayer:GetModel():find("mossman.mdl") or pPlayer:GetModel():find("female_") then
		male = false
	end

	local selectedSound, _ = table.Random(self.m_tblPlayerSounds[male and "Male" or "Female"][strKey])
	pPlayer:EmitSound(selectedSound)
end

function GM.Util:IsAreaEmpty(vecPoint, intRad, tblIgnore)
	tblIgnore = tblIgnore or {}
	local found = ents.FindInSphere(vecPoint, intRad)

	for idx, ent in pairs(found) do
		if not self.m_tblIgnoreSpawnEnts[ent:GetClass()] and not tblIgnore[ent] and not (ent:GetParent() and tblIgnore[ent:GetParent()] or nil) then return false end
	end

	return true
end

function GM.Util:FindSpawnPoint(tblSpawns, intRad)
	for k, v in pairs(tblSpawns) do
		local found = ents.FindInSphere(v[1], intRad)

		for idx, ent in pairs(found) do
			if self.m_tblIgnoreSpawnEnts[ent:GetClass()] then
				found[idx] = nil
			end
		end

		if table.Count(found) == 0 then return v[1], v[2] end
	end
end

do
	local mins, maxs = Vector(-18, -18, -100), Vector(18, 18, 74)

	function GM.Util:IsPointEmpty(vecPos, tblIgnore)
		if not util.IsInWorld(vecPos) then return false end
		local point = util.PointContents(vecPos)
		local a = point ~= CONTENTS_SOLID and point ~= CONTENTS_MOVEABLE and point ~= CONTENTS_LADDER and point ~= CONTENTS_PLAYERCLIP and point ~= CONTENTS_MONSTERCLIP

		if tblIgnore then
			local b = true

			for k, v in pairs(ents.FindInSphere(vecPos, 35)) do
				if v:IsNPC() or v:IsPlayer() or v:IsVehicle() or v:GetClass() == "prop_physics" or v:GetClass() == "prop_physics_multiplayer" and not table.HasValue(tblIgnore, v) then
					b = false
					break
				end
			end

			return a and b
		else
			return a
		end
	end

	function GM.Util:MinMaxsStuck(vecPos, minBound, maxBound)
		if not self:IsPointEmpty(Vector(vecPos.x + minBound.x, vecPos.y + minBound.y, vecPos.z + minBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x - minBound.x, vecPos.y + minBound.y, vecPos.z + minBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x - minBound.x, vecPos.y - minBound.y, vecPos.z + minBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x + minBound.x, vecPos.y - minBound.y, vecPos.z + minBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x + maxBound.x, vecPos.y + maxBound.y, vecPos.z + maxBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x - maxBound.x, vecPos.y + maxBound.y, vecPos.z + maxBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x - maxBound.x, vecPos.y - maxBound.y, vecPos.z + maxBound.z)) then return true end
		if not self:IsPointEmpty(Vector(vecPos.x + maxBound.x, vecPos.y - maxBound.y, vecPos.z + maxBound.z)) then return true end

		return false
	end

	function GM.Util:UnstuckPlayer( pPlayer, minDist )
		local curDist = minDist or 8
		local distance, maxIter = curDist, 48
		local count, newVec, tr, min, max

		while distance < 72 do
			count = maxIter

			while count > 0 do
				count = count -1
				newVec = pPlayer:GetPos() -Vector(
					math.Rand( -distance, distance ),
					math.Rand( -distance, distance ),
					math.Rand( -distance, distance )
				)

				if not util.TraceHull{
					start = newVec,
					endpos = newVec,
					filter = pPlayer,
					mins = mins,
					maxs = maxs
				}.StartSolid then
					min, max = pPlayer:GetCollisionBounds()
					if self:MinMaxsStuck( pPlayer:GetPos(), min, max ) then
						if self:MinMaxsStuck( pPlayer:GetPos(), mins, maxs ) then
							return true
						end
					end

					tr = util.TraceLine{
						start = newVec,
						endpos = newVec +Vector( 0, 0, 72 ),
						filter = pPlayer,
					}
					if not tr.HitWorld and not tr.StartSolid then
						pPlayer:SetPos( newVec )
						return true
					end
				end
			end

			distance = distance +curDist
		end

		return false
	end
end

function GM.Util:DefinePolynomialCurveScalar(intF, intA, intB, intC, intD)
	return function(intX) return intA * intX ^ 4 + intB * intX ^ 3 + intC * intX ^ 2 + intD * intX + intF end
end

--Took a while to get the right algorithm for this..
--By The Maw
do
	local insert = table.insert
	local t, Ab, Points, Step, Point1_for, Point2_for, i

	function GM.Util:BezierCurve(Point1, Ang1, Point2, Ang2, size, iter)
		local Points = {}
		local Step = 1 / iter
		local Point1_for = Point1 + Ang1:Forward() * size
		local Point2_for = Point2 + Ang2:Forward() * size

		for i = 0, iter do
			t = Step * i
			Ab = 1 - t
			insert(Points, Ab ^ 3 * Point1 + 3 * Ab ^ 2 * t * Point1_for + 3 * Ab * t ^ 2 * Point2_for + t ^ 3 * Point2)
		end

		return Points
	end
end

if CLIENT then
	local tan = math.tan
	local rad = math.rad
	local MPos = mesh.Position
	local MNor = mesh.Normal
	local MAdv = mesh.AdvanceVertex
	local Step, BSiz, BHeight, LastAng
	local NextCurve, Ang, Ang2, Rig, Rig2, i

	function GM.Util:CurveToMesh(Curve, Size, iter)
		Step = 360 / iter
		BSiz = tan(rad(Step / 4)) * Size
		BHeight = BSiz / iter * 4
		LastAng = nil
		mesh.Begin(MATERIAL_QUADS, (#Curve - 1) * iter)

		for k, v in pairs(Curve) do
			NextCurve = Curve[k + 1]

			if NextCurve then
				Ang = (NextCurve - v):Angle()
				Ang2 = LastAng or Ang * 1

				for i = 1, iter do
					Rig = Ang:Right()
					Rig2 = Ang2:Right()
					MPos(v + Rig2 * BSiz)
					MNor(Rig2)
					MAdv()
					MPos(NextCurve + Rig * BSiz)
					MNor(Rig)
					MAdv()
					Ang:RotateAroundAxis(Ang:Forward(), Step)
					Ang2:RotateAroundAxis(Ang2:Forward(), Step)
					Rig = Ang:Right()
					Rig2 = Ang2:Right()
					MPos(NextCurve + Rig * BSiz)
					MNor(Rig)
					MAdv()
					MPos(v + Rig2 * BSiz)
					MNor(Rig2)
					MAdv()
				end

				LastAng = Ang
			end
		end

		mesh.End()
	end

	function GM.Util:CurveToMeshStatic(Curve, Size, iter, mat)
		Step = 360 / iter
		BSiz = tan(rad(Step / 4)) * Size
		BHeight = BSiz / iter * 4
		LastAng = nil
		local ret = Mesh(mat)
		mesh.Begin(ret, MATERIAL_QUADS, (#Curve - 1) * iter)

		for k, v in pairs(Curve) do
			NextCurve = Curve[k + 1]

			if NextCurve then
				Ang = (NextCurve - v):Angle()
				Ang2 = LastAng or Ang * 1

				for i = 1, iter do
					Rig = Ang:Right()
					Rig2 = Ang2:Right()
					MPos(v + Rig2 * BSiz)
					MNor(Rig2)
					MAdv()
					MPos(NextCurve + Rig * BSiz)
					MNor(Rig)
					MAdv()
					Ang:RotateAroundAxis(Ang:Forward(), Step)
					Ang2:RotateAroundAxis(Ang2:Forward(), Step)
					Rig = Ang:Right()
					Rig2 = Ang2:Right()
					MPos(NextCurve + Rig * BSiz)
					MNor(Rig)
					MAdv()
					MPos(v + Rig2 * BSiz)
					MNor(Rig2)
					MAdv()
				end

				LastAng = Ang
			end
		end

		mesh.End()

		return ret
	end
end

--The Maw
--This file was taken from one of my other projects, called Devinity 2. Converts source units to metric.
do
	local Measure = {
		M = 52.49344,
		KM = 52493.44,
		AU = 7852906865466.24,
		LY = 496626287418591869.952
	}

	local abs = math.abs
	local floor = math.floor

	function GM.Util:ConvertUnits(Number)
		Number = abs(Number)

		if Number * 10 < Measure.M then
			return floor(Number * 100) / 100, "Units"
		elseif Number * 10 < Measure.KM then
			return floor(Number / Measure.M * 100) / 100, "M"
		elseif Number * 10 < Measure.AU then
			return floor(Number / Measure.KM * 100) / 100, "KM"
		elseif Number * 10 < Measure.LY then
			return floor(Number / Measure.AU * 100) / 100, "AU"
		else
			return floor(Number / Measure.LY * 100) / 100, "LY"
		end
	end

	function GM.Util:ConvertUnitsToKM(Number)
		Number = abs(Number)

		return floor(Number / Measure.KM * 100) / 100, "KM"
	end

	function GM.Util:ConvertUnitsToM(intUnits)
		local inches = intUnits * 0.75
		local meters = inches * 0.0254
		local unit

		if meters >= 1000 then
			meters = math.Round(meters / 1000, 2)
			unit = "KM"
		else
			meters = math.Round(meters)
			unit = "M"
		end

		return meters, unit
	end
end

do
	g_TickList = g_TickList or {}
	g_TickSchedule = g_TickSchedule or {}
	g_TickSchedule_NumTicks = g_TickSchedule_NumTicks or 0

	local function update()
		g_TickSchedule_NumTicks = g_TickSchedule_NumTicks + 1
		local v, i = nil, 0
		::loop::
		i = i + 1
		v = g_TickList[i]

		if v and v.LastTick + v.Interval < g_TickSchedule_NumTicks then
			v.LastTick = g_TickSchedule_NumTicks
			v.Callback(v.Meta)
		end

		if v then
			goto loop
		end
	end

	local function schedule(_, strID, intEveryNTicks, funcCallback, tblMeta)
		local idx = #g_TickList + 1

		table.insert(g_TickList, {
			id = strID,
			Interval = intEveryNTicks,
			Callback = funcCallback,
			Meta = tblMeta,
			LastTick = 0
		})

		g_TickSchedule[strID] = {
			idx = idx,
			Interval = intEveryNTicks,
			Callback = funcCallback,
			Meta = tblMeta,
			LastTick = 0
		}
	end

	local function unschedule(_, strID)
		table.remove(g_TickList, g_TickSchedule[strID].idx)
		g_TickSchedule[strID] = nil
	end

	local function isschedule(_, strID)
		return g_TickSchedule[strID] and true
	end

	local function getschedule(_, strID)
		return g_TickSchedule[strID]
	end

	GM.Util.ScheduleTick = schedule
	GM.Util.RemoveScheduledTick = unschedule
	GM.Util.IsSchedule = isschedule
	GM.Util.GetSchedule = getschedule
	GM.Util.UpdateTickSchedule = update
end

do
	g_SafeCallBuffer = {}

	function GM.Util:NextTick(funcCallSafe, a1, a2, a3, a4, a5, a6)
		table.insert(g_SafeCallBuffer, function()
			funcCallSafe(a1, a2, a3, a4, a5, a6)
		end)
	end

	function GM.Util:RunSafeCalls()
		for _, v in pairs(g_SafeCallBuffer) do
			local b, err = pcall(v)

			if not b then
				err = err or ""
				GAMEMODE:LogDebug("[SafeCall][ERROR] " .. tostring(err))
			end
		end

		g_SafeCallBuffer = {}
	end

	GM.Util:ScheduleTick("GM:SafeCalls", 0, GM.Util.RunSafeCalls, GM.Util)
end

do
	--  Adaptation of the Secure Hashing Algorithm (SHA-244/256)
	--  Found Here: http://lua-users.org/wiki/SecureHashAlgorithm
	--  
	--  Using an adapted version of the bit library
	--  Found Here: https://bitbucket.org/Boolsheet/bslf/src/1ee664885805/bit.lua
	local MOD = 2 ^ 32
	local MODM = MOD - 1

	local function memoize(f)
		local mt = {}
		local t = setmetatable({}, mt)

		function mt:__index(k)
			local v = f(k)
			t[k] = v

			return v
		end

		return t
	end

	local function make_bitop_uncached(t, m)
		local function bitop(a, b)
			local res, p = 0, 1

			while a ~= 0 and b ~= 0 do
				local am, bm = a % m, b % m
				res = res + t[am][bm] * p
				a = (a - am) / m
				b = (b - bm) / m
				p = p * m
			end

			res = res + (a + b) * p

			return res
		end

		return bitop
	end

	local function make_bitop(t)
		local op1 = make_bitop_uncached(t, 2 ^ 1)
		local op2 = memoize(function(a) return memoize(function(b) return op1(a, b) end) end)

		return make_bitop_uncached(op2, 2 ^ (t.n or 1))
	end

	local bxor1 = make_bitop({
		[0] = {
			[0] = 0,
			[1] = 1
		},
		[1] = {
			[0] = 1,
			[1] = 0
		},
		n = 4
	})

	local function bxor(a, b, c, ...)
		local z = nil

		if b then
			a = a % MOD
			b = b % MOD
			z = bxor1(a, b)

			if c then
				z = bxor(z, c, ...)
			end

			return z
		elseif a then
			return a % MOD
		else
			return 0
		end
	end

	local function band(a, b, c, ...)
		local z

		if b then
			a = a % MOD
			b = b % MOD
			z = ((a + b) - bxor1(a, b)) / 2

			if c then
				z = bit32_band(z, c, ...)
			end

			return z
		elseif a then
			return a % MOD
		else
			return MODM
		end
	end

	local function bnot(x)
		return (-1 - x) % MOD
	end

	local function rshift1(a, disp)
		if disp < 0 then return lshift(a, -disp) end

		return math.floor(a % 2 ^ 32 / 2 ^ disp)
	end

	local function rshift(x, disp)
		if disp > 31 or disp < -31 then return 0 end

		return rshift1(x % MOD, disp)
	end

	local function lshift(a, disp)
		if disp < 0 then return rshift(a, -disp) end

		return (a * 2 ^ disp) % 2 ^ 32
	end

	local function rrotate(x, disp)
		x = x % MOD
		disp = disp % 32
		local low = band(x, 2 ^ disp - 1)

		return rshift(x, disp) + lshift(low, 32 - disp)
	end

	local k = {0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2}

	local function str2hexa(s)
		return (string.gsub(s, ".", function(c) return string.format("%02x", string.byte(c)) end))
	end

	local function num2s(l, n)
		local s = ""

		for i = 1, n do
			local rem = l % 256
			s = string.char(rem) .. s
			l = (l - rem) / 256
		end

		return s
	end

	local function s232num(s, i)
		local n = 0

		for i = i, i + 3 do
			n = n * 256 + string.byte(s, i)
		end

		return n
	end

	local function preprocs(msg, len)
		local extra = 64 - ((len + 9) % 64)
		len = num2s(8 * len, 8)
		msg = msg .. string.char(128) .. string.rep(string.char(0), extra) .. len
		assert(#msg % 64 == 0)

		return msg
	end

	local function initH256(H)
		H[1] = 0x6a09e667
		H[2] = 0xbb67ae85
		H[3] = 0x3c6ef372
		H[4] = 0xa54ff53a
		H[5] = 0x510e527f
		H[6] = 0x9b05688c
		H[7] = 0x1f83d9ab
		H[8] = 0x5be0cd19

		return H
	end

	local function digestblock(msg, i, H)
		local w = {}

		for j = 1, 16 do
			w[j] = s232num(msg, i + (j - 1) * 4)
		end

		for j = 17, 64 do
			local v = w[j - 15]
			local s0 = bxor(rrotate(v, 7), rrotate(v, 18), rshift(v, 3))
			v = w[j - 2]
			w[j] = w[j - 16] + s0 + w[j - 7] + bxor(rrotate(v, 17), rrotate(v, 19), rshift(v, 10))
		end

		local a, b, c, d, e, f, g, h = H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]

		for i = 1, 64 do
			local s0 = bxor(rrotate(a, 2), rrotate(a, 13), rrotate(a, 22))
			local maj = bxor(band(a, b), band(a, c), band(b, c))
			local t2 = s0 + maj
			local s1 = bxor(rrotate(e, 6), rrotate(e, 11), rrotate(e, 25))
			local ch = bxor(band(e, f), band(bnot(e), g))
			local t1 = h + s1 + ch + k[i] + w[i]
			h, g, f, e, d, c, b, a = g, f, e, d + t1, c, b, a, t1 + t2
		end

		H[1] = band(H[1] + a)
		H[2] = band(H[2] + b)
		H[3] = band(H[3] + c)
		H[4] = band(H[4] + d)
		H[5] = band(H[5] + e)
		H[6] = band(H[6] + f)
		H[7] = band(H[7] + g)
		H[8] = band(H[8] + h)
	end

	function g_SHA256(msg)
		msg = preprocs(msg, #msg)
		local H = initH256({})

		for i = 1, #msg, 64 do
			digestblock(msg, i, H)
		end

		return str2hexa(num2s(H[1], 4) .. num2s(H[2], 4) .. num2s(H[3], 4) .. num2s(H[4], 4) .. num2s(H[5], 4) .. num2s(H[6], 4) .. num2s(H[7], 4) .. num2s(H[8], 4))
	end
end