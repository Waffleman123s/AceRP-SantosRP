--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--
-- 
GM.Plates = {}
GM.License = {}
GM.License.m_intLastTick = 0

function GM.License:LazyTickPlayer(pPlayer)
	self:UpdateRevokedLicenses(pPlayer)
end

function GM.Plates:SetupPlates(pPlayer, eCar)
	local data = self:GetPlayerPlate(pPlayer, eCar.UID)
	pPlayer.m_strPlateNumber = data.Serial
	eCar:SetNWString("plate_serial", data.Serial)
	eCar:SetNWBool("custom_plate", data.Custom)
end

function GM.Plates:GetPlayerCustomPlates(pPlayer, funcCallback)
	GAMEMODE.SQL:QueryReadOnly(([[SELECT * FROM character_data_store WHERE `key` = 'LicensePlates' and character_id = %d]]):format(pPlayer:GetCharacterID()), function(tblData, q)
		if not tblData or not tblData[1] or not tblData[1].value then
			if funcCallback then
				funcCallback(nil)
			end

			return
		end

		local tab = util.JSONToTable(tblData[1].value)
		local count = 0

		for k, v in pairs(tab) do
			if v.Custom then
				count = count + 1
			end
		end

		if funcCallback then
			funcCallback(count)
		end

		return
	end)
end

function GM.Plates:IsPlateTaken(strSerial, funcCallback)
	GAMEMODE.SQL:QueryReadOnly(([[SELECT * FROM character_data_store WHERE `key` = 'LicensePlates' AND LOCATE('%s', value) > 0]]):format(SQLStr(strSerial, true)), function(tblData, q)
		if not tblData or not tblData[1] or not tblData[1].value then
			if funcCallback then
				funcCallback(false)
			end

			return
		end

		if funcCallback then
			funcCallback(true)
		end

		return
	end)
end

function GM.Plates:RandomPlate()
	local letters = {}

	for i = 1, 3 do
		letters[i] = string.char(65 + math.random(0, 25))
	end

	return ("%s%s%s-%d%d%d"):format(letters[1], letters[2], letters[3], math.random(0, 9), math.random(0, 9), math.random(0, 9))
end

function GM.Plates:GenerateRandomPlate(pPlayer, strCarUID, funcCallback)
	local str = self:RandomPlate()

	self:IsPlateTaken(str, function(bIsTaken)
		if not IsValid(pPlayer) then return end

		if not bIsTaken then
			self:SetPlayerPlate(pPlayer, strCarUID, str, false)

			if funcCallback then
				funcCallback({
					Serial = str,
					Custom = false
				})
			end

			return {
				Serial = str,
				Custom = false
			}
		else
			return self:GenerateRandomPlate(pPlayer, strCarUID, funcCallback)
		end
	end)
end

function GM.Plates:PlayerResetPlate(pPlayer)
	if not IsValid(GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer)) then return pPlayer:AddNote("You must have a vehicle out to reset the plate for it.") end
	local strCarUID = GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer).UID
	if not pPlayer:GetCharacter().Vehicles[strCarUID] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.LicensePlates = saveTable.LicensePlates or {}
	self:GenerateRandomPlate(pPlayer, strCarUID)
	pPlayer:AddNote("You have successfully removed the custom plate off your" .. GAMEMODE.Cars:GetCarByUID(strCarUID).Name)
end

function GM.Plates:PlayerBuyPlate(pPlayer, strPlate)
	if not IsValid(GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer)) then return pPlayer:AddNote("You must have a vehicle out to purchase a custom plate for it.") end
	local strCarUID = GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer).UID
	local carData = GAMEMODE.Cars:GetJobCarByUID(GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer).UID)
	if carData and carData.Job then return pPlayer:AddNote("You cannot purchase a custom plate for a job vehicle!") end
	if not GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "custom_plates") then return pPlayer:AddNote("You must be VIP to purchase a custom plate.") end
	if not pPlayer:GetCharacter().Vehicles[strCarUID] then return end
	if not pPlayer:CanAfford(GAMEMODE.Config.LPlateCost) then return pPlayer:AddNote("You cannot afford to buy a custom license plate!") end
	if strPlate:len() < 1 or strPlate:len() > 7 or strPlate:find("[^%a%d-]") then return pPlayer:AddNote("You entered an invalid plate number.") end

	self:GetPlayerCustomPlates(pPlayer, function(intCount)
		if isnumber(GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "custom_plates_limit")) and intCount > GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "custom_plates_limit") then return pPlayer:AddNote("You have hit the limit of custom plates you are allowed! (" .. GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "custom_plates_limit") .. ")") end

		self:IsPlateTaken(strPlate, function(bIsTaken)
			if not bIsTaken then
				pPlayer:TakeMoney(GAMEMODE.Config.LPlateCost, "Custom license plate registration")
				self:SetPlayerPlate(pPlayer, strCarUID, strPlate, true)

				return pPlayer:AddNote("You have purchased the plate " .. strPlate .. " for your " .. GAMEMODE.Cars:GetCarByUID(strCarUID).Name)
			else
				return pPlayer:AddNote("This license plate is already in use.")
			end
		end)
	end)
end

function GM.License:PlayerBuyPlate(pPlayer, strPlate)
	return GAMEMODE.Plates:PlayerBuyPlate(pPlayer, strPlate)
end

function GM.License:PlayerResetPlate(pPlayer)
	return GAMEMODE.Plates:PlayerResetPlate(pPlayer)
end

function GM.Plates:GetPlayerPlate(pPlayer, strCarUID)
	local uid = isstring(strCarUID) and strCarUID or strCarUID.UID
	local d = GAMEMODE.Cars:GetJobCarByUID(strCarUID)

	if d and d.Job then
		self:GenerateRandomPlate(pPlayer, strCarUID)

		return {}
	end

	if not pPlayer:GetCharacter().Vehicles[uid] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)

	if not saveTable then
		return {
			Serial = "",
			Custom = false
		}
	end

	saveTable.LicensePlates = saveTable.LicensePlates or {}

	if not saveTable.LicensePlates[uid] then
		self:GenerateRandomPlate(pPlayer, strCarUID)
	end

	return saveTable.LicensePlates[uid] or {}
end

function GM.Plates:SetPlayerPlate(pPlayer, strCarUID, strNewSerial, bIsCustom)
	local uid = isstring(strCarUID) and strCarUID or strCarUID.UID
	local d = GAMEMODE.Cars:GetJobCarByUID(strCarUID)

	if d and d.Job then
		if GAMEMODE.Cars:PlayerHasCar(pPlayer) then
			pPlayer.m_strPlateNumber = strNewSerial
			GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer):SetNWString("plate_serial", strNewSerial)
			GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer):SetNWBool("custom_plate", bIsCustom)
		end

		return
	end

	if not pPlayer:GetCharacter().Vehicles[uid] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.LicensePlates = saveTable.LicensePlates or {}

	saveTable.LicensePlates[uid] = {
		Serial = strNewSerial,
		Custom = bIsCustom
	}

	if GAMEMODE.Cars:PlayerHasCar(pPlayer) then
		self:SetupPlates(pPlayer, GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer))
	end

	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "LicensePlates")
	GAMEMODE.SQL:CommitPlayerDiffs(pPlayer:SteamID64())
end

function GM.Plates:RemovePlayerPlate(pPlayer, strCarUID)
	local uid = isstring(strCarUID) and strCarUID or strCarUID.UID
	if not pPlayer:GetCharacter().Vehicles[uid] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.LicensePlates = saveTable.LicensePlates or {}
	saveTable.LicensePlates[uid] = nil
end

function GM.License:PlayerSpawnedVehicle(pPlayer, entVeh)
	GAMEMODE.Plates:SetupPlates(pPlayer, entVeh)
end

-- function GM.License:PlayerSpawnedVehicle( pPlayer, entVeh )
-- 	if pPlayer.m_strPlateNumber then
-- 		entVeh:SetNWString( "plate_serial", pPlayer.m_strPlateNumber )
-- 		return
-- 	end
-- 	--We haven't loaded this player yet
-- 	self:GetPlateNumber( pPlayer, function()
-- 		if not IsValid( pPlayer ) then return end
-- 		if pPlayer.m_strPlateNumber then
-- 			if IsValid( entVeh ) then
-- 				entVeh:SetNWString( "plate_serial", pPlayer.m_strPlateNumber )
-- 			end
-- 			return
-- 		end
-- 		--They haven't gotten a plate number yet!
-- 		self:GeneratePlateSerial( pPlayer, function()
-- 			if not IsValid( pPlayer ) or not IsValid( entVeh ) then
-- 				return
-- 			end
-- 			entVeh:SetNWString( "plate_serial", pPlayer.m_strPlateNumber )
-- 		end )
-- 	end )
-- end
-- function GM.License:GamemodeOnPlayerReady( pPlayer )
-- 	self:GetPlateNumber( pPlayer, function()
-- 		if not IsValid( pPlayer ) then return end
-- 		if pPlayer.m_strPlateNumber then
-- 			return 
-- 		end
-- 		--They haven't gotten a plate number yet!
-- 		self:GeneratePlateSerial( pPlayer )
-- 	end )
-- end
-- --[[ License plate addon integrated and rewritten ]]--
-- function GM.License:WritePlateNumber( pPlayer, strNumber, funcCallback )
-- 	GAMEMODE.SQL:PooledQueryWrite( GAMEMODE.SQL:GetPlayerPoolID(pPlayer:SteamID64()),
-- 		([[INSERT INTO gamemode_plate_numbers (`character_id`, value) VALUES (%d, '%s') ON DUPLICATE KEY UPDATE value='%s']]):format(
-- 		pPlayer:GetCharacterID(),
-- 		strNumber,
-- 		strNumber
-- 	), function( tblData, q )
-- 		if not IsValid( pPlayer ) then return end
-- 		if funcCallback then funcCallback() end
-- 	end )
-- end
-- function GM.License:GetPlateNumber( pPlayer, funcCallback )
-- 	if pPlayer.m_bInPlateNumberQuery then return end
-- 	pPlayer.m_bInPlateNumberQuery = true
-- 	GAMEMODE.SQL:QueryReadOnly(
-- 		([[SELECT p.value FROM gamemode_plate_numbers p WHERE p.character_id = %d]]):format(
-- 			pPlayer:GetCharacterID()
-- 		),
-- 		function( tblData, q )
-- 			if not IsValid( pPlayer ) then return end
-- 			pPlayer.m_bInPlateNumberQuery = false
-- 			if not tblData or not tblData[1] or not tblData[1].value then
-- 				if funcCallback then
-- 					funcCallback()
-- 				end
-- 				return
-- 			end
-- 			pPlayer.m_strPlateNumber = tblData[1].value
-- 			if funcCallback then
-- 				funcCallback()
-- 			end
-- 		end
-- 	)
-- end
-- function GM.License:GeneratePlateSerial( pPlayer, funcCallback )
-- 	if pPlayer.m_bInPlateNumberQuery then return end
-- 	pPlayer.m_bInPlateNumberQuery = true
-- 	--Generate a new plate
-- 	local letters = {}
-- 	for i = 1, 3 do
-- 		letters[i] = string.char( 65 +math.random(0, 25) )
-- 	end
-- 	local str = ("%s%s%s-%d%d%d"):format(
-- 		letters[1], letters[2], letters[3],
-- 		math.random(0, 9), math.random(0, 9), math.random(0, 9)
-- 	)
-- 	--See if it is already in use
-- 	GAMEMODE.SQL:QueryReadOnly(
-- 		([[SELECT * FROM gamemode_plate_numbers p WHERE p.value = '%s']]):format(
-- 			str
-- 		),
-- 		function( tblData, q )
-- 			if not IsValid( pPlayer ) then return end
-- 			pPlayer.m_bInPlateNumberQuery = false
-- 			if not tblData or not tblData[1] or not tblData[1].value then
-- 				--Not in use, we can take it
-- 				pPlayer.m_strPlateNumber = str
-- 				self:WritePlateNumber( pPlayer, str, funcCallback )
-- 				return
-- 			end
-- 			--This plate was generated already, try again
-- 			self:GeneratePlateSerial( pPlayer, funcCallback )
-- 		end
-- 	)
-- end
-- function GM.License:PlayerBuyPlate( pPlayer, strPlate )
-- 	if not GAMEMODE.Player:GetPlayerVIPFlag( pPlayer, "custom_plates" ) then return end
-- 	if pPlayer.m_bBuyingPlate then return end
-- 	if not pPlayer:CanAfford( GAMEMODE.Config.LPlateCost ) then
-- 		pPlayer:AddNote( "You can't afford to buy a custom plate number!" )
-- 		return false
-- 	end
-- 	if strPlate:len() < 1 or strPlate:len() > 7 or strPlate:find( "[^%a%d-]" ) then
-- 		pPlayer:AddNote( "You entered an invalid plate number." )
-- 		return false
-- 	end
-- 	pPlayer.m_bBuyingPlate = true
-- 	--See if it is already in use
-- 	GAMEMODE.SQL:QueryReadOnly(
-- 		([[SELECT * FROM gamemode_plate_numbers p WHERE p.value = '%s']]):format(
-- 			SQLStr(strPlate, true)
-- 		),
-- 		function( tblData, q )
-- 			if not IsValid( pPlayer ) then return end
-- 			pPlayer.m_bInPlateNumberQuery = false
-- 			if not tblData or not tblData[1] or not tblData[1].value then
-- 				--Not in use, we can take it
-- 				pPlayer.m_strPlateNumber = strPlate
-- 				pPlayer:TakeMoney( GAMEMODE.Config.LPlateCost, "Custom license plate registration" )
-- 				pPlayer:AddNote( "You purchased a custom license plate!" )
-- 				self:WritePlateNumber( pPlayer, strPlate, function()
-- 					if not IsValid( pPlayer ) then return end
-- 					pPlayer.m_bBuyingPlate = false
-- 				end )
-- 				if GAMEMODE.Cars:PlayerHasCar( pPlayer ) then
-- 					GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer ):SetNWString( "plate_serial", strPlate )
-- 				end
-- 				return
-- 			end
-- 			--This plate is in use
-- 			pPlayer.m_bBuyingPlate = false
-- 			pPlayer:AddNote( "That plate number is already in use." )
-- 		end
-- 	)
-- end
--[[ License Management ]]
--
function GM.License:GenerateNumbers(intAmount)
	local str = ""

	for i = 1, intAmount do
		str = str .. math.random(0, 9)
	end

	return str
end

function GM.License:GenerateLicense(pPlayer)
	local license = "V%s-%s-%s-%s-%s"
	license = license:format(self:GenerateNumbers(3), self:GenerateNumbers(3), self:GenerateNumbers(2), self:GenerateNumbers(3), self:GenerateNumbers(1))
	GAMEMODE.Player:SetSharedGameVar(pPlayer, "driver_license", license)
	self:UpdateLicenseData(pPlayer)
end

function GM.License:RevokeLicense(pPlayer)
	GAMEMODE.Player:SetSharedGameVar(pPlayer, "driver_license", "")
	self:UpdateLicenseData(pPlayer)
end

function GM.License:PlayerHasLicense(pPlayer)
	return GAMEMODE.Player:GetSharedGameVar(pPlayer, "driver_license", "") ~= ""
end

function GM.License:GetPlayerPlateNumber(pPlayer)
	if not GAMEMODE.Cars:PlayerHasCar(pPlayer) then return "unknown" end

	return GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer):GetNWString("plate_serial")
end

function GM.License:GetPlayerFromPlateNumber(strPlateNumber)
	for k, v in pairs(player.GetAll()) do
		if not GAMEMODE.Player:PlayerHasCar(v) then continue end
		if GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer):GetNWString("plate_serial"):lower() == strPlateNumber:lower() then return v end
	end
end

function GM.License:PlayerSubmitDrivingTest(pPlayer, tblOptions)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	if saveTable.License and (saveTable.License.RevokeTime or saveTable.License.ID) then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "dmv" then return end

	if saveTable.LastDrivingTestTime then
		if saveTable.LastDrivingTestTime + GAMEMODE.Config.DrivingTestRetakeDelay > os.time() then
			local time = math.ceil(((saveTable.LastDrivingTestTime + GAMEMODE.Config.DrivingTestRetakeDelay) - os.time()) / 60)
			pPlayer:AddNote("You must wait " .. time .. " minutes before taking this test again.")

			return
		end
	end

	if table.Count(tblOptions) ~= table.Count(GAMEMODE.Config.DrivingTestQuestions_Answers) then return false end
	local numCorrect = 0

	for qID, pickedKey in pairs(tblOptions) do
		if GAMEMODE.Config.DrivingTestQuestions_Answers[qID].Options[pickedKey] then
			numCorrect = numCorrect + 1
		end
	end

	if GAMEMODE.Config.MinCorrectDrivingTestQuestions > numCorrect then
		pPlayer:AddNote("You failed your driving test!")
		saveTable.LastDrivingTestTime = os.time()
		GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "LastDrivingTestTime")
	else
		pPlayer:AddNote("You passed your driving test!")
		self:GenerateLicense(pPlayer)
		pPlayer:AddNote("Your license id is " .. GAMEMODE.Player:GetSharedGameVar(pPlayer, "driver_license"))
	end
end

--[[ License Dot Management ]]
--
function GM.License:PlayerDotLicense(pPlayer, pDottedPlayer, strDotReason)
	if not IsValid(pDottedPlayer) then return false end
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	if not GAMEMODE.Cars:IsPlayerCarForJob(pPlayer, JOB_POLICE) then return false end
	if pPlayer:GetVehicle() ~= GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer) then return false end
	if not self:PlayerHasLicense(pDottedPlayer) then return false end
	if strDotReason == "" then return false end
	if strDotReason:len() > GAMEMODE.Config.MaxLicenseDotReasonLength then return false end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pDottedPlayer)
	if not saveTable then return false end
	saveTable.License = saveTable.License or {}
	saveTable.License.Dots = saveTable.License.Dots or {}

	table.insert(saveTable.License.Dots, {
		GivenBy = pPlayer:Nick(),
		Reason = strDotReason,
		Date = os.time()
	})

	if table.Count(saveTable.License.Dots) > GAMEMODE.Config.MaxLicenseDotHistory then
		table.remove(saveTable.License.Dots, 1)
	end

	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "License")
	pPlayer:AddNote(("You placed a warning on %s's license!"):format(pDottedPlayer:Nick()))
	pDottedPlayer:AddNote("You received a warning on your license!")

	return true
end

function GM.License:PlayerRevokePlayerLicenseWarning(pPlayer, pTarget, intID)
	if not IsValid(pTarget) then return false end
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.License or not saveTable.License.Dots then return false end
	if not saveTable.License.Dots[intID] then return false end
	table.remove(saveTable.License.Dots, intID)
	GAMEMODE.SQL:MarkDiffDirty(pTarget, "data_store", "License")
	pPlayer:AddNote(("You revoked a warning from %s's license!"):format(pTarget:Nick()))
	pTarget:AddNote("You had a warning on your license revoked!")

	return true
end

function GM.License:GetPlayerDots(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return {} end
	if not saveTable.License then return {} end

	return saveTable.License.Dots
end

--[[ Stolen Vehicle Marking ]]
--
function GM.License:PlayerTogglePlayerVehicleStolenStat(pPlayer, pOwner)
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	if not IsValid(pOwner) then return end
	local car = GAMEMODE.Cars:GetCurrentPlayerCar(pOwner)
	if not IsValid(car) then return end
	car:SetNWBool("stolen", not car:GetNWBool("stolen", false))
end

--[[ Impound marking ]]
--
function GM.License:PlayerTogglePlayerVehicleImpoundStat(pPlayer, pOwner)
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	if not IsValid(pOwner) then return end
	local car = GAMEMODE.Cars:GetCurrentPlayerCar(pOwner)
	if not IsValid(car) then return end
	car:SetNWBool("impound", not car:GetNWBool("impound", false))

	if car:GetNWBool("impound") then
		for k, v in pairs(player.GetAll()) do
			if GAMEMODE.Jobs:GetPlayerJobID(v) ~= JOB_TOW then continue end
			GAMEMODE.Net:SendTextMessage(v, "Tow Dispatch", ("The police have requested the following vehicle be impounded:\n%s %s\nPlate #:%s"):format(car.CarData.Make, car.CarData.Name, car:GetNWString("plate_serial", "")))
			v:EmitSound("santosrp/sms.mp3")
		end
	end
end

--[[ License Revoke Management ]]
--
function GM.License:UpdateRevokedLicenses(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.License then return end
	if not saveTable.License.RevokeTime then return end

	if saveTable.License.RevokeTime + saveTable.License.RevokeDuration < os.time() then
		saveTable.License.RevokeTime = nil
		saveTable.License.RevokeDuration = nil
		self:GenerateLicense(pPlayer)
		pPlayer:AddNote("Your license is no longer revoked!")
	end
end

function GM.License:PlayerRevokePlayerLicense(pPlayer, pRevoke, intDuration)
	if not IsValid(pRevoke) then return false end
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	if not GAMEMODE.Cars:IsPlayerCarForJob(pPlayer, JOB_POLICE) then return false end
	if pPlayer:GetVehicle() ~= GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer) then return false end
	if not self:PlayerHasLicense(pRevoke) then return false end
	if intDuration < GAMEMODE.Config.MinLicenseRevokeTime or intDuration > GAMEMODE.Config.MaxLicenseRevokeTime then return false end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pRevoke)
	if not saveTable then return false end
	saveTable.License = saveTable.License or {}
	saveTable.License.RevokeTime = os.time()
	saveTable.License.RevokeDuration = intDuration
	--Clear dots
	saveTable.License.Dots = nil
	self:RevokeLicense(pRevoke) --Revoke calls update which commits license data
	local time = math.ceil(intDuration / 60)
	pPlayer:AddNote("You revoked " .. pRevoke:Nick() .. "'s license!")
	pRevoke:AddNote("Your license was revoked for " .. time .. " minutes!")

	return true
end

--[[ Ticket Management ]]
--
function GM.License:GetPlayerUnpiadTickets(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.Tickets then return {} end

	return saveTable.Tickets.Unpaid or {}
end

function GM.License:GetPlayerPaidTickets(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.Tickets then return {} end

	return saveTable.Tickets.Paid or {}
end

function GM.License:AddPlayerTicket(pPlayer, strReason, strGivenBy, intPrice)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return false end
	saveTable.Tickets = saveTable.Tickets or {}
	saveTable.Tickets.Unpaid = saveTable.Tickets.Unpaid or {}
	if table.Count(saveTable.Tickets.Unpaid) > GAMEMODE.Config.MaxOutstandingTickets then return false end

	table.insert(saveTable.Tickets.Unpaid, {
		Price = intPrice,
		GivenBy = strGivenBy,
		Reason = strReason,
		Date = os.time()
	})

	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "Tickets")

	return true
end

function GM.License:PlayerTicketPlayer(pPlayer, pTicket, strReason, intPrice)
	if not IsValid(pTicket) then return false end
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	if strReason == "" then return false end
	if strReason:len() > GAMEMODE.Config.MaxTicketReasonLength then return false end
	if intPrice < GAMEMODE.Config.MinTicketPrice or intPrice > GAMEMODE.Config.MaxTicketPrice then return false end

	if self:AddPlayerTicket(pTicket, strReason, pPlayer:Nick(), intPrice) then
		pTicket:AddNote(pPlayer:Nick() .. " gave you a ticket for $" .. string.Comma(intPrice))
		pPlayer:AddNote("You gave " .. pTicket:Nick() .. " a ticket for $" .. string.Comma(intPrice))

		return true
	end

	return false
end

function GM.License:PlayerTicketPlayerCar(pPlayer, entTarget, strReason, intPrice)
	if not IsValid(entTarget) or not entTarget.CarData then return false end
	if strReason == "" then return false end
	if strReason:len() > GAMEMODE.Config.MaxTicketReasonLength then return false end
	if intPrice < GAMEMODE.Config.MinTicketPrice or intPrice > GAMEMODE.Config.MaxTicketPrice then return false end

	entTarget.m_tblWaitingTicket = {
		Price = intPrice,
		GivenBy = pPlayer:Nick(),
		Reason = strReason
	}

	pPlayer:AddNote("You left a ticket for the owner of this car.")

	return true
end

function GM.License:PlayerRevokePlayerUnpaidTicket(pPlayer, pTarget, intID)
	if not IsValid(pTarget) then return false end
	if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, JOB_POLICE) then return false end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pTarget)
	if not saveTable or not saveTable.Tickets or not saveTable.Tickets.Unpaid then return false end
	if not saveTable.Tickets.Unpaid[intID] then return false end
	table.remove(saveTable.Tickets.Unpaid, intID)
	GAMEMODE.SQL:MarkDiffDirty(pTarget, "data_store", "Tickets")
	pPlayer:AddNote(("You revoked an unpaid ticket for %s!"):format(pTarget:Nick()))
	pTarget:AddNote("You had an unpaid ticket revoked!")

	return true
end

function GM.License:PlayerPayTicket(pPlayer, intTicketIDX)
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "dmv" then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.Tickets or not saveTable.Tickets.Unpaid then return false end
	local ticketData = saveTable.Tickets.Unpaid[intTicketIDX]
	if not ticketData then return false end

	if pPlayer:CanAfford(ticketData.Price) then
		pPlayer:TakeMoney(ticketData.Price, "Traffic citation payment")

		if not saveTable.Tickets.Paid then
			saveTable.Tickets.Paid = {}
		end

		table.insert(saveTable.Tickets.Paid, ticketData)

		if table.Count(saveTable.Tickets.Paid) > GAMEMODE.Config.MaxTicketHistory then
			table.remove(saveTable.Tickets.Paid, 1)
		end

		table.remove(saveTable.Tickets.Unpaid, intTicketIDX)
		GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "Tickets")
		pPlayer:AddNote("You paid for a ticket!")

		return true
	end

	pPlayer:AddNote("You can't afford to pay that ticket!")

	return false
end

function GM.License:PlayerEnteredVehicle(pPlayer, entVeh)
	if entVeh.m_tblWaitingTicket and entVeh == GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer) then
		if self:AddPlayerTicket(pPlayer, entVeh.m_tblWaitingTicket.Reason, entVeh.m_tblWaitingTicket.GivenBy, entVeh.m_tblWaitingTicket.Price) then
			pPlayer:AddNote("You found a ticket on your car for $" .. string.Comma(entVeh.m_tblWaitingTicket.Price) .. "!")
			entVeh.m_tblWaitingTicket = nil
		end
	end
end

--[[ Data Management ]]
--
function GM.License:ApplyLicenseData(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable or not saveTable.License then return end

	if saveTable.License.RevokeTime then
		if saveTable.License.RevokeTime + saveTable.License.RevokeDuration < os.time() then
			saveTable.License.RevokeTime = nil
			saveTable.License.RevokeDuration = nil
			GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "License")
		end
	end

	if saveTable.License.RevokeTime then
		GAMEMODE.Player:SetSharedGameVar(pPlayer, "driver_license", "", true)
	else
		GAMEMODE.Player:SetSharedGameVar(pPlayer, "driver_license", saveTable.License.ID, true)
	end
end

function GM.License:UpdateLicenseData(pPlayer)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.License = saveTable.License or {}
	saveTable.License.ID = GAMEMODE.Player:GetSharedGameVar(pPlayer, "driver_license", "unknown")
	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "License")
end

--[[ Data Format For Cop Computer ]]
--
function GM.License:GetCopComputerData(pPlayer)
	local data = {}
	data.Dots = self:GetPlayerDots(pPlayer)
	data.PlateNumber = self:GetPlayerPlateNumber(pPlayer)
	data.UnpiadTickets = self:GetPlayerUnpiadTickets(pPlayer)
	data.PaidTickets = self:GetPlayerPaidTickets(pPlayer)
	data.PhoneNum = GAMEMODE.Player:GetGameVar(pPlayer, "phone_number", "N/A")

	return data
end

--[[ Game Vars ]]
--
hook.Add("GamemodeDefineGameVars", "DefineLicenseVars", function(pPlayer)
	GAMEMODE.Player:DefineSharedGameVar(pPlayer, "driver_license", "", "String", true)
end)

hook.Add("GamemodePlayerSelectCharacter", "ApplyLicenseVars", function(pPlayer)
	GAMEMODE.License:ApplyLicenseData(pPlayer)
end)

hook.Add("GamemodeInitSQLTables", "DefinePlateNumberDB", function()
	GAMEMODE.SQL:PooledQueryWrite(1, [[CREATE TABLE IF NOT EXISTS `gamemode_plate_numbers` (
		`character_id` INT(10) UNSIGNED NOT NULL,
		`value` VARCHAR(255) NULL,
		UNIQUE INDEX `character_id` (`character_id`),
		INDEX `player_id_value` (`character_id`, `value`)
	) ENGINE=InnoDB;]], function() end)
end)