function ShowUpdateCharacterMenu()
  if ValidPanel( GAMEMODE.Gui.m_pnlCharUpdate ) then
    GAMEMODE.Gui.m_pnlCharUpdate:Remove()
  end

  if ValidPanel( GAMEMODE.Gui.m_pnlCharSel ) then
    GAMEMODE.Gui.m_pnlCharSel:SetVisible( false )
  end

  GAMEMODE.Gui.m_pnlCharUpdate = vgui.Create( "SRPUpdateCharacterPanel" )
  GAMEMODE.Gui.m_pnlCharUpdate:SetPos( 0, 0 )
  GAMEMODE.Gui.m_pnlCharUpdate:SetSize( ScrW(), ScrH() )
  GAMEMODE.Gui.m_pnlCharUpdate:SetVisible( true )
  GAMEMODE.Gui.m_pnlCharUpdate:MakePopup()
end