--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--
GM.Player = (GAMEMODE or GM).Player or {}
GM.Player.m_tblPlayerData = (GAMEMODE or GM).Player.m_tblPlayerData or {}

include("mysql.lua")
mysql:SetModule("mysqloo")
hook.Add("DatabaseConnected", "properties.DatabaseConnected", function()
	print("connected player?")
end)

function GM.Player:InitialSpawn(pPlayer)
	if pPlayer:IsBot() and DEV_SERVER then
		pPlayer.SteamID64 = function() return pPlayer:Nick() end

		self.m_tblPlayerData[pPlayer:SteamID64()] = {
			SQLID = 0,
			SelectedCharacter = 0,
			Characters = {
				[0] = GAMEMODE.Char:NewCharacter()
			},
			GameVars = {},
			SharedGameVars = {},
			PlayerDataStore = {}
		}

		self.m_tblPlayerData[pPlayer:SteamID64()].Characters[0].Model.Base = "models/humans/modern/male_01_02.mdl"
		pPlayer.m_bGamemodeDataLoaded = true
		self:DefineGameVars(pPlayer)
	end
end

function GM.Player:Spawn(pPlayer)
	--This player just spawned or hasn't picked a character
	if not pPlayer.m_bGamemodeDataLoaded or not GAMEMODE.Char:GetPlayerCharacter(pPlayer) then
		GAMEMODE:PlayerSpawnAsSpectator(pPlayer)
		pPlayer:Freeze(true)
		pPlayer:AllowFlashlight(false)

		return
	end

	pPlayer:UnSpectate()
	pPlayer:Freeze(false)
	pPlayer:InitializeHands("male07")
	pPlayer:AllowFlashlight(true)
	self:UpdatePlayerMoveSpeed(pPlayer)

	if not GAMEMODE.Jobs:PlayerHasJob(pPlayer) then
		GAMEMODE.Jobs:SetPlayerJob(pPlayer, JOB_CIVILIAN, true) --This shouldn't be needed, but just in case
	else --Setjob calls loadout, so do this so it doesn't happen twice in this case
		hook.Call("PlayerLoadout", GAMEMODE, pPlayer)

		if GAMEMODE.Jobs:GetPlayerJob(pPlayer).PlayerSetModel then
			GAMEMODE.Jobs:GetPlayerJob(pPlayer):PlayerSetModel(pPlayer)
		else --fallback to civ
			GAMEMODE.Jobs:GetJobByID(JOB_CIVILIAN):PlayerSetModel(pPlayer)
		end
	end

	--Find a spot to put them
	local foundSpot

	for k, v in pairs(GAMEMODE.Config.SpawnPoints or {}) do
		local found = ents.FindInSphere(v, 16)

		for idx, ent in pairs(found) do
			if GAMEMODE.Util.m_tblIgnoreSpawnEnts[ent:GetClass()] then
				found[idx] = nil
			end
		end

		if table.Count(found) == 0 then
			foundSpot = v
			break
		end
	end

	if not foundSpot and GAMEMODE.Config.SpawnPoints then
		local vec, _ = table.Random(GAMEMODE.Config.SpawnPoints)
		foundSpot = vec
	end

	pPlayer:SetPos(foundSpot)
	pPlayer:SetHealth(100)

	--What the fuck? Force them to be ON the ground
	pPlayer:SetPos(util.TraceLine{
		start = foundSpot + Vector(0, 0, 1),
		endpos = foundSpot + Vector(0, 0, -16384),
		filter = pPlayer
	}.HitPos)

	-- print("LOADING CHARACTER LETS SEE THE UMMM... BGS?")
	local selectObj = mysql:Select("characters");
	selectObj:Select("bodygroup")
	selectObj:Where("id", pPlayer:GetCharacterID());
	selectObj:Callback(function(result, status, lastID)
		if (type(result) == "table" and #result > 0) then
			-- print("got properties(s)")
			local groups = util.JSONToTable(result[1].bodygroup)
			if groups && !table.IsEmpty(groups) then
				for k, v in pairs( pPlayer:GetBodyGroups() ) do
					if groups[v.id] then
						if groups[v.id] > pPlayer:GetBodygroupCount( v.id ) -1 then continue end
						pPlayer:SetBodygroup( v.id, groups[v.id] )
					end
				end
			end
		else
			-- print "[PropertiesDB] no Properties to load"
		end
		-- print("select query dead...")
	end)
	selectObj:Execute()
	pPlayer:AddNote("Press 'H' to toggle voice modes.")
end

function GM.Player:Loadout(pPlayer)
	local job = GAMEMODE.Jobs:GetPlayerJob(pPlayer)
	if not job then return end

	for k, v in pairs(GAMEMODE.Config.GlobalLoadout) do
		pPlayer:Give(v)
	end

	job:PlayerLoadout(pPlayer)
	GAMEMODE.Inv:PlayerLoadout(pPlayer)
	pPlayer:SelectWeapon("weapon_srphands")
end

function GM.Player:PlayerDeath(pPlayer)
	self:ClearMoveSpeedModifiers(pPlayer)
end

-- ----------------------------------------------------------------
-- Player move speed modifiers
-- ----------------------------------------------------------------
function GM.Player:UpdatePlayerMoveSpeed(pPlayer)
	local newWalk, newRun = GAMEMODE.Config.DefWalkSpeed, GAMEMODE.Config.DefRunSpeed

	if pPlayer.m_tblSpeedFlags then
		for k, v in pairs(pPlayer.m_tblSpeedFlags) do
			newWalk = newWalk + v[1]
			newRun = newRun + v[2]
		end
	end

	if newWalk > newRun then
		newRun = newWalk
	end

	pPlayer:SetWalkSpeed(math.max(newWalk, 45))
	pPlayer:SetRunSpeed(math.max(newRun, 45))
end

function GM.Player:ModifyMoveSpeed(pPlayer, strModifierID, intWalkMod, intRunMod)
	if not pPlayer.m_tblSpeedFlags then
		pPlayer.m_tblSpeedFlags = {}
	end

	pPlayer.m_tblSpeedFlags[strModifierID] = {intWalkMod, intRunMod}
	self:UpdatePlayerMoveSpeed(pPlayer)
end

function GM.Player:GetMoveSpeedModifier(pPlayer, strModifierID)
	if not pPlayer.m_tblSpeedFlags then return end

	return pPlayer.m_tblSpeedFlags[strModifierID]
end

function GM.Player:IsMoveSpeedModifierActive(pPlayer, strModifierID)
	if not pPlayer.m_tblSpeedFlags then return false end

	return pPlayer.m_tblSpeedFlags[strModifierID] and true
end

function GM.Player:RemoveMoveSpeedModifier(pPlayer, strModifierID, bNoUpdate)
	if not pPlayer.m_tblSpeedFlags then return end
	pPlayer.m_tblSpeedFlags[strModifierID] = nil

	if not bNoUpdate then
		self:UpdatePlayerMoveSpeed(pPlayer)
	end
end

function GM.Player:ClearMoveSpeedModifiers(pPlayer)
	if not pPlayer.m_tblSpeedFlags then return end

	for k, v in pairs(pPlayer.m_tblSpeedFlags) do
		self:RemoveMoveSpeedModifier(pPlayer, k, true)
	end

	self:UpdatePlayerMoveSpeed(pPlayer)
end

-- ----------------------------------------------------------------
-- Player gamemode data
-- ----------------------------------------------------------------
function GM.Player:PlayerReadyForData(pPlayer)
	if not IsValid(pPlayer) or pPlayer.m_bGamemodeDataLoaded then return end
	pPlayer.m_bGamemodeDataLoaded = true
	if not pPlayer.m_bValidGameSession and not DEV_SERVER then return end --Module has not validated the player yet, they will call us back
	GAMEMODE:PrintDebug(0, tostring(pPlayer) .. " is ready to load game data.")

	self:LoadGameData(pPlayer, function()
		if not IsValid(pPlayer) then return end --wow, lamer
		GAMEMODE:PrintDebug(0, tostring(pPlayer) .. " had their game data loaded.")
		hook.Call("GamemodeOnPlayerReady", GAMEMODE, pPlayer)
		--send them all of their characters in a short format for view in the selection menu
		GAMEMODE.Net:SendPlayerCharacters(pPlayer)
	end)
end

function GM.Player:GetData(strSID64)
	return self.m_tblPlayerData[strSID64]
end

function GM.Player:LoadGameData(pPlayer, funcCallback)
	local dataProto = {
		SQLID = 0,
		Characters = {}, --Load this
		GameVars = {}, --Shared vars from server to this client
		SharedGameVars = {}, --Shared vars from server to all clients about this client
		PlayerDataStore = {}
	}

	self.m_tblPlayerData[pPlayer:SteamID64()] = dataProto

	GAMEMODE.SQL:LoadPlayerID(pPlayer, function(intID)
		if not IsValid(pPlayer) then return end
		self.m_tblPlayerData[pPlayer:SteamID64()].SQLID = intID
		pPlayer:SetPlayerSQLID(intID)
		GAMEMODE.SQL:UpdatePlayerLastSeenTime(GAMEMODE.SQL:GetPlayerPoolID(pPlayer:SteamID64()), intID)

		GAMEMODE.SQL:LoadPlayerDataStore(pPlayer, function(tblData)
			self.m_tblPlayerData[pPlayer:SteamID64()].PlayerDataStore = tblData

			GAMEMODE.SQL:LoadPlayerCharacters(pPlayer, function(tblCharacters)
				if not IsValid(pPlayer) then return end
				self.m_tblPlayerData[pPlayer:SteamID64()].Characters = tblCharacters
				self:DefineGameVars(pPlayer)
				funcCallback()
			end)
		end)
	end)
end

function GM.Player:DefineGameVars(pPlayer)
	hook.Call("GamemodeDefineGameVars", {}, pPlayer)
end

--Game vars, these network only when changed, and are defined first with a type for better networking
--Game vars must be defind on the server AND the client!
function GM.Player:DefineGameVar(pPlayer, strVar, vaValue, strType, bDontNetwork)
	if not pPlayer:GetGamemodeData() then return end

	pPlayer:GetGamemodeData().GameVars[strVar] = {
		Type = strType,
		Value = vaValue,
		Default = vaValue
	}

	if not bDontNetwork then
		GAMEMODE.Net:UpdateGameVar(pPlayer, strVar)
	end

	GAMEMODE:PrintDebug(0, tostring(pPlayer) .. "::Game var " .. strVar .. " was defined.")
end

function GM.Player:GetGameVarType(pPlayer, strVar)
	if not pPlayer:GetGamemodeData() then return end
	if not pPlayer:GetGamemodeData().GameVars[strVar] then return end

	return pPlayer:GetGamemodeData().GameVars[strVar].Type
end

function GM.Player:GetGameVar(pPlayer, strVar, vaFallback)
	if not pPlayer:GetGamemodeData() then return vaFallback end
	if not pPlayer:GetGamemodeData().GameVars[strVar] then return vaFallback end

	return pPlayer:GetGamemodeData().GameVars[strVar].Value
end

function GM.Player:SetGameVar(pPlayer, strVar, vaValue, bDontNetwork)
	if not pPlayer:GetGamemodeData() then return end
	if not pPlayer:GetGamemodeData().GameVars[strVar] then return end
	pPlayer:GetGamemodeData().GameVars[strVar].Value = vaValue

	if not bDontNetwork then
		GAMEMODE.Net:UpdateGameVar(pPlayer, strVar)
	end

	GAMEMODE:PrintDebug(0, tostring(pPlayer) .. "::Game var " .. strVar .. " was set to " .. tostring(vaValue))
end

--Shared game vars, these network only when changed, and are defined first with a type for better networking
--Shared game vars must be defind on the server AND the client!
--Shared game vars are sent to ALL clients
function GM.Player:DefineSharedGameVar(pPlayer, strVar, vaValue, strType, bDontNetwork)
	if not pPlayer:GetGamemodeData() then return end

	pPlayer:GetGamemodeData().SharedGameVars[strVar] = {
		Type = strType,
		Value = vaValue,
		Default = vaValue
	}

	if not bDontNetwork then
		GAMEMODE.Net:UpdateSharedGameVar(pPlayer, strVar)
	end

	GAMEMODE:PrintDebug(0, tostring(pPlayer) .. "::Shared game var " .. strVar .. " was defined.")
end

function GM.Player:GetSharedGameVarType(pPlayer, strVar)
	if not pPlayer:GetGamemodeData() then return end
	if not pPlayer:GetGamemodeData().SharedGameVars[strVar] then return end

	return pPlayer:GetGamemodeData().SharedGameVars[strVar].Type
end

function GM.Player:GetSharedGameVar(pPlayer, strVar, vaFallback)
	if not pPlayer:GetGamemodeData() then return vaFallback end
	if not pPlayer:GetGamemodeData().SharedGameVars[strVar] then return vaFallback end

	return pPlayer:GetGamemodeData().SharedGameVars[strVar].Value
end

function GM.Player:SetSharedGameVar(pPlayer, strVar, vaValue, bDontNetwork)
	if not pPlayer:GetGamemodeData() then return end
	if not pPlayer:GetGamemodeData().SharedGameVars[strVar] then return end
	pPlayer:GetGamemodeData().SharedGameVars[strVar].Value = vaValue

	if not bDontNetwork then
		GAMEMODE.Net:UpdateSharedGameVar(pPlayer, strVar)
	end

	GAMEMODE:PrintDebug(0, tostring(pPlayer) .. "::Shared game var " .. strVar .. " was set to " .. tostring(vaValue))
end

function GM.Player:WriteCookie(pPlayer, strKey, strValue)
	local tbl = pPlayer:GetGamemodeData()
	if not tbl or not tbl.PlayerDataStore then return end
	local ds = tbl.PlayerDataStore
	ds.Cookies = ds.Cookies or {}
	ds.Cookies[strKey] = strValue
	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "player_data_store", "Cookies")
end

function GM.Player:GetCookie(pPlayer, strKey)
	local tbl = pPlayer:GetGamemodeData()
	if not tbl or not tbl.PlayerDataStore or not tbl.PlayerDataStore.Cookies then return end

	return tbl.PlayerDataStore.Cookies[strKey]
end

-- ----------------------------------------------------------------
-- Player vip flags
-- ----------------------------------------------------------------
GM.Player.m_tblVIPFlags = {}

function GM.Player:RegisterVIPFlag(strFlagID, strGroupID, tblData, strInherit)
	self.m_tblVIPFlags[strFlagID] = self.m_tblVIPFlags[strFlagID] or {}

	self.m_tblVIPFlags[strFlagID][strGroupID] = {
		Inherits = strInherit,
		Data = tblData
	}
end

function GM.Player:GetPlayerVIPFlag(pPlayer, strFlagID, strLevel)
	local group = pPlayer:GetVIPGroup()
	if not group then return end
	if not self.m_tblVIPFlags[strFlagID] then return end
	local data = self.m_tblVIPFlags[strFlagID][strLevel or group]
	if not data then return end
	local ret = {}

	if data.Inherits then
		ret = self:GetPlayerVIPFlag(pPlayer, strFlagID, data.Inherits) or {}
		table.Merge(ret, data.Data)
	else
		ret = data.Data
	end

	return ret
end

GM.Config.BuildVIPFlags()
-- ----------------------------------------------------------------
-- Player meta functions
-- ----------------------------------------------------------------
local pmeta = debug.getregistry().Player

function pmeta:GetGamemodeData()
	return GAMEMODE.Player:GetData(self:SteamID64())
end

function pmeta:GetCharacters()
	return GAMEMODE.Char:GetPlayerCharacters(self)
end

function pmeta:GetCharacter()
	return GAMEMODE.Char:GetPlayerCharacter(self)
end

function pmeta:HasValidCharacter()
	if not self:GetGamemodeData() then return false end

	return GAMEMODE.Char:GetPlayerCharacter(self) and true or false
end

function pmeta:GetCharacterID()
	if self.m_intCachedCharacterID then return self.m_intCachedCharacterID end
	if not self:GetGamemodeData() then return end

	if self:GetGamemodeData().SelectedCharacter then
		self.m_intCachedCharacterID = self:GetGamemodeData().SelectedCharacter
	end

	return self:GetGamemodeData().SelectedCharacter
end

function pmeta:GetInventory()
	if not self:HasValidCharacter() then return end

	return self:GetCharacter().Inventory
end

function pmeta:GetEquipment()
	if not self:HasValidCharacter() then return end

	return self:GetCharacter().Equipped
end

function pmeta:GetEquipSlot(strSlotName)
	if not self:HasValidCharacter() then return end

	return self:GetCharacter().Equipped[strSlotName]
end

function pmeta:GetMoney()
	if not self:HasValidCharacter() then return end

	return self:GetCharacter().Money.Wallet
end

function pmeta:AddMoney(intAmount, strTransactionDesc)
	if not self:HasValidCharacter() then return false end
	local char = self:GetGamemodeData().Characters[self:GetCharacterID()]
	char.Money.Wallet = char.Money.Wallet + intAmount
	GAMEMODE.Player:SetGameVar(self, "money_wallet", char.Money.Wallet)
	GAMEMODE.SQL:MarkDiffDirty(self, "money_wallet")

	if strTransactionDesc then
		char.Transactions = char.Transactions or {}

		table.insert(char.Transactions, {
			type = "deposit",
			method = "wallet",
			amount = intAmount,
			desc = strTransactionDesc,
			time = os.time()
		})

		GAMEMODE.SQL:MarkDiffDirty(self, "transactions")
	end

	return true
end

function pmeta:TakeMoney(intAmount, strTransactionDesc)
	if not self:HasValidCharacter() then return false end
	local char = self:GetGamemodeData().Characters[self:GetCharacterID()]
	if char.Money.Wallet - intAmount < 0 then return false end
	char.Money.Wallet = char.Money.Wallet - intAmount
	GAMEMODE.Player:SetGameVar(self, "money_wallet", char.Money.Wallet)
	GAMEMODE.SQL:MarkDiffDirty(self, "money_wallet")

	if strTransactionDesc then
		char.Transactions = char.Transactions or {}

		table.insert(char.Transactions, {
			type = "withdraw",
			method = "wallet",
			amount = intAmount,
			desc = strTransactionDesc,
			time = os.time()
		})

		GAMEMODE.SQL:MarkDiffDirty(self, "transactions")
	end

	return true
end

function pmeta:CanAfford(intAmount, bank)
	if not self:HasValidCharacter() then return false end
	if bank then
		return self:GetBankMoney() - intAmount >= 0
	end
	return self:GetMoney() - intAmount >= 0
end

function pmeta:GetBankMoney()
	if not self:HasValidCharacter() then return end

	return self:GetCharacter().Money.Bank
end

function pmeta:AddBankMoney(intAmount, strTransactionDesc)
	if not self:HasValidCharacter() then return false end
	local char = self:GetGamemodeData().Characters[self:GetCharacterID()]
	char.Money.Bank = char.Money.Bank + intAmount
	GAMEMODE.Player:SetGameVar(self, "money_bank", char.Money.Bank)
	GAMEMODE.SQL:MarkDiffDirty(self, "money_bank")

	if strTransactionDesc then
		local data = {}
		data.m_intAmount = intAmount
		data.m_strType = "add"
		data.m_strReason = strTransactionDesc
		GAMEMODE.Net:SendPlayerTransaction(self, data)
		char.Transactions = char.Transactions or {}

		table.insert(char.Transactions, {
			type = "deposit",
			method = "bank",
			amount = intAmount,
			desc = strTransactionDesc,
			time = os.time()
		})

		GAMEMODE.SQL:MarkDiffDirty(self, "transactions")
	end

	return true
end

function pmeta:TakeBankMoney(intAmount, strTransactionDesc)
	if not self:HasValidCharacter() then return false end
	local char = self:GetGamemodeData().Characters[self:GetCharacterID()]
	if char.Money.Bank - intAmount < 0 then return false end
	char.Money.Bank = char.Money.Bank - intAmount
	GAMEMODE.Player:SetGameVar(self, "money_bank", char.Money.Bank)
	GAMEMODE.SQL:MarkDiffDirty(self, "money_bank")

	if strTransactionDesc then
		local data = {}
		data.m_intAmount = intAmount
		data.m_strType = "remove"
		data.m_strReason = strTransactionDesc
		GAMEMODE.Net:SendPlayerTransaction(self, data)
		char.Transactions = char.Transactions or {}

		table.insert(char.Transactions, {
			type = "withdraw",
			method = "bank",
			amount = intAmount,
			desc = strTransactionDesc,
			time = os.time()
		})

		GAMEMODE.SQL:MarkDiffDirty(self, "transactions")
	end

	return true
end

function pmeta:GetTalkingNPC()
	return self.m_entTalkingNPC
end

function pmeta:WithinTalkingRange()
	if not IsValid(self:GetTalkingNPC()) then return false end
	if IsValid(self:GetTalkingNPC().m_entDeathRag) then return false end

	return self:GetPos():Distance(self:GetTalkingNPC():GetPos()) <= 200
end

function pmeta:AddNote(strMsg, intIcon, intDuration)
	GAMEMODE.Net:SendHint(self, strMsg, intIcon, intDuration)
end

do
	--This function can be called a lot with large player counts!
	local alive = pmeta.Alive
	local hasWep = pmeta.HasWeapon
	local isRag = pmeta.IsRagdolled
	local isUncon = pmeta.IsUncon

	function pmeta:IsIncapacitated()
		if not alive(self) then return true end
		if hasWep(self, "weapon_handcuffed") or hasWep(self, "weapon_ziptied") then return true end
		if GAMEMODE.Jail:IsPlayerInJail(self) then return true end
		if isRag(self) or isUncon(self) then return true end

		return false
	end
end

g_OldNick = g_OldNick or pmeta.Nick
pmeta.RealNick = g_OldNick

function pmeta:Nick()
	local first = GAMEMODE.Player:GetSharedGameVar(self, "name_first")
	local last = GAMEMODE.Player:GetSharedGameVar(self, "name_last")

	if not first or first == "" then
		return g_OldNick(self)
	else
		return first .. " " .. last
	end
end

g_OldName = g_OldName or pmeta.Name
pmeta.RealName = g_OldNick

function pmeta:Name()
	local first = GAMEMODE.Player:GetSharedGameVar(self, "name_first")
	local last = GAMEMODE.Player:GetSharedGameVar(self, "name_last")

	if not first or first == "" then
		return g_OldName(self)
	else
		return first .. " " .. last
	end
end

g_OldGetName = g_OldGetName or pmeta.GetName
pmeta.RealGetName = g_OldGetName

function pmeta:GetName()
	local first = GAMEMODE.Player:GetSharedGameVar(self, "name_first")
	local last = GAMEMODE.Player:GetSharedGameVar(self, "name_last")

	if not first or first == "" then
		return g_OldGetName(self)
	else
		return first .. " " .. last
	end
end

--[[g_IsSuperAdmin = g_IsSuperAdmin or pmeta.IsSuperAdmin
function pmeta:IsSuperAdmin( ... )
	if self:CheckGroup( "community_manager" ) then
		return true
	end

	return g_IsSuperAdmin( self, ... )
end]]
--
g_CheckGroup = g_CheckGroup or pmeta.CheckGroup

if not g_CheckGroup then
	function pmeta:CheckGroup(strName, ...)
		return strName == self:GetUserGroup()
	end
end

function pmeta:GetVIPGroup()
	--if DEV_SERVER then
	--	return "vip_t2"
	--end
	local mod = GAMEMODE.Module:GetModule("IPB Forum Groups/Whitelist")

	if mod then
		for _, data in pairs(GAMEMODE.Config.IPBServerGuardGroups) do
			if not table.HasValue(GAMEMODE.Config.VIPRanks, data.group) then continue end

			for _, id in pairs(data.ids) do
				if mod:InGroup(self, id) then return data.group end
			end
		end
	end

		for lvl, groups in pairs(GAMEMODE.Config.VIPGroups) do
			if groups[self:GetUserGroup()] then return GAMEMODE.Config.VIPRanks[lvl] end
		end
end

function pmeta:InitializeHands(name)
	local oldhands = self:GetHands()

	if IsValid(oldhands) then
		oldhands:Remove()
	end

	local hands = ents.Create("gmod_hands")

	if IsValid(hands) then
		self:SetHands(hands)
		hands:SetOwner(self)
		local info = player_manager.TranslatePlayerHands(name)

		if info then
			hands:SetModel(info.model)
			hands:SetSkin(info.skin)
			hands:SetBodyGroups(info.body)
		end

		local vm = self:GetViewModel(0)
		hands:AttachToViewmodel(vm)
		vm:DeleteOnRemove(hands)
		self:DeleteOnRemove(hands)
		hands:Spawn()
	end
end