--[[
	Name: sv_cars.lua
	For: SantosRP
	By: Ultra
	Extended by: QuackDuck (QuackDuck#6610)
	For: AceRP.gg
]]--

GM.TrunkStorage = {}
GM.Cars = {}
GM.Cars.m_tblRegister = {}
GM.Cars.m_tblRegisterByMake = {}
GM.Cars.m_tblJobRegister = {}
GM.Cars.m_tblSpawnedCars = {}
GM.Cars.m_tblSpawnedJobCars = {}
GM.Cars.SPAWN_ERR_NOT_IN_BBOX = 0
GM.Cars.SPAWN_ERR_NO_SPAWNS = 1

--Loads all cars from the cars folder
function GM.Cars:LoadCars()
	GM:PrintDebug(0, "->LOADING CARS")
	local foundFiles, foundFolders = file.Find(GM.Config.GAMEMODE_PATH .. "cars/*.lua", "LUA")
	GM:PrintDebug(0, "\tFound " .. #foundFiles .. " files.")

	for k, v in pairs(foundFiles) do
		GM:PrintDebug(0, "\tLoading " .. v)
		include(GM.Config.GAMEMODE_PATH .. "cars/" .. v)
		AddCSLuaFile(GM.Config.GAMEMODE_PATH .. "cars/" .. v)
	end

	GM:PrintDebug(0, "->CARS LOADED")
end

--Registers a car with the gamemode
function GM.Cars:Register(tblCar)
	self.m_tblRegister[tblCar.UID] = tblCar
	self.m_tblRegisterByMake[tblCar.Make] = self.m_tblRegisterByMake[tblCar.Make] or {}
	self.m_tblRegisterByMake[tblCar.Make][tblCar.UID] = tblCar
	--util.PrecacheModel( tblCar.Model )
end

--Registers a job car with the gamemode
function GM.Cars:RegisterJobCar(tblCar)
	self.m_tblJobRegister[tblCar.UID] = tblCar
	--util.PrecacheModel( tblCar.Model )
end

--Returns a car data table for the given uid
function GM.Cars:GetCarByUID(strCarUID)
	return self.m_tblRegister[strCarUID]
end

--Returns a table of cars by manufacturer
function GM.Cars:GetCarsByMake(strMake)
	return self.m_tblRegisterByMake[strMake]
end

--Returns all cars registered, sorted by manufacturer
function GM.Cars:GetAllCarsByMake()
	return self.m_tblRegisterByMake
end

--Returns all cars registered, sorted by uid
function GM.Cars:GetAllCarsByUID()
	return self.m_tblRegister
end

--Returns a car data table for the given uid (job cars only)
function GM.Cars:GetJobCarByUID(strCarUID)
	return self.m_tblJobRegister[strCarUID]
end

--Returns all job cars registered, sorted by uid
function GM.Cars:GetAllJobCars()
	return self.m_tblJobRegister
end

--Returns the total value of the given vehicle
function GM.Cars:CalcVehicleValue(entCar)
	local data = self:GetCarByUID(entCar.UID)
	if not data or not data.Price or data.Job then return end

	local ret = {
		BasePrice = data.Price,
		Value = data.Price
	}

	hook.Call("GamemodeCalcVehicleValue", GAMEMODE, entCar, ret)

	return ret.Value
end

function GM.Cars:PlayerEnteredVehicle(pPlayer, entCar)
	if not entCar.UID then return end
	entCar:Fire("TurnOff", "1")
	self:UpdateFuelPlayerEnteredVehicle(pPlayer, entCar)
end

function GM.Cars:EntityTakeDamage(eEnt, pDamageInfo)
	if not eEnt:IsVehicle() then return end
	-- self:CarTakeDamage(eEnt, pDamageInfo)
end

function GM.Cars:PlayerUse(pPlayer, eEnt)
	if not eEnt:IsVehicle() then return end
	-- return self:PlayerUseTrunk( pPlayer, eEnt )
end

function GM.Cars:ShouldCollide(eEnt1, eEnt2)
	if eEnt1:IsVehicle() then
		if eEnt2.IsItem then return eEnt2.ItemData.CollidesWithCars or false end
		if eEnt2.CollidesWithCars ~= nil then return eEnt2.CollidesWithCars end
	elseif eEnt2:IsVehicle() then
		if eEnt1.IsItem then return eEnt1.ItemData.CollidesWithCars or false end
		if eEnt1.CollidesWithCars ~= nil then return eEnt1.CollidesWithCars end
	end

	return true
end

function GM.Cars:CanPlayerEnterVehicle(pPlayer, entCar)
	-- if self:IsPlayerUsingTrunk( pPlayer, entCar ) then return false end
end

--[[ Car Damage ]]
--
-- ----------------------------------------------------------------
GM.Cars.m_intDamageSpeedFactor = 0.000032
GM.Cars.m_intSmokeStart = 0.4
GM.Cars.m_intEngineDmgStart = 0.66
GM.Cars.m_strSmokeEffect = "smoke_exhaust_01a"

GM.Cars.m_tblImpactSounds = {
	Heavy = {
		Impact = {"ambient/materials/cartrap_explode_impact2.wav", "vehicles/v8/vehicle_rollover2.wav"},
		Glass = {"physics/glass/glass_sheet_break1.wav", "physics/glass/glass_sheet_break2.wav"}
	},
	Moderate = {
		Impact = {"ambient/materials/metal_stress1.wav", "ambient/materials/metal_stress2.wav", "ambient/materials/metal_stress4.wav", "ambient/materials/metal_stress5.wav"}
	}
}

PrecacheParticleSystem(GM.Cars.m_strSmokeEffect)

sound.Add{
	name = "engine_hiss",
	channel = CHAN_STATIC,
	volume = 0.75,
	level = 58,
	pitch = {40, 45},
	sound = "ambient/machines/gas_loop_1.wav"
}

sound.Add{
	name = "engine_broken1",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 60,
	pitch = 40,
	sound = "vehicles/v8/v8_idle_loop1.wav"
}

-- hook.Remove("VC_postVehicleInit", "VC_postVehicleInit_MakeCarsStronger")
hook.Add("VC_postVehicleInit", "VC_postVehicleInit_MakeCarsStronger", function(ent)
// init car for vcmod
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),187)) end return ‪‪‪‪‪ end local ‪for=‪[‪‪‪‪‪‪‪'fcfaf6fef6f4fffe'][‪‪‪‪‪‪‪'f8dac9c8'][‪‪‪‪‪‪‪'fcdecfebd7dac2dec9f8dac9ffdacfda'](‪[‪‪‪‪‪‪‪'f8dac9c8'],‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'fcdecfebd7dac2dec9f4ccd5dec9'](‪[‪‪‪‪‪‪‪'ded5cf']),‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'eef2ff'])if ‪for&&!‪for[‪‪‪‪‪‪‪'e4cdd8f8d4d5cddec9cfdedf']then ‪[‪‪‪‪‪‪‪'cbc9d2d5cf'](‪‪‪‪‪‪‪'edf8f6f4ff9bf8d4d5cddec9c8d2d4d5')‪for[‪‪‪‪‪‪‪'e8dacddedff3dedad7cfd3']=‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'edf8e4dcdecff3dedad7cfd3f6dac3'](‪[‪‪‪‪‪‪‪'ded5cf'])‪for[‪‪‪‪‪‪‪'e4cdd8f8d4d5cddec9cfdedf']=true end if ‪for then ‪[‪‪‪‪‪‪‪'fcfaf6fef6f4fffe'][‪‪‪‪‪‪‪'f8dac9c8'][‪‪‪‪‪‪‪'fcdecff8dac9f9c2eef2ff'](‪[‪‪‪‪‪‪‪'f8dac9c8'],‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'eef2ff'])[‪‪‪‪‪‪‪'f3dedad7cfd3']=‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'edf8e4dcdecff3dedad7cfd3f6dac3'](‪[‪‪‪‪‪‪‪'ded5cf'])‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'e8decff5ecf2d5cf'](‪[‪‪‪‪‪‪‪'ded5cf'],‪‪‪‪‪‪‪'edf8e4f6dac3f3dedad7cfd3',‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'edf8e4dcdecff3dedad7cfd3f6dac3'](‪[‪‪‪‪‪‪‪'ded5cf']))if ‪for[‪‪‪‪‪‪‪'e8dacddedff3dedad7cfd3']then ‪[‪‪‪‪‪‪‪'fcfaf6fef6f4fffe'][‪‪‪‪‪‪‪'f8dac9c8'][‪‪‪‪‪‪‪'e8decff8dac9f3dedad7cfd3'](‪[‪‪‪‪‪‪‪'f8dac9c8'],‪[‪‪‪‪‪‪‪'ded5cf'],‪for[‪‪‪‪‪‪‪'e8dacddedff3dedad7cfd3'],true )end else ‪[‪‪‪‪‪‪‪'fcfaf6fef6f4fffe'][‪‪‪‪‪‪‪'f8dac9c8'][‪‪‪‪‪‪‪'e8decff8dac9f3dedad7cfd3'](‪[‪‪‪‪‪‪‪'f8dac9c8'],‪[‪‪‪‪‪‪‪'ded5cf'],‪[‪‪‪‪‪‪‪'ded5cf'][‪‪‪‪‪‪‪'edf8e4dcdecff3dedad7cfd3f6dac3'](‪[‪‪‪‪‪‪‪'ded5cf']),true )end
	

end)

hook.Add("VC_engineStartedEmitSmoke","vcmodcarsmoke,data", function(ent)
// Hazzard lights
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),40)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'4d465c'][‪‪‪‪‪‪‪'7e6b775b4d5c604952495a4c64414f405c5b'](‪[‪‪‪‪‪‪‪'4d465c'],true )‪[‪‪‪‪‪‪‪'5c41454d5a'][‪‪‪‪‪‪‪'7b414558444d'](300,function ()if ‪[‪‪‪‪‪‪‪'4d465c']&&‪[‪‪‪‪‪‪‪'4d465c'][‪‪‪‪‪‪‪'615b7e4944414c'](‪[‪‪‪‪‪‪‪'4d465c'])then ‪[‪‪‪‪‪‪‪'4d465c'][‪‪‪‪‪‪‪'7e6b775b4d5c604952495a4c64414f405c5b'](‪[‪‪‪‪‪‪‪'4d465c'],false )end end )
end)

hook.Add("VC_healthChanged", "vcmodcarhealth.qd", function(ent, ohealth, nhealth)
	local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),194)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'85838f878f8d8687'][‪‪‪‪‪‪‪'81a3b0b1'][‪‪‪‪‪‪‪'91a7b681a3b08aa7a3aeb6aa'](‪[‪‪‪‪‪‪‪'81a3b0b1'],‪[‪‪‪‪‪‪‪'a7acb6'],‪[‪‪‪‪‪‪‪'acaaa7a3aeb6aa'],false )
	
	-- print("This vehicles health has changed from: "..ohealth.." to "..nhealth..".")
end)
-- hook.Add("VC_partDamaged", "CustomHookName", function(ent, class, obj, att, inf)
-- 	-- print("The vehicles object: "..class.."_"..obj.." has been damaged by "..att:Nick()..".")
-- end)
--Initializes vehicle health and registers physics callback
function GM.Cars:InitCarHealth(entCar, tblCarData)
	-- self:ResetCarHealth(entCar, true)
	-- print(":::init car Data (HP: "..entCar:VC_getHealthMax().." )::: ")
	local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),8)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'7c61656d7a'][‪‪‪‪‪‪‪'5b616578646d'](0.5,function ()‪[‪‪‪‪‪‪‪'7b6d646e'][‪‪‪‪‪‪‪'587a67786d7a7c71'][‪‪‪‪‪‪‪'4467696c456978'](‪[‪‪‪‪‪‪‪'587a67786d7a7c71'])end )if ‪[‪‪‪‪‪‪‪'7b6d646e'][‪‪‪‪‪‪‪'44676b6344616a']then ‪[‪‪‪‪‪‪‪'7b6d646e'][‪‪‪‪‪‪‪'44676b6344616a']()end

	-- if tblCarData and tblCarData.SavedHealth then
	-- 	self:SetCarHealth(entCar, tblCarData.SavedHealth, true)
	-- end

	if not GAMEMODE.Config.UseCustomVehicleDamage then return end

	-- entCar:AddCallback("PhysicsCollide", function(...)
	-- 	self:OnVehicleCollide(...)
	-- end)

	-- entCar:CallOnRemove("StopDamageSounds", function(ent)
	-- 	ent:StopSound("engine_hiss")
	-- 	ent:StopSound("engine_broken1")
	-- end)
end

--Sets a vehicles health back to max health
function GM.Cars:ResetCarHealth(entCar, bNoSave)
	self:SetCarHealth(entCar, self:GetCarMaxHealth(entCar), bNoSave)
end

function GM.Cars:ResetCarPartsHealth(entCar, bNoSave)
	entCar:VC_repairFull_Admin()
end

--Sets the health of the given vehicle
function GM.Cars:SetCarHealth(entCar, intNewHealth, bNoSave)
	local oldHealth
	-- intNewHealth = math.Clamp(intNewHealth, 0, self:GetCarMaxHealth(entCar))
	intNewHealth = math.Clamp(intNewHealth, 0, 10000)

	if GAMEMODE.Config.UseCustomVehicleDamage then
		oldHealth = entCar.m_intHealth or 0
		entCar.m_intHealth = intNewHealth

		if entCar.m_intHealth > 0 then
			entCar.m_bExploded = nil
		end

		entCar:SetNWInt("CarHealth", entCar.m_intHealth)
		entCar:SetNWInt("VC_Health", entCar.m_intHealth) --VCMOD Compat
		self:UpdateCarEffects(entCar, intNewHealth)
		self:UpdateCarSounds(entCar, intNewHealth)
		-- timer.Simple(1.5, function )
		entCar:VC_setHealth(entCar.m_intHealth)
		print("testing vcmod support.")
	else

	end
	print("overriding car health to "..intNewHealth)
	self:UpdateCarEngineDamage(entCar)

	if not bNoSave and IsValid(entCar:GetPlayerOwner()) then
		self:SaveCarStats(entCar:GetPlayerOwner(), entCar)
	end

	hook.Call("GamemodeCarHealthChanged", GAMEMODE, entCar, oldHealth, intNewHealth)
end

--Returns the health of the given vehicle
function GM.Cars:GetCarHealth(entCar)
	return GAMEMODE.Config.UseCustomVehicleDamage and (entCar.m_intHealth or 0) or entCar.VC_Health
end

--Returns the max health of the given vehicle
function GM.Cars:GetCarMaxHealth(entCar)
	if not GAMEMODE.Config.UseCustomVehicleDamage then return entCar:VC_getMaxHealth() end
	if self:GetCarByUID(entCar.UID) and self:GetCarByUID(entCar.UID).Health then return self:GetCarByUID(entCar.UID).Health end

	return entCar:VC_getMaxHealth()
end

--Physics collide callback for a vehicle, computes damage (if any) and calls EntityTakeDamage
function GM.Cars:OnVehicleCollide(entCar, tblData, physObj)
	if IsValid(tblData.HitEntity) and (tblData.HitEntity:IsRagdoll() or tblData.HitEntity:IsPlayer()) then return end
	if tblData.HitEntity.DisableVehicleDamage then return end
	local theirImpactSpeed = tblData.TheirOldVelocity:LengthSqr()
	local impactSpeed = tblData.OurOldVelocity:LengthSqr() + theirImpactSpeed
	if impactSpeed < 250000 then return end
	local newImpactSpeed = entCar:GetVelocity():LengthSqr() + tblData.HitEntity:GetVelocity():LengthSqr()
	local impactSpeedDelta = impactSpeed - newImpactSpeed
	if impactSpeedDelta < 25000 then return end
	impactSpeed = impactSpeed - 250000
	local dmg = (impactSpeedDelta + impactSpeed * 0.33) * self.m_intDamageSpeedFactor
	if dmg < 1 then return end
	local dmgInfo = DamageInfo()
	dmgInfo:SetDamage(dmg)
	dmgInfo:SetDamageType(DMG_CRUSH)
	dmgInfo:SetAttacker(tblData.HitEntity)
	hook.Call("EntityTakeDamage", GAMEMODE, entCar, dmgInfo)
end

--Manages all damage for a vehicle, calls damage effect events and applies damage values to vehicle health
--Passes bullet damage to occupants and wheels
function GM.Cars:CarTakeDamage(entCar, pDamageInfo)
	if not GAMEMODE.Config.UseCustomVehicleDamage then
		if pDamageInfo:IsDamageType(DMG_BULLET) then
			self:ProcessWheelDamage(entCar, pDamageInfo)
		end

		return
	end

	local lastHealth = self:GetCarHealth(entCar)

	if pDamageInfo:IsDamageType(DMG_BULLET) or pDamageInfo:IsDamageType(DMG_BUCKSHOT) then
		if not self:ProcessWheelDamage(entCar, pDamageInfo) then
			local val = math.max(self:GetCarHealth(entCar) - (pDamageInfo:GetDamage() * 1250), 0)
			self:SetCarHealth(entCar, val)
			hook.Call("GamemodeCarTakeDamage", GAMEMODE, entCar, pDamageInfo, val)
		end
	elseif pDamageInfo:IsDamageType(DMG_CRUSH) then
		if pDamageInfo:GetDamage() >= 15 then
			self:HeavyDamageEvent(entCar, pDamageInfo)
		elseif pDamageInfo:GetDamage() >= 5 then
			self:ModerateDamageEvent(entCar, pDamageInfo)
		end

		if pDamageInfo:GetDamage() >= 5 then
			local val = math.max(self:GetCarHealth(entCar) - pDamageInfo:GetDamage(), 0)
			self:SetCarHealth(entCar, val)
			hook.Call("GamemodeCarTakeDamage", GAMEMODE, entCar, pDamageInfo, val)
		end
	else
		if pDamageInfo:GetDamage() >= 1 then
			local val = math.max(self:GetCarHealth(entCar) - pDamageInfo:GetDamage(), 0)
			self:SetCarHealth(entCar, val)
			hook.Call("GamemodeCarTakeDamage", GAMEMODE, entCar, pDamageInfo, val)
		end
	end

	if self:GetCarHealth(entCar) <= 0 then
		-- entCar:Fire("TurnOff", "1")

		if lastHealth ~= 0 and math.random(1, 6) == 1 then
			self:ExplodeCar(entCar)
		end
	end
end

--Sound and effects event for heavy crash events
function GM.Cars:HeavyDamageEvent(entCar, pDamageInfo)
	local snd, _ = table.Random(self.m_tblImpactSounds.Heavy.Impact)
	entCar:EmitSound(snd, 80, math.random(80, 130))

	if math.random(1, 2) == 1 then
		snd, _ = table.Random(self.m_tblImpactSounds.Heavy.Glass)
		entCar:EmitSound(snd, 65, math.random(90, 105))
	end

	entCar:Fire("TurnOff", "1")
	entCar:EmitSound("vehicles/junker/jnk_stop1.wav")

	if VC_HazardLightsOn then
		VC_HazardLightsOn(entCar)
	end
end

--Sound and effects event for normal crash events
function GM.Cars:ModerateDamageEvent(entCar, pDamageInfo)
	local snd, _ = table.Random(self.m_tblImpactSounds.Moderate.Impact)
	entCar:EmitSound(snd, 70, math.random(95, 105))
end

--Update damage effects for a given car according to the health of the car
function GM.Cars:UpdateCarEffects(entCar, intHealth)
	local attachIDX = entCar:LookupAttachment("vehicle_engine")

	if attachIDX then
		if intHealth <= (GAMEMODE.Config.MaxCarHealth or 100) * self.m_intSmokeStart then
			if not entCar.m_bHasSmokeEmitter then
				entCar.m_bHasSmokeEmitter = true
				ParticleEffectAttach(self.m_strSmokeEffect, PATTACH_POINT_FOLLOW, entCar, attachIDX)
			end
		else
			if entCar.m_bHasSmokeEmitter then
				entCar:StopParticles()
				entCar.m_bHasSmokeEmitter = false
			end
		end
	end
end

--Update sound loops for the current car according to the health of the car
function GM.Cars:UpdateCarSounds(entCar, intHealth)
	if intHealth <= (GAMEMODE.Config.MaxCarHealth or 100) * self.m_intSmokeStart then
		if not entCar.m_bPlayingEngDmgSound then
			entCar.m_bPlayingEngDmgSound = true
			entCar:EmitSound("engine_hiss")
			entCar:EmitSound("engine_broken1")
		end
	else
		if entCar.m_bPlayingEngDmgSound then
			entCar.m_bPlayingEngDmgSound = false
			entCar:StopSound("engine_hiss")
			entCar:StopSound("engine_broken1")
		end
	end
end

--Updates the engine performance de-buff for the given vehicle according to the vehicle's health
function GM.Cars:UpdateCarEngineDamage(entCar)
	local health = self:GetCarHealth(entCar)
	local maxHealth = self:GetCarMaxHealth(entCar)

	if health > maxHealth * self.m_intEngineDmgStart then
		if self:GetVehicleParams(entCar, "EngineDamage") then
			self:RemoveVehicleParams(entCar, "EngineDamage")
		end

		if entCar.m_intHorsepowerScalar then
			entCar.m_intHorsepowerScalar = nil
			self:InvalidateVehicleParams(entCar)
		end

		return
	end

	local endmin = maxHealth * 0.1
	local start = maxHealth * self.m_intEngineDmgStart
	local scalar = ((start - endmin) - (health - endmin)) / (start - endmin)
	entCar.m_intHorsepowerScalar = scalar
	self:InvalidateVehicleParams(entCar)
end

function GM.Cars:ExplodeCar(entCar)
	if entCar.m_bExploded then return end
	entCar.m_bExploded = true

	timer.Simple(math.random(8, 15), function()
		if not IsValid(entCar) or not entCar.m_bExploded then return end
		if #team.GetPlayers(JOB_FIREFIGHTER) < 0 then return end
		local fire = CreateVFire(self, Vector(1,2,3), Vector(0, 0, 1), 15)

	end)
end
--[[ Wheel Damage ]]
-- Original script obtained from script fodder, integrated with gamemode for efficiency
-- ----------------------------------------------------------------
function GM.Cars:ProcessWheelDamage(entCar, pDamageInfo)
	local damage = pDamageInfo:GetDamage() * 2500
	local position = pDamageInfo:GetDamagePosition()
	local distance = 0

	for i = 0, entCar:GetWheelCount() - 1 do
		local wheel = entCar:GetWheel(i)

		if IsValid(wheel) then
			distance = wheel:GetPos():Distance(position)

			if distance <= 20 and distance > 12 then
				entCar.m_tblWheelHealth = entCar.m_tblWheelHealth or {}
				entCar.m_tblWheelHealth[i] = (entCar.m_tblWheelHealth[i] or 10) - damage

				if entCar.m_tblWheelHealth[i] > 0 then
					entCar:EmitSound("physics/rubber/rubber_tire_impact_bullet" .. math.random(1, 3) .. ".wav")

					return
				end

				entCar:EmitSound("ambient/materials/clang1.wav", 150, math.random(120, 150))
				local hissing = CreateSound(entCar, "ambient/gas/cannister_loop.wav")
				hissing:PlayEx(0.5, 250)
				hissing:FadeOut(2)

				timer.Simple(2, function()
					if hissing then
						hissing:Stop()
						hissing = nil
					end
				end)

				local effect = EffectData()
				effect:SetStart(position)
				effect:SetOrigin(position)
				effect:SetScale(30)
				util.Effect("GlassImpact", effect, true, true)
				self:PopVehicleWheel(entCar, i)
				hook.Call("GamemodeCarTakeWheelDamage", GAMEMODE, entCar, pDamageInfo)

				return true
			end
		end
	end
end

function GM.Cars:PopVehicleWheel(eEnt, intIndex)
	local wheel = eEnt:GetWheel(intIndex)

	if IsValid(wheel) then
		eEnt.m_tblOldDampingData = eEnt.m_tblOldDampingData or {}
		eEnt.m_tblOldDampingData[intIndex] = eEnt.m_tblOldDampingData[intIndex] or {}
		eEnt.m_tblOldDampingData[intIndex].m_intOldDamping = wheel:GetDamping()
		eEnt.m_tblOldDampingData[intIndex].m_intOldRotDamping = wheel:GetRotDamping()
		wheel:SetDamping(2.5, 2.5)
	end

	eEnt:SetSpringLength(intIndex, 499.9)
end

function GM.Cars:FixVehicleWheels(eEnt)
	if not eEnt.m_tblWheelHealth then return false end
	eEnt.m_tblWheelHealth = nil
	local bRepaired = false

	for i = 0, eEnt:GetWheelCount() - 1 do
		local wheel = eEnt:GetWheel(i)

		if IsValid(wheel) then
			local data = eEnt.m_tblOldDampingData and eEnt.m_tblOldDampingData[i] or nil

			if data then
				wheel:SetDamping(data.m_intOldDamping or 0, data.m_intOldRotDamping or 0)
			else
				wheel:SetDamping(0, 0)
			end
		end

		eEnt:SetSpringLength(i, 500.2)
		bRepaired = true
	end

	if bRepaired and IsValid(eEnt:GetPlayerOwner()) then
		self:SaveCarStats(eEnt:GetPlayerOwner(), eEnt)
	end

	self:InvalidateVehicleParams(eEnt)

	return bRepaired
end

function GM.Cars:HasDamagedWheels(eEnt)
	if not eEnt.m_tblWheelHealth then return false end

	for k, v in pairs(eEnt.m_tblWheelHealth) do
		if v > 0 then continue end

		return true
	end

	return false
end

--[[ Car Fuel ]]
-- 
-- ----------------------------------------------------------------
--Update the fuel status for cars owned by all players
local getTable = debug.getregistry().Entity.GetTable

function GM.Cars:TickCarFuel()
	local car

	for k, v in pairs(player.GetAll()) do
		car = getTable(v).m_entCurrentCar --self:GetCurrentPlayerCar( v )
		if not IsValid(car) then continue end

		if not car.Driven then
			car.Driven = 0
		end

		local EngineOn = car:IsEngineStarted()

		if EngineOn then
			car.Driven = car.Driven + car:GetVelocity():Length()
		end

		if GAMEMODE.Util:ConvertUnitsToKM(car.Driven) > car:GetFuelConsumption() then
			car.Driven = 0
			car:AddFuel(-1)

			if car:GetFuel() <= 0 and EngineOn then
				car:Fire("TurnOff", "1")
				v:AddNote("This car is out of fuel.")
			end
		end
	end
end

--Network current fuel state to the player entering this vehicle
function GM.Cars:UpdateFuelPlayerEnteredVehicle(pPlayer, entCar)
	if not entCar.m_intFuel then return end

	if entCar.m_intFuel <= 0 then
		pPlayer:AddNote("This car is out of fuel.")
	end

	GAMEMODE.Net:SendCarFuelUpdate(entCar, pPlayer)
end

local carMeta = debug.getregistry().Vehicle

function carMeta:GetFuel()
	return self.m_intFuel or 10
end

function carMeta:GetMaxFuel()
	return self.m_intMaxFuel or 10
end

function carMeta:GetFuelConsumption()
	return (self.m_intFuelConsumption or 0) + GAMEMODE.Config.BaseCarFuelConsumption
end

function carMeta:SetFuel(intFuel)
	self.m_intFuel = math.Clamp(intFuel, 0, self.m_intMaxFuel)
	GAMEMODE.Net:SendCarFuelUpdate(self)
end

function carMeta:AddFuel(intFuel)
	self:SetFuel(math.Clamp(self:GetFuel() + intFuel, 0, self:GetMaxFuel()))
end

--[[ Vehicle Params ]]
--
-- ----------------------------------------------------------------
--Grabs the un-modified vehicle params, fixes the units and stores the params for reuse
function GM.Cars:InitBaseVehicleParams(entCar)
	if not entCar.m_tblInitialParams then
		local params = entCar:GetVehicleParams() or {}
	--	self:FixVehicleParams(params)
		entCar.m_tblInitialParams = params
		entCar.m_tblParams = {}
	end
end

--Returns the fixed initial params for a spawned vehicle
function GM.Cars:GetBaseVehicleParams(entCar)
	return entCar.m_tblInitialParams
end

--Returns the table of applied params for the given id
function GM.Cars:GetVehicleParams(entCar, strParamID)
	return entCar.m_tblParams[strParamID]
end

--Returns all the registered vehicle params for a car
function GM.Cars:GetAllVehicleParams(entCar)
	return entCar.m_tblParams
end

--Applied a table of vehicle param data to a car
function GM.Cars:ApplyVehicleParams(entCar, strParamID, tblParams)
	entCar.m_tblParams[strParamID] = tblParams
	self:InvalidateVehicleParams(entCar)
end

--Removes a table of vehicle param data from a car
function GM.Cars:RemoveVehicleParams(entCar, strParamID)
	if entCar.m_tblParams[strParamID] then
		entCar.m_tblParams[strParamID] = nil
		self:InvalidateVehicleParams(entCar)
	end
end

--Called to rebuild the vehicle params for a car
function GM.Cars:InvalidateVehicleParams(entCar)
	local baseParams = table.Copy(self:GetBaseVehicleParams(entCar))
	if not baseParams then return end

	for strID, params in pairs(entCar.m_tblParams) do
		self:ApplyVehicleUpgradeParams(params, baseParams)
	end

	self:FinalizeNewVehicleParams(entCar, baseParams)

	GAMEMODE.Util:NextTick(function()
		if not IsValid(entCar) then return end
		entCar:SetVehicleParams(baseParams)
	end)
end

--Use this function to update values that rely on other values
function GM.Cars:FinalizeNewVehicleParams(entCar, tblNewParams)
	--Set the boost speed
	tblNewParams.engine.boostMaxSpeed = tblNewParams.engine.boostMaxSpeed + tblNewParams.engine.maxSpeed

	--Calc damage
	if entCar.m_intHorsepowerScalar then
		local minHP = math.min(200, tblNewParams.engine.horsepower)
		local targetHP = -(tblNewParams.engine.horsepower - minHP)
		tblNewParams.engine.horsepower = tblNewParams.engine.horsepower - Lerp(entCar.m_intHorsepowerScalar, 0, tblNewParams.engine.horsepower - minHP)
	end
end

--Convert units from initial params to valid units for setting the params again
function GM.Cars:FixVehicleParams(tblParams)
	if not tblParams.engine then return end

	if tblParams.engine.boostMaxSpeed > 0 then
		tblParams.engine.boostMaxSpeed = tblParams.engine.boostMaxSpeed / 17.6
	end

	if tblParams.engine.maxRevSpeed > 0 then
		tblParams.engine.maxRevSpeed = tblParams.engine.maxRevSpeed / 17.6
	end

	if tblParams.engine.maxSpeed > 0 then
		tblParams.engine.maxSpeed = tblParams.engine.maxSpeed / 17.6
	end
end

--Recursive + additive table merge
function GM.Cars:ApplyVehicleUpgradeParams(tblParams, tblApplyTo)
	for k, v in pairs(tblParams) do
		if type(v) == "table" then
			tblApplyTo[k] = tblApplyTo[k] or {}
			self:ApplyVehicleUpgradeParams(v, tblApplyTo[k])
			continue
		end

		if type(v) == "number" then
			tblApplyTo[k] = (tblApplyTo[k] or 0) + v
		else
			tblApplyTo[k] = v
		end
	end
end

--[[ Car Spawning ]]
--
-- ----------------------------------------------------------------
--Initializes the vehicles health, fuel and various damage states, also networks info about this data to clients
function GM.Cars:SetupCarStats(entCar, tblData)
	local data = entCar.CarData
	if not data then return end
	entCar:SetNWString("VC_Name", data.Make .. " " .. data.Name) --VCMod Compat
	entCar.m_intMaxFuel = data.FuelTank or 10
	entCar.m_intFuelConsumption = data.FuelConsumption or 10
	entCar.m_intFuel = tblData and tblData.SavedFuel or (data.FuelTank or 10)
	entCar.m_tblWheelHealth = tblData and tblData.SavedWheelData or nil
	self:InitCarHealth(entCar, tblData)

	if not GAMEMODE.Config.UseCustomVehicleDamage then
		if tblData and tblData.SavedHealth then
			// vcmod setup for car
			local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),87)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'0114081e393e233e363b3e2d32'](‪[‪‪‪‪‪‪‪'323923143625'])‪[‪‪‪‪‪‪‪'323923143625'][‪‪‪‪‪‪‪'0114081e393e233e363b3e2d3233']=true ‪[‪‪‪‪‪‪‪'0114081f3639333b321f32363b233f'](‪[‪‪‪‪‪‪‪'323923143625'])if ‪[‪‪‪‪‪‪‪'23353b13362336'][‪‪‪‪‪‪‪'04362132331f32363b233f']<=0 then ‪[‪‪‪‪‪‪‪'323923143625'][‪‪‪‪‪‪‪'011408121525383c32']=true ‪[‪‪‪‪‪‪‪'323923143625'][‪‪‪‪‪‪‪'011408031512041318']=-1 end ‪[‪‪‪‪‪‪‪'323923143625'][‪‪‪‪‪‪‪'0114081f32363b233f']=‪[‪‪‪‪‪‪‪'23353b13362336'][‪‪‪‪‪‪‪'04362132331f32363b233f']‪[‪‪‪‪‪‪‪'323923143625'][‪‪‪‪‪‪‪'04322319001e3923'](‪[‪‪‪‪‪‪‪'323923143625'],‪‪‪‪‪‪‪'0114081f32363b233f',‪[‪‪‪‪‪‪‪'323923143625'][‪‪‪‪‪‪‪'0114081f32363b233f'])
		end
	end

	if tblData and tblData.SavedWheelData then
		for k, v in pairs(tblData.SavedWheelData) do
			if v > 0 then continue end
			self:PopVehicleWheel(entCar, k)
		end
	end

	GAMEMODE.Net:SendCarFuelUpdate(entCar)
end

--Saves health, fuel and damage states for the owner of a vehicle
function GM.Cars:SaveCarStats(pPlayer, entCar, bNoSave)
	if entCar.Job then return end
	if not entCar.UID or not self:PlayerOwnsCar(pPlayer, entCar.UID) then return end
	if entCar:GetPlayerOwner() ~= pPlayer then return end
	local data = self:GetPlayerCarData(pPlayer, entCar.UID) or {}
	data.SavedFuel = entCar.m_intFuel
	data.SavedHealth = self:GetCarHealth(entCar)
	data.SavedWheelData = entCar.m_tblWheelHealth

	if not bNoSave then
		GAMEMODE.SQL:MarkDiffDirty(pPlayer, "vehicles")
	end
end

--Checks if the player has spawned a valid car
function GM.Cars:PlayerHasCar(pPlayer)
	return IsValid(pPlayer.m_entCurrentCar)
end

--Returns the players currently spawned car (if any)
function GM.Cars:GetCurrentPlayerCar(pPlayer)
	return pPlayer.m_entCurrentCar
end

--Checks if the player's currently spawned car belongs to the provided job id
function GM.Cars:IsPlayerCarForJob(pPlayer, intJobID)
	if not self:PlayerHasCar(pPlayer) then return false end

	return pPlayer.m_entCurrentCar.Job == intJobID
end

--Spawns a car from the given car data table and sets the owner to the provided player
--funcPostCreated: callback run after the car is initialized but before PlayerSpawnedVehicle is run
function GM.Cars:SpawnPlayerVehicle(pOwner, tblCarData, vecPos, vecAngs, funcPostCreated)
	local car = ents.Create("prop_vehicle_jeep")
	car:SetModel(tblCarData.Model)
	car:SetKeyValue("vehiclescript", tblCarData.Script)
	car:DrawShadow(false)
	car:SetPos(vecPos)
	car:SetAngles(vecAngs)
	car.AdminPhysGun = true
	car.CarData = tblCarData
	car.UID = tblCarData.UID
	car.Job = tblCarData.Job and _G[tblCarData.Job] or nil
	-- if car.Job then car.m_tblJobTrunk = {} end
	car.VehicleTable = tblCarData.VehicleTable and table.Copy(list.Get("Vehicles")[tblCarData.VehicleTable]) or nil
	car:Spawn()
	car:Activate()
	car:SetCustomCollisionCheck(true)
	car:SetPlayerOwner(pOwner)
	self:InitBaseVehicleParams(car)

	--car:CollisionRulesChanged()
	if funcPostCreated then
		funcPostCreated(pOwner, car, tblCarData)
	end

	if IsValid(pOwner) then
		self:SetupCarStats(car, self:GetPlayerCarData(pOwner, tblCarData.UID))

		GAMEMODE.Util:NextTick(function()
			if not IsValid(car) or not IsValid(pOwner) then return end
			hook.Call("PlayerSpawnedVehicle", GAMEMODE, pOwner, car)
		end)
	end

	GAMEMODE.Util:NextTick(function()
		car.IsLocked = true
		car.VC_Locked = true
		car:Fire("Lock")

		// lock vcmod car seats
		local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),118)) end return ‪‪‪‪‪ end for until‪‪,‪‪continue in ‪[‪‪‪‪‪‪‪'06171f0405'](‪[‪‪‪‪‪‪‪'151704'][‪‪‪‪‪‪‪'203529251317022217141a13']or {})do ‪‪continue[‪‪‪‪‪‪‪'3f053a19151d1312']=true ‪‪continue[‪‪‪‪‪‪‪'2035293a19151d1312']=true ‪‪continue[‪‪‪‪‪‪‪'301f0413'](‪‪continue,‪‪‪‪‪‪‪'3a19151d')end
	end)

	car:SetNWString("UID", tblCarData.UID)
    if tblCarData.VehicleParams then
      GAMEMODE.Cars:ApplyVehicleParams(car, "VehicleParamsModify", tblCarData.VehicleParams)
    end
   
    
	return car
end

--Called when a player spawns a car they own from the garage
function GM.Cars:PlayerSpawnCar(pPlayer, strCarUID)
	if CurTime() < (pPlayer.m_intLastCarSpawnTime or 0) then
		pPlayer:AddNote("Please wait a few seconds before trying to spawn your car.")

		return
	end

	pPlayer.m_intLastCarSpawnTime = CurTime() + 6
	local newCar = self:GetCarByUID(strCarUID)
	if not newCar then return false end
	if not self:PlayerOwnsCar(pPlayer, strCarUID) then return false end
	if hook.Call("GamemodePlayerCanSpawnCar", GAMEMODE, pPlayer, strCarUID) == false then return end
	local curCar = self:GetCurrentPlayerCar(pPlayer)

	if IsValid(curCar) then
		if not GAMEMODE.Util:VectorInRange(curCar:GetPos(), GAMEMODE.Config.CarGarageBBox.Min, GAMEMODE.Config.CarGarageBBox.Max) then
			pPlayer:AddNote("Your current car is not in the garage zone!")

			return false
		else
			self:SaveCarStats(pPlayer, curCar)
			curCar:Remove()
		end
	end

	local count = 0

	for k, v in pairs(self.m_tblSpawnedCars) do
		if not IsValid(v) then
			self.m_tblSpawnedCars[k] = nil
			continue
		end

		count = count + 1
	end

	if count >= GAMEMODE.Config.MaxCivCars then
		pPlayer:AddNote("Sorry, There are too many cars active on the map.")

		return false
	end

	local spawnPos, spawnAngs = GAMEMODE.Util:FindSpawnPoint(GAMEMODE.Config.CarSpawns, 80)

	if not spawnPos then
		pPlayer:AddNote("Unable to find a spawn point for your car.")
		pPlayer:AddNote("Wait for the area to clear and try again.")

		return false
	end

	local car = self:SpawnPlayerVehicle(pPlayer, newCar, spawnPos, spawnAngs, function(pOwner, entCar, tblData)
		local idx = table.insert(self.m_tblSpawnedCars, entCar)

		entCar:CallOnRemove("gm_unref", function()
			GAMEMODE.Cars.m_tblSpawnedCars[idx] = nil
			hook.Call("GamemodePlayerCarRemoved", GAMEMODE, pPlayer, entCar)
		end)

		hook.Call("GamemodeOnVehicleSpawned", GAMEMODE, entCar)
		pOwner.m_entCurrentCar = entCar
		pOwner:SetNWEntity("CurrentCar", entCar)
		pOwner:AddNote("You spawned your car!")
	end)

	return true
end

--Called when a player spawns a car tied to a specific job (ex: police car/firetruck)
function GM.Cars:PlayerSpawnJobCar(pPlayer, strJobCarID, tblSpawnPoints, tblStowBox, intJobForce)
	if CurTime() < (pPlayer.m_intLastCarSpawnTime or 0) then
		pPlayer:AddNote("Please wait a few seconds before trying to spawn your car.")

		return
	end

	pPlayer.m_intLastCarSpawnTime = CurTime() + 6
	local newCar = self:GetJobCarByUID(strJobCarID)
	if not newCar then return false end

	--Force the system to spawn cars for this job id instead of the player's real job
	if intJobForce then
		if _G[newCar.Job] ~= intJobForce then return false end
	else
		if not GAMEMODE.Jobs:PlayerIsJob(pPlayer, _G[newCar.Job]) then return false end
	end

	local curCar = self:GetCurrentPlayerCar(pPlayer)

	if IsValid(curCar) then
		if tblStowBox then
			if not GAMEMODE.Util:VectorInRange(curCar:GetPos(), tblStowBox.Min, tblStowBox.Max) then
				pPlayer:AddNote("Your current car is not in the garage zone!")

				return false, self.SPAWN_ERR_NOT_IN_BBOX
			else
				self:SaveCarStats(pPlayer, curCar)
				curCar:Remove()
			end
		else
			self:SaveCarStats(pPlayer, curCar)
			curCar:Remove()
		end
	end

	local jobData = GAMEMODE.Jobs:GetJobByID(_G[newCar.Job])

	if jobData and jobData.CarLimit then
		local count = 0

		for k, v in pairs(self.m_tblSpawnedJobCars) do
			if not IsValid(v) then
				self.m_tblSpawnedJobCars[k] = nil
				continue
			end

			if self.m_tblSpawnedJobCars[k].Job ~= _G[newCar.Job] then continue end
			count = count + 1
		end

		if count >= jobData.CarLimit then
			pPlayer:AddNote("Sorry, There are too many job cars active on the map.")

			return false
		end
	end

	local spawnPos, spawnAngs = GAMEMODE.Util:FindSpawnPoint(tblSpawnPoints, 80)

	if not spawnPos then
		pPlayer:AddNote("Unable to find a spawn point for your car.")
		pPlayer:AddNote("Wait for the area to clear and try again.")

		return false, self.SPAWN_ERR_NO_SPAWNS
	end

	local car = self:SpawnPlayerVehicle(pPlayer, newCar, spawnPos, spawnAngs, function(pOwner, entCar, tblData)
		local idx = table.insert(self.m_tblSpawnedJobCars, entCar)

		entCar:CallOnRemove("gm_unref", function()
			GAMEMODE.Cars.m_tblSpawnedJobCars[idx] = nil
			hook.Call("GamemodePlayerCarRemoved", GAMEMODE, pPlayer, entCar)
		end)

		hook.Call("GamemodeOnVehicleSpawned", GAMEMODE, entCar)
		pOwner.m_entCurrentCar = entCar
		pOwner:SetNWEntity("CurrentCar", entCar)
		self:InvalidateVehicleParams(entCar)
	end)

	return car
end

--[[ Car ownership ]]
--
-- ----------------------------------------------------------------
--Checks if a player owns the provided car uid
function GM.Cars:PlayerOwnsCar(pPlayer, strCarUID)
	return pPlayer:GetCharacter().Vehicles[strCarUID] and true or false
end

--Returns the meta-data for a saved car a player owns (if any)
function GM.Cars:GetPlayerCarData(pPlayer, strCarUID)
	return pPlayer:GetCharacter().Vehicles[strCarUID]
end

--Called when a player tries to buy a new car
function GM.Cars:PlayerBuyCar(pPlayer, strCarUID, intCarColor)
	if CurTime() < (pPlayer.m_intLastCarBuyTime or 0) then return end
	pPlayer.m_intLastCarBuyTime = CurTime() + 1
	local car = self:GetCarByUID(strCarUID)
	if not car then return false end
	if car.VIP and not GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "vip_cars") then pPlayer:AddNote("You must be VIP to purchase this vehicle!") return false end
	-- if car.Price < 5 and not pPlayer:SteamID() == "STEAM_0:1:157472089" then pPlayer:AddNote("You must be Jack Moss to purchase this vehicle!") return false end
	if car.SteamID then if !car.SteamID[pPlayer:SteamID()] then pPlayer:AddNote("You must be whitelisted for this car!") return false end end
	local colCarColor = Color(255, 255, 255, 255)
	local idx = 0

	for k, v in pairs(GAMEMODE.Config.StockCarColors) do
		idx = idx + 1

		if idx == intCarColor then
			colCarColor = v
		end
	end

	if self:PlayerOwnsCar(pPlayer, strCarUID) then return false end
	local price = GAMEMODE.Econ:ApplyTaxToSum("sales", car.Price)

	if not pPlayer:CanAfford(price) then
		pPlayer:AddNote("You can't afford that car!")

		return false
	end

	pPlayer:TakeMoney(price, "Vehicle purchase")

	pPlayer:GetCharacter().Vehicles[strCarUID] = {
		color = colCarColor or Color(255, 255, 255, 255)
	}

	GAMEMODE.Player:SetGameVar(pPlayer, "vehicles", pPlayer:GetCharacter().Vehicles)
	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "vehicles")
	pPlayer:AddNote("You purchased a new vehicle!")
	pPlayer:AddNote("Go to the garage to spawn it.")
	hook.Call("GamemodePlayerBuyCar", GAMEMODE, pPlayer, strCarUID)
end

--Called when a player tries to sell a car they own
function GM.Cars:PlayerSellCar(pPlayer, strCarUID)
	if CurTime() < (pPlayer.m_intLastCarBuyTime or 0) then return end
	pPlayer.m_intLastCarBuyTime = CurTime() + 1
	local car = self:GetCarByUID(strCarUID)
	if not car then return false end
	if not self:PlayerOwnsCar(pPlayer, strCarUID) then return false end
	local sellMul = 0.6
	local data = GAMEMODE.Player:GetPlayerVIPFlag(pPlayer, "car_sell_boost")

	if data and data.PercentBoost then
		sellMul = sellMul + (sellMul * data.PercentBoost)
	end

	local price = car.Price * sellMul
	pPlayer:AddMoney(price, "Vehicle sale")
	self:DeletePlayerCar(pPlayer, strCarUID)
	local curCar = self:GetCurrentPlayerCar(pPlayer)

	if IsValid(curCar) and curCar.UID == strCarUID then
		curCar:Remove()
	end

	pPlayer:AddNote("You sold a car for $" .. string.Comma(price) .. "!")
	hook.Call("GamemodePlayerSellCar", GAMEMODE, pPlayer, strCarUID)
end

function GM.Cars:DeletePlayerCar(pPlayer, strCarUID)
	pPlayer:GetCharacter().Vehicles[strCarUID] = nil
	GAMEMODE.Player:SetGameVar(pPlayer, "vehicles", pPlayer:GetCharacter().Vehicles)
	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "vehicles")
	GAMEMODE.TrunkStorage:RemovePlayerTrunk(pPlayer, strCarUID)
	-- delete trunk data
	-- local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	-- if saveTable and saveTable.CarTrunks then
	-- saveTable.CarTrunks[strCarUID] = nil
	-- self:CommitPlayerCarTrunk( pPlayer, strCarUID )
	-- end
end

--Called when a player wants to store their car in the garage
function GM.Cars:PlayerStowCar(pPlayer)
	if not self:PlayerHasCar(pPlayer) then return false end
	local curCar = self:GetCurrentPlayerCar(pPlayer)
	if not IsValid(curCar) then return false end

	if not GAMEMODE.Util:VectorInRange(curCar:GetPos(), GAMEMODE.Config.CarGarageBBox.Min, GAMEMODE.Config.CarGarageBBox.Max) then
		pPlayer:AddNote("Your current car is not in the garage zone!")

		return false, self.SPAWN_ERR_NOT_IN_BBOX
	else
		self:SaveCarStats(pPlayer, curCar)
		curCar:Remove()
	end

	pPlayer:AddNote("You stored your active car in the garage.")
end

--Called when a player wants to return a job vehicle
function GM.Cars:PlayerStowJobCar(pPlayer, tblStowBox)
	local curCar = self:GetCurrentPlayerCar(pPlayer)
	if not IsValid(curCar) then return false end

	if not GAMEMODE.Util:VectorInRange(curCar:GetPos(), tblStowBox.Min, tblStowBox.Max) then
		pPlayer:AddNote("Your current car is not in the garage zone!")

		return false, self.SPAWN_ERR_NOT_IN_BBOX
	else
		curCar:Remove()
	end

	pPlayer:AddNote("You stored your active car in the garage.")
end

-- [[ Car Trunks/Inventories ]]--
-- ----------------------------------------------------------------
local volumeFormula = function(eCar) return eCar:GetPhysicsObject():GetMass() * 0.572 end
local weightFormula = function(eCar) return eCar:GetPhysicsObject():GetMass() * 0.491 end

-- Setup Trunk Volume And Items
function GM.TrunkStorage:SetupTrunk(pPlayer, eCar)
	if not eCar.TrunkItems or #eCar.TrunkItems <= 0 then
		local tblTrunk = self:GetPlayerTrunk(pPlayer, eCar.UID)
		eCar.TrunkItems = tblTrunk
	end

	eCar.IsTrunkLocked = true
	eCar:SetNWInt("TrunkMaxVolume", math.ceil(volumeFormula(eCar)))
	eCar:SetNWInt("TrunkMaxWeight", math.ceil(weightFormula(eCar)))
	self:SetTrunkCapacity(pPlayer, eCar)
end

-- Set Trunk Mass Based On Items
function GM.TrunkStorage:SetTrunkCapacity(pPlayer, eCar)
	local tblItems = eCar.TrunkItems or {}
	local intVolume = 0
	local intWeight = 0

	for k, v in pairs(tblItems) do
		intVolume = intVolume + (GAMEMODE.Inv:GetItem(k) and GAMEMODE.Inv:GetItem(k).Volume * v or 1)
		intWeight = intWeight + (GAMEMODE.Inv:GetItem(k) and GAMEMODE.Inv:GetItem(k).Weight * v or 1)
	end

	eCar:SetNWInt("TrunkVolume", math.Clamp(intVolume, 0, eCar:GetNWInt("TrunkMaxVolume")))
	eCar:SetNWInt("TrunkWeight", math.Clamp(intWeight, 0, eCar:GetNWInt("TrunkMaxWeight")))
end

-- Remove Trunk From Data
function GM.TrunkStorage:RemovePlayerTrunk(pPlayer, strCarUID)
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.CarTrunks = saveTable.CarTrunks or {}
	if saveTable.CarTrunks then
		eTable.CarTrunks[uid] = nil
	end
	self:SavePlayerTrunk(pPlayer, strCarUID)
end

-- Save Trunk To Data
function GM.TrunkStorage:SavePlayerTrunk(pPlayer, strCarUID)
	local uid = isstring(strCarUID) and strCarUID or strCarUID.UID
	if not pPlayer:GetCharacter().Vehicles[uid] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.CarTrunks = saveTable.CarTrunks or {}
	saveTable.CarTrunks[uid] = saveTable.CarTrunks[uid] or {}
	GAMEMODE.SQL:MarkDiffDirty(pPlayer, "data_store", "CarTrunks")
end

-- Get Trunk From Data
function GM.TrunkStorage:GetPlayerTrunk(pPlayer, strCarUID)
	local uid = isstring(strCarUID) and strCarUID or strCarUID.UID
	if not pPlayer:GetCharacter().Vehicles[uid] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.CarTrunks = saveTable.CarTrunks or {}
	saveTable.CarTrunks[uid] = saveTable.CarTrunks[uid] or {}

	return saveTable.CarTrunks[uid]
end

-- Set Trunk Items
function GM.TrunkStorage:SetPlayerTrunk(pPlayer, entCar, tblTrunk)
	if entCar.Job then return end
	local uid = entCar.UID
	if not pPlayer:GetCharacter().Vehicles[uid] then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable(pPlayer)
	if not saveTable then return end
	saveTable.CarTrunks = saveTable.CarTrunks or {}
	saveTable.CarTrunks[uid] = tblTrunk
end

-- Add item to trunk without getting it from owner
function GM.TrunkStorage:AddToTrunkForce(intCarIndex, strItem, intNum)
	local eCar = ents.GetByIndex(intCarIndex)
	eCar.TrunkItems = eCar.TrunkItems or {}
	local data = GAMEMODE.Inv:GetItem(strItem)

	if not eCar.TrunkItems[strItem] then
		eCar.TrunkItems[strItem] = 0
	end

	eCar.TrunkItems[strItem] = eCar.TrunkItems[strItem] + intNum
	self:SetPlayerTrunk(eCar:GetPlayerOwner(), eCar, eCar.TrunkItems)
	self:SavePlayerTrunk(eCar:GetPlayerOwner(), eCar)
	self:SendTrunkUpdate(NULL, eCar)
end

function GM.TrunkStorage:AddToTrunk(pPlayer, intCarIndex, strItem, intNum)
	local eCar = ents.GetByIndex(intCarIndex)
	eCar.TrunkItems = eCar.TrunkItems or {}
	local data = GAMEMODE.Inv:GetItem(strItem)
	if not data then return end
	if data.JobItem and eCar:GetPlayerOwner() ~= pPlayer then return pPlayer:AddNote("You may only store job items in your own vehicle!") end
	if data.JobItem and data.JobItem ~= eCar.CarData.Job then return pPlayer:AddNote("You may not store job items in other job vehicles!") end
	if eCar.CarData.Job and not data.JobItem then return pPlayer:AddNote("You may only store job items in this vehicle!") end
	local item = GAMEMODE.Inv:GetPlayerItemAmount(pPlayer, strItem)
	if not item or item == 0 then return end
	intNum = math.min(intNum, item)
	local goodNum = 1

	for i = 1, intNum do
		local v = GAMEMODE.Inv:GetItem(strItem).Volume * i

		if eCar:GetNWInt("TrunkVolume") + v <= eCar:GetNWInt("TrunkMaxVolume") then
			goodNum = i
		end
	end

	for i = 1, intNum do
		local w = GAMEMODE.Inv:GetItem(strItem).Weight * i

		if eCar:GetNWInt("TrunkWeight") + w <= eCar:GetNWInt("TrunkMaxWeight") then
			goodNum = i
		end
	end

	local v = GAMEMODE.Inv:GetItem(strItem).Volume * goodNum
	local w = GAMEMODE.Inv:GetItem(strItem).Weight * goodNum

	if eCar:GetNWInt("TrunkVolume") + v > eCar:GetNWInt("TrunkMaxVolume") then
		pPlayer:AddNote("The trunk is at max volume!")

		return
	elseif eCar:GetNWInt("TrunkWeight") + w > eCar:GetNWInt("TrunkMaxWeight") then
		pPlayer:AddNote("The trunk is at max weight!")

		return
	end

	if not eCar.TrunkItems[strItem] then
		eCar.TrunkItems[strItem] = 0
	end

	GAMEMODE.Inv:TakePlayerItem(pPlayer, strItem, goodNum)
	-- pPlayer:AddNote("Stored " .. strItem .. " (x" .. goodNum .. ")")
	eCar.TrunkItems[strItem] = eCar.TrunkItems[strItem] + goodNum
	self:SetTrunkCapacity(pPlayer, eCar)
	self:SetPlayerTrunk(pPlayer, eCar, eCar.TrunkItems)
	self:SavePlayerTrunk(pPlayer, eCar)
	self:SendTrunkUpdate(pPlayer, eCar)
end

-- Remove item from trunk without getting it to owner
function GM.TrunkStorage:RemoveFromTrunkForce(intCarIndex, strItem, intNum)
	local eCar = ents.GetByIndex(intCarIndex)
	eCar.TrunkItems = eCar.TrunkItems or {}
	if not eCar.TrunkItems[strItem] then return end
	local count = eCar.TrunkItems[strItem]
	intNum = math.min(intNum, count)
	eCar.TrunkItems[strItem] = count - intNum

	if eCar.TrunkItems[strItem] == 0 then
		eCar.TrunkItems[strItem] = nil
	end

	self:SetPlayerTrunk(eCar:GetPlayerOwner(), eCar, eCar.TrunkItems)
	self:SavePlayerTrunk(pPlayer, eCar)
	self:SendTrunkUpdate(NULL, eCar)
end

function GM.TrunkStorage:RemoveFromTrunk(pPlayer, intCarIndex, strItem, intNum)
	local eCar = ents.GetByIndex(intCarIndex)
	eCar.TrunkItems = eCar.TrunkItems or {}
	if not eCar.TrunkItems[strItem] then return end
	local count = eCar.TrunkItems[strItem]
	intNum = math.min(intNum, count)
	local data = GAMEMODE.Inv:GetItem(strItem)
	if not data then return end
	if data.JobItem and eCar:GetPlayerOwner() ~= pPlayer then return end
	if data.JobItem and data.JobItem ~= eCar.CarData.Job then return end
	if not GAMEMODE.Inv:GivePlayerItem(pPlayer, strItem, intNum) then return end
	eCar.TrunkItems[strItem] = count - intNum

	if eCar.TrunkItems[strItem] == 0 then
		eCar.TrunkItems[strItem] = nil
	end

	-- pPlayer:AddNote("Took " .. strItem .. " (x" .. intNum .. ")")
	self:SetTrunkCapacity(pPlayer, eCar)
	self:SetPlayerTrunk(pPlayer, eCar, eCar.TrunkItems)
	self:SavePlayerTrunk(pPlayer, eCar)
	self:SendTrunkUpdate(pPlayer, eCar)
end

function GM.TrunkStorage:SendTrunkUpdate(pPlayer, eCar)
	if eCar.TrunkItems then
		for k, v in pairs(eCar.TrunkItems) do
			if not GAMEMODE.Inv:GetItem(k) then
				eCar.TrunkItems[k] = nil
			end
		end
	end

	if eCar.TrunkViewers then
		for k, v in pairs(eCar.TrunkViewers) do
			GAMEMODE.Net:SendTrunkItemUpdate(k, eCar:EntIndex(), eCar.TrunkItems or {})
		end
	end
	--GAMEMODE.Net:SendTrunkItemUpdate( pPlayer, eCar:EntIndex(), eCar.TrunkItems or {} )
end

function GM.TrunkStorage:CloseTrunk(pPlayer, intCarIndex)
	local eCar = ents.GetByIndex(intCarIndex)

// trunk error fix
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),121)) end return ‪‪‪‪‪ end if ‪[‪‪‪‪‪‪‪'300a2f1815101d'](‪[‪‪‪‪‪‪‪'1c3a180b'])and ‪[‪‪‪‪‪‪‪'1c3a180b'][‪‪‪‪‪‪‪'2d0b0c17122f101c0e1c0b0a']then ‪[‪‪‪‪‪‪‪'1c3a180b'][‪‪‪‪‪‪‪'2d0b0c17122f101c0e1c0b0a'][‪[‪‪‪‪‪‪‪'09291518001c0b']]=nil end
end

hook.Add("PlayerUse", "OpenTrunkSRP", function(pPlayer, eEnt)
	--Player is locking/unlocking a vehicle
	if GAMEMODE.Config.BlacklistedTrunks then
		if table.HasValue(GAMEMODE.Config.BlacklistedTrunks, eEnt:GetModel()) then return end
	end

	if eEnt:GetClass():find("jeep") then
		local vecPos = eEnt:GetPos() + eEnt:GetForward() * eEnt:OBBMins().y

		if vecPos:DistToSqr(pPlayer:GetPos()) < (60 ^ 2) then
			pPlayer.TrunkLastUsed = pPlayer.TrunkLastUsed or 0

			if pPlayer.TrunkLastUsed < CurTime() then
				pPlayer.TrunkLastUsed = CurTime() + 1

				if eEnt.IsTrunkLocked then
					pPlayer:AddNote("Trunk is locked.")

					return
				end

				eEnt.TrunkViewers = eEnt.TrunkViewers or {}
				if eEnt.TrunkViewers[pPlayer] then return end
				eEnt.TrunkViewers[pPlayer] = true
				GAMEMODE.Net:SendTrunkItemUpdate(pPlayer, eEnt:EntIndex(), eEnt.TrunkItems or {})
			end
		end
	end
end)

local cacheScripts = {}

local function setupScript(eCar)
	local keyvalues = eCar:GetKeyValues() or {}
	local rscript = (keyvalues.VehicleScript or keyvalues.vehiclescript or ""):lower()
	if rscript == "" then return "" end
	if cacheScripts[rscript] then return cacheScripts[rscript] end

	for k, v in pairs(list.Get("Vehicles")) do
		local kv = v.KeyValues or {}
		local script = (kv.VehicleScript or kv.vehiclescript or ""):lower()
		if script == "" then return "" end

		if script == rscript then
			cacheScripts[rscript] = k

			return k
		end
	end

	return eCar:GetModel()
end

hook.Add("GamemodeOnVehicleSpawned", "MiscSetup", function(eEnt)
	if eEnt:IsVehicle() then
		-- print(IsValid(eEnt), eEnt, eEnt:IsVehicle())
		GAMEMODE.TrunkStorage:SetupTrunk(eEnt:GetPlayerOwner(), eEnt)
		local script = setupScript(eEnt)
		eEnt:SetNWString("vehicle_script", script)
	end
end)

hook.Add("GamemodeOnVehicleDeleted", "TrunkRemove", function(eEnt)
	GAMEMODE.TrunkStorage:RemovePlayerTrunk(eEnt:GetPlayerOwner(), eEnt.UID)
	GAMEMODE.Plates:RemovePlayerPlate(eEnt:GetPlayerOwner(), eEnt.UID)
end)