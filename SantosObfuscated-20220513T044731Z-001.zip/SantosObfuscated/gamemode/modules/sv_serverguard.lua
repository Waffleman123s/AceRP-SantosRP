if not serverguard then return end

local Module = {}
Module.Name = "ServerGuard Integration: Server Component"
if DEV_SERVER then
	Module.SQLHost = "localhost"
	Module.SQLUser = "santos_serverg"
	Module.SQLPass = "1234"
	Module.SQLDBName = "serverguard"
else
	if PRIVATE_SERVER then
		Module.SQLHost = "localhost"
		Module.SQLUser = "santos_private_sguard"
		Module.SQLPass = "cJOE4qErL5OxxjQL"
		Module.SQLDBName = "santos_private_sguard"
	elseif PUBLIC_SERVER then
		Module.SQLHost = "localhost"
		Module.SQLUser = "santos_public_sguard"
		Module.SQLPass = "cRkuxJ3R9mDdSW9Z"
		Module.SQLDBName = "santos_public_sguard"
	end
end

function Module:OnLoad()
	self:RequireHook( "Initialize" )

	--Should be removed if we want to call Connect() on our own
	hook.Remove( "serverguard.Initialize", "serverguard.mysql.Initialize" )
	
	serverguard.mysql:SetModule( "tmysql4" )
end

function Module:Initialize()
	serverguard.mysql:Connect( self.SQLHost, self.SQLUser, self.SQLPass, self.SQLDBName )
end

GM.Module:Register( Module )