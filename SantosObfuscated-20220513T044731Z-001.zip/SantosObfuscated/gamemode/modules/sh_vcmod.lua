local Module = {}
Module.Name = "VCMod Integration: Shared Component"
Module.m_tblGroupsAllowed = {
	["superadmin"] = true,
}

function Module:VC_CanEditAdminSettings( pPlayer, bDef )
	if not self.m_tblGroupsAllowed[pPlayer:GetUserGroup()] then
		return false
	end
end

function Module:OnLoad()
	self:RequireHook( "VC_CanEditAdminSettings" )
end

GM.Module:Register( Module )