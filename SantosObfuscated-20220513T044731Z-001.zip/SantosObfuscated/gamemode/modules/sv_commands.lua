--[[
	Name: sv_commands.lua
	For: SantosRP
	By: Ultra
]]--

local Module = {}
Module.Name = "Gamemode Commands"

local RestrictedIDList = {
	["76561198102286835"] = true, -- Tylrrr
}

if PUBLIC_SERVER then
	--RestrictedIDList["76561198081888809"] = true --http://steamcommunity.com/profiles/76561198081888809/ 
end

-- local function checkID( pPlayer )
	-- if DEV_SERVER then return true end
	-- return pPlayer:IsFullyAuthenticated() and pPlayer:IsSuperAdmin()
-- end

concommand.Add( "srp_admin_save_shutdown", function( pPlayer, strCmd, tblArgs )
	if IsValid( pPlayer ) and not pPlayer:IsSuperAdmin() then return end
	GAMEMODE:CloseServer( "in-game command", function()
		--Crash the server, leave no survivors 
		debug.sethook() --interrupt any debug hooks
		table.Empty( debug.getregistry() ) --fuck up _R
		_G = nil --fuck up _G
	end )
end )

concommand.Add( "srp_admin_restart_postpone", function( pPlayer, strCmd, tblArgs )
	if IsValid( pPlayer ) and not pPlayer:IsSuperAdmin() then return end
	GAMEMODE.Module:GetModule( "AutoRestart" ):PostponeRestart( pPlayer )
end )

concommand.Add( "srp_admin_force_save", function( pPlayer )
	if IsValid( pPlayer ) and not pPlayer:IsSuperAdmin() then return end
	for k, v in pairs( player.GetAll() ) do
		GAMEMODE.SQL:CommitPlayerDiffs( v:SteamID64() )
	end
end )

concommand.Add( "srp_admin_msgall", function( pPlayer, strCmd, tblArgs )
	if IsValid( pPlayer ) and not pPlayer:IsSuperAdmin() then return end
	
	local text = string.Implode( " ", tblArgs )
	if text == "" then return end
	for k, v in pairs( player.GetAll() ) do
		v:PrintMessage( HUD_PRINTCENTER, text )
		v:AddNote( text, NOTIFY_ERROR, 30 )
	end
end )
--[[ 
--sh_unconscious
concommand.Add( "srp_dev_unrag_me", function( pPlayer )
	if not pPlayer:IsSuperAdmin() then return end
	
	if pPlayer:IsUncon() then
		pPlayer:WakeUp()
	elseif pPlayer:IsRagdolled() then
		pPlayer:UnRagdoll()
	end
end )

concommand.Add( "srp_dev_unrag_other", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end
	local foundPlayer

	if not tblArgs[1] then
		foundPlayer = util.TraceLine{
			start = pPlayer:GetShootPos(),
			endpos = pPlayer:GetShootPos() +pPlayer:GetAimVector() *1e9,
			filter = pPlayer
		}.Entity

		if not IsValid( foundPlayer ) or not foundPlayer:IsPlayer() then
			foundPlayer = nil
		end
	else
		local targetName = string.Implode( " ", tblArgs )
		for k, v in pairs( player.GetAll() ) do
			if v:Nick():match( targetName ) then
				foundPlayer = v
				break
			end
		end
	end
	
	if not IsValid( foundPlayer ) then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, "Unable to locate a valid player!" )
		return
	end

	local done
	if foundPlayer:IsUncon() then
		foundPlayer:WakeUp()
		done = true
	elseif foundPlayer:IsRagdolled() then
		foundPlayer:UnRagdoll()
		done = true
	end

	if done then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, ("Unragdolling player %s"):format(foundPlayer:Nick()) )
	else
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, ("Player %s is not currently a ragdoll"):format(foundPlayer:Nick()) )
	end
end )

--sv_firesystem
-- concommand.Add( "srp_dev_clear_fire", function( pPlayer )
-- 	if IsValid( pPlayer ) and not pPlayer:IsSuperAdmin() then return end
-- 	for k, v in pairs( ents.FindByClass("ent_fire") ) do
-- 		if not IsValid( v ) or v.IsMapProp then continue end
-- 		v:Remove()
-- 	end
-- end )

--sv_inventory
 concommand.Add( "srp_dev_give_item", function( pPlayer, strCmd, tblArgs )
 	if not pPlayer:IsSuperAdmin() then return end
 	local itemName = tostring( tblArgs[1] )

 	if not GAMEMODE.Inv:ValidItem( itemName ) then
 		return
 	end

 	GAMEMODE.Inv:GivePlayerItem( pPlayer, itemName, tonumber(tblArgs[2] or 1) )
 end )

--sv_jobs
concommand.Add( "srp_admin_whitelist_player", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsAdmin() then return end
	local targetName = tblArgs[1] or ""
	local jobID = tblArgs[2] and tonumber( tblArgs[2] ) or nil

	if not jobID then
		return
	end

	for k, v in pairs( player.GetAll() ) do
		if v:Nick():lower():find( targetName:lower() ) then
			if GAMEMODE.Jobs:IsPlayerWhitelisted( v, jobID ) then
				--
				return
			end

			GAMEMODE.Jobs:WhitelistPlayer( v, jobID )
			return
		end
	end
end )

--sv_license
concommand.Add( "srp_dev_givelicense", function( pPlayer )
	if not pPlayer:IsSuperAdmin() then return end
	GAMEMODE.License:GenerateLicense( pPlayer )
end )

concommand.Add( "srp_dev_removelicense", function( pPlayer )
	if not pPlayer:IsSuperAdmin() then return end
	local saveTable = GAMEMODE.Char:GetCurrentSaveTable( pPlayer )
	if not saveTable then return end
	saveTable.License = nil

	GAMEMODE.Player:SetSharedGameVar( pPlayer, "driver_license", "" )
end )

-- --sv_player
-- concommand.Add( "srp_dev_give_money", function( pPlayer, strCmd, tblArgs )
-- 	if not pPlayer:IsSuperAdmin() then return end
-- 	local amount = math.max( tonumber(tblArgs[1] or 0), 0 )
-- 	pPlayer:AddMoney( amount, "Developer command" )
-- end )

concommand.Add( "srp_dev_remove", function( pPlayer, strCmd, tblArgs )
	if pPlayer:IsAdmin() then
		local trEnt = pPlayer:GetEyeTrace().Entity
		if IsValid( trEnt ) and not trEnt:IsPlayer() then
			if trEnt.IsMapProp then return end
			trEnt:Remove()
		end
	end
end )

concommand.Add( "srp_dev_repair", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end
	local trEnt = pPlayer:GetEyeTrace().Entity
	if IsValid( trEnt ) and trEnt.IsItem then
		trEnt.m_intLastDmgTime = nil
		GAMEMODE.EntityDamage:SetItemHealth( trEnt, trEnt.m_flMaxHealth or 100 )
	end
end )

concommand.Add( "srp_dev_change_player_name", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() or not pPlayer:CheckGroup( "community_manager" ) then return end
	local targetSID = tostring( tblArgs[1] or "" )

	local foundPlayer
	for k, v in pairs( player.GetAll() ) do
		if v:SteamID() == targetSID then
			foundPlayer = v
			break
		end
	end	

	if not IsValid( foundPlayer ) then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, "Unable to locate a player with that steam id!" )
		return
	end

	if not foundPlayer:HasValidCharacter() then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, "That player has not loaded a character yet!" )
		return
	end

	local nameFirst, nameLast = tostring( tblArgs[2] or "" ), tostring( tblArgs[3] or "" )

	if nameFirst:len() <= 0 or nameLast:len() <= 0 then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, "Cannot set a zero-length name!" )
		return
	end

	pPlayer:PrintMessage( HUD_PRINTCONSOLE, "Changing ".. foundPlayer:Nick().. "'s name to ".. nameFirst.. " ".. nameLast.. "!" )

	local id = GAMEMODE.SQL:GetPlayerPoolID( foundPlayer:SteamID64() )
	GAMEMODE.SQL:UpdateCharacterFirstName( id, foundPlayer:GetCharacterID(), nameFirst )
	GAMEMODE.SQL:UpdateCharacterLastName( id, foundPlayer:GetCharacterID(), nameLast )
	GAMEMODE.Player:SetSharedGameVar( foundPlayer, "name_first", nameFirst )
	GAMEMODE.Player:SetSharedGameVar( foundPlayer, "name_last", nameLast )	
	foundPlayer:GetCharacter().Name.First = nameFirst 
	foundPlayer:GetCharacter().Name.Last = nameLast
end )

concommand.Add( "srp_dev_uncuff_me", function( pPlayer )
	if not pPlayer:IsSuperAdmin() then return end
	pPlayer:StripWeapon( "weapon_handcuffed" )
	pPlayer:StripWeapon( "weapon_ziptied" )
end )

concommand.Add( "srp_dev_uncuff_other", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end
	local foundPlayer

	if not tblArgs[1] then
		foundPlayer = util.TraceLine{
			start = pPlayer:GetShootPos(),
			endpos = pPlayer:GetShootPos() +pPlayer:GetAimVector() *1e9,
			filter = pPlayer
		}.Entity

		if not IsValid( foundPlayer ) or not foundPlayer:IsPlayer() then
			foundPlayer = nil
		end
	else
		local targetName = string.Implode( " ", tblArgs )
		for k, v in pairs( player.GetAll() ) do
			if v:Nick():match( targetName ) then
				foundPlayer = v
				break
			end
		end
	end
	
	if not IsValid( foundPlayer ) then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, "Unable to locate a valid player!" )
		return
	end

	foundPlayer:StripWeapon( "weapon_handcuffed" )
	foundPlayer:StripWeapon( "weapon_ziptied" )
	pPlayer:PrintMessage( HUD_PRINTCONSOLE, ("Player %s was uncuffed!"):format(foundPlayer:Nick()) )
end )

--sv_player_damage
concommand.Add( "srp_dev_heal_me", function( pPlayer, strCmd, tblArgs )
	if not DEV_SERVER then
		if not pPlayer:IsSuperAdmin() then return end
	end

	GAMEMODE.PlayerDamage:HealPlayerLimbs( pPlayer )
	pPlayer:SetHealth( pPlayer:GetMaxHealth() )
end )

concommand.Add( "srp_dev_heal_other", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end
	local foundPlayer

	if not tblArgs[1] then
		foundPlayer = util.TraceLine{
			start = pPlayer:GetShootPos(),
			endpos = pPlayer:GetShootPos() +pPlayer:GetAimVector() *1e9,
			filter = pPlayer
		}.Entity

		if not IsValid( foundPlayer ) or not foundPlayer:IsPlayer() then
			foundPlayer = nil
		end
	else
		local targetName = string.Implode( " ", tblArgs )
		for k, v in pairs( player.GetAll() ) do
			if v:Nick():match( targetName ) then
				foundPlayer = v
				break
			end
		end
	end
	
	if not IsValid( foundPlayer ) then
		pPlayer:PrintMessage( HUD_PRINTCONSOLE, "Unable to locate a valid player!" )
		return
	end

	pPlayer:PrintMessage( HUD_PRINTCONSOLE, ("Healing player %s"):format(foundPlayer:Nick()) )
	GAMEMODE.PlayerDamage:HealPlayerLimbs( foundPlayer )
	foundPlayer:SetHealth( foundPlayer:GetMaxHealth() )
end )

--sv_santos_customs
concommand.Add( "srp_dev_fix_carshop", function( pPlayer )
	if not pPlayer:IsSuperAdmin() then return end
	GAMEMODE.CarShop.m_tblDoors = {}
	GAMEMODE.CarShop:Initialize()
end )

--sv_skills
concommand.Add( "srp_dev_give_xp", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end
	local skill = tostring( tblArgs[1] )
	local num = tonumber( tblArgs[2] )
	GAMEMODE.Skills:GivePlayerXP( pPlayer, skill, num )
end )

concommand.Add( "srp_dev_set_level", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end
	local skill = tostring( tblArgs[1] )
	local level = tonumber( tblArgs[2] )
	GAMEMODE.Skills:SetPlayerXP( pPlayer, skill, GAMEMODE.Skills:GetXPForLevel(skill, level) )
end )
]]--
function Module:OnLoad()
end

GM.Module:Register( Module )