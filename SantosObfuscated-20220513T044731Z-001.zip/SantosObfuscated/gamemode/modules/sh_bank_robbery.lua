--[[
	Name: sh_config.lua
	For: Project Steele
	By: Christopher Steele/xrayhunter
]]

local Module = {}
Module.Name = "BankRobberyShared"

if SERVER then
	function Module:AttachThermiteEnt( eEnt, intSlotIDX )
		local ent = ents.Create( "ent_thermite" )
		ent:SetPos( eEnt:LocalToWorld(eEnt.ThermitePoints[intSlotIDX].pos) )
		ent:SetAngles( eEnt:LocalToWorldAngles(eEnt.ThermitePoints[intSlotIDX].ang) )
		ent:Spawn()
		ent:Activate()
		ent:SetParent( eEnt )
		eEnt:DeleteOnRemove( ent )
		ent:CallOnRemove( "UnrefDoorSlot", function()
			if not ent.m_bLit then
				eEnt:SetNW2Bool( "ThermiteSlot".. intSlotIDX, false )
			end
		end )
		table.insert( eEnt.m_tblThermiteEnts, ent )
	end
end

function Module:InstallThermiteFunctions( eEnt, tblPoints, intBurnTimeMin, intBurnTimeMax, funcCanAttach, funcThermiteDone )
	eEnt.ThermiteRequired = eEnt.ThermiteRequired or #tblPoints
	eEnt.ThermiteBurnTimeMin = eEnt.ThermiteBurnTimeMin or intBurnTimeMin
	eEnt.ThermiteBurnTimeMax = eEnt.ThermiteBurnTimeMax or intBurnTimeMax
	eEnt.ThermitePoints = eEnt.ThermitePoints or tblPoints
	if SERVER then eEnt.m_tblThermiteEnts = {} end

	eEnt:SetNW2Int( "ThermiteSlots", eEnt.ThermiteRequired )
	eEnt:SetNW2Bool( "ThermiteEnabled", false )
	eEnt:SetNW2Bool( "ThermiteFinished", false )
	for k, v in pairs( tblPoints ) do
		eEnt:SetNW2Vector( "ThermiteSlot".. k.. "_pos", v.pos )
		eEnt:SetNW2Bool( "ThermiteSlot".. k, false )
	end
	
	if SERVER then
		function eEnt:EnableThermite( bEnable )
			eEnt:SetNW2Bool( "ThermiteEnabled", bEnable )
		end

		function eEnt:IsThermiteEnabled()
			return self:GetNW2Bool( "ThermiteEnabled" )
		end

		function eEnt:SetThermiteFinished( bEnable )
			eEnt:SetNW2Bool( "ThermiteFinished", bEnable )
		end

		function eEnt:IsThermiteFinished()
			return self:GetNW2Bool( "ThermiteFinished" )
		end

		function eEnt:ClearThermite()
			for k, v in pairs( self.m_tblThermiteEnts ) do
				if IsValid( v ) then v:Remove() end
			end
			for k, v in pairs( tblPoints ) do
				eEnt:SetNW2Bool( "ThermiteSlot".. k, false )
			end
		end

		function eEnt:ThermiteActive()
			return self.m_bThermiteActive
		end
		
		function eEnt:CanAttachThermite( pPlayer, intSlotID )
			if not self:IsThermiteEnabled() then return false end
			if self:GetNW2Bool( "ThermiteSlot".. intSlotID ) == true then
				return false
			end

			if funcCanAttach then
				if not funcCanAttach( self, pPlayer, intSlotID ) then return false end
			end

			return true
		end

		function eEnt:AttachThermite( pPlayer, intSlotID )
			self:SetNW2Bool( "ThermiteSlot".. intSlotID, true )
			Module:AttachThermiteEnt( self, intSlotID )

			for k, v in pairs( tblPoints ) do
				if not self:GetNW2Bool( "ThermiteSlot".. k ) then return true end
			end

			self:OnThermitePlaced()
			return true
		end

		function eEnt:OnThermitePlaced()
			self:EnableThermite( false )
			for k, v in pairs( self.m_tblThermiteEnts ) do
				if not IsValid( v ) then continue end
				v.ItemTakeBlocked = true
			end

			self.m_bThermiteActive = true
			timer.Simple( 3, function()
				if not IsValid( self ) then return end

				local duration = math.random( self.ThermiteBurnTimeMin, self.ThermiteBurnTimeMax )
				for k, v in pairs( self.m_tblThermiteEnts ) do
					if not IsValid( v ) then continue end
					v:IgniteThermite( duration )
				end

				timer.Simple( duration, function()
					if not IsValid( self ) then return end
					self:OnThermiteDone()
					self.m_bThermiteActive = false
				end )
			end )
		end

		function eEnt:OnThermiteDone()
			for k, v in pairs( self.m_tblThermiteEnts ) do
				if IsValid( v ) then v:Remove() end
			end

			for i = 1, self.ThermiteRequired do
				self:SetNW2Bool( "ThermiteSlot".. i, false )
			end
			self:EnableThermite( false )
			self:SetThermiteFinished( true );

			if funcThermiteDone then
				funcThermiteDone( self )
			end
		end
	end
end

function Module:OnLoad()
	if CLIENT then
		self:RequireHook( "MetworkEntityCreated" )
	end
end

GM.Module:Register( Module )