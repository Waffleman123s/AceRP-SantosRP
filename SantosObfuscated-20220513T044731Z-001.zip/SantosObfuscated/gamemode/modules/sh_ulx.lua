if ulx == nil then return; end;
if ULib == nil then return; end;

local CATEGORY_NAME = "AceRP";

-- Give Base SWEP
function ulx.giveswep( calling_ply, target_plys, classname )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        if v:HasWeapon(classname) then
            v:StripWeapon(classname);
        end

        v:Give( classname );

        table.insert( affected_plys, v )
	end
end
local giveswep = ulx.command( CATEGORY_NAME, "ulx giveswep", ulx.giveswep, "!giveswep" )
giveswep:addParam{ type=ULib.cmds.PlayersArg }
giveswep:addParam{ type=ULib.cmds.StringArg }
giveswep:defaultAccess( ULib.ACCESS_SUPERADMIN )
giveswep:help( "Gives target(s) SWEP. If you already have the weapon, it will update it." )


-- UnJail/Jail
function ulx.santosunjail( calling_ply, target_plys )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        if GAMEMODE.Jail:IsPlayerInJail(v) then
            GAMEMODE.Jail:ReleasePlayerFromJail(v, "Admin Release", true, true);
            v:AddNote("You were released by an admin.");
            calling_ply:AddNote(v:Nick() .. " was released!");
        else
            calling_ply:AddNote(v:Nick() .. " is not in jail!");
        end

        table.insert( affected_plys, v )
	end
end
local santosunjail = ulx.command( CATEGORY_NAME, "ulx santosunjail", ulx.santosunjail, "!santosunjail" )
santosunjail:addParam{ type=ULib.cmds.PlayersArg }
santosunjail:defaultAccess( ULib.ACCESS_SUPERADMIN )
santosunjail:help( "Unjails a character from prison." )

function ulx.santosjail( calling_ply, target_plys, mins, reason )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        if not GAMEMODE.Jail:IsPlayerInJail(v) then
            if GAMEMODE.Jail:PlayerSendPlayerToJailAdmin(calling_ply, v, mins, reason, true) then
                calling_ply:AddNote(v:Nick() .. " was sent to jail!");
            else
                calling_ply:AddNote("Error occured while sending " .. v:Nick() .. " to jail!");
            end
        else
            calling_ply:AddNote(v:Nick() .. " is already in jail!");
        end

        table.insert( affected_plys, v )
	end
end
local santosjail = ulx.command( CATEGORY_NAME, "ulx santosjail", ulx.santosjail, "!santosjail" )
santosjail:addParam{ type=ULib.cmds.PlayersArg }
santosjail:addParam{ type=ULib.cmds.NumArg }
santosjail:addParam{ type=ULib.cmds.StringArg }
santosjail:defaultAccess( ULib.ACCESS_SUPERADMIN )
santosjail:help( "Jails a character." )


function ulx.showinventory( calling_ply, target_plys )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        local inv = v:GetInventory() or {}
        local bankStorage = GAMEMODE.Char:GetCurrentSaveTable( v ) or {}
        if bankStorage.BankItems then
            bankStorage = bankStorage.BankItems; -- Forward push to correct table...
        else
            bankStorage = {};
        end
        calling_ply:ChatPrint(v:Nick() .. "'s Personal Inventory:")
        calling_ply:ChatPrint("Wallet: " .. calling_ply:GetMoney());
        calling_ply:ChatPrint("===================================");
        if #table.GetKeys(inv) > 0 then
            for k, v in pairs(inv) do
                calling_ply:ChatPrint(k .. " x" .. v);
            end
        else
            calling_ply:ChatPrint("Personal inventory is empty!");
        end
        calling_ply:ChatPrint(v:Nick() .. "'s Bank Inventory:")
        calling_ply:ChatPrint("Bank Stored Money: ".. calling_ply:GetBankMoney());
        calling_ply:ChatPrint("===================================");
        if #table.GetKeys(bankStorage) > 0 then
            for k, v in pairs(bankStorage) do
                calling_ply:ChatPrint(k .. " x" .. v);
            end
        else
            calling_ply:ChatPrint("Bank is empty!");
        end

        table.insert( affected_plys, v )
	end
end
local showinventory = ulx.command( CATEGORY_NAME, "ulx showinventory", ulx.showinventory, "!showinventory" )
showinventory:addParam{ type=ULib.cmds.PlayersArg }
showinventory:defaultAccess( ULib.ACCESS_SUPERADMIN )
showinventory:help( "Shows player inventory (WIP)." )

function ulx.showvehicles( calling_ply, target_plys )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]
        local garage = GAMEMODE.TrunkStorage:GetPlayerCars(v);
        calling_ply:ChatPrint(v:Nick() .. "'s Garage:")
        calling_ply:ChatPrint("===================================");
        if #table.GetKeys(garage) > 0 then
            PrintTable(garage);
            -- for k, v in pairs(garage) do
            --     calling_ply:ChatPrint(k .. " x" .. v);
            -- end
        else
            calling_ply:ChatPrint("Garage is empty!");
        end

        table.insert( affected_plys, v )
	end
end
local showvehicles = ulx.command( CATEGORY_NAME, "ulx showvehicles", ulx.showvehicles, "!showvehicles" )
showvehicles:addParam{ type=ULib.cmds.PlayersArg }
showvehicles:defaultAccess( ULib.ACCESS_SUPERADMIN )
showvehicles:help( "Shows player garage (WIP)." )

-- Give Item
function ulx.giveitem( calling_ply, target_plys, amount, itemID )
    if not GAMEMODE.Inv:ValidItem( itemID ) then
        calling_ply:ChatPrint("Sorry, \"" .. itemID .. "\" doesn't exist!");
		return
    end
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        calling_ply:ChatPrint("Gave \"" .. itemID .. "\" x" .. amount);
        GAMEMODE.Inv:GivePlayerItem( v, itemID, amount )

        table.insert( affected_plys, v )
	end
end
local giveitem = ulx.command( CATEGORY_NAME, "ulx giveitem", ulx.giveitem, "!giveitem" )
giveitem:addParam{ type=ULib.cmds.PlayersArg }
giveitem:addParam{ type=ULib.cmds.NumArg }
giveitem:addParam{ type=ULib.cmds.StringArg }
giveitem:defaultAccess( ULib.ACCESS_SUPERADMIN )
giveitem:help( "Gives a character an item." )

-- Permakill 
function ulx.permakill( calling_ply, target_plys )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]
        
        if GAMEMODE.Char:PlayerForceDeleteCharacter(v) then
            print("[AceRP Security] ".. calling_ply.. " has PK'd ".. target_plys)
            calling_ply:ChatPrint("Deleted " .. v:Nick());
            v:KillSilent();
            hook.Call("GamemodeOnPlayerReady", GAMEMODE, v)
            --send them all of their characters in a short format for view in the selection menu
            GAMEMODE.Net:SendPlayerCharacters(v)
        else
            calling_ply:ChatPrint("Failed to delete " .. v:Nick());
        end
    end
end
local permakill = ulx.command( CATEGORY_NAME, "ulx permakill", ulx.permakill, "!pk" )
permakill:addParam{ type=ULib.cmds.PlayersArg }
permakill:defaultAccess( ULib.ACCESS_SUPERADMIN )
permakill:help( "Permakill a player." )

-- Full Heal 
function ulx.fullheal( calling_ply, target_plys )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]
        -- Wake up the player, if needed it.
        if v:IsUncon() then
            v:WakeUp()
        elseif v:IsRagdolled() then
            v:UnRagdoll()
        end
        -- Heal the player.
        GAMEMODE.PlayerDamage:HealPlayerLimbs( v )
        v:SetHealth( v:GetMaxHealth() )
        -- Feed the player.
        GAMEMODE.Needs:AddPlayerNeed( v, "Hunger", 9999 );
        -- Fill the thirst for the player.
        GAMEMODE.Needs:AddPlayerNeed( v, "Thirst", 9999 );
        -- Stamina Reset
        GAMEMODE.Needs:AddPlayerNeed( v, "Stamina", 9999 );
    end
end
local fullheal = ulx.command( CATEGORY_NAME, "ulx fullheal", ulx.fullheal, "!fullheal" )
fullheal:addParam{ type=ULib.cmds.PlayersArg }
fullheal:defaultAccess( ULib.ACCESS_SUPERADMIN )
fullheal:help( "Fully heals, feeds, and no longer hankering for thirst for a player." )

-- Clear Fire 
function ulx.clearfire( calling_ply )
	for k, v in pairs( ents.FindByClass("ent_fire") ) do
		if not IsValid( v ) or v.IsMapProp then continue end
		v:Remove()
	end
end
local clearfire = ulx.command( CATEGORY_NAME, "ulx clearfire", ulx.clearfire, "!clearfire" )
clearfire:defaultAccess( ULib.ACCESS_SUPERADMIN )
clearfire:help( "Clears all fires in the server." )

-- Save All Data 
function ulx.savealldata( calling_ply )
	for k, v in pairs( player.GetAll() ) do
		GAMEMODE.SQL:CommitPlayerDiffs( v:SteamID64() )
	end
end
local savealldata = ulx.command( CATEGORY_NAME, "ulx savealldata", ulx.savealldata, "!savealldata" )
savealldata:defaultAccess( ULib.ACCESS_SUPERADMIN )
savealldata:help( "Saves all player data that are currently connected." )

-- (Un)whitelist Player
function ulx.whitelist( calling_ply, target_plys, jobID, shouldnt_whitelist )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        if jobID == nil or jobID <= 0 then jobID = GAMEMODE.Jobs:GetPlayerJobID(v); end;

        local jobInfo = GAMEMODE.Jobs:GetJobByID(jobID);
        if SERVER then
            if jobInfo == nil or not jobInfo.WhitelistName then
                calling_ply:ChatPrint("Sorry, you cannot (un)whitelist this job!");
                if jobInfo == nil then
                    calling_ply:ChatPrint("Contact a dev, the job info was null. [MODULE : SH_ULX]");
                end
                if not jobInfo.WhitelistName then
                    calling_ply:ChatPrint("Job isn't whitelistable.");
                end
                continue;
            end

            if not shouldnt_whitelist then
                if jobID == GAMEMODE.Jobs:GetPlayerJobID(v) then
                    calling_ply:ChatPrint("Cannot set " .. v:Nick() .. " to " .. GAMEMODE.Jobs:GetJobByID(jobID).Name .. " due to them already being the current job.")
                    continue;
                end

                if GAMEMODE.Jobs:IsPlayerWhitelisted( v, jobID ) then
                    calling_ply:ChatPrint(v:Nick() .. " is already whitelisted to that job!");
                    continue;
                end
                GAMEMODE.Jobs:WhitelistPlayer( v, jobID )
                calling_ply:ChatPrint(v:Nick() .. " is now whitelisted to " .. GAMEMODE.Jobs:GetJobByID(jobID).Name);
            else
                if not GAMEMODE.Jobs:IsPlayerWhitelisted( v, jobID ) then
                    print("Player is already unwhitelisted!");
                    calling_ply:ChatPrint(v:Nick() .. " is not whitelisted to that job!");
                    continue;
                end
                GAMEMODE.Jobs:UnWhitelistPlayer(v, jobID);
                calling_ply:ChatPrint(v:Nick() .. " is now unwhitelisted from " .. GAMEMODE.Jobs:GetJobByID(jobID).Name);
            end
        end
        table.insert( affected_plys, v )
	end
end
local whitelist = ulx.command( CATEGORY_NAME, "ulx whitelist", ulx.whitelist, "!whitelist" )
whitelist:addParam{ type=ULib.cmds.PlayersArg }
whitelist:addParam{ type=ULib.cmds.NumArg, ULib.cmds.optional }
whitelist:addParam{ type=ULib.cmds.BoolArg, invisible=true }
whitelist:defaultAccess( ULib.ACCESS_SUPERADMIN )
whitelist:help( "(Un)Whitelists a character from a job." )
whitelist:setOpposite( "ulx unwhitelist", {_, _, _, true}, "!unwhitelist" )

-- Give/Revoke License
function ulx.givelicense( calling_ply, target_plys, shouldnt_license )
--function ulx.givelicense( calling_ply, target_plys, licenseID, shouldnt_license ) -- Later update...

    local affected_plys = {}
    for i=1, #target_plys do
        local v = target_plys[ i ]
        if not shouldnt_license then
            GAMEMODE.License:GenerateLicense( v )
        else
            local saveTable = GAMEMODE.Char:GetCurrentSaveTable( v )
            if not saveTable then return end
            saveTable.License = nil

            GAMEMODE.Player:SetSharedGameVar( v, "driver_license", "" )
        end
    end

end
local givelicense = ulx.command( CATEGORY_NAME, "ulx givelicense", ulx.givelicense, "!givelicense" )
givelicense:addParam{ type=ULib.cmds.PlayersArg }
--givelicense:addParam{ type=ULib.cmds.StringArg } -- Later update...
givelicense:addParam{ type=ULib.cmds.BoolArg, invisible=true }
givelicense:defaultAccess( ULib.ACCESS_SUPERADMIN )
givelicense:help( "Gives character the license/permit." )
givelicense:setOpposite( "ulx unlicense", {_, _, true}, "!unlicense" )

-- Give Money
function ulx.givemoney( calling_ply, target_plys, amount, shouldnt_givemoney )
    local affected_plys = {}
    for i=1, #target_plys do
        local v = target_plys[ i ]
        if not shouldnt_givemoney then
            v:AddMoney( amount, "Developer command" )
        else
            v:AddMoney(-amount, "Developer command");
        end
    end
end
local givemoney = ulx.command( CATEGORY_NAME, "ulx givemoney", ulx.givemoney, "!givemoney" )
givemoney:addParam{ type=ULib.cmds.PlayersArg }
givemoney:addParam{ type=ULib.cmds.NumArg }
givemoney:addParam{ type=ULib.cmds.BoolArg, invisible=true }
givemoney:defaultAccess( ULib.ACCESS_SUPERADMIN )
givemoney:help( "Gives money to the character." )
givemoney:setOpposite( "ulx takemoney", {_, _, _, false}, "!takemoney" )

-- Remove World Entity
function ulx.removeworldentity( calling_ply )
    local trEnt = calling_ply:GetEyeTrace().Entity
    if IsValid( trEnt ) and not trEnt:IsPlayer() then
        if trEnt.IsMapProp then return end
        trEnt:Remove()
    end
end
local removeworldentity = ulx.command( CATEGORY_NAME, "ulx rent", ulx.removeworldentity, "!rent" )
removeworldentity:defaultAccess( ULib.ACCESS_SUPERADMIN )
removeworldentity:help( "Removes an entity infront of you." )

-- Remove World Entity
function ulx.removeworldentityArea( calling_ply )
    for k, v in pairs(ents.FindInSphere(calling_ply:GetPos(), 200))do
        if IsValid( v ) and not v:IsPlayer() then
            if v.IsMapProp then return end
            v:Remove()
        end
    end
end
local removeworldentityArea = ulx.command( CATEGORY_NAME, "ulx arent", ulx.removeworldentityArea, "!arent" )
removeworldentityArea:defaultAccess( ULib.ACCESS_SUPERADMIN )
removeworldentityArea:help( "Removes entities around you." )


-- Repair
function ulx.repair( calling_ply )
    local ent = calling_ply:GetEyeTrace().Entity
    if not ent then return end

    GAMEMODE.Cars:ResetCarHealth(ent);
    ent:EmitSound("items/smallmedkit1.wav", 70);
    GAMEMODE.Cars:FixVehicleWheels(ent);
    if isfunction(ent.SetFuel) then
        ent:SetFuel(9999)
    end
end
local repair = ulx.command( CATEGORY_NAME, "ulx repair", ulx.repair, "!repair" )
repair:defaultAccess( ULib.ACCESS_SUPERADMIN )
repair:help( "Repairs vehicle in front of yourself." )

-- Change RPName
function ulx.changerpname( calling_ply, target_plys, firstname, lastname )
	if firstname:len() <= 0 or lastname:len() <= 0 then
		calling_ply:PrintMessage( HUD_PRINTCONSOLE, "Cannot set a zero-length name!" )
		return
    end
	if #target_plys > 1 then
		calling_ply:PrintMessage( HUD_PRINTCONSOLE, "You have more than one target, please utilize the !menu instead." )
		return
    end

    local foundPlayer = target_plys[1];
    calling_ply:PrintMessage( HUD_PRINTCONSOLE, "Changing ".. foundPlayer:Nick().. "'s name to ".. firstname.. " ".. lastname.. "!" )
    foundPlayer:AddNote("Your person's name was changed to \"".. firstname .. " " .. lastname .."\" by an admin.");

	local id = GAMEMODE.SQL:GetPlayerPoolID( foundPlayer:SteamID64() )
	GAMEMODE.SQL:UpdateCharacterFirstName( id, foundPlayer:GetCharacterID(), firstname )
	GAMEMODE.SQL:UpdateCharacterLastName( id, foundPlayer:GetCharacterID(), lastname )
	GAMEMODE.Player:SetSharedGameVar( foundPlayer, "name_first", firstname )
	GAMEMODE.Player:SetSharedGameVar( foundPlayer, "name_last", lastname )	
	foundPlayer:GetCharacter().Name.First = firstname 
	foundPlayer:GetCharacter().Name.Last = lastname
end
local changerpname = ulx.command( CATEGORY_NAME, "ulx changerpname", ulx.changerpname, "!changerpname" )
changerpname:addParam{ type=ULib.cmds.PlayersArg }
changerpname:addParam{ type=ULib.cmds.StringArg }
changerpname:addParam{ type=ULib.cmds.StringArg }
changerpname:defaultAccess( ULib.ACCESS_SUPERADMIN )
changerpname:help( "Change a character's roleplay name." )

-- Uncuff
function ulx.uncuff( calling_ply, target_plys )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        v:StripWeapon( "weapon_handcuffed" )
        v:StripWeapon( "weapon_ziptied" )
        calling_ply:PrintMessage( HUD_PRINTCONSOLE, ("Player %s was uncuffed!"):format(v:Nick()) )
    end

end
local uncuff = ulx.command( CATEGORY_NAME, "ulx uncuff", ulx.uncuff, "!uncuff" )
uncuff:addParam{ type=ULib.cmds.PlayersArg }
uncuff:defaultAccess( ULib.ACCESS_SUPERADMIN )
uncuff:help( "Uncuffs a player." )

-- Hard reset 
function ulx.resetmap( calling_ply )
    game.CleanUpMap();
    calling_ply:AddNote("Resetting Map");
    GAMEMODE.Map:SpawnMapProps();
    ulx.reloadnpcs(calling_ply);
end
local resetmap = ulx.command( CATEGORY_NAME, "ulx resetmap", ulx.resetmap, "!resetmap" )
resetmap:defaultAccess( ULib.ACCESS_SUPERADMIN )
resetmap:help( "[WARNING MAY CRASH SERVER] Reseting map" )

-- Reset Carshop
function ulx.resetcarshop( calling_ply )
	GAMEMODE.CarShop.m_tblDoors = {}
	GAMEMODE.CarShop:Initialize()
end
local resetcarshop = ulx.command( CATEGORY_NAME, "ulx resetcarshop", ulx.resetcarshop, "!resetcarshop" )
resetcarshop:defaultAccess( ULib.ACCESS_SUPERADMIN )
resetcarshop:help( "Resets the carshop." )

-- Reset UIs
if SERVER then
    util.AddNetworkString("ruis")
end
function ulx.resetgui( calling_ply )
    net.Start("ruis");
    net.Send(calling_ply);
end
local resetgui = ulx.command( CATEGORY_NAME, "ulx resetuis", ulx.resetgui, "!resetuis" )
resetgui:defaultAccess( ULib.ACCESS_SUPERADMIN )
resetgui:help( "Resets the UIs." )

if CLIENT then
    net.Receive("ruis", function()
        GAMEMODE.Gui:Initialize()
    end)
end

-- Reload NPCs
function ulx.reloadnpcs( calling_ply )
    for k, v in pairs(ents.FindByClass("ent_npc_interactive"))do
        v:Remove();
    end
    GAMEMODE.Map:SpawnNPCs();
end
local reloadnpcs = ulx.command( CATEGORY_NAME, "ulx reloadnpcs", ulx.reloadnpcs, "!reloadnpcs" )
reloadnpcs:defaultAccess( ULib.ACCESS_SUPERADMIN )
reloadnpcs:help( "Reload the NPCs." )

-- Set Skills
function ulx.setskilllevel( calling_ply, target_plys, level, skillID )
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        GAMEMODE.Skills:SetPlayerXP( v, skillID, GAMEMODE.Skills:GetXPForLevel(skillID, level) )

        table.insert( affected_plys, v )
	end
end
local setskilllevel = ulx.command( CATEGORY_NAME, "ulx setskilllevel", ulx.setskilllevel, "!setskilllevel" )
setskilllevel:addParam{ type=ULib.cmds.PlayersArg }
setskilllevel:addParam{ type=ULib.cmds.NumArg }
setskilllevel:addParam{ type=ULib.cmds.StringArg, ULib.cmds.takeRestOfLine }
setskilllevel:defaultAccess( ULib.ACCESS_SUPERADMIN )
setskilllevel:help( "Sets a character's skill level." )

function ulx.giveskillexp( calling_ply, target_plys, experience, skillID)
    local affected_plys = {}
	for i=1, #target_plys do
        local v = target_plys[ i ]

        GAMEMODE.Skills:GivePlayerXP( v, skillID, experience )

        table.insert( affected_plys, v )
	end
end
local giveskillexp = ulx.command( CATEGORY_NAME, "ulx giveskillexp", ulx.giveskillexp, "!giveskillexp" )
giveskillexp:addParam{ type=ULib.cmds.PlayersArg }
giveskillexp:addParam{ type=ULib.cmds.NumArg }
giveskillexp:addParam{ type=ULib.cmds.StringArg, ULib.cmds.takeRestOfLine }
giveskillexp:defaultAccess( ULib.ACCESS_SUPERADMIN )
giveskillexp:help( "Gives a character skill experience." )

-- Stop Bank Alarm
function ulx.stopalarm( calling_ply )
	GAMEMODE.Module:GetModule( "BankRobberyServer" ):StopAlarms()
end
local stopalarm = ulx.command( CATEGORY_NAME, "ulx stopalarm", ulx.stopalarm, "!stopalarm" )
clearfire:defaultAccess( ULib.ACCESS_SUPERADMIN )
clearfire:help( "Stops the bank alarm" )