local Module = {}
Module.Name = "Logs"

function Module:Log(str, nolog)
	local curName = "maze_logs/" .. os.date("%m_%d_%y") .. ".txt"
	local s = "[" .. os.date("%H:%M:%S") .. "] " .. str .. "\n"
	-- file.Append(curName, s)
	-- ServerLog(s)

	-- self:LogDiscord(str, nolog)
	--serverguard.plugin.FindByID("logs"):Log( s )
end

function Module:LogDiscord(str, nolog)
	local mod = (GM or GAMEMODE).Module:GetModule("Discord Logs")

	if mod and not nolog then
		mod:Log(str)
	end
end

function Module:PlayerConnect(strName)
	self:Log(("Player %s is connecting"):format(strName))
end

function Module:GamemodePlayerDeleteCharacter(pPlayer, intCharID)
	self:Log(("Player %s (%s) DELETED a character - %s %s"):format(pPlayer:Nick(), pPlayer:SteamID(), GAMEMODE.Char:GetPlayerCharacters(pPlayer)[intCharID].Name.First, GAMEMODE.Char:GetPlayerCharacters(pPlayer)[intCharID].Name.Last))
end

function Module:GamemodePlayerCreateCharacter(pPlayer, intCharID)
	self:Log(("Player %s (%s) CREATED a character - %s %s"):format(pPlayer:Nick(), pPlayer:SteamID(), GAMEMODE.Char:GetPlayerCharacters(pPlayer)[intCharID].Name.First, GAMEMODE.Char:GetPlayerCharacters(pPlayer)[intCharID].Name.Last))
end

function Module:GamemodePlayerSelectCharacter(pPlayer)
	local cash = pPlayer:GetMoney()
	local cashb = pPlayer:GetBankMoney()
	if not cash or not cashb then return end
	cash = cash + cashb
	pPlayer.m_intLogStartCash = cash
	self:Log(("Player %s (%s) selected a character - Total Money: $%s"):format(pPlayer:Nick(), pPlayer:SteamID(), pPlayer.m_intLogStartCash))
end

function Module:PlayerDisconnected(pPlayer)
	if not IsValid(pPlayer) then return end
	local cash = pPlayer:GetMoney()
	local cashb = pPlayer:GetBankMoney()
	if not cash or not cashb then return end
	cash = cash + cashb
	local diff = cash - pPlayer.m_intLogStartCash
	self:Log(("Player %s (%s) has left the game - Total Money: $%s (%s change)"):format(pPlayer:Nick(), pPlayer:SteamID(), cash, diff))
end

function Module:PlayerDroppedItem(pPlayer, strItemID, bOwnerless, ent)
	self:Log(("Player %s (%s) dropped a(n) %s%s"):format(pPlayer:Nick(), pPlayer:SteamID(), strItemID, bOwnerless and " (Ownerless)" or ""))
end

function Module:GamemodePlayerTookItem(pPlayer, eEnt)
	if not IsValid(eEnt) or not eEnt.ItemData then return end
	self:Log(("Player %s (%s) picked up a(n) %s"):format(pPlayer:Nick(), pPlayer:SteamID(), eEnt.ItemData.Name))
end

function Module:GamemodePlayerDroppedMoney(pPlayer, intAmount, bOwnerless)
	self:Log(("Player %s (%s) dropped $%s%s"):format(pPlayer:Nick(), pPlayer:SteamID(), intAmount, bOwnerless and " (Ownerless)" or ""))
end

function Module:GamemodePlayerCraftedItem(pPlayer, strItemID)
	self:Log(("Player %s (%s) crafted a(n) %s"):format(pPlayer:Nick(), pPlayer:SteamID(), strItemID))
end

function Module:GamemodePlayerBuyNPCItem(pPlayer, strNPCID, strItemID, intAmount)
	self:Log(("Player %s (%s) bought %s %s"):format(pPlayer:Nick(), pPlayer:SteamID(), intAmount, strItemID))
end

function Module:GamemodePlayerSellNPCItem(pPlayer, strNPCID, strItemID, intAmount)
	self:Log(("Player %s (%s) sold %s %s"):format(pPlayer:Nick(), pPlayer:SteamID(), intAmount, strItemID))
end

function Module:GamemodePlayerBuyCar(pPlayer, strCarUID)
	self:Log(("Player %s (%s) bought a new car (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), strCarUID))
end

function Module:GamemodePlayerSellCar(pPlayer, strCarUID)
	self:Log(("Player %s (%s) sold a car (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), strCarUID))
end

function Module:PlayerSpawnedVehicle(pPlayer, entCar)
	if not IsValid(entCar) or not entCar.CarData then return end
	self:Log(("Player %s (%s) spawned a vehicle (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), entCar.CarData.Name))
end

function Module:GamemodePlayerCarRemoved(pPlayer, entCar)
	if not IsValid(pPlayer) then return end
	if not IsValid(entCar) or not entCar.CarData then return end
	self:Log(("Player %s (%s) had their vehicle removed (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), entCar.CarData.Name))
end

function Module:GamemodePlayerQuitJob(pPlayer, intJobID)
	self:Log(("Player %s (%s) quit job %s"):format(pPlayer:Nick(), pPlayer:SteamID(), GAMEMODE.Jobs:GetJobByID(intJobID).Name))
end

function Module:GamemodePlayerSetJob(pPlayer, intJobID)
	self:Log(("Player %s (%s) joined job %s"):format(pPlayer:Nick(), pPlayer:SteamID(), GAMEMODE.Jobs:GetJobByID(intJobID).Name))
end

function Module:GamemodePlayerBuyProperty(pPlayer, strName)
	self:Log(("Player %s (%s) bought a new property (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), strName))
end

function Module:GamemodePlayerSellProperty(pPlayer, strName)
	self:Log(("Player %s (%s) sold a property (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), strName))
end

function Module:GamemodeOnPlayerJailBreak(pPlayer)
	self:Log(("Player %s (%s) broke out of jail!"):format(pPlayer:Nick(), pPlayer:SteamID()))
end

function Module:GamemodePlayerJailed(pBeingJailed, pPlayer, intDuration, strReason)
	self:Log(("Player %s (%s) was jailed by player %s (%s) for %s seconds - Reason: %s"):format(pBeingJailed:Nick(), pBeingJailed:SteamID(), pPlayer:Nick(), pPlayer:SteamID(), intDuration, strReason))
end

function Module:GamemodePlayerReleasedFromJail(pJailedPlayer, pPlayer, strReason)
	self:Log(("Player %s (%s) was freed from jail by player %s (%s) - Reason: %s"):format(pJailedPlayer:Nick(), pJailedPlayer:SteamID(), pPlayer:Nick(), pPlayer:SteamID(), strReason))
end

function Module:GamemodePlayerBailedFromJail(pPlayer, pPayingPlayer, bailPrice)
	self:Log(("Player %s (%s) was bailed out of jail by player %s (%s) - Cost: %s"):format(pPlayer:Nick(), pPlayer:SteamID(), pPayingPlayer:Nick(), pPayingPlayer:SteamID(), bailPrice))
end

function Module:GamemodePlayerWarrantPlayer(pPlayer, pWarrantPlayer, strReason)
	self:Log(("Player %s (%s) issued a warrant for player %s (%s) - Reason: %s"):format(type(pPlayer) == 'string' and pPlayer or pPlayer:Nick(), type(pPlayer) == 'string' and "System/Console" or pPlayer:SteamID(), pWarrantPlayer:Nick(), pWarrantPlayer:SteamID(), strReason))
end

function Module:GamemodePlayerClearWarrant(pPlayer, pWarrantPlayer)
	self:Log(("Player %s (%s) removed a warrant from player %s (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), pWarrantPlayer:Nick(), pWarrantPlayer:SteamID()))
end

function Module:GamemodeOnPlayerLeaveJail(pPlayer, strReason)
	self:Log(("Player %s (%s) left jail (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), strReason))
end

function Module:GamemodeCarShopRepair(pPlayer, entCar)
	self:Log(("Player %s (%s) repaired their vehicle (%s) at maze customs"):format(pPlayer:Nick(), pPlayer:SteamID(), entCar.CarData.Name))
end

function Module:GamemodePlayerFriskRandomItem(pPlayer, pTarget, strName, intAmount)
	self:Log(("Player %s (%s) frisked %s %s from ragdolled player %s (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), intAmount, strName, pTarget:Nick(), pTarget:SteamID()))
end

function Module:GamemodePlayerFriskPlayer(pPlayer, pTarget)
	self:Log(("Player %s (%s) is frisking player %s (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), pTarget:Nick(), pTarget:SteamID()))
end

function Module:GamemodePlayerExecutePlayer(pPlayer, pDamageInfo)
	local attacker = pDamageInfo:GetInflictor()

	if IsValid(attacker) and attacker:IsPlayer() then
		self:Log(("Player %s (%s) was executed by player %s (%s)"):format(pPlayer:Nick(), pPlayer:SteamID(), attacker:Nick(), attacker:SteamID()))
	else
		self:Log(("Player %s (%s) was executed by an unknown player"):format(pPlayer:Nick(), pPlayer:SteamID()))
	end
end

function Module:GamemodePlayerTakeDamage(eEnt, pDamageInfo)
	if not IsValid(eEnt) or not eEnt:IsPlayer() then return end
	local attacker = pDamageInfo:GetInflictor()

	if IsValid(attacker) and attacker:IsVehicle() and attacker.CarData and IsValid(attacker:GetPlayerOwner()) then
		local driver = attacker:GetDriver()

		if IsValid(driver) then
			self:Log(("Player %s (%s) was run over by player %s (%s) driving a %s owned by player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), driver:Nick(), driver:SteamID(), attacker.CarData.Name, attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		else
			self:Log(("Player %s (%s) took damage from vehicle %s owned by player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), attacker.CarData.Name, attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		end
	elseif attacker.IsItem and IsValid(attacker:GetPlayerOwner()) then
		self:Log(("Player %s (%s) took damage from dropped item %s owned by player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), attacker.ItemData.Name, attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
	else
		attacker = pDamageInfo:GetAttacker()
		if not IsValid(attacker) then return end

		if attacker:IsPlayer() then
			self:Log(("Player %s (%s) took damage from player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), attacker:Nick(), attacker:SteamID(), pDamageInfo:GetDamage()))
		else
			self:Log(("Player %s (%s) took damage from an unknown source - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), pDamageInfo:GetDamage()))
		end
	end
end

function Module:GamemodePlayerTakeFatalDamage(eEnt, pDamageInfo)
	if not IsValid(eEnt) or not eEnt:IsPlayer() then return end
	local attacker = pDamageInfo:GetInflictor()

	if IsValid(attacker) and attacker:IsVehicle() and attacker.CarData and IsValid(attacker:GetPlayerOwner()) then
		local driver = attacker:GetDriver()

		if IsValid(driver) then
			self:Log(("Player %s (%s) was fatally run over by player %s (%s) driving a %s owned by player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), driver:Nick(), driver:SteamID(), attacker.CarData.Name, attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		else
			self:Log(("Player %s (%s) took fatal damage from vehicle %s owned by player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), attacker.CarData.Name, attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		end
	elseif attacker.IsItem and IsValid(attacker:GetPlayerOwner()) then
		self:Log(("Player %s (%s) took fatal damage from dropped item %s owned by player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), attacker.ItemData.Name, attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
	else
		attacker = pDamageInfo:GetAttacker()
		if not IsValid(attacker) then return end

		if attacker:IsPlayer() then
			self:Log(("Player %s (%s) took fatal damage from player %s (%s) - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), attacker:Nick(), attacker:SteamID(), pDamageInfo:GetDamage()))
		else
			self:Log(("Player %s (%s) took fatal damage from an unknown source - Amount: %s"):format(eEnt:Nick(), eEnt:SteamID(), pDamageInfo:GetDamage()))
		end
	end
end

function Module:GamemodeCarTakeDamage(entCar, pDamageInfo, intScaledDamage)
	local attacker = pDamageInfo:GetAttacker()
	local name = entCar.CarData and entCar.CarData.Name or "Unknown vehicle"

	if not IsValid(attacker) then
		self:Log(("Vehicle %s owned by player %s (%s) took damage from an unknown source - Amount: %s"):format(name, entCar:GetPlayerOwner():Nick(), entCar:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
	else
		if attacker.IsItem then
			self:Log(("Vehicle %s owned by player %s (%s) took damage from a dropped item (%s) owned by player %s (%s) - Amount: %s"):format(name, entCar:GetPlayerOwner():Nick(), entCar:GetPlayerOwner():SteamID(), attacker.ItemData and attacker.ItemData.Name or "Unkown item", attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		elseif attacker:IsPlayer() then
			self:Log(("Vehicle %s owned by player %s (%s) took damage from player %s (%s) - Amount: %s"):format(name, entCar:GetPlayerOwner():Nick(), entCar:GetPlayerOwner():SteamID(), attacker:Nick(), attacker:SteamID(), pDamageInfo:GetDamage()))
		elseif attacker:IsVehicle() then
			self:Log(("Vehicle %s owned by player %s (%s) took damage from a vehicle (%s) owned by player %s (%s) - Amount: %s"):format(name, entCar:GetPlayerOwner():Nick(), entCar:GetPlayerOwner():SteamID(), attacker.CarData and attacker.CarData.Name or "Unknown vehicle", attacker:GetPlayerOwner():Nick(), attacker:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		else
			self:Log(("Vehicle %s owned by player %s (%s) took damage from an unknown source - Amount: %s"):format(name, entCar:GetPlayerOwner():Nick(), entCar:GetPlayerOwner():SteamID(), pDamageInfo:GetDamage()))
		end
	end
end

function Module:GamemodeDoorRam(pPlayer, entTarget)
end

function Module:GamemodeFireAxeDoor(pPlayer, entTarget)
end

function Module:OnLoad()
	if not file.IsDir("maze_logs", "DATA") then
		file.CreateDir("maze_logs")
	end

	self:Log("Server is starting up... \n\n\n", true)
	self:RequireHook"GamemodePlayerSelectCharacter"
	self:RequireHook"PlayerConnect"
	self:RequireHook"PlayerDisconnected"
	self:RequireHook"GamemodePlayerTakeDamage"
	self:RequireHook"GamemodePlayerTakeFatalDamage"
	self:RequireHook"PlayerDroppedItem"
	self:RequireHook"GamemodePlayerTookItem"
	self:RequireHook"GamemodePlayerDroppedMoney"
	self:RequireHook"GamemodePlayerCraftedItem"
	self:RequireHook"GamemodePlayerBuyNPCItem"
	self:RequireHook"GamemodePlayerSellNPCItem"
	self:RequireHook"GamemodePlayerBuyCar"
	self:RequireHook"GamemodePlayerSellCar"
	self:RequireHook"PlayerSpawnedVehicle"
	self:RequireHook"GamemodePlayerCarRemoved"
	self:RequireHook"GamemodePlayerQuitJob"
	self:RequireHook"GamemodePlayerSetJob"
	self:RequireHook"GamemodePlayerBuyProperty"
	self:RequireHook"GamemodePlayerSellProperty"
	self:RequireHook"GamemodeOnPlayerJailBreak"
	self:RequireHook"GamemodePlayerJailed"
	self:RequireHook"GamemodePlayerReleasedFromJail"
	self:RequireHook"GamemodePlayerBailedFromJail"
	self:RequireHook"GamemodePlayerWarrantPlayer"
	self:RequireHook"GamemodePlayerClearWarrant"
	self:RequireHook"GamemodeOnPlayerLeaveJail"
	self:RequireHook"GamemodeCarTakeDamage"
	--self:RequireHook "GamemodeCarTakeWheelDamage"
	self:RequireHook"GamemodeCarShopRepair"
	--self:RequireHook "onLockpickCompleted"
	--self:RequireHook "GamemodeDoorRam"
	--self:RequireHook "GamemodeFireAxeDoor"
	self:RequireHook"GamemodePlayerFriskRandomItem"
	self:RequireHook"GamemodePlayerFriskPlayer"
	self:RequireHook"GamemodePlayerExecutePlayer"
	self:RequireHook"GamemodePlayerDeleteCharacter"
	self:RequireHook"GamemodePlayerCreateCharacter"
end

GM.Module:Register(Module)