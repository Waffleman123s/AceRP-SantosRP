--[[
	Name: sv_bank_robbery.lua
	For: Project Steele
	By: Christopher Steele
]]--

local Module = {}
Module.Name = "BankRobberyServer"

-- Alarm System
-- ----------------------------------------------------------------
Module.m_bAlarmsEnabled = true
Module.m_bAlarmsOn = false
function Module:StartAlarms()
	if not self.m_bAlarmsEnabled then return false end
	self.m_bAlarmsOn = true
	timer.Create( "BankRobberyAlarm", 2, 0, function()
		for k, v in pairs( GAMEMODE.Map:GetMapProp("bankServer").m_tblAlarmPoints ) do
			sound.Play( "ambient/alarms/klaxon1.wav", v, 100, 100, 1 )
		end
	end )

	GAMEMODE.Jobs:GetJobByID( JOB_POLICE ):TextAllPlayers( "Dispatch ", "10-90 Bank alarm" )
	return true
end

function Module:StopAlarms(override)
	if not self.m_bAlarmsOn then return false end
	self.m_bAlarmsOn = false
	timer.Destroy( "BankRobberyAlarm" )
	return true
end

hook.Add("PostCleanupMap", "GM:Bank:Reload", function()
	local mod = GAMEMODE.Module:GetModule( "BankRobberyServer" )
	mod.m_bAlarmsOn = false
	timer.Destroy( "BankRobberyAlarm" )
end)


function Module:SetAlarmsEnabled( bEnable )
	if not bEnable then self:StopAlarms() end
	self.m_bAlarmsEnabled = bEnable
end

function Module:GetAlarmsEnabled()
	return self.m_bAlarmsEnabled
end

-- Loot Spawning
-- ----------------------------------------------------------------
Module.m_tblSpawnedLoot = {}
function Module:GamemodeBankRobbery_VaultDoorOpen( bOpen )
	if bOpen then
		self:SpawnLoot()
	else
		timer.Simple( 60, function()
			self:RemoveLoot()
		end )
	end
end

function Module:SpawnLoot()
	if self:HasSpawnedLoot() then return end
	local prop = GAMEMODE.Map:GetMapProp( "bankServer" )

	local count, num = math.random( GAMEMODE.Config.BankRobbery_DepositBoxSpawnAmount.min, GAMEMODE.Config.BankRobbery_DepositBoxSpawnAmount.max ), 0
	for k, v in RandomPairs( prop.m_tblLootSpawns.DepositBoxes ) do
		if num >= count then break end
		num = num +1

		--Spawn a deposit box
		local ent = ents.Create( "ent_deposit_box" )
		ent:SetPos( v.pos )
		ent:SetAngles( v.ang )
		ent.BlockPhysGun = true
		ent:Spawn()
		ent:Activate()
		ent:SetDTBool( GAMEMODE.Map.DT_IS_MAP_PROP, true )
		table.insert( self.m_tblSpawnedLoot, ent )
	end
	
	for k, v in pairs( prop.m_tblLootSpawns.Money ) do
		local ent = ents.Create( "ent_vault_money" )
		ent:SetPos( v.pos )
		ent:SetAngles( v.ang )
		ent.BlockPhysGun = true
		ent:Spawn()
		ent:Activate()
		ent:SetDTBool( GAMEMODE.Map.DT_IS_MAP_PROP, true )
		ent:Setup( math.random(GAMEMODE.Config.BankRobbery_CashSpawnAmount.min, GAMEMODE.Config.BankRobbery_CashSpawnAmount.max) )
		table.insert( self.m_tblSpawnedLoot, ent )		
	end
end

function Module:RemoveLoot()
	for k, v in pairs( self.m_tblSpawnedLoot ) do
		if not IsValid( v ) then continue end
		v:Remove()
	end
	self.m_tblSpawnedLoot = {}
end

function Module:HasSpawnedLoot()
	for k, v in pairs( self.m_tblSpawnedLoot ) do
		if IsValid( v ) then return true end	
	end
	return false
end

-- Door Setup
-- ----------------------------------------------------------------
function Module:InitVaultLockDoor()
	local prop = GAMEMODE.Map:GetMapProp( "bankServer" )
	local propSH = GAMEMODE.Map:GetMapProp( "bankShared" )

	local door
	for k, v in pairs( ents.GetAll() ) do
		if v:MapCreationID() == prop.m_intVaultLockMapID then
			door = v
			break
		end
	end

	if not IsValid( door ) then error( "BankRobbery: Unable to locate vault door!" ) return end
	self.m_entVaultLockDoor = door
end

function Module:GetVaultLockDoor()
	return self.m_entVaultLockDoor
end

function Module:InitVaultDoor()
	local prop = GAMEMODE.Map:GetMapProp( "bankServer" )
	local propSH = GAMEMODE.Map:GetMapProp( "bankShared" )

	local door
	for k, v in pairs( ents.GetAll() ) do
		if v:MapCreationID() == prop.m_intVaultMapID then
			door = v
			break
		end
	end

	if not IsValid( door ) then error( "BankRobbery: Unable to locate vault door!" ) return end
	self.m_entVaultDoor = door

	--Setup thermite functions for the vault door
	local funcCanAttach = function()
		return true
	end
	local funcThermiteDone = function()
		self.m_entVaultDoor:EmitSound( "ambient/materials/metal_stress".. math.random(1, 5).. ".wav", 60 )
	end
	GAMEMODE.Module:GetModule( "BankRobberyShared" ):InstallThermiteFunctions(
		self.m_entVaultDoor,
		propSH.m_tblVaultThermitePoints,
		propSH.m_tblVaultThermiteBurnTime.min,
		propSH.m_tblVaultThermiteBurnTime.max,
		funcCanAttach,
		funcThermiteDone
	)
end

function Module:GetVaultDoor()
	return self.m_entVaultDoor
end

function Module:InitBankDoor()
	local prop = GAMEMODE.Map:GetMapProp( "bankServer" )
	local door
	for k, v in pairs( ents.GetAll() ) do
		if v:MapCreationID() == prop.m_intBankDoorID then
			door = v
			break
		end
	end

	if not IsValid( door ) then error( "BankRobbery: Unable to locate bank door!" ) return end
	self.m_entBankDoor = door
end

function Module:GetBankDoor()
	return self.m_entBankDoor
end

-- Load
-- ----------------------------------------------------------------
function Module:InitPostEntity()
	local prop = GAMEMODE.Map:GetMapProp( "bankServer" )
	local propSH = GAMEMODE.Map:GetMapProp( "bankShared" )
	if not prop or not propSH then return end

	self:RequireHook( "canLockpick" )
	self:RequireHook( "GamemodeCanDoorRam" )
	self:RequireHook( "GamemodeCanFireAxeDoor" )
	self:RequireHook( "GamemodeBankRobbery_VaultDoorOpen" )
	
	self:InitVaultLockDoor()
	self:InitVaultDoor()
	self:InitBankDoor()
end

function Module:canLockpick( pPlayer, eEnt, tblTrace )
	if eEnt == self.m_entVaultDoor or eEnt == self.m_entBankDoor then return false end
end

function Module:GamemodeCanDoorRam( pPlayer, eEnt )
	if eEnt == self.m_entVaultDoor or eEnt == self.m_entBankDoor then return false end
end

function Module:GamemodeCanFireAxeDoor( pPlayer, eEnt )
	if eEnt == self.m_entVaultDoor or eEnt == self.m_entBankDoor then return false end
end

function Module:OnLoad()
	self:RequireHook( "InitPostEntity" )
end

GM.Module:Register( Module )