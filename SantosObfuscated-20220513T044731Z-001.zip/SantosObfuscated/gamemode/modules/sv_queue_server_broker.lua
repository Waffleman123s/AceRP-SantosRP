local Module = {}
Module.Name = "QueueServerBroker"
Module.m_tblTokens = {}
Module.m_tblConnecting = {}
Module.m_varEnabled = CreateConVar( "srp_queue_server_enabled", "1", FCVAR_NONE, "Enable the queue server broker" )

function Module:AddToken( strToken, intTimeout )
	self.m_tblTokens[strToken] = intTimeout
	timer.Simple( math.max(intTimeout -os.time(), 0), function()
		self.m_tblTokens[strToken] = nil
	end )
end

function Module:IsActive()
	if self.m_varEnabled:GetInt() ~= 1 then return end
	return self:GetPlayerCount() >= GAMEMODE.Config.QueueServerEnable
end

function Module:CheckPassword( strSteamID64, strIP, strSVPass, strCLPass, strName )
	if self:IsActive() then
		if not self.m_tblTokens[strCLPass] or os.time() > self.m_tblTokens[strCLPass] then
			return false, "The player queue is currently active for this server. Please connect to the queue server instead."
		end
		if self.m_tblTokens[strCLPass] then
			self.m_tblConnecting[strSteamID64] = { token = strCLPass, ip = strIP, name = strName }
			self.m_tblTokens[strCLPass] = nil
		end
	end

	self.m_tblConnecting[strSteamID64] = { token = strCLPass, ip = strIP, name = strName }
end

function Module:player_disconnect( tblData )
	local sid64 = util.SteamIDTo64( tblData.networkid )
	self.m_tblConnecting[sid64] = nil
end

function Module:PlayerInitialSpawn( pPlayer )
	self.m_tblConnecting[pPlayer:SteamID64()] = nil
end

function Module:GetConnecting()
	return self.m_tblConnecting
end

function Module:GetPlayerCount()
	local playing = {}
	for k, v in pairs( player.GetAll() ) do
		playing[v:SteamID64()] = true
	end
	for k, v in pairs( self:GetConnecting() ) do
		playing[k] = true
	end
	return table.Count( playing )
end

function Module:OnLoad()
	if not GM.Config.EnableQueueBroker then return end
	
	gameevent.Listen "player_disconnect"
	self:RequireHook( "CheckPassword" )
	self:RequireHook( "player_disconnect" )
	self:RequireHook( "PlayerInitialSpawn" )

	GM.ServerNet:RegisterEventHandle( "api", "get_connect_token", function( pClientSocket, packet )
		local token = packet:ReadNTString()
		local timeout = tonumber( packet:ReadNTString() )
		local status = isstring( token ) and token:len() > 0
		if status then status = isnumber( timeout ) and timeout > os.time() end
		if status then
			print( self.Name.. "::AddToken-".. token )
			self:AddToken( token, timeout )
		end
		
		--Send to api server
		local resp = BromPacket()
		if not status then
			resp:WriteLine( util.TableToJSON({retcode = "input error"}) )
		else
			resp:WriteLine( util.TableToJSON({retcode = "success", token = token, timeout = timeout}) )
		end
		pClientSocket:Send( resp, true )
	end )

	GM.ServerNet:RegisterEventHandle( "api", "get_full_player_count", function( pClientSocket, packet )
		--Send to api server
		local resp = BromPacket()
		resp:WriteLine( util.TableToJSON({retcode = "success", count = self:GetPlayerCount()}) )
		pClientSocket:Send( resp, true )
	end )
end

GM.Module:Register( Module )