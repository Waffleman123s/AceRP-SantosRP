--[[
	Name: sv_car_radios.lua
	For: SantosRP
	By: Ultra
]]--

local Module = {}
Module.Name = "car_radios_sv"

function Module:PlayStation( entVeh, intStationID, bIsCustom )
	local modSH = GAMEMODE.Module:GetModule( "car_radios_sh" )

	if not bIsCustom and not modSH.m_tblStations[intStationID] then return end
	if entVeh.m_intCurrentRadioStation == intStationID then return end
	entVeh.m_intCurrentRadioStation = intStationID
	self:NetworkCarRadioPlay( entVeh, intStationID, bIsCustom )
end

function Module:StopStation( entVeh )
	entVeh.m_intCurrentRadioStation = nil
	self:NetworkCarRadioStop( entVeh )
end

function Module:GamemodeOnPlayerReady( pPlayer )
	self:SendFullCarRadioUpdate( pPlayer )
end

function Module:PlayerLeaveVehicle( pPlayer, entVehicle )
	if entVehicle.m_intCurrentRadioStation then
		self:StopStation( entVehicle )
	end
end

--Netcode
function Module:NetworkCarRadioPlay( entVeh, intStationID, bIsCustom )
	if bIsCustom then
		self:NetworkCarRadioPlayCustom( entVeh, intStationID )
		return
	end
	
	GAMEMODE.Net:NewEvent( "cradio", "p" )
		net.WriteEntity( entVeh )
		net.WriteUInt( intStationID, 32 )
	GAMEMODE.Net:BroadcastEvent()
end

function Module:NetworkCarRadioPlayCustom( entVeh, intStationID )
	GAMEMODE.Net:NewEvent( "cradio", "pc" )
		net.WriteEntity( entVeh )
		net.WriteUInt( intStationID, 32 )
	GAMEMODE.Net:BroadcastEvent()
end

function Module:NetworkCarRadioStop( entVeh )
	GAMEMODE.Net:NewEvent( "cradio", "s" )
		net.WriteEntity( entVeh )
	GAMEMODE.Net:BroadcastEvent()
end

function Module:SendFullCarRadioUpdate( pPlayer )
	local foundCars = {}
	for k, v in pairs( ents.FindByClass("prop_vehicle_jeep") ) do
		if not v.m_intCurrentRadioStation then continue end
		foundCars[#foundCars +1] = v
	end

	GAMEMODE.Net:NewEvent( "cradio", "fupd" )
		net.WriteUInt( #foundCars, 16 )

		for k, v in pairs( foundCars ) do
			net.WriteEntity( v )
			net.WriteUInt( v.m_intCurrentRadioStation, 32 )
		end
	GAMEMODE.Net:FireEvent( pPlayer )
end

function Module:OnLoad()
	self:RequireHook( "PlayerLeaveVehicle" )
	self:RequireHook( "GamemodeOnPlayerReady" )

	GM.Net:AddProtocol( "cradio", 10 )
	GM.Net:RegisterEventHandle( "cradio", "rp", function( intMsgLen, pPlayer )
		local veh = pPlayer:GetVehicle()
		if not IsValid( veh ) or veh:GetDriver() ~= pPlayer then return end
		if veh:GetClass() ~= "prop_vehicle_jeep" then return end

		Module:PlayStation( veh, net.ReadUInt(32) )
	end )

	GM.Net:RegisterEventHandle( "cradio", "rpc", function( intMsgLen, pPlayer )
		if not GAMEMODE.Player:GetPlayerVIPFlag( pPlayer, "custom_radio" ) then return end

		local veh = pPlayer:GetVehicle()
		if not IsValid( veh ) or veh:GetDriver() ~= pPlayer then return end
		if veh:GetClass() ~= "prop_vehicle_jeep" then return end

		Module:PlayStation( veh, net.ReadUInt(32), true )
	end )

	GM.Net:RegisterEventHandle( "cradio", "rs", function( intMsgLen, pPlayer )
		local veh = pPlayer:GetVehicle()
		if not IsValid( veh ) or veh:GetDriver() ~= pPlayer then return end
		if veh:GetClass() ~= "prop_vehicle_jeep" then return end

		Module:StopStation( veh )
	end )
end

GM.Module:Register( Module )