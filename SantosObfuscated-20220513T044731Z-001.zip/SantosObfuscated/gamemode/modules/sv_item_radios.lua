--[[
	Name: sv_item_radios.lua
	For: SantosRP
	By: Ultra
]]--

local Module = {}
Module.Name = "item_radios_sv"

function Module:PlayStation( entProp, intStationID, bIsCustom )
	local modSH = GAMEMODE.Module:GetModule( "item_radios_sh" )

	if not bIsCustom and not modSH.m_tblStations[intStationID] then return end
	if entProp.m_intCurrentRadioStation == intStationID then return end
	entProp.m_intCurrentRadioStation = intStationID

	self:NetworkPropRadioPlay( entProp, intStationID, bIsCustom )
end

function Module:StopStation( entProp )
	entProp.m_intCurrentRadioStation = nil
	self:NetworkPropRadioStop( entProp )
end

function Module:GamemodeOnPlayerReady( pPlayer )
	self:SendFullPropRadioUpdate( pPlayer )
end

--Netcode
function Module:NetworkPropRadioPlay( entRadio, intStationID, bIsCustom )
	if bIsCustom then
		self:NetworkPropRadioPlayCustom( entRadio, intStationID )
		return
	end
	
	GAMEMODE.Net:NewEvent( "iradio", "p" )
		net.WriteEntity( entRadio )
		net.WriteUInt( intStationID, 32 )
	GAMEMODE.Net:BroadcastEvent()
end

function Module:NetworkPropRadioPlayCustom( entRadio, intStationID )
	GAMEMODE.Net:NewEvent( "iradio", "pc" )
		net.WriteEntity( entRadio )
		net.WriteUInt( intStationID, 32 )
	GAMEMODE.Net:BroadcastEvent()
end

function Module:NetworkPropRadioStop( entRadio )
	GAMEMODE.Net:NewEvent( "iradio", "s" )
		net.WriteEntity( entRadio )
	GAMEMODE.Net:BroadcastEvent()
end

function Module:SendFullPropRadioUpdate( pPlayer )
	local foundRadios = {}
	for k, v in pairs( ents.FindByClass("ent_itemradio") ) do
		if not v.m_intCurrentRadioStation then continue end
		foundRadios[#foundRadios +1] = v
	end

	GAMEMODE.Net:NewEvent( "iradio", "fupd" )
		net.WriteUInt( #foundRadios, 16 )

		for k, v in pairs( foundRadios ) do
			net.WriteEntity( v )
			net.WriteUInt( v.m_intCurrentRadioStation, 32 )
		end
	GAMEMODE.Net:FireEvent( pPlayer )
end

function Module:NetworkOpenRadioMenu( pPlayer )
	GAMEMODE.Net:NewEvent( "iradio", "m" )
		net.WriteEntity( entRadio )
	GAMEMODE.Net:FireEvent( pPlayer )
end

function Module:OnLoad()
	self:RequireHook( "GamemodeOnPlayerReady" )
	GM.Net:AddProtocol( "iradio", 11 )

	GM.Net:RegisterEventHandle( "iradio", "rp", function( intMsgLen, pPlayer )
		local ent = net.ReadEntity()
		if not IsValid( ent ) or ent:GetPos():Distance( pPlayer:GetPos() ) > 200 then return end
		if ent:GetClass() ~= "ent_itemradio" then return end

		Module:PlayStation( ent, net.ReadUInt(32) )
	end )

	GM.Net:RegisterEventHandle( "iradio", "rpc", function( intMsgLen, pPlayer )
		if not GAMEMODE.Player:GetPlayerVIPFlag( pPlayer, "custom_radio" ) then return end

		local ent = net.ReadEntity()
		if not IsValid( ent ) or ent:GetPos():Distance( pPlayer:GetPos() ) > 200 then return end
		if ent:GetClass() ~= "ent_itemradio" then return end

		Module:PlayStation( ent, net.ReadUInt(32), true )
	end )

	GM.Net:RegisterEventHandle( "iradio", "rs", function( intMsgLen, pPlayer )
		local ent = net.ReadEntity()
		if not IsValid( ent ) or ent:GetPos():Distance( pPlayer:GetPos() ) > 200 then return end
		if ent:GetClass() ~= "ent_itemradio" then return end

		Module:StopStation( ent )
	end )
end

GM.Module:Register( Module )