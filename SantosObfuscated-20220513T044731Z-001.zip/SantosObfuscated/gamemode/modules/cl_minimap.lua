-- if game.GetMap() != "rp_rockford_v1b" then return end

nmap = {}


function util.ProjectToAxis2D( level, x1, y1, x2 ,y2 )
	local fc = (y1-level)/(y1-y2)
	return x2*fc+x1*(1-fc)
end

local meta = {}
meta.__index = meta

local mat = {
	arrow = Material("radar_centre.png", "smooth noclamp"),
	dot = Material("icon_circle", "smooth noclamp"),
	
	-- Map Bullshit
	--area = Material("rp_australia2", "smooth noclamp"),
	--solid = Material("rp_australia2", "smooth noclamp"),
	--radius = Material("radar_radius", "smooth noclamp"),
	-- Newexton City
	area = Material("bottom.png", "smooth nocull"),
	--solid = Material("rp_newexton2_city", "smooth noclamp nocull"),
	radius = Material("radar_radius", "smooth noclamp"),
	-- Woogong
	area2 = Material("top.png", "smooth nocull"),
	--solid2 = Material("rp_newexton2_woogong", "smooth noclamp nocull"),
}

local color_shadow = Color(0,0,0,0)
local color_solidmap = Color(255,255,255,200)

function nmap.new()
	return setmetatable({
		x = 32,
		y = 32,
		w = 256,
		h = 256,
		pos = Vector(),
		ratio = 1,
		top = 0,
		bottom = 32 + 256,
		numsec = 32768 / 256,
		scale = 2,
		mx = Matrix(),
		yaw = 0,
		area = mat.area,
		area2 = mat.area2,
		--solid = mat.solid,
		--solid2 = mat.solid2,
		iconScale = 1,
		solidShadow = mat.solidShadow
	}, meta)
end

function meta:applySize(x, y, w, h, ratio)
	self.x = x
	self.y = y
	self.w = w
	self.h = h

	self.numsec = 32768 / w
	self.ratio = ratio

	self.top = y + h * 0.5 - w * ratio * 0.5
	self.bottom = y + h * 0.5 + w * ratio * 0.5
end

function meta:worldToMap(vec)
	local o = vec
	local vec = vec - self.pos
	local ang = (vec):Angle().y * -1
	vec.z = 0

	local dist = vec:Length() / (self.numsec / self.scale)

	local ang = ang + self.yaw - 90

	vec.x = self.x + self.w * 0.5 + math.cos(math.rad(ang)) * dist
	vec.y = self.y + self.h * 0.5 + math.sin(math.rad(ang)) * dist

	local newy, newx = vec.y, vec.x

	if vec.y <= self.top then
		newx = util.ProjectToAxis2D(self.top, self.x + self.w * 0.5, self.y + self.h * 0.5, vec.x, vec.y)
	elseif vec.y >= self.bottom then
		newx = util.ProjectToAxis2D(self.bottom, self.x + self.w * 0.5, self.y + self.h * 0.5, vec.x, vec.y)
	end

	if vec.x <= self.x then
		newy = util.ProjectToAxis2D(self.x, self.y + self.h * 0.5, self.x + self.w * 0.5, vec.y, vec.x)
	elseif vec.x >= self.x + self.w then
		newy = util.ProjectToAxis2D(self.x + self.w, self.y + self.h * 0.5, self.x + self.w * 0.5, vec.y, vec.x)
	end

	vec.y = math.Clamp(newy, self.top, self.bottom)
	vec.x = math.Clamp(newx, self.x, self.x + self.w)

	return vec
end

function meta:worldToMapDirection(vec)
	vec.x = -vec.x
	vec:Rotate( Angle(0,self.yaw+90,0))
	local H2 = self.h*0.5*self.ratio
	local W2 = self.w*0.5
	local newy, newx = vec.y, vec.x

	if vec.y < 0 then
		newy = -H2
	else
		newy = H2
	end
	newx = util.ProjectToAxis2D(newy, 0, 0, vec.x, vec.y)

	if newx > W2 then
		newx = W2
	elseif newx < -W2 then
		newx = -W2
	end
	newy = util.ProjectToAxis2D(newx,0,0, vec.y, vec.x)

	vec.x = self.x + self.w * 0.5 + newx
	vec.y = self.y + self.h * 0.5 + newy

	return vec
end

function meta:worldToMapAngles(angOrEnt)
	if IsEntity(angOrEnt) then
		local ent = angOrEnt

		return self:worldToMapAngles(ent:InVehicle() and ent:GetVehicle():GetAngles().y + 90 or ent:EyeAngles().y)
	elseif isangle(angOrEnt) then
		local ang = angOrEnt
		return self:worldToMapAngles(ang.y)
	elseif isnumber(angOrEnt) then
		local yaw = angOrEnt

		return -90 + yaw - self.yaw
	end
end

function meta:calculateMatrix()
	local pos = Vector()
	pos:Set(self.pos)
	pos.x = pos.x / 32768 + 1
	pos.y = 1 - pos.y / 32768
	pos.z = 0

	self.mx:Identity()
	self.mx:Translate(Vector(-0.5, -0.5, 0))
	self.mx:Translate(pos)
	self.mx:Scale(Vector(1/self.scale, 1/self.scale, 1))
	self.mx:Rotate(Angle(0, -self.yaw + 90, 0))
	self.mx:Translate(Vector(-0.5, -0.5, 0))
end

local PlayerPos = Vector()

timer.Create( "MinimapPosCheck", 1, 0, function()
	if IsValid( LocalPlayer() ) then
		PlayerPos = LocalPlayer():GetPos()
	end
end )

function meta:draw()
	self:calculateMatrix()

	local maparea--, mapsolid
	-- print(PlayerPos.z)
	if PlayerPos.z < 2476 then
		self.area:SetMatrix("$basetexturetransform", self.mx)
		maparea = self.area
		-- print("rendering bottom");
		--self.solid:SetMatrix("$basetexturetransform", self.mx)
		--mapsolid = self.solid
	else
		self.area2:SetMatrix("$basetexturetransform", self.mx)
		maparea = self.area2
		-- print("rendering top");
		--self.solid2:SetMatrix("$basetexturetransform", self.mx)
		--mapsolid = self.solid2
	end

	--self.solidShadow:SetMatrix("$basetexturetransform", self.mx)

	surface.SetDrawColor(ColorAlpha(color_white, 255))
	surface.SetMaterial(maparea)
	surface.DrawTexturedRect(self.x, self.y, self.w, self.h)

	--surface.SetDrawColor(color_shadow)
	--surface.SetMaterial(self.solidShadow)
	--surface.DrawTexturedRect(self.x, self.y + 3, self.w, self.h)

	--surface.SetDrawColor(color_solidmap)
	--surface.SetMaterial(mapsolid)
	--surface.DrawTexturedRect(self.x, self.y, self.w, self.h)

	surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
	surface.DrawOutlinedRect( self.x, self.y, self.w, self.h )

	-- surface.SetDrawColor(Color(255, 255, 255, 100))
	-- surface.DrawRect(self.x, self.y, self.w, self.h)



	-- self:drawDebugAxis()
	self:drawCompas()
	-- self:drawComrades()
	--self:drawRadius()
	--self:drawRadiusDots()
	-- self:drawTraders()
	self:drawStatic()
	-- self:drawCurrentCar()
	self:drawLocalPlayer()
	-- self:drawJobNPCs()
	-- self:drawTeamPolice()
	-- self:drawServices()
	-- self:drawDumbsters()
	-- self:drawProperty()


	-- null test
	--[[
	local vec = self:worldToMap(Vector(0, 0, 0))
	surface.SetDrawColor(Color(255, 0, 0))
	surface.DrawRect(vec.x - 4, vec.y - 4, 8, 8)
	]]
end


-- local key = Material("icon16/key.png")
-- function meta:drawProperty()
-- 	for _, ent in pairs(ents.FindByClass("sign")) do
-- 		if ent:GetOwnerName() != "" then
-- 			self:drawMarker({ent:GetPos(), key})
-- 		end
-- 	end
-- end

do -- player drawing
	function meta:drawLocalPlayer()
		local LocalPlayer = LocalPlayer()
		local vec = self:worldToMap(LocalPlayer:GetPos())
		render.SetMaterial(mat.arrow)
		local s = math.max(20, 32 * self.scale / 6)
		render.DrawQuadEasy(Vector(vec.x, vec.y), -vector_up, s, s, color_white, self:worldToMapAngles(LocalPlayer))
	end

	local comrades = {}

	function meta:drawComrades()
		table.Empty(comrades)

		for _, pl in pairs(comrades) do
			local vec = self:worldToMap(pl:GetPos())
			render.SetMaterial(mat.arrow)
			local s = math.max(10, 24 * self.scale / 6)
			render.DrawQuadEasy(Vector(vec.x, vec.y), -vector_up, s, s, color_white, self:worldToMapAngles(pl))
		end
	end

	function meta:drawCurrentCar()
		local entCar = GAMEMODE.Cars:GetCurrentPlayerCar(LocalPlayer())
		if not IsValid(entCar) then return end

		local plyPos = PlayerPos
		local carPos = entCar:GetPos()

		if plyPos:DistToSqr( carPos ) > 3000 ^ 2 then return end
		if plyPos.z > -400 and carPos.z < -400 or plyPos.z < -400 and carPos.z > -400 then return end

		self:drawMarker({entCar:GetPos(), Material("personalvehicle.png","smooth noclamp")})
	end

	do -- drawRadius
		local mx_radius = Matrix()
		local radius_enabled = false
		local radius_period = 5
		local radius_time = 1
		local radius_size = 3000

		local col_radius = Color(64,255,0,200)

		local radius_dots = {}
		local radius_target

		function meta:drawRadius()
			local POS = PlayerPos

			if radius_enabled then -- TODO: if radar effects
				-- calculate radius effect transformation
				local radius_state = math.min(1,(RealTime()%radius_period)/radius_time)
				local radius_scale = 16384/radius_state/self.scale/radius_size
				local radius_alpha = 1-radius_state
				if radius_alpha ~= 0 then
					mx_radius:Identity()
					mx_radius:Translate(Vector(0.5, 0.5, 0))
					mx_radius:Scale( Vector(radius_scale, radius_scale, radius_scale) )
					mx_radius:Translate(Vector(-0.5, -0.5, 0))

					mat.radius:SetMatrix("$basetexturetransform", mx_radius)

					col_radius.a = radius_alpha*255
					surface.SetDrawColor(col_radius)
					surface.SetMaterial(mat.radius)
					surface.DrawTexturedRect(self.x, self.y, self.w, self.h)
				end

				if radius_state < 1 then
					for k, v in pairs(player.GetAll()) do
						if v ~= LocalPlayer() and not v:GetNoDraw() and v:Health() > 0 and POS:Distance(v:GetPos()) < radius_state * radius_size then
							if not radius_dots[v] then
								radius_dots[v] = {}
							end

							radius_dots[v].vec = v:GetPos()
							radius_dots[v].start = RealTime()
						end
					end
				end
			end
		end

		function meta:drawRadiusDots()
			for pl, d in pairs(radius_dots) do
				if IsValid(pl) and not pl:GetNoDraw() and not comrades[pl] and not invisible[pl] and (RealTime() - d.start) * 0.1 < 1 then
					local vec = self:worldToMap(d.vec)
					render.SetMaterial(mat.dot)
					local s = 24 * self.scale/6 * math.max(0, (1 - (RealTime() - d.start) * 0.1))
					local fl = math.abs(math.sin(RealTime() * 8)) * 255
					render.DrawQuadEasy(Vector(vec.x, vec.y), -vector_up, s + 1, s + 1, Color(255, 255, 255, 100), -90)
					render.DrawQuadEasy(Vector(vec.x, vec.y), -vector_up, s, s, radius_target == pl and Color(255, fl, fl) or team.GetColor(pl:Team()), -90)
				else
					radius_dots[pl] = nil
				end
			end
		end
	end
end




local static = {

	{Vector(6087.96875, 13164.90625, 7.875), Material("radar_modgarage.png", "smooth noclamp")}, -- Car Dealer
	{Vector(9596.373046875, 13659.296875, 367.25622558594), Material("radar_spray.png", "smooth noclamp")}, -- Bobs Customs
	{Vector(2235.0285644531, 3066.2158203125, 533.23614501953), Material("radar_police.png", "smooth noclamp")}, -- Police
	{Vector(12884.801757813, 12889.5546875, 481.0100402832), Material("radar_hostpital.png", "smooth noclamp")}, -- Hospital
	{Vector(13221.712890625, 10796.61328125, 326.19412231445), Material("radar_fire.png", "smooth noclamp")}, -- Fire
--	{Vector(-9731.115234, -15557.321289, 0), Material("radar_flag.png", "smooth noclamp")}, -- Racetrack
	{Vector(8706.8974609375, 9845.1123046875, 330.68774414063), Material("radar_tshirt.png", "smooth noclamp")}, -- Tshirt
	{Vector(15022.079101563, 9925.6513671875, 312.20220947266), Material("radar_dateFood.png", "smooth noclamp")}, -- Food
	{Vector(12084.907226563, 7361.7065429688, 20.909133911133), Material("radar_mafiaCasino.png", "smooth noclamp")}, -- Casino
	{Vector(4576.49609375, 9704.5908203125, 128.03125), Material("cannabis.png", "smooth noclamp")}, -- Drug dealer 1	
	{Vector(8765.357421875, -13482.932617188, 12.144336700439), Material("cannabis.png", "smooth noclamp")}, -- Drug dealer 2		
	{Vector(15075.807617188, 13623.012695313, 8.03125), Material("cannabis.png", "smooth noclamp")}, -- Drug dealer 2	
	{Vector(5058.0756835938, 3259.9321289063, 257.13104248047), Material("city-hall.png", "smooth noclamp")}, -- City Hall			
	{Vector(6607.96875, 2671.09375, 7.96875), Material("credit-card.png", "smooth noclamp")}, -- Bank						
--	{Vector(11772.031250, -1808.031250, 0), Material("radar_impound.png", "smooth noclamp")}, 
--	{Vector(2821.578125, 9002.195313, 0), Material("radar_diner.png", "smooth noclamp")}, 
--	{Vector(-9351.958984, -9384.376953, 0), Material("radar_gangP.png", "smooth noclamp")}, 
--	{Vector(2881.968750, 1107.968750, 0), Material("radar_gangY.png", "smooth noclamp")}, 
--	{Vector(-4143.542969, 953.736938, 0), Material("radar_bulldozer.png", "smooth noclamp")},
--	{Vector(-5754.314941, 5183.891113, 0), Material("radar_gangN.png", "smooth noclamp")},
	{Vector(9801.28125, 4537.0625, 7.96875), Material("radar_propertyR.png", "smooth noclamp")}, -- Realator
--	{Vector(13518.778320, 7593.438477, 0), Material("radar_CATALINAPINK.png", "smooth noclamp")},
	--{Vector(9867.856445, 15401.590820, 0), Material("radar_qmark.png", "smooth noclamp")}, -- Drug Dealer Location
--	{Vector(3920.701416, -11556.870117, 0), Material("radar_CJ.png", "smooth noclamp")},
--	{Vector(8850.663086, 3620.114502, 0), Material("radar_gangB.png", "smooth noclamp")},
--	{Vector(-5774.754883, -1582.056763, 0), Material("radar_cash.png", "smooth noclamp")},
}

function meta:drawMarker(v)
	local vec = self:worldToMap(v[1])
	render.SetMaterial(v[2])
	local s = math.max(24, 32 * self.scale*self.iconScale/7)
	if v[3] == true then
		s = math.max(16, 16 * 0.4)
	end
	render.DrawQuadEasy(Vector(vec.x, vec.y), -vector_up, s, s, color_white, -90)
end
	
function meta:drawMarkerA(pos, icon, scale, size)
	scale = scale or 1
	local vec = self:worldToMap(pos, true)
	if !vec then return end
	render.SetMaterial(icon)
	render.DrawQuadEasy(Vector(vec.x, vec.y), -vector_up, size, size, color_white, -90)
end

function meta:drawJobNPCs()
	for k, v in pairs(Job.NPC) do
		for k, v in pairs(v.pos) do
			if v.icon then
				self:drawMarker({v.pos, v.icon})
			end
		end
	end
end

function meta:drawStatic()
	for k, v in pairs(static) do
		if PlayerPos.z > 654 then
			if v[1].z < 654 then continue end
		else
			if v[1].z > 654 then continue end
		end

		if not self.isbigmap then
			if PlayerPos:DistToSqr( v[1] ) >= 10000 ^ 2 then
				continue
			end
		end

		self:drawMarker(v)
	end
end

local icon = Material('icon16/error.png')

local icon = Material('icon16/box.png')
function meta:drawDumbsters()
	for k, v in pairs(ents.GetAll()) do
		if v:GetClass() == "storage" then
			if v:GetPos():Distance(PlayerPos) < 3000 then
				self:drawMarkerA(v:GetPos(), icon, 0.1, 5)
			end
		end
	end
end

do -- drawCompas
	surface.CreateFont("nx_minimap_sides", {
		size = 12,
		weight = 0,
		antialias = true,
		font = "Uni Sans"
	})

	local named = {
			[0] = "N",
			[3] = "E",
			[6] = "S",
			[9] = "W",
	}
	local col_compas_outline = Color(0,0,0,255)
	local col_compas_outline_mid = Color(0,0,0,128)
	local col_compas_exact = Color(255,255,255,255)
	local col_compas_mid   = Color(128,128,128,255)

	local mat_circle = Material"gui/minimap/icon_circle"

	function meta:drawCompas()
		for i = 0, 11 do
			if i%3==0 then
				local rad = -math.rad(360/12*i)
				local vec = self:worldToMapDirection(Vector(math.cos(rad), math.sin(rad), 0))
				local text = named[i] or i
				
				surface.SetFont("nx_minimap_sides")
				local w, h = surface.GetTextSize( text )
				surface.SetMaterial(mat_circle)
				if i%3==0 then
					surface.SetDrawColor( col_compas_outline )
					surface.SetTextColor( col_compas_exact )
				else
					surface.SetTextColor( col_compas_mid )
					surface.SetDrawColor( col_compas_outline_mid )
				end
				surface.DrawTexturedRect(vec.x - h, vec.y - h, h*2,h*2)
				surface.SetTextPos(vec.x - w/2, vec.y - h/2)
				surface.DrawText( text )
			end
		end
	end
end

function meta:drawDebugAxis()
	surface.SetDrawColor(Color(255, 0, 0))
	surface.DrawLine(self.x, self.top, self.x + self.w, self.top)
	surface.DrawLine(self.x, self.bottom, self.x + self.w, self.bottom)

	surface.SetDrawColor(Color(0, 255, 0))
	surface.DrawLine(self.x, self.y, self.x, self.y + self.h)
	surface.DrawLine(self.x + self.w, self.y, self.x + self.w, self.y + self.h)

	surface.SetDrawColor(Color(0, 255, 0))
	surface.DrawLine(self.x + self.w/2, self.y, self.x + self.w/2, self.y + self.h)
	surface.SetDrawColor(Color(255, 0, 0))
	--surface.DrawLine(self.x, self.y + self.h/2, self.x + self.w, self.y + self.h/2)
end


minimap = nmap.new()
minimap:applySize(0, ScrH(), 256, 256, 10/16)
minimap:applySize( 8, ScrH() - (minimap.bottom - ScrH()) - 56, 256, 256, 10/16)

bigmap = nmap.new()
--bigmap:applySize(ScrW() - 512 - 64, 32, 512, 512, 1)
bigmap:applySize(0, 0, ScrH(), ScrH(), 10/16)
--bigmap.area = mat.nmarea
--bigmap.solid = mat.nmsolid
--bigmap.solidShadow = mat.nmsolidShadow

timer.Simple(0, function()
	notification.yoff = ScrH() - minimap.top + 64
	notification.xoff = 20
end)

local mdl = ClientsideModel("error.mdl")
mdl:SetNoDraw(true)

local noDraw = true
local lastPos = Vector(0,0,0)

local disable = CreateClientConVar( "srp_minimap", "1", true, false )
hook.Add("HUDPaint","Minimap",function()
	if disable:GetInt() == 1 then return end
	if disable:GetInt() == 0 then return end

	-- hack to fix material bug
	render.SetBlend(0)
	mdl:DrawModel()
	render.SetBlend(1)

	local pos = LocalPlayer():EyePos()
	local dt = lastPos - pos
	lastPos:Set(pos)
	dt = dt:Length()/FrameTime()

	minimap.scale = Lerp(FrameTime(), minimap.scale, dt > 0 and 2 or 3)
	minimap.yaw = RenderAngles().y
	minimap.pos = pos
	minimap:draw()

	if IsValid( LocalPlayer().Instrument ) then return end
	if input.IsKeyDown(KEY_M) and not vgui.CursorVisible() then
		bigmap.pos = Vector()
		bigmap.yaw = 90
		bigmap.scale = 0.6
		bigmap.iconScale = 1
		bigmap.isbigmap = true
		bigmap:draw()
	end

--	 surface.SetFont("DermaLarge")
--	 surface.SetTextColor( Color(255,255,255) )
--	 surface.SetTextPos(ScrW() -1850, ScrH() - 225)
--	 surface.DrawText( "M - Map" )
end)