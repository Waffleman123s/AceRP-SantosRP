local Module = {}
Module.Name = "daynight"
Module.m_intCurDay = 1
Module.m_tblNightLights = {}
Module.m_tblTimeData = Module.m_tblTimeData or {}

--Wrapping the old internal system
function Module:GetTime()
	if not StormFox then return 0 end
	return StormFox.GetTime( true )
end
function Module:GetDay()
	return self.m_intCurDay
end
function Module:NightLightsOn()
end
function Module:TurnOnNightLights()
end
function Module:TurnOffNightLights()
end
function Module:Tick()
	local newTime = self:GetTime()
	self.m_intLastTime = self.m_intLastTime or newTime
	hook.Call( "GamemodeOnTimeChanged", GAMEMODE, self.m_intLastTime, newTime )
	
	if self.m_intLastTime ~= newTime then
		if newTime == 0 then
			Module.m_intCurDay = Module.m_intCurDay +1
			if Module.m_intCurDay > 7 then
				Module.m_intCurDay = 1
			end
		end
	end
	
	self.m_intLastTime = newTime
end


--Patch out the snow texture stuff - this explodes tier0 on paralake_v4
function Module:Initialize()
	RunConsoleCommand( "sf_sv_material_replacment", "0" )
	RunConsoleCommand( "sf_disableweatherdebuffs", "1" )
	RunConsoleCommand( "sf_disable_windpush", "1" )
	RunConsoleCommand( "sf_disable_autoweather_cold", "1" )

	--Patch out admin settings
	net.Receivers["stormfox - weatherc"] = function() end
end

function Module:OnLoad()
	self:RequireHook( "Initialize" ) 
	self:RequireHook( "Tick" )
end

GM.Module:Register( Module )