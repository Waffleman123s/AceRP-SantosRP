--[[
	Name: cl_chatradios.lua
	For: SantosRP
	By: Ultra
]]--

if PRIVATE_SERVER then return end

local Module = {}
Module.Name = "Chat Radios"
Module.m_tblChannels = {}
Module.DefaultChatRadioChannel = 1

function Module:RegisterChannel( intChanID, strName, bEncrypted )
	self.m_tblChannels[intChanID] = { Name = strName, Encrypted = bEncrypted }
end

function Module:GetChannel( intChanID )
	return self.m_tblChannels[intChanID]
end

function Module:GetChannels()
	return self.m_tblChannels
end

function Module:IsChannelEncrypted( intChanID )
	return self.m_tblChannels[intChanID].Encrypted
end

function Module:HasRadio()
	return self.m_intCurrentChannel ~= nil
end

function Module:HasChannelKey( intChanID )
	local job = GAMEMODE.Jobs:GetPlayerJob( LocalPlayer() )
	if not job or not job.HasChatRadio or not job.ChannelKeys then return end
	return job.ChannelKeys[intChanID] and true
end

function Module:RequestSetChannel( intChanID )
	GAMEMODE.Net:RequestChangeChatRadioChannel( intChanID )
end

function Module:RequestMuteRadio( bMute )
	GAMEMODE.Net:RequestMuteChatRadio( bMute )
end

function Module:GetCurrentChannel()
	return self.m_intCurrentChannel
end

function Module:SetCurrentChannel( intChanID )
	self.m_intCurrentChannel = intChanID
	hook.Call( "GamemodeChatRadioChannelChanged", GAMEMODE, intChanID )
end

function Module:Tick()
	if input.IsKeyDown( KEY_F2 ) then
		if not ValidPanel( self.m_pnlChatRadio ) then return end
		if self.m_pnlChatRadio:IsVisible() or vgui.CursorVisible() then return end
		if ValidPanel( vgui.GetKeyboardFocus() ) then return end
		self.m_pnlChatRadio:Open()	
	else
		if ValidPanel( self.m_pnlChatRadio ) and self.m_pnlChatRadio:IsVisible() then
			self.m_pnlChatRadio:Close()
		end
	end
end

function Module:BuildChatRadioMenu()
	if ValidPanel( self.m_pnlChatRadio ) then
		self.m_pnlChatRadio:Remove()
	end

	self.m_pnlChatRadio = vgui.Create( "SRPChatRadioMenu" )
	self.m_pnlChatRadio:SetSize( 226, 185 )
	self.m_pnlChatRadio:SetPos( ScrW() -self.m_pnlChatRadio:GetWide() -5, (ScrH() /2) -(self.m_pnlChatRadio:GetTall() /2) )
	self.m_pnlChatRadio:SetVisible( false )
end

function Module:InitPostEntity()
	self:BuildChatRadioMenu()
end

function Module:OnLoad()
	self:RequireHook( "Tick" )
	self:RequireHook( "InitPostEntity" )
	GM.Net:AddProtocol( "chat_radio", 12 )

	function GM.Net:RequestChangeChatRadioChannel( intNewChanID )
		self:NewEvent( "chat_radio", "rs" )
			net.WriteUInt( intNewChanID, 8 )
		self:FireEvent()
	end

	function GM.Net:RequestMuteChatRadio( bMuted )
		self:NewEvent( "chat_radio", "rm" )
			net.WriteBit( bMuted )
		self:FireEvent()
	end

	GM.Net:RegisterEventHandle( "chat_radio", "c", function( intMsgLen, pPlayer )
		if net.ReadBit() == 0 then
			self:SetCurrentChannel( nil )
			return
		end
		self:SetCurrentChannel( net.ReadUInt(8) )
	end )
end

GM.Module:Register( Module )