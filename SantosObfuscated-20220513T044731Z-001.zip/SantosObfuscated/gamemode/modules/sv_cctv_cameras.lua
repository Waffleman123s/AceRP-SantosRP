local Module = {}
Module.Name = "cctv_cameras"
Module.m_tblCams = {}

function Module:RegisterCamera(eCam, bIsPolice)
	table.insert(self.m_tblCams, {eCam, bIsPolice})
end

function Module:GetCamerasFor(eMonitorOwner, eRequester, bIsPolice)
	local m_tblSend = {}

	if bIsPolice then
		for k, v in pairs(self.m_tblCams) do
			if not IsValid(v[1]) then continue end

			if v[2] then
				m_tblSend[k] = v[1]
			end
		end
	else
		for k, v in pairs(self.m_tblCams) do
			if not IsValid(v[1]) then continue end

			if v[1].CreatedBy == eMonitorOwner or v.CreatedBy == eRequester then
				m_tblSend[k] = v[1]
			end
		end
	end

	return m_tblSend
end

GM.Module:Register(Module)