if DEV_SERVER then return end

local Module = {}
Module.Disabled = false
Module.Name = "AutoRestart"
Module.RestartHour = 9 --24 hour scale
Module.m_tblData = {}

function Module:RestartServer()
	self.m_bRestartFlag = false
	GAMEMODE:CloseServer( self.Name, function()
		hook.Call( "GamemodeAutoRestart", GAMEMODE )

		--Crash the server, leave no survivors 
		debug.sethook() --interrupt any debug hooks
		table.Empty( debug.getregistry() ) --fuck up _R
		_G = nil --fuck up _G
	end )
end

function Module:PostponeRestart( pPlayer )
	if not self.m_tblData.Warn1 then return end
	if self.m_tblData.postpone then return end
	
	self.m_tblData.postpone = true
	self:WarnPlayers( ("%s has postponed the automatic restart"):format(pPlayer:Nick()) )
	hook.Call( "GamemodeAutoRestartPostpone", GAMEMODE, pPlayer )
end

function Module:Tick()
	if CurTime() < (self.m_intLastTick or 0) then return end
	self.m_intLastTick = CurTime() +1

	local dateLocale = os.date( "*t", os.time() )
	if dateLocale.hour == self.HourBefore then --hour before
		self.m_bRestartFlag = true --flag set for restart

		--Warnings
		if self.m_bRestartFlag and not self.m_tblData.postpone then
			if dateLocale.min == 45 and not self.m_tblData.Warn1 then
				self.m_tblData.Warn1 = true
				self:WarnPlayers( "WARNING: Automatic restart will occur in 15 minutes!" )
			elseif dateLocale.min == 50 and not self.m_tblData.Warn2 then
				self.m_tblData.Warn2 = true
				self:WarnPlayers( "WARNING: Automatic restart will occur in 10 minutes!" )
			elseif dateLocale.min == 55 and not self.m_tblData.Warn3 then
				self.m_tblData.Warn3 = true
				self:WarnPlayers( "WARNING: Automatic restart will occur in 5 minutes!" )
			elseif dateLocale.min == 59 and not self.m_tblData.Warn4 then
				self.m_tblData.Warn4 = true
				self:WarnPlayers( "WARNING: Automatic restart will occur in 1 minute!" )
			end
		end
	elseif dateLocale.hour == self.RestartHour then --hour of
		if self.m_tblData.postpone then
			self.m_tblData = {}
			self.m_bRestartFlag = false
			return
		end

		if dateLocale.min == 0 and self.m_bRestartFlag then
			self:RestartServer()
		end
	end
end

function Module:WarnPlayers( strMsg )
	for k, v in pairs( player.GetAll() ) do
		v:AddNote( strMsg )
		v:PrintMessage( HUD_PRINTCENTER, strMsg )
	end
end

function Module:OnLoad()
	self:RequireHook( "Tick" )

	self.HourBefore = self.RestartHour -1
	if self.HourBefore < 0 then
		self.HourBefore = 23
	end
end

GM.Module:Register( Module )