local Module = {}
Module.Name = "PropLoader"
Module.m_bEnabledHUD = false

Module.m_tblBad = {
	["func_"] = true,
	["env_"] = true,
	["prop_door_"] = true,
	["prop_vehicle_"] = true,
	["ent_tow"] = true
}

Module.m_tblData = {}
Module.m_strCurrentFile = ""

if SERVER then
	function Module:Notify(strFormat, ...)
		local strFormatted = string.format(strFormat, ...)
		MsgN("<---- Santos Prop Saver :: " .. strFormatted .. " :: ---->")
	end

	function Module:OnEntitySpawned(strClass, eEnt)
		if not IsValid(eEnt) then return end

		if eEnt:GetModel() == "models/props/cs_assault/firehydrant.mdl" then
			eEnt:SetMoveType(MOVETYPE_NONE)

			local ePhys = eEnt:GetPhysicsObject()

			if IsValid(ePhys) then
				ePhys:EnableMotion(false)
			end
		end
	end

	function Module:SpawnEntity(tblData)
		local strClass = tblData.Class
		local intID = tblData.ID
		local vecPos = tblData.Pos
		local angPos = tblData.Angs
		local strModel = tblData.Model

		for _, eEnt in pairs(ents.FindByClass(strClass or "prop_physics_multiplayer")) do
			if eEnt:GetPos():DistToSqr(vecPos) < (25 * 25) then
				eEnt:Remove()
			end
		end

		local eEnt = ents.Create(strClass or "prop_physics_multiplayer")
		if not eEnt or not IsValid(eEnt) then return end
		eEnt:SetNWInt("PropLoader::SaveID", tonumber(intID))

		if strModel then
			eEnt:SetModel(strModel)
		end

		eEnt:SetPos(vecPos)
		eEnt:SetAngles(angPos)
		eEnt.IsMapProp = true
		eEnt:SetDTBool(GAMEMODE.Map.DT_IS_MAP_PROP, true)
		eEnt:Spawn()
		eEnt:Activate()
		eEnt:SetSaveValue("fademindist", GAMEMODE.Config.DetailPropFadeMin)
		eEnt:SetSaveValue("fademaxdist", GAMEMODE.Config.DetailPropFadeMax)
		eEnt:SetMoveType(MOVETYPE_VPHYSICS)
		eEnt:SetSolid(SOLID_VPHYSICS)
		self:OnEntitySpawned(strClass, eEnt)
	end

	function Module:InitPostEntity()
		for _, files in pairs(file.Find(self.m_strCurrentFolderPath .. "*.dat", "DATA")) do
			local tblData = file.Read(self.m_strCurrentFolderPath .. files)

			if tblData then
				tblData = util.JSONToTable(tblData)
				if table.Count(tblData) < 1 then continue end

				for _, tblEntity in pairs(tblData) do
					self:SpawnEntity(tblEntity)
				end

				self:Notify("%d entities were spawned for file %s", table.Count(tblData), files)
			end
		end
	end
end

if CLIENT then
	function Module:IsBad(strClass)
		for strKey, _ in pairs(self.m_tblBad) do
			if strClass:find(strKey) then return true end
		end

		return false
	end

	function Module:HUDPaint()
		-- if not LocalPlayer():IsSuperAdmin() then return end
		local eEnt = LocalPlayer():GetEyeTrace().Entity
		if not IsValid(eEnt) then return end
		if not self.m_bEnabledHUD then return end

		if tonumber(eEnt:GetNWInt("PropLoader::SaveID")) > 0 then
			draw.SimpleText("Unique ID: " .. eEnt:GetNWInt("PropLoader::SaveID"), "Trebuchet24", ScrW() / 2, ScrH() / 2 - 100, Color(255, 255, 255), 1)
			draw.SimpleText(eEnt:GetClass(), "Trebuchet24", ScrW() / 2, ScrH() / 2 - 75, Color(255, 255, 255), 1)
			draw.SimpleText("*proploader_remove* to unsave.", "Trebuchet24", ScrW() / 2, ScrH() / 2 - 50, Color(255, 255, 255), 1)
		elseif not eEnt:GetDTBool(GAMEMODE.Map.DT_IS_MAP_PROP) and not self:IsBad(eEnt:GetClass()) then
			draw.SimpleText(eEnt:GetClass(), "Trebuchet24", ScrW() / 2, ScrH() / 2 - 75, Color(255, 255, 255), 1)
			draw.SimpleText("*proploader_add* to save.", "Trebuchet24", ScrW() / 2, ScrH() / 2 - 50, Color(255, 255, 255), 1)
		else
			draw.SimpleText(eEnt:GetClass(), "Trebuchet24", ScrW() / 2, ScrH() / 2 - 75, Color(255, 255, 255), 1)
			draw.SimpleText("Bad entity.", "Trebuchet24", ScrW() / 2, ScrH() / 2 - 50, Color(255, 255, 255), 1)
		end
	end
end

function Module:AddCommand(strCommand, funcRun)
	concommand.Add(strCommand, funcRun)
end

function Module:OnLoad()
	if SERVER then
		self.m_strCurrentFolderPath = "proploader/" .. game.GetMap():gsub(".bsp", "") .. "/"
		file.CreateDir(self.m_strCurrentFolderPath)
		self:RequireHook("InitPostEntity")

		self:AddCommand("proploader_reload", function(pPlayer, _, tblArgs)
			if not pPlayer:IsSuperAdmin() then return end
			local strFile = tblArgs[1] or self.m_strCurrentFile
			if not strFile then return pPlayer:ChatPrint("Bad file name.") end
			if not file.Exists(self.m_strCurrentFolderPath .. strFile .. ".dat", "DATA") then return pPlayer:ChatPrint("Bad file name.") end
			local tblData = file.Read(self.m_strCurrentFolderPath .. strFile .. ".dat")
			tblData = util.JSONToTable(tblData)

			for _, tblEntity in pairs(tblData) do
				self:SpawnEntity(tblEntity)
			end
		end)

		self:AddCommand("proploader_save", function(pPlayer, _, tblArgs)
			if not pPlayer:IsSuperAdmin() then return end
			local strFile = tblArgs[1] or self.m_strCurrentFile
			local tblData = self.m_tblData
			if table.Count(tblData) < 1 then return pPlayer:ChatPrint("No prop data to save.") end

			if file.Exists(self.m_strCurrentFolderPath .. strFile .. ".dat", "DATA") then
				local tblFile = file.Read(self.m_strCurrentFolderPath .. strFile .. ".dat")
				tblFile = util.JSONToTable(tblFile)

				for intKey, tblNew in pairs(tblData) do
					if tblFile[intKey] then
						tblFile[intKey] = tblData[intKey]
					end
				end

				table.Merge(tblData, tblFile)
			end

			tblData = util.TableToJSON(tblData, true)
			file.Write(self.m_strCurrentFolderPath .. strFile .. ".dat", tblData)
			pPlayer:ChatPrint("Saved data under file data/" .. self.m_strCurrentFolderPath .. strFile .. ".dat")
			self.m_tblData = {}
		end)

		self:AddCommand("proploader_clear", function(pPlayer, _, _)
			if not pPlayer:IsSuperAdmin() then return end
			self.m_tblData = {}
			pPlayer:ChatPrint("Cleared prop loader current data.")
		end)

		self:AddCommand("proploader_add", function(pPlayer, _, _)
			if not pPlayer:IsSuperAdmin() then return end
			local eEnt = pPlayer:GetEyeTrace().Entity
			if not IsValid(eEnt) then return pPlayer:ChatPrint("Invalid entity.") end
			local intUID = util.CRC(tostring(eEnt:GetPos()) .. eEnt:GetModel())

			self.m_tblData[intUID] = {
				ID = intUID,
				Class = eEnt:GetClass(),
				Pos = eEnt:GetPos(),
				Angs = eEnt:GetAngles(),
				Color = eEnt:GetColor(),
				Model = eEnt:GetModel()
			}

			pPlayer:ChatPrint("Saved " .. eEnt:GetClass() .. " as " .. intUID)
			eEnt:SetNWInt("PropLoader::SaveID", intUID)
		end)

		self:AddCommand("proploader_make", function(pPlayer, _, tblArgs)
			if not pPlayer:IsSuperAdmin() then return end
			local strClass = tblArgs[1] or "prop_physics_multiplayer"
			local strModel = tblArgs[2] or "models/error.mdl"
			local eEnt = ents.Create(strClass)
			if not eEnt or not IsValid(eEnt) then return end
			eEnt:SetModel(strModel)
			eEnt:SetPos(pPlayer:GetEyeTrace().HitPos + Vector(0, 0, 10))
			eEnt:Spawn()
			eEnt:Activate()
			undo.Create("propload_make")
			undo.AddEntity(eEnt)
			undo.SetPlayer(pPlayer)
			undo.Finish()
			pPlayer:ChatPrint("Created entity.")
		end)

		self:AddCommand("proploader_remove", function(pPlayer, _, _)
			if not pPlayer:IsSuperAdmin() then return end
			local eEnt = pPlayer:GetEyeTrace().Entity
			if not IsValid(eEnt) then return pPlayer:ChatPrint("Invalid entity.") end
			local intUID = util.CRC(tostring(eEnt:GetPos()) .. eEnt:GetModel())
			self.m_tblData[intUID] = nil
			pPlayer:ChatPrint("Removed " .. eEnt:GetClass() .. " as " .. intUID)
			eEnt:SetNWInt("PropLoader::SaveID", 0)
			eEnt.IsMapProp = false
			eEnt:SetDTBool(GAMEMODE.Map.DT_IS_MAP_PROP, false)
		end)

		self:AddCommand("proploader_load", function(pPlayer, _, tblArgs)
			if not pPlayer:IsSuperAdmin() then return end
			local strFile = tblArgs[1] or self.m_strCurrentFile
			if not strFile then return pPlayer:ChatPrint("Bad file name.") end
			if not file.Exists(self.m_strCurrentFolderPath .. strFile .. ".dat", "DATA") then return pPlayer:ChatPrint("Bad file name.") end
			local tblFile = file.Read(self.m_strCurrentFolderPath .. strFile .. ".dat")
			tblFile = util.JSONToTable(tblFile)
			self.m_tblData = tblFile
			pPlayer:ChatPrint("Set file data as current.")
		end)
	else
		self:RequireHook("HUDPaint")

		-- self:AddCommand("proploader_toggle", function(pPlayer, _, _)
			-- self.m_bEnabledHUD = not self.m_bEnabledHUD
			-- print("Prop loader " .. (self.m_bEnabledHUD and "enabled." or "disabled."))
		-- end)
	end
end

GM.Module:Register(Module)