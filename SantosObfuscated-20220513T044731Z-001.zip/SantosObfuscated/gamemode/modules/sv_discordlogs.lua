local Module = {}
Module.Disabled = true
Module.Name = "Discord Logs"
Module.Webhook = "https://discord.com/api/webhooks/937086987033247764/vq_kdp--kP0gjtKqKLmbEUCZS0kCq2auGXKxUTRM3weU4jXY-_96JJS3U3YqINI3uTre"
Module.DiscordHandle = "https://projectsteele.com/goat/discord_webhook.php"

Module.BaseLogEmbed = {
	username = "Server Logs",
	embeds = {
		{
			color = 100000,
			timestamp = "<server_time>",
			footer = {
				text = "Discord Logger"
			},
			fields = {
				{
					name = "Log",
					value = "``<log_message>``"
				},
				{
					name = "Server Time",
					value = "``<log_time>``"
				},
				{
					name = "Server",
					value = "``<server_name>`` (<server_ip>)"
				}
			}
		}
	}
}

function Module:GetServerTime()
  local time = os.time()
  local date = os.date("%Y-%m-%dT%H:%M:%SZ", time)

  return date
end

function Module:Log(str)
	self.BaseLogEmbed.embeds[1].color = math.random(100000, 199999)
	local embed = util.TableToJSON(self.BaseLogEmbed)

	embed = embed:Replace("<log_message>", str)
	embed = embed:Replace("<log_time>", os.date())
	embed = embed:Replace("<server_time>", self:GetServerTime())
	embed = embed:Replace("<server_name>", GetHostName())
	embed = embed:Replace("<server_ip>", game.GetIPAddress())
	
	http.Post(self.DiscordHandle, {json = embed, url = self.Webhook})

	print(embed)

end

GM.Module:Register(Module)