--[[
	Name: sv_chatradios.lua
	For: SantosRP
	By: Ultra
]]--

if PRIVATE_SERVER then return end

local Module = {}
Module.Name = "Chat Radios"
Module.m_tblChannels = {}
Module.DefaultChatRadioChannel = 1

function Module:RegisterChannel( intChanID, strName, bEncrypted )
	self.m_tblChannels[intChanID] = { Name = strName, Encrypted = bEncrypted }
end

function Module:GetChannel( intChanID )
	return self.m_tblChannels[intChanID]
end

function Module:GetChannels()
	return self.m_tblChannels
end

function Module:IsChannelEncrypted( intChanID )
	return self.m_tblChannels[intChanID].Encrypted
end

function Module:GrantEncryptedChannelKey( pPlayer, intChanID )
	pPlayer.m_tblChatRadioChanKeys = pPlayer.m_tblChatRadioChanKeys or {}
	pPlayer.m_tblChatRadioChanKeys[intChanID] = true
end

function Module:RevokeEncryptedChannelKey( pPlayer, intChanID )
	pPlayer.m_tblChatRadioChanKeys = pPlayer.m_tblChatRadioChanKeys or {}
	pPlayer.m_tblChatRadioChanKeys[intChanID] = nil
end

function Module:PlayerHasChannelKey( pPlayer, intChanID )
	if not pPlayer.m_tblChatRadioChanKeys then return false end
	return pPlayer.m_tblChatRadioChanKeys[intChanID] or false
end

function Module:PlayerHasRadio( pPlayer )
	local job = GAMEMODE.Jobs:GetPlayerJob( pPlayer )
	if not job or not job.HasChatRadio then return false end
	return true
end

function Module:PlayerSetChannel( pPlayer, intChan )
	if not self:PlayerHasRadio( pPlayer ) then return end
	if not self:GetChannel( intChan ) then return end
	pPlayer.m_intRadioChannel = intChan
	GAMEMODE.Net:SendPlayerChatRadioChannel( pPlayer, intChan )
end

function Module:GetPlayerChannel( pPlayer )
	return pPlayer.m_intRadioChannel
end

function Module:PlayerMuteRadio( pPlayer, bMuted )
	if not self:PlayerHasRadio( pPlayer ) then return end
	pPlayer.m_bRadioMuted = bMuted
end

function Module:GamemodePlayerCanHearPlayersVoice( pPlayer1, pPlayer2 )
	if not self:PlayerHasRadio( pPlayer1 ) or not self:PlayerHasRadio( pPlayer2 ) then return end
	if pPlayer1.m_intRadioChannel == pPlayer2.m_intRadioChannel then
		if pPlayer1.m_bRadioMuted or pPlayer2.m_bRadioMuted then return end
		if pPlayer1:IsIncapacitated() or pPlayer2:IsIncapacitated() then return end

		if self:IsChannelEncrypted( self:GetPlayerChannel(pPlayer1) ) then
			if self:PlayerHasChannelKey( pPlayer1, pPlayer1.m_intRadioChanne ) then
				if self:PlayerHasChannelKey( pPlayer2, pPlayer2.m_intRadioChannel ) then
					return true
				end
			end
		else
			return true
		end
	end
end

function Module:GamemodePlayerSetJob( pPlayer, intJobID )
	local job = GAMEMODE.Jobs:GetJobByID( intJobID )
	if job and job.HasChatRadio then
		self:PlayerSetChannel( pPlayer, job.DefaultChatRadioChannel or 1 )

		if job.ChannelKeys then
			for k, v in pairs( job.ChannelKeys ) do
				self:GrantEncryptedChannelKey( pPlayer, k )
			end
		end
	else
		GAMEMODE.Net:SendPlayerChatRadioChannel( pPlayer, nil )
	end
end

function Module:GamemodePlayerQuitJob( pPlayer, intJobID )
	pPlayer.m_intRadioChannel = nil
	pPlayer.m_bRadioMuted = nil

	local job = GAMEMODE.Jobs:GetJobByID( intJobID )
	if job and job.HasChatRadio and job.ChannelKeys then
		for k, v in pairs( job.ChannelKeys ) do
			self:RevokeEncryptedChannelKey( pPlayer, k )
		end
	end
end

function Module:OnLoad()
	self:RequireHook( "GamemodePlayerSetJob" )
	self:RequireHook( "GamemodePlayerQuitJob" )
	self:RequireHook( "GamemodePlayerCanHearPlayersVoice" )

	GM.Net:AddProtocol( "chat_radio", 12 )

	GM.Net:RegisterEventHandle( "chat_radio", "rs", function( intMsgLen, pPlayer )
		self:PlayerSetChannel( pPlayer, net.ReadUInt(8) )
	end )

	GM.Net:RegisterEventHandle( "chat_radio", "rm", function( intMsgLen, pPlayer )
		self:PlayerMuteRadio( pPlayer, net.ReadBit() == 1 )
	end )

	function GM.Net:SendPlayerChatRadioChannel( pPlayer, intChan )
		self:NewEvent( "chat_radio", "c" )
			net.WriteBit( intChan ~= nil )
			if intChan ~= nil then
				net.WriteUInt( intChan, 8 )
			end
		self:FireEvent( pPlayer )
	end
end

GM.Module:Register( Module )