local Module = {}
Module.Name = "Web Materials"
file.CreateDir("mazerp/webmats")
Module.m_tabCache = {}
Module.m_matError = Material("error")

function Module:MaterialExists(strUrl)
    local strUid = util.CRC(strUrl)
    local strFormat = "mazerp/webmats/%s.png"

    return file.Exists(strFormat:format(strUid), "DATA")
end

function Module:GetCache()
    return self.m_tabCache
end

function Module:GetMaterial(strUrl)
    local strUid = util.CRC(strUrl)
    local strFormat = "mazerp/webmats/%s.png"
    local strMaterial = "data/mazerp/webmats/%s.png"

    if file.Exists(strFormat:format(strUid), "DATA") then
        self.m_tabCache[strUrl] = Material(strMaterial:format(strUid))

        return self.m_tabCache[strUrl]
    end

    return self.m_matError
end

function Module:SetupMaterial(strUrl)
    self.m_tabCache[strUrl] = self.m_matError
end

function Module:WriteMaterial(strUrl, strData)
    local strUid = util.CRC(strUrl)
    local strFormat = "mazerp/webmats/%s.png"
    file.Write(strFormat:format(strUid), strData)
    self.m_tabCache[strUrl] = strData
end

function Module:ClearCache()
    self.m_tabCache = {}
    local tabFiles, _ = file.Find("mazerp/webmats/*", "DATA")

    for intKey, strName in pairs(tabFiles) do
        file.Delete("mazerp/webmats/" .. strName)
    end
end

function Module:FetchMaterial(strUrl)
    if not strUrl then return self.m_matError end
    if self.m_tabCache[strUrl] then return self.m_tabCache[strUrl] end
    if self:MaterialExists(strUrl) then return self:GetMaterial(strUrl) end
    self:SetupMaterial(strUrl)
    http.Fetch(strUrl, function(strData)
        self:WriteMaterial(strUrl, strData)
        self.m_tabCache[strUrl] = self:GetMaterial(strUrl)
    end)

    return self.m_tabCache[strUrl]
end

function Module:OnLoad()
end

GM.Module:Register(Module)