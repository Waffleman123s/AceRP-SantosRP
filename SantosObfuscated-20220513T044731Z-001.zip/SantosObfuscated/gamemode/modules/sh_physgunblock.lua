hook.Add("OnPhysgunPickup", "PATCH:BlacklistPickup", function(ply, ent)
    if not ply:IsSuperAdmin() and table.HasValue({"casinokit_roulette", "casinokit_holdem", "casinokit_machine", "casinokit_slot_fruits", "casinokit_slot_videobj", "casinokit_slot_videopoker", "casinokit_blackjack", "casinokit_table", "casinokit_seat", "casinokit_dealernpc", "casinokit_npc", "casinokit_chipnpc", "ent_fire"}, ent:GetClass()) then
        return false;
    end

    return;
end)