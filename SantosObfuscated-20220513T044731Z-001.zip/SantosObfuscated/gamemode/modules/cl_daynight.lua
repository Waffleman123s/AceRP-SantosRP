local Module = {}
Module.Name = "daynight"
Module.m_intCurDay = 1

--Wrapping the old internal system
function Module:GetTime()
	if not StormFox then return 0 end
	return StormFox.GetTime( true )
end
function Module:GetDay()
	return self.m_intCurDay
end
function Module:Tick()
	local newTime = self:GetTime()
	self.m_intLastTime = self.m_intLastTime or newTime
	hook.Call( "GamemodeOnTimeChanged", GAMEMODE, self.m_intLastTime, newTime )
	
	if self.m_intLastTime ~= newTime then
		if newTime == 0 then
			Module.m_intCurDay = Module.m_intCurDay +1
			if Module.m_intCurDay > 7 then
				Module.m_intCurDay = 1
			end
		end
	end
	
	self.m_intLastTime = newTime
end

--Patch out the snow texture stuff - this explodes tier0 on paralake_v4
function Module:ThisIsNotAnError()
	error( "This is not an error, we are stopping execution of StormFox code that would lead to a crash on paralake_city_v4.\n" )
end
function Module:ItsALameWorkaround()
	self:ThisIsNotAnError()
end

function Module:Initialize()
	--Alright, we gon hack our way out of this one
	g_RealPrint = g_RealPrint or print
	function print( a1, ... )
		if a1 == "[StormFox]: Loading cached texmap..." or a1 == "[StormFox]: Generating texmap (Might take a bit)..." then
			g_RealPrint( a1, ... )
			print = g_RealPrint
			--Shit, stop them!
			self:ItsALameWorkaround()
			return
		end
		return g_RealPrint( a1, ... )
	end
end

function Module:GetStormFoxUI()
	if not hook.GetTable()["PopulateToolMenu"] then return end
	local fnUi = hook.GetTable()["PopulateToolMenu"]["Populate StormFox Menus"]
	if not fnUi then return end
	local a, b = debug.getupvalue( fnUi, 1 ) --This is totally safe and will never change /s
	if a == "client_settings" then
		return b
	end
end

function Module:OnLoad()
	if game.SinglePlayer() then
		self:RequireHook( "Initialize" )
	end
	self:RequireHook( "InitPostEntity" )
	self:RequireHook( "Tick" )
end

GM.Module:Register( Module )