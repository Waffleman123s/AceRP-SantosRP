local Module = {}
Module.Name = "ChatCommands"
Module.m_tblCommands = {}
Module.m_tblLiteralCommands = {}

function Module:Add(strCmd, funcCommand, funcChatMod)
	self.m_tblCommands[strCmd] = {
		cmd = funcCommand,
		chat = funcChatMod
	}
end

function Module:AddLiteral(strCmd, funcCommand)
	self.m_tblLiteralCommands[strCmd] = funcCommand
end

function Module:PlayerSay(pPlayer, strText, bTeamOnly)
	if self.m_tblLiteralCommands[strText] then return self.m_tblLiteralCommands[strText](pPlayer, bTeamOnly) end

	for k, v in pairs(self.m_tblCommands) do
		if strText:sub(1, #k) == k then return v.cmd(pPlayer, strText, bTeamOnly) end
	end
end

if CLIENT then
	function Module:GamemodeModifyForChatTypes(tblArgs, pPlayer, strText)
		for k, v in pairs(self.m_tblCommands) do
			if strText:sub(1, #k) == k then return v.chat(tblArgs, pPlayer, strText) end
		end
	end
end

function Module:OnLoad()
	self:RequireHook("PlayerSay")

	if CLIENT then
		self:RequireHook("GamemodeModifyForChatTypes")
	end

	self:Add("/ads ", function(pPlayer, strText, bTeamOnly)
		if pPlayer:CanAfford(GAMEMODE.Config.AdvertPrice) then
			pPlayer:TakeMoney(GAMEMODE.Config.AdvertPrice)
			pPlayer:AddNote("Your advertisement cost you $" .. string.Comma(GAMEMODE.Config.AdvertPrice))

			return strText
		else
			pPlayer:AddNote("Advertisements cost $" .. string.Comma(GAMEMODE.Config.AdvertPrice) .. ". You can't afford that.")

			return ""
		end
	end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 6)
		table.insert(tblArgs, Color(60, 200, 60))
		table.insert(tblArgs, "(Advertisement) ")

		return strText, -1, true
	end)

	self:Add("/broadcast ", function(pPlayer, strText, bTeamOnly)
		if GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_MAYOR or GAMEMODE.Jobs:GetPlayerJobID(pPlayer) == JOB_DEPUTY_MAYOR then
			return strText
		else
			return ""
		end
	end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 12)
		table.insert(tblArgs, Color(249, 114, 114))
		table.insert(tblArgs, "(Mayor Broadcast) ")

		return strText, -1
	end)

	self:Add("/tweet ", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 8)
		table.insert(tblArgs, Color(122, 170, 255))
		table.insert(tblArgs, "(Tweet) ")

		return strText, -1
	end)

-- 	self:Add("/anontweet ", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
-- 		strText = string.sub(strText, 12)
-- 		table.insert(tblArgs, Color(122, 170, 255))
-- 		table.insert(tblArgs, "(Anonymous Tweet) ")

-- 		return strText, -1, true
-- 	end)

	self:Add("/w ", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 4)
		table.insert(tblArgs, Color(135, 206, 235))
		table.insert(tblArgs, "(Whisper) ")

		return strText, 200
	end)

	self:Add("/y ", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 4)
		table.insert(tblArgs, Color(255, 140, 0))
		table.insert(tblArgs, "(Yell) ")

		return strText, 900
	end)

	self:Add("/me ", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 5)
		table.insert(tblArgs, Color(255, 50, 50))
		table.insert(tblArgs, "(Action) ")

		return strText, 500
	end)

	self:Add("/looc ", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 7)
		table.insert(tblArgs, Color(255, 255, 255))
		table.insert(tblArgs, "(Local OOC) ")
		
		return strText, 500
	end)
	
	self:Add("/roll", function(pPlayer, strText, bTeamOnly) end, function(tblArgs, pPlayer, strText)
		strText = math.random (100)  --> (a number from 1 to 5)
		table.insert(tblArgs, Color(255, 255, 255))
		table.insert(tblArgs, "(Roll) ")

		return strText, 500
	end)

	self:Add("//", function(pPlayer, strText, bTeamOnly)
		if not PUBLIC_SERVER then
			if not pPlayer:IsAdmin() and not pPlayer:CheckGroup("moderator") and not pPlayer:CheckGroup("headofdev") then return "" end
		end

		return strText
	end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 3)
		strText = string.Trim(strText)
		table.insert(tblArgs, Color(60, 200, 60))
		table.insert(tblArgs, "(OOC) ")

		return strText, -1
	end)

	self:Add("/ooc", function(pPlayer, strText, bTeamOnly)
		if not PUBLIC_SERVER then
			if not pPlayer:IsAdmin() and not pPlayer:CheckGroup("moderator") and not pPlayer:CheckGroup("headofdev") then return "" end
		end

		return strText
	end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 5)
		strText = string.Trim(strText)
		table.insert(tblArgs, Color(60, 200, 60))
		table.insert(tblArgs, "(OOC) ")

		return strText, -1
	end)

	self:Add("/announce ", function(pPlayer, strText, bTeamOnly)
		if not pPlayer:IsStaff() then return "" end

		return strText
	end, function(tblArgs, pPlayer, strText)
		strText = string.sub(strText, 11)
		strText = string.Trim(strText)
		table.insert(tblArgs, Color(255, 0, 0))
		table.insert(tblArgs, "(Server Annoucement) ")

		return strText, -1, true
	end)

	self:AddLiteral("/unstuck", function(pPlayer, bTeamOnly)
		if GAMEMODE.Jail:IsPlayerInJail(pPlayer) then
			pPlayer:AddNote("You may not use that command while in jail!")

			return ""
		end

		if pPlayer:InVehicle() then
			pPlayer:AddNote("You may not use that command while in a vehicle!")

			return ""
		end

		if pPlayer:IsIncapacitated() then
			pPlayer:AddNote("You may not use that command while incapacitated!")

			return ""
		end

		if pPlayer.m_intLastUnstuckTime then
			if pPlayer.m_intLastUnstuckTime > CurTime() then
				local time = math.Round(pPlayer.m_intLastUnstuckTime - CurTime())
				pPlayer:AddNote("You must wait " .. time .. " seconds before trying this command again.")

				return ""
			end
		end

		GAMEMODE.Util:UnstuckPlayer(pPlayer)
		pPlayer.m_intLastUnstuckTime = CurTime() + 30
		pPlayer:AddNote("You should now be unstuck!")

		return ""
	end)
end

GM.Module:Register(Module)