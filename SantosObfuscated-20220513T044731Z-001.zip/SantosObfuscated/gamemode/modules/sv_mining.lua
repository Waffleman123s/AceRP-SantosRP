--[[
	Name: sv_mining.lua
	For: SantosRP
	By: Xrayhunter
]]--

GM.Mining = (GAMEMODE or GM).Mining or {}
GM.Mining.ReSpawnTime = 300; -- {30, 300} -- Currently 5 minutes, or with the table 30 seconds to 5 minutes. 
GM.Mining.Limit = 0; -- 0 = [Unlimited] - Mine limit. [Of course following the rules]
GM.Mining.SpawnRateMax = 2; -- 0 = [Unlimited] - Amount of mines will spawn at a time. [Of course following the rules]
GM.Mining.ENT = "ent_mine_base" -- No touch.

function GM.Mining:SaveAllMines()
    local data = {};
    for k, v in pairs(ents.FindByClass(self.ENT))do
        table.insert(data, {pos = v:GetPos(), ang = v:GetAngles()});
    end

	if not file.IsDir("xray", "DATA") then
		file.CreateDir("xray")
	end

	if not file.IsDir("xray/mines", "DATA") then
		file.CreateDir("xray/mines")
    end
    
	if not file.IsDir("xray/mines/" .. game.GetMap(), "DATA") then
		file.CreateDir("xray/mines/".. game.GetMap())
	end

    file.Write("xray/mines/".. game.GetMap() ..".txt", util.TableToJSON(data));
end

function GM.Mining:ForgetAllMines()
	if not file.IsDir("xray", "DATA") then
		file.CreateDir("xray")
	end

	if not file.IsDir("xray/mines", "DATA") then
		file.CreateDir("xray/mines")
    end
    
	if not file.IsDir("xray/mines/" .. game.GetMap(), "DATA") then
		file.CreateDir("xray/mines/".. game.GetMap())
    end
    
    file.Write("xray/mines/".. game.GetMap() ..".txt", util.TableToJSON({}));
end

function GM.Mining:GetAllMines()
	if not file.IsDir("xray", "DATA") then
		file.CreateDir("xray")
	end

	if not file.IsDir("xray/mines", "DATA") then
		file.CreateDir("xray/mines")
    end
    
	if not file.IsDir("xray/mines/" .. game.GetMap(), "DATA") then
		file.CreateDir("xray/mines/".. game.GetMap())
    end
    
    local data = util.JSONToTable(file.Read("xray/mines/".. game.GetMap() ..".txt", "DATA") or "");
    return data or {};
end

function GM.Mining:ResetMines()
    local mines = self:GetAllMines();
    
    for k, v in pairs(ents.FindByClass(self.ENT))do
        if IsValid( v ) then
            v:Remove();
        end
    end

    local countSpawns = 0;
    for k, v in pairs(mines)do
        if self.Limit > 0 and self.Limit > #ents.FindByClass(self.ENT) then return; end; 
        if self.SpawnRateMax > 0 and countSpawns > self.SpawnRateMax then return; end;

        local ent = ents.Create(self.ENT);
        if IsValid(ent) then
            ent:SetPos( v.pos );
            ent:SetAngles( v.ang );
            ent:Spawn();
            countSpawns = countSpawns + 1;
        end
    end
end

function GM.Mining:StartTimer()
    if timer.Exists("gm:mining:spawner") then  
        timer.Destroy("gm:mining:spawner");
    end;
    timer.Create("gm:mining:spawner", 1, 0, function()
        local mines = self:GetAllMines();
        local countSpawns = 0;
        for k, v in pairs(mines)do
            if #ents.FindInSphere(v.pos, 100) > 0 then continue; end; -- Skip, cannot place here.
            if self.Limit > 0 and self.Limit > #ents.FindByClass(self.ENT) then break; end; -- Stop, Too many mines...
            if self.SpawnRateMax > 0 and countSpawns > self.SpawnRateMax then break; end; -- Stop, Too many mines at a time...
    
            local ent = ents.Create(self.ENT);
            if IsValid(ent) then
                ent:SetPos( v.pos );
                ent:SetAngles( v.ang );
                ent:Spawn();
                countSpawns = countSpawns + 1;
            end
        end
        if type(GAMEMODE.Mining.ReSpawnTime) == "table" then
            timer.Simple(math.random(GAMEMODE.Mining.ReSpawnTime[1] or 30, GAMEMODE.Mining.ReSpawnTime[2] or 300), function()
                timer.Start("gm:mining:spawner");
            end)
        elseif type(GAMEMODE.Mining.ReSpawnTime) == "number" then
            timer.Simple(GAMEMODE.Mining.ReSpawnTime, function()
                timer.Start("gm:mining:spawner");
            end)
        end
        timer.Stop("gm:mining:spawner");
    end)
end

hook.Add("PostGamemodeLoaded", "GM:Mining:Load", function()
    (GAMEMODE or GM).Mining:StartTimer();
end)

hook.Add("PostCleanupMap", "GM:Mining:Reload", function()
    (GAMEMODE or GM).Mining:StartTimer();
end)
