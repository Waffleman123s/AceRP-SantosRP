--See https://github.com/SuperiorServers/NoMultirun/

local Module = {}
Module.Name = "NoMultirun"
Module.m_intUpdateRate = 30 --Seconds
Module.m_intTimeoutDelay = 10 --Extra time to consider a session valid for

function Module:GamemodeInitSQLTables()
	GAMEMODE.SQL:PooledQueryWrite( 1, [[CREATE TABLE IF NOT EXISTS `server_sessions` (
`steamid` VARCHAR(255) NOT NULL,
`time` INT NOT NULL,
`server` TEXT NOT NULL,
PRIMARY KEY (`steamid`)
) ENGINE=InnoDB;]] )

	self.ServerID = g_SHA256( GetConVarString("ip").. ":".. GetConVarString("hostport") )

	GAMEMODE.SQL:PooledQueryWrite( 1, ([[DELETE FROM server_sessions WHERE server = '%s';]]):format(self.ServerID) )
	timer.Create( "GM:Module:NoMultirun", self.m_intUpdateRate, 0, function()
		GAMEMODE.SQL:PooledQueryWrite( 1, ([[UPDATE server_sessions SET time = UNIX_TIMESTAMP() WHERE server = '%s';)]]):format(
			self.ServerID
		) )
	end )
end

do
	local query = "SELECT steamid, server FROM server_sessions WHERE steamid='%s' AND time >= (UNIX_TIMESTAMP() -%d) AND server != '%s';"
	function Module:AuthPlayer( strSID64, funcCallback )
		GAMEMODE.SQL:QueryReadOnly( query:format(
			strSID64,
			self.m_intUpdateRate +self.m_intTimeoutDelay,
			self.ServerID
		), function( tblData, q )
			if #tblData > 0 then
				game.KickID( util.SteamIDFrom64(strSID64), "Active player session on another server detected." )
			else
				if funcCallback then funcCallback() end
			end
		end )
	end
end

function Module:CheckPassword( strSID64 )
	self:AuthPlayer( strSID64 )
end

function Module:PlayerAuthed( pPlayer )
	self:AuthPlayer( pPlayer:SteamID64(), function()
		if not IsValid( pPlayer ) then return end

		GAMEMODE.SQL:PooledQueryWrite( 1, ([[REPLACE INTO server_sessions(steamid, time, server) VALUES('%s', UNIX_TIMESTAMP(), '%s');]]):format(
			pPlayer:SteamID64(),
			self.ServerID
		), function()
			if not IsValid( pPlayer ) then return end

			pPlayer.m_bValidGameSession = true
			if pPlayer.m_bGamemodeDataLoaded then --We need to actually start loading them now
				pPlayer.m_bGamemodeDataLoaded = false
				GAMEMODE.Player:PlayerReadyForData( pPlayer )
			end
		end )
	end )
end

function Module:player_disconnect( tblData )
	local sid64 = util.SteamIDTo64( tblData.networkid )
	GAMEMODE.SQL:PooledQueryWrite( 1, ([[DELETE FROM server_sessions WHERE steamid = '%s' AND server = '%s';]]):format(
		sid64,
		self.ServerID
	) )
end

function Module:PlayerInitialSpawn( pPlayer )
	if game.SinglePlayer() then
		pPlayer.m_bValidGameSession = true
		if pPlayer.m_bGamemodeDataLoaded then --We need to actually start loading them now
			pPlayer.m_bGamemodeDataLoaded = false
			GAMEMODE.Player:PlayerReadyForData( pPlayer )
		end
		return	
	end
end

function Module:OnLoad()
	self:RequireHook( "player_disconnect" )
	self:RequireHook( "PlayerAuthed" )
	self:RequireHook( "CheckPassword" )
	self:RequireHook( "GamemodeInitSQLTables" )

	if game.SinglePlayer() then
		self:RequireHook( "PlayerInitialSpawn" )
	end
end

if not DEV_SERVER then
	GM.Module:Register( Module )
end