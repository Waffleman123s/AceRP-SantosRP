local Module = {}
Module.Name = "Player Perms"
Module.Ranks = {}
-- Module.Ranks[rank] = true
Module.Ranks["trialmoderator"] = true
Module.Ranks["moderator"] = true
Module.Ranks["mod"] = true

function Module:SetupMeta()
	local p = debug.getregistry().Player

	function p:IsStaff()
		return self:IsAdmin() or self:IsSuperAdmin() or Module.Ranks[self:GetUserGroup()]
	end
	
	function p:IsPolice()
	    return self:Team() == 2
	    end
end

function Module:OnLoad()
	self:SetupMeta()
end

GM.Module:Register( Module )