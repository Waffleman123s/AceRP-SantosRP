if not serverguard then return end

local Module = {}
Module.Name = "ServerGuard Integration: Shared Component"
Module.AllowedCMDs = {
	["freeze"] = true,
	["send"] = true,
	["spectate"] = true,
	["kick"] = true,
	["ungod"] = true,
	["report"] = true,
	["cleardecals"] = true,
	["noclip"] = true,
	["unmute"] = true,
	["announce"] = true,
	["pm"] = true,
	["invisible"] = true,
	["ungag"] = true,
	["gag"] = true,
	["help"] = true,
	["ignite"] = true,
	["menu"] = true,
	["bring"] = true,
	["return"] = true,
	["extinguish"] = true,
	["ban"] = true,
	["slay"] = true,
	["plugintoggle"] = true,
	["mute"] = true,
	["unban"] = true,
	["respond"] = true,
	["rank"] = true,
	["goto"] = true,
	["a"] = true,
	["god"] = true,
}

function Module:OnLoad()
	self:RequireHook( "Initialize" )
	self:RequireHook( "GamemodeOnPlayerReady" )
end

function Module:Initialize()
	--Some of these commands could cause issues with the gamemode (mainly weapon/armor/ammo/spawning/jailing commands)
	--so only whitelist what we want and remove the rest
	local cmds = serverguard.permission:GetAll()
	for k, v in pairs( serverguard.command:GetTable() ) do
		if not self.AllowedCMDs[k] then
			if v.permissions then --Clean these up!
				if type( v.permissions ) == "string" then
					serverguard.permission:Remove( v.permissions )
				else
					for k2, v2 in pairs( v.permissions ) do
						serverguard.permission:Remove( v2 )
					end
				end
			end

			--Remove the command
			serverguard.command:Remove( k )
		end
	end

	--Suppress global notify - silent mode
	g_ServerGuardNotif = g_ServerGuardNotif or serverguard.Notify

	serverguard.Notify = function( pPlayer, ... )
		if not IsValid( pPlayer ) then return end
		return g_ServerGuardNotif( pPlayer, ... )
	end

	self:RegisterGamemodeCommands()
end

function Module:GamemodeOnPlayerReady( pPlayer )
	--Apply saved admin_hide status if true
	if GAMEMODE.Player:GetCookie( pPlayer, "admin_hide" ) == true then
		pPlayer:SetNW2Bool( "admin_hide", true )
	end
end

function Module:RegisterGamemodeCommands()
	--Unragdoll
	local command = {}
	command.help = "Un-ragdoll/revive another player."
	command.command = "unrag"
	command.arguments = { "player" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Un-Ragdoll" }

	function command:OnPlayerExecute( pPlayer, pTarget, tblArgs )
		if pTarget then
			if pTarget:IsUncon() then
				pTarget:WakeUp()
				return true
			elseif pTarget:IsRagdolled() then
				pTarget:UnRagdoll()
				return true
			end
		end
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Un-Ragdoll", function()
			serverguard.command.Run( "unrag", false, player:SteamID64() )
		end )
		option:SetImage( "icon16/heart.png" )
	end
	serverguard.command:Add( command )

	--Change RP Name
	local command = {}
	command.help = "Changes a player's rp name and saves to sql."
	command.command = "setrpname"
	command.arguments = { "player", "name_first", "name_last" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Set RP Name" }

	function command:OnPlayerExecute( pPlayer, pTarget, tblArgs )
		local first, last = tblArgs[2], tblArgs[3]
		if not first or not last then return end
		
		if first:len() <= 0 or last:len() <= 0 then
			return
		end

		local id = GAMEMODE.SQL:GetPlayerPoolID( pTarget:SteamID64() )
		GAMEMODE.SQL:UpdateCharacterFirstName( id, pTarget:GetCharacterID(), first )
		GAMEMODE.SQL:UpdateCharacterLastName( id, pTarget:GetCharacterID(), last )
		GAMEMODE.Player:SetSharedGameVar( pTarget, "name_first", first )
		GAMEMODE.Player:SetSharedGameVar( pTarget, "name_last", last )	
		pTarget:GetCharacter().Name.First = first 
		pTarget:GetCharacter().Name.Last = last
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Set RP Name", function()
			Derma_StringRequest(
				"Set RP Name",
				"Enter new first name",
				"",
				function( strNameFirst )
					if not strNameFirst or strNameFirst:Trim():len() <= 0 then return end
					Derma_StringRequest(
						"Set RP Name",
						"Enter new last name",
						"",
						function( strNameLast )
							if not strNameLast or strNameLast:Trim():len() <= 0 then return end
							serverguard.command.Run( "setrpname", false, player:SteamID64(), strNameFirst, strNameLast )
						end,
						function( str )
						end,
						"Change Name",
						"Cancel"
					)
				end,
				function( str )
				end,
				"Continue",
				"Cancel"
			)
		end )

		option:SetImage( "icon16/overlays.png" )
	end
	serverguard.command:Add( command )

	--Uncuff
	local command = {}
	command.help = "Frees a player from handcuffs or zipties."
	command.command = "uncuff"
	command.arguments = { "player" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Uncuff" }

	function command:OnPlayerExecute( pPlayer, pTarget, tblArgs )
		pTarget:StripWeapon( "weapon_handcuffed" )
		pTarget:StripWeapon( "weapon_ziptied" )
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Uncuff", function()
			serverguard.command.Run( "uncuff", false, player:SteamID64() )
		end )
		option:SetImage( "icon16/lock_break.png" )
	end
	serverguard.command:Add( command )

	--Heal
	local command = {}
	command.help = "Fully restores a player's health and limb status."
	command.command = "heal"
	command.arguments = { "player" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Heal" }

	function command:OnPlayerExecute( pPlayer, pTarget, tblArgs )
		if not pTarget then return end
		if not pTarget.m_tblLimbMetaData then return end
		
		if pTarget:IsUncon() then
			pTarget:WakeUp()
			return true
		elseif pTarget:IsRagdolled() then
			pTarget:UnRagdoll()
			return true
		end

		GAMEMODE.PlayerDamage:HealPlayerLimbs( pTarget )
		pTarget:SetHealth( pTarget:GetMaxHealth() )
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Heal", function()
			serverguard.command.Run( "heal", false, player:SteamID64() )
		end )
		option:SetImage( "icon16/heart.png" )
	end
	serverguard.command:Add( command )

	--MakeCiv
	local command = {}
	command.help = "Set the job of a player to civilian."
	command.command = "makeciv"
	command.arguments = { "player" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Make Civilian" }

	function command:OnPlayerExecute( pPlayer, pTarget, tblArgs )
		GAMEMODE.Jobs:SetPlayerJob( pTarget, JOB_CIVILIAN )
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Make Civilian", function()
			serverguard.command.Run( "makeciv", false, player:SteamID64() )
		end )
		option:SetImage( "icon16/user_go.png" )
	end
	serverguard.command:Add( command )

	--Set Job
	local command = {}
	command.help = "Set the job of a player."
	command.command = "setjob"
	command.arguments = { "player", "jobid" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Set Job" }

	function command:Execute( pPlayer, bSilent, tblArgs )
		if not GAMEMODE.Jobs:GetJobs()[tblArgs[2] or ""] then return end
		local target = player.GetBySteamID64( tblArgs[1] )
		if not IsValid( target ) then return end
		
		GAMEMODE.Jobs:SetPlayerJob( target, GAMEMODE.Jobs:GetJobs()[tblArgs[2] or ""].ID )
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local jobmenu, option = menu:AddSubMenu( "Set Job" )

		jobmenu:SetSkin( "serverguard" )
		option:SetImage( "icon16/user_go.png" )

		for k, v in pairs( GAMEMODE.Jobs:GetJobs() ) do
			jobmenu:AddOption( v.Name, function()
				serverguard.command.Run( "setjob", false, player:SteamID64(), v.ID )
			end )
		end
	end
	serverguard.command:Add( command )

	--Change Sex
	local command = {}
	command.help = "Change the sex of a player character."
	command.command = "changesex"
	command.arguments = { "player" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Change Sex" }

	function command:Execute( pPlayer, bSilent, tblArgs )
		local target = player.GetBySteamID64( tblArgs[1] )
		if not IsValid( target ) or not target:GetCharacter() then return end

		local newValue = target:GetCharacter().Sex == 0 and 1 or 0
		local cid = target:GetCharacterID()
		
		local id = GAMEMODE.SQL:GetPlayerPoolID( target:SteamID64() )
		GAMEMODE.SQL:UpdateCharacterSex( id, cid, newValue )
		GAMEMODE.Player:SetSharedGameVar( target, "char_sex", newValue )	
		target:GetCharacter().Sex = newValue 

		local mdl = GAMEMODE.Config.PlayerModels[newValue == 0 and "Male" or "Female"]
		mdl, _ = next( mdl )
		target:SetModel( mdl )

		GAMEMODE.Player:SetGameVar( target, "char_model_base", mdl )
		GAMEMODE.Player:SetGameVar( target, "char_model_overload", "" )
		target:GetCharacter().Model.Base = mdl
		target:GetCharacter().Model.Overload = nil
		GAMEMODE.SQL:UpdateCharacterModel( id, cid, mdl )
		GAMEMODE.SQL:UpdateCharacterModelOverload( id, cid, "" )
		GAMEMODE.SQL:CommitPlayerDiffs( target:SteamID64() )

		GAMEMODE.Jobs:SetPlayerJob( target, JOB_CIVILIAN )

		return true
	end
	function command:ContextMenu( player, menu, rankData )
		menu:AddOption( "Change Sex", function()
			Derma_Query(
				"Are you sure you want to do this? Changing sex will change models and force the player back to the civilian job!",
				"Change Sex",
				"OK",
				function() serverguard.command.Run( "changesex", false, player:SteamID64() ) end,
				"Abort",
				function() end
			)
		end )
	end
	serverguard.command:Add( command )

	--Change Model
	local command = {}
	command.help = "Change the model of a player character."
	command.command = "changemodel"
	command.arguments = { "player", "model" }
	command.optionalArguments = {}
	command.bDisallowConsole = true
	command.permissions = { "Change Model" }

	function command:Execute( pPlayer, bSilent, tblArgs )
		local target = player.GetBySteamID64( tblArgs[1] )
		if not IsValid( target ) or not target:GetCharacter() then return end

		local s = target:GetCharacter().Sex
		local mdl = tblArgs[2]
		if not mdl or not GAMEMODE.Config.PlayerModels[s == 0 and "Male" or "Female"][mdl] then
			return
		end

		local cid = target:GetCharacterID()
		local id = GAMEMODE.SQL:GetPlayerPoolID( target:SteamID64() )
		GAMEMODE.SQL:UpdateCharacterSex( id, cid, newValue )

		GAMEMODE.Player:SetGameVar( target, "char_model_base", mdl )
		GAMEMODE.Player:SetGameVar( target, "char_model_overload", "" )
		target:GetCharacter().Model.Base = mdl
		target:GetCharacter().Model.Overload = nil
		GAMEMODE.SQL:UpdateCharacterModel( id, cid, mdl )
		GAMEMODE.SQL:UpdateCharacterModelOverload( id, cid, "" )
		GAMEMODE.SQL:CommitPlayerDiffs( target:SteamID64() )
		target:SetModel( mdl )

		GAMEMODE.Jobs:SetPlayerJob( target, JOB_CIVILIAN )

		return true
	end
	function command:ContextMenu( player, menu, rankData )
		menu:AddOption( "Change Model", function()
			Derma_Query(
				"Are you sure you want to do this? Changing models will force the player back to the civilian job!",
				"Change Sex",
				"OK",
				function() GAMEMODE.Gui:ShowAdminModelPicker( player ) end,
				"Abort",
				function() end
			)
		end )
	end
	serverguard.command:Add( command )

	--Fix Car
	local command = {}
	command.help = "Sets the health of the car a player is looking at to 100%"
	command.command = "fixcar"
	command.arguments = { "player" }
	command.optionalArguments = {}
	command.bDisallowConsole = false
	command.permissions = { "Fix Car" }

	function command:Execute( pPlayer, bSilent, tblArgs )
		local target = player.GetBySteamID64( tblArgs[1] )
		if not IsValid( target ) or not target:GetCharacter() then
			pPlayer:AddNote( "Unkown player given to fixcar" )
			return
		end

		local veh = target:GetEyeTrace().Entity
		if not IsValid( veh ) or not veh:IsVehicle() or not veh.UID then
			pPlayer:AddNote( "Player is not looking at a vehicle!" )
			return
		end
		if veh:GetPos():Distance( target:GetPos() ) > 200 then
			pPlayer:AddNote( "Player is not close enough to the vehicle!" )
			return
		end

		GAMEMODE.Cars:FixVehicleWheels( veh )
		GAMEMODE.Cars:ResetCarHealth( veh )
		pPlayer:AddNote( ("%s's car has been fixed!"):format(target:Nick()) )
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Fix Car", function()
			serverguard.command.Run( "fixcar", false, player:SteamID64() )
		end )
		option:SetImage( "icon16/wrench.png" )
	end
	serverguard.command:Add( command )

	--Hidden
	local command = {}
	command.help = "Hide a player from showing on the scoreboard"
	command.command = "hide"
	command.arguments = { "player", "enable" }
	command.optionalArguments = {}
	command.bDisallowConsole = false
	command.permissions = { "Hide Player" }

	function command:Execute( pPlayer, bSilent, tblArgs )
		local target = player.GetBySteamID64( tblArgs[1] )
		if not IsValid( target ) or not target:GetCharacter() then
			pPlayer:AddNote( "Unkown player given to hide" )
			return
		end

		--Toggle hidden status
		local val = tobool( tblArgs[2] )
		GAMEMODE.Player:WriteCookie( target, "admin_hide", val )
		target:SetNW2Bool( "admin_hide", val )

		pPlayer:AddNote( target:Nick() .. " is now ".. (val and "hidden" or "visible") )
		return true
	end
	function command:ContextMenu( player, menu, rankData )
		local option = menu:AddOption( "Hide Player", function()
			serverguard.command.Run( "hide", false, player:SteamID64(), tostring(not player:GetNW2Bool("admin_hide")) )
		end )
		option:SetImage( "icon16/wrench.png" )
	end
	serverguard.command:Add( command )
end
GM.Module:Register( Module )