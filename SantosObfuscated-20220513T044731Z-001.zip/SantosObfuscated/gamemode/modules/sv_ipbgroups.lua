local Module = {}
Module.Disabled = true
Module.Name = "IPB Forum Groups/Whitelist"
Module.m_tblLoadedGroups = {}

-- Allowed groups in whitelist.
Module.m_tblWhitelistGroups = {
	10, 11, 12, 13, 14, 15, 23, 25, 26,
	29, 31, 33, 34, 38, 39, 4, 40, 41,
	42, 43, 48, 49, 50, 51, 53, 54, 56,
	57, 58, 60, 7, 9, 59, 62
}

Module.m_tblGroupOverloads = {
	["76561198170321387"] = "founder", --ShawnO
}
Module.m_tblListBypass = {
	["76561198170321387"] = true, --ShawnO
	["76561197993104777"] = true, --Ultra
}

Module.m_intConnectRetryInterval = 60
Module.m_tblReconnectErrors = {
	["lost connection to mysql server during query"] = true,
	["mysql server has gone away"] = true,
}

require( "tmysql4" )

function Module:Connect( strIP, strUser, strPass, strDatabaseName )
	local db, err = tmysql.initialize( strIP, strUser, strPass, strDatabaseName )
	if not db then return error( "Unable to initialize a database connection! Error: ".. err ) end
	self.m_pDB = db

	timer.Create( "KeepAliveReadDB", 10, 0, function()
		if not self.m_pDB then return end
		self.m_pDB:Query( "SELECT 5+5;" )
	end )

	GM:LogDebug( "[IPB Link] Forum database connected." )
end

function Module:Query( strQuery, funcCallback )
	if not self.m_pDB then return end
	if not self.m_bWaitingReconnect and self.m_pDB:IsConnected() then --We can run this now
		self.m_pDB:Query( strQuery, function( tblData )
			tblData = tblData[1]

			if tblData.status then --Query ran OK
				funcCallback( tblData )
			else
				funcCallback( tblData )

				GAMEMODE:LogDebug( "[IPB Link] Forum Query Error! Error: ".. tblData.error )
				--We lost connection, put this in the queue and try to start the reconnect loop
				if tblData.error and self.m_tblReconnectErrors[tblData.error:lower()] then
					table.insert( self.m_tblReadQueue, { strQuery, funcCallback } )
					self:ReconnectDB()
				end
			end
		end )
	else
		--We lost connection or are trying to reconnect
		self:ReconnectDB()
		funcCallback( {error = "Lost connection to mysql server during query"} )
	end
end

function Module:ReconnectDB()
	if self.m_bWaitingReconnect then return end --We are already trying to reconnect right now
	GAMEMODE:LogDebug( "[IPB Link] Attempting to reconnect the forum database." )
	self.m_bWaitingReconnect = true

	self.m_pDB:Query( "SELECT 5+5;", function( tblData )
		if tblData.error and self.m_tblReconnectErrors[tblData.error:lower()] then
			GAMEMODE:LogDebug( "[IPB Link] Connection to forum database failed, retrying in ".. self.m_intConnectRetryInterval.. " seconds..." )

			timer.Simple( self.m_intConnectRetryInterval +1, function()
				if not self.m_pDB or not self.m_bWaitingReconnect then return end
				self.m_bWaitingReconnect = nil
				self:ReconnectDB()
			end )
		else
			self.m_bWaitingReconnect = nil

			local runQueue = table.Copy( self.m_tblReadQueue )
			self.m_tblReadQueue = {}
			for k, v in ipairs( runQueue ) do
				self:Query( v[1], v[2] )
			end
		end
	end )
end

function Module:PlayerGroupsLoaded( ply )
	-- Check if the player's groups are saved.
	if self.m_tblLoadedGroups[ply:SteamID64()] then
		return true
	end
	return false
end

function Module:RemovePlayerGroups( ply )
	-- Verify player groups have been loaded.
	if self:PlayerGroupsLoaded( ply ) then
		-- Remove all of their data.
		self.m_tblLoadedGroups[ply:SteamID64()] = nil
	end
end

function Module:InGroup( ply, groupID )
	-- Verify the groups have been loaded
	-- for this player.
	if self:PlayerGroupsLoaded( ply ) then
		-- Check if the user has the specified group.
		if table.HasValue( self.m_tblLoadedGroups[ply:SteamID64()], groupID ) then
			return true
		end
	end

	return false
end

function Module:PlayerInitialSpawn( ply )
	if ply:IsBot() then return end
	
	if not PUBLIC_SERVER then
		GAMEMODE:LogDebug( ("[IPB Link] Begin whitelist check for player %s"):format(ply:Nick()) )
	else
		GAMEMODE:LogDebug( ("[IPB Link] Begin forum data lookup for player %s"):format(ply:Nick()) )
	end
	
	--if ply:IsBot() then return end
	-- Query to check for an existing IPB account and retrieve their groups.
	local query = "SELECT member_id, member_group_id, mgroup_others FROM core_members WHERE steamid='".. ply:SteamID64().. "';"
	-- Perform the query 
	self:Query(query, function( data )
		if not IsValid( ply ) then return end
		local canJoin = false

		-- Verify that data was returned.
		if data.data and data.data[1] then
			local row = data.data[1]
			-- Set up the player's table of groups.
			self.m_tblLoadedGroups[ply:SteamID64()] = {}
			-- Add the player's main group.
			table.insert( self.m_tblLoadedGroups[ply:SteamID64()], row["member_group_id"] )

			if row["member_id"] then
				ply.m_intIPBMemberID = tonumber( row["member_id"] )
			end
		
			-- Check if they have other groups. 
			if row["mgroup_others"] ~= "" then
				-- Split the groups and insert them into the table.
				for g in string.gmatch(row["mgroup_others"], '([^,]+)') do
					-- Add the group.
					table.insert(self.m_tblLoadedGroups[ply:SteamID64()],tonumber(g))
				end
			end
			
			-- Check if any of the groups are in the whitelist.
			for k, g in pairs( self.m_tblLoadedGroups[ply:SteamID64()] ) do
				-- Check if group is whitelisted.
				if table.HasValue( self.m_tblWhitelistGroups, g ) then
					-- Allow the player to join.
					canJoin = true
					if not PUBLIC_SERVER then
						GAMEMODE:LogDebug( ("[IPB Link] Player %s is in group id %d, whitelisted"):format(ply:Nick(), g) )
					end
					
					break
				end
			end
		end
		
		if self.m_tblListBypass[ply:SteamID64()] then canJoin = true end
		
		-- The player will be kicked if they are not allowed in the server. 
		if not PUBLIC_SERVER and not canJoin then
			local msg = ""
			if data.error then
				if self.m_tblReconnectErrors[data.error:lower()] then
					msg = "Unable to connect to the whitelist,\ntry again in a moment or alert staff if the issue persists."
				else
					msg = "You are not whitelisted"
				end
			else
				msg = "You are not whitelisted"
			end

			timer.Simple( 1, function()
				if not IsValid( ply ) then return end
				GAMEMODE:LogDebug( ply:Nick().. " kicked from server. ".. msg )
				ply:Kick( msg )
			end )
		else
			if ulx then --Apply ulx ranks
				for k, data in ipairs( GAMEMODE.Config.IPBUlxGroups ) do
					local breakContinue
					for _, id in pairs( data.ids ) do
						if self.m_tblGroupOverloads[ply:SteamID64()] then
							ply:SetUserGroup( self.m_tblGroupOverloads[ply:SteamID64()] )
							breakContinue = true
						elseif self:InGroup( ply, id ) then
							ply:SetUserGroup( data.group )
							breakContinue = true
							break
						end
					end

					if breakContinue then break end
				end
			elseif serverguard then --Apply serverguard ranks
				--Wait until serverguard loads data, PostPlayerLoad
				serverguard.player:SetRank( ply, "user", true )
			end
		end
	end)
end

function Module:PlayerDisconnected( ply )
	-- Remove the player's groups from the table.
	self:RemovePlayerGroups( ply )
end

function Module:GamemodeIsPlayerJobWhitelisted( pPlayer, intJobID )
	local enum = GAMEMODE.Jobs:GetJobByID( intJobID ).Enum
	if not GAMEMODE.Config.IPBJobWhitelist[enum] then return end
	for k, v in pairs( GAMEMODE.Config.IPBJobWhitelist[enum] ) do
		if self:InGroup( pPlayer, v ) then
			return true
		end
	end
	
	return false
end

--Argh hook names!
Module["serverguard.LoadPlayerData"] = function( self, pPlayer )
	timer.Simple( 5, function()
		if not IsValid( pPlayer ) then return end
		
		for k, data in ipairs( GAMEMODE.Config.IPBServerGuardGroups ) do
			local breakContinue
			for _, id in pairs( data.ids ) do
				if self.m_tblGroupOverloads[pPlayer:SteamID64()] then
					local rankData = serverguard.ranks:GetRank( self.m_tblGroupOverloads[pPlayer:SteamID64()] )
					serverguard.player:SetRank( pPlayer, self.m_tblGroupOverloads[pPlayer:SteamID64()], true )
					serverguard.player:SetImmunity( pPlayer, rankData.immunity )
					pPlayer.m_bIPBRankSet = true
					breakContinue = true
				elseif self:InGroup( pPlayer, id ) then
					local rankData = serverguard.ranks:GetRank( data.group )
					serverguard.player:SetRank( pPlayer, data.group, true )
					serverguard.player:SetImmunity( pPlayer, rankData.immunity )
					pPlayer.m_bIPBRankSet = true
					breakContinue = true
					break
				end
			end
		
			if breakContinue then
				hook.Call( "GamemodePlayerRankApplied", GAMEMODE, pPlayer )
				break
			end
		end
	end )
end

function Module:GamemodeOnPlayerReady( pPlayer )
	if not pPlayer.m_bIPBRankSet then
		self["serverguard.LoadPlayerData"]( self, pPlayer )
	end
end

function Module:GamemodePlayerSelectCharacter( pPlayer )
	GAMEMODE.Player:SetSharedGameVar( pPlayer, "forum_id", pPlayer.m_intIPBMemberID or 0, true )
end

function Module:GamemodeDefineGameVars( pPlayer )
	GAMEMODE.Player:DefineSharedGameVar( pPlayer, "forum_id", 0, "UInt32", true )
end

function Module:OnLoad()
	if not game.SinglePlayer() and not DEV_SERVER then
		self:Connect(
			GM.Config.SQLIPBHostName,
			GM.Config.SQLIPBUserName,
			GM.Config.SQLIPBPassword,
			GM.Config.SQLIPBDBName
		)
		
		self:RequireHook( "PlayerInitialSpawn" )
		self:RequireHook( "PlayerDisconnected" )
		self:RequireHook( "GamemodeIsPlayerJobWhitelisted" )
		self:RequireHook( "serverguard.LoadPlayerData" )
		self:RequireHook( "GamemodeOnPlayerReady" )
		self:RequireHook( "GamemodePlayerSelectCharacter" )
		self:RequireHook( "GamemodeDefineGameVars" )
	end
end

GM.Module:Register( Module )