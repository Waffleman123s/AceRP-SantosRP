ENT.Type = "anim"
ENT.DisableVehicleDamage = true