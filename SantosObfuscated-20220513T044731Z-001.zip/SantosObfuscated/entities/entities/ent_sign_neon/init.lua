--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

local btnData = { scale = 0.2, mdl = 'models/maxofs2d/button_06.mdl', pos = Vector('2.156250 -0.064453 8.012291'), ang = Angle('90.000 -0.000 0.000') }

function ENT:Initialize()
	self:DrawShadow( false )
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:PhysWake()

	self.m_entBtnPower = ents.Create( "ent_button" )
	self.m_entBtnPower:DrawShadow( false )
	self.m_entBtnPower:SetModel( btnData.mdl )
	self.m_entBtnPower:SetPos( self:LocalToWorld(btnData.pos) )
	self.m_entBtnPower:SetAngles( self:LocalToWorldAngles(btnData.ang) )
	self.m_entBtnPower:Spawn()
	self.m_entBtnPower:Activate()
	self.m_entBtnPower:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.m_entBtnPower:SetModelScale( btnData.scale )
	self.m_entBtnPower:SetIsToggle( true )
	self.m_entBtnPower:SetParent( self )
	self.m_entBtnPower.BlockPhysGun = true
	self:DeleteOnRemove( self.m_entBtnPower )

	self.m_entBtnPower:SetCallback( function( _, pPlayer, bToggle )
		self:SetOn( bToggle )
		self.m_entBtnPower:EmitSound( self.SoundButton )
	end )

	self:SetColR( 255 )
	self:SetColG( 255 )
	self:SetColB( 255 )
	self:SetFontID( 0 )
end

function ENT:Use( pPlayer )
	if not IsValid( pPlayer ) or not pPlayer:IsPlayer() then return end
	if self:GetPlayerOwner() ~= pPlayer then return end
	
	GAMEMODE.Net:OpenNeonSignMenu( self, pPlayer )
end

GAMEMODE.Net:RegisterEventHandle( "ent", "nsgn_st", function( intMsgLen, pPlayer )
	local ent = net.ReadEntity()
	if not IsValid( ent ) or ent:GetClass() ~= "ent_sign_neon" then return end
	if ent:GetPlayerOwner() ~= pPlayer then return end
	
	local str = net.ReadString()
	if str:len() > ent.m_intMaxTextLen then return end
	
	ent:SetText( str )
	ent:SetFontID( math.min(net.ReadUInt(4), 3) )
end )

function GAMEMODE.Net:OpenNeonSignMenu( entSign, pPlayer )
	self:NewEvent( "ent", "nsgn_sm" )
		net.WriteEntity( entSign )
	self:FireEvent( pPlayer )
end