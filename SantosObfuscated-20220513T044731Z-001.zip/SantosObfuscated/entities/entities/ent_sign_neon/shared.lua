--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/Items/battery.mdl" )
ENT.SoundButton		= Sound( "buttons/lightswitch2.wav" )
ENT.m_intMaxTextLen = 30

util.PrecacheModel( 'models/maxofs2d/button_06.mdl' )

function ENT:SetupDataTables()
	self:NetworkVar( "Int", 0, "ColR" )
	self:NetworkVar( "Int", 1, "ColG" )
	self:NetworkVar( "Int", 2, "ColB" )

	self:NetworkVar( "Int", 3, "FontID" )
	self:NetworkVar( "String", 0, "Text" )

	self:NetworkVar( "Bool", 0, "On" )
end