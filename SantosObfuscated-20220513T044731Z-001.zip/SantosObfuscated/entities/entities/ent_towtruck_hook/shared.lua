ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= "Bobblehead"
ENT.Purpose			= "Stuff"
ENT.Model 			= Model( "models/statetrooper/ram_tow_hook.mdl" )
ENT.SoundImpact 	= Sound( "weapons/crowbar/crowbar_impact1.wav" )
ENT.SoundHit 		= Sound( "weapons/crossbow/hit1.wav" )

function ENT:SetupDataTables()
	self:NetworkVar( "Entity", 0, "AttachedTo" )
	self:SetAttachedTo( NULL )

	if SERVER then
		self:NetworkVarNotify( "AttachedTo", self.AttachChanged )
	end
end

function ENT:CanPlayerDrag( pPlayer )
	return GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_TOW
end