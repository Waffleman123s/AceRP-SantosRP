--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/Items/ammocrate_smg1.mdl" )
ENT.Sounds 			= {
	[1] = { open = Sound("AmmoCrate.Open"), close = Sound("AmmoCrate.Close") },
	[2] = { open = Sound("ambient/materials/squeekyfloor1.wav"), close = Sound("ambient/materials/squeekyfloor2.wav") },
}

function ENT:SetupDataTables()
	self:NetworkVar( "Int", 0, "MaxVolume" )
end