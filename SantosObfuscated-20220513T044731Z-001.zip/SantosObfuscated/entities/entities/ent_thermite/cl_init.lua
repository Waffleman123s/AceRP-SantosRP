--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra

	fire_01.pcf
		fire_jet_01_flame
]]--

include "shared.lua"

function ENT:Initialize()
end

function ENT:Think()
	if not self.m_sndBurn then
		self.m_sndBurn = CreateSound( self, "weapons/flaregun/burn.wav" )
		self.m_sndBurn:SetSoundLevel( 60 )
		return
	end
	
	if self:GetBurning() and not self.m_sndBurn:IsPlaying() then
		self.m_sndBurn:PlayEx( 0.5, 100 )
		local ang = Angle(
			-self:GetAngles().p,
			self:GetAngles().y +130 +90,
			-self:GetAngles().r
		)
		ParticleEffect( "fire_jet_01_flame", self:GetPos(), ang, self ) 
	elseif not self:GetBurning() and self.m_sndBurn:IsPlaying() then
		self.m_sndBurn:Stop()
	end

	--Update effects
	if self:GetBurning() then
		if CurTime() > (self.m_intLast or 0) then
			self.m_intLast = CurTime() +0.1
			local effectData = EffectData()
			effectData:SetOrigin( self:GetPos() )
			effectData:SetMagnitude( 2 )
			effectData:SetScale( 1 )
			effectData:SetRadius( 1 )
			effectData:SetNormal( self:GetRight() )
			util.Effect( "ElectricSpark", effectData )
		end
	end
end

function ENT:OnRemove()
	self.m_sndBurn:Stop()
end

function ENT:Draw()
	self:DrawModel()
end