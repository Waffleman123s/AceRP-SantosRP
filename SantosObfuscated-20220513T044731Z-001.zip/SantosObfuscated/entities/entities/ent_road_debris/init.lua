--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:DrawShadow( false )
	self.BlockPhysGun = true

	self.m_intHits = 0
	self.m_intMaxHits = 6
end

function ENT:ShovelHit( entShovel )
	self.m_intHits = self.m_intHits +1
	local snd, _ = table.Random( self.Sounds )
	self:EmitSound( snd )
	local shade = 255 *(1 -(self.m_intHits /self.m_intMaxHits))
	self:SetColor( Color(shade, shade, shade, 255) )

	if self.m_intHits >= self.m_intMaxHits then
		if IsValid( entShovel ) and entShovel.OnRoadDebrisClear then
			self.m_entRemovedBy = entShovel.Owner
			entShovel:OnRoadDebrisClear( self )
			self:Remove()
		end
	end
end