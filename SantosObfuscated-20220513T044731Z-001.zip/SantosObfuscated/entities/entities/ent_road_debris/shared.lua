--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_debris/concrete_spawnplug001a.mdl" )
ENT.Sounds 			= {
	Sound( "physics/concrete/boulder_impact_hard1.wav" ),
	Sound( "physics/concrete/boulder_impact_hard2.wav" ),
	Sound( "physics/concrete/boulder_impact_hard3.wav" ),
	Sound( "physics/concrete/boulder_impact_hard4.wav" ),
}

ENT.FixDuration		= 12

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "WrenchAttached" )
	self:NetworkVar( "Float", 0, "AttachTime" )
end