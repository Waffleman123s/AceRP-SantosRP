--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra
]]--

include "shared.lua"

local colBlack = Color( 0, 0, 0, 255 )
local childEnts = {
	{ mdl = Model('models/props_wasteland/prison_pipefaucet001a.mdl'), pos = Vector('10.053988 -16.002645 -14.779698'), ang = Angle('-0.120 -135.000 0.159') },
	{ mdl = Model('models/props_pipes/valve003.mdl'), pos = Vector('0.015963 -15.021167 5.458448'), ang = Angle('89.800 -82.093 7.907') },
	{ mdl = Model('models/props_pipes/pipe03_straight01_long.mdl'), pos = Vector('11.281982 0.591003 23.429970'), ang = Angle('-0.159 -45.000 89.880') },
	{ mdl = Model('models/props_pipes/pipe02_connector01.mdl'), pos = Vector('-8.465456 -4.227775 12.494489'), ang = Angle('-89.800 99.463 -99.452') },
	{ mdl = Model('models/props_lab/powerbox02b.mdl'), pos = Vector('-0.032367 15.409517 -16.056519'), ang = Angle('0.198 90.000 -0.027') },
	{ mdl = Model('models/props_lab/reciever01d.mdl'), pos = Vector('-6.472632 1.488562 8.602362'), ang = Angle('0.159 135.000 0.120') },
	{ mdl = Model('models/props_lab/reciever01d.mdl'), pos = Vector('-6.487377 1.464255 5.238107'), ang = Angle('0.159 135.000 0.120') },
}
local sndBoil = Sound( "ambient/machines/deep_boil.wav" )
local sndMachine = Sound( "ambient/machines/refinery_loop_1.wav" )

ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:Initialize()
	self.m_tblEnts = {}

	for k, v in pairs( childEnts ) do
		local ent = ClientsideModel( v.mdl, RENDERGROUP_OPAQUE )
		ent:SetPos( self:LocalToWorld(v.pos) )
		ent:SetAngles( self:LocalToWorldAngles(v.ang) )
		ent:SetParent( self )
		ent:SetNoDraw( true )
		self.m_tblEnts[ent] = k
	end

	self.m_sndBoil = CreateSound( self, sndBoil )
	self.m_sndMachine = CreateSound( self, sndMachine )
end

function ENT:OnRemove()
	for k, v in pairs( self.m_tblEnts ) do
		k:Remove()
	end

	if self.m_sndBoil then self.m_sndBoil:Stop() end
	if self.m_sndMachine then self.m_sndMachine:Stop() end
end

function ENT:Draw()
	self:DrawModel()

	for k, v in pairs( self.m_tblEnts ) do
		if not IsValid( k ) then continue end
		if not IsValid( k:GetParent() ) then
			k:SetPos( self:LocalToWorld(childEnts[v].pos) )
			k:SetAngles( self:LocalToWorldAngles(childEnts[v].ang) )
			k:SetParent( self )
		end
		
		k:SetNoDraw( false )
			k:DrawModel()
		k:SetNoDraw( true )
	end

	self:DrawUI()
end

function ENT:ThinkSounds()
	if self:GetStillOn() then
		if not self.m_sndBoil:IsPlaying() then
			self.m_sndBoil:SetSoundLevel( 58 )
			self.m_sndBoil:PlayEx( 0.8, 100 )
		end

		if not self.m_sndMachine:IsPlaying() then
			self.m_sndMachine:SetSoundLevel( 58 )
			self.m_sndMachine:PlayEx( 0.25, 100 )
		end
	else
		if self.m_sndBoil:IsPlaying() then
			self.m_sndBoil:Stop()
		end

		if self.m_sndMachine:IsPlaying() then
			self.m_sndMachine:Stop()
		end
	end
end

function ENT:Think()
	self:ThinkSounds()
end

function ENT:DrawBar( intX, intY, intW, intH, colColor, intCur, intMax )
	surface.SetDrawColor( colBlack )
	surface.DrawRect( intX, intY, intW, intH )

	local padding = 1
	local wide = (intCur /intMax) *(intW -(padding *2))
	surface.SetDrawColor( colColor )
	surface.DrawRect( intX +padding, intY +padding, wide, intH -(padding *2) )
end

local colRed = Color( 255, 50, 50, 255 )
function ENT:DrawUI()
	if self:GetPos():DistToSqr( LocalPlayer():GetPos() ) > GAMEMODE.Config.RenderDist_Level1 ^2 then
		return
	end

	local data = GAMEMODE.Inv:GetItem( self:GetItemID() or "" )
	if not data or not data.StillVars then return end
	
	--Fluid Amount
	local camPos = self:LocalToWorld( Vector(-6.95, 9.2, 8.17) )
	local camAng = self:LocalToWorldAngles( Angle(0, 225, 90) )
	cam.Start3D2D( camPos, camAng, 0.05 )
		self:DrawBar( 0, -(48 /2), 96, 48, colRed, self:GetFluidAmount(), self.MaxFluid )
		
		surface.SetFont( "DermaLarge" )
		surface.SetTextColor( 255, 255, 255, 255 )
		surface.SetTextPos( 5, -16 )
		surface.DrawText( "Fluid" )
	cam.End3D2D()

	--ID
	local camPos = self:LocalToWorld( Vector(-6.95, 9.2, 4.8) )
	local camAng = self:LocalToWorldAngles( Angle(0, 225, 90) )
	cam.Start3D2D( camPos, camAng, 0.05 )
		self:DrawBar( 0, -(48 /2), 96, 48, colRed, self:GetProgress(), self.MaxProgress )
		
		surface.SetFont( "Trebuchet18" )
		surface.SetTextColor( 255, 255, 255, 255 )
		surface.SetTextPos( 5, -19 )
		surface.DrawText( data.Name.. " ->" )
		surface.SetTextPos( 5, 0 )
		surface.DrawText( data.StillVars.GiveItem )
	cam.End3D2D()
end