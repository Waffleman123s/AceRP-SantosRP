--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 				= "anim"
ENT.Base 				= "base_anim"
ENT.PrintName			= ""
ENT.Author				= ""
ENT.Purpose				= ""
ENT.Model 				= Model( "models/props_c17/substation_transformer01d.mdl" )
ENT.SoundOn 			= Sound( "buttons/lever5.wav" )
ENT.SoundDumpOn 		= Sound( "ambient/machines/squeak_3.wav" )
ENT.SoundDumpOff 		= Sound( "ambient/machines/squeak_5.wav" )

util.PrecacheModel( 'models/maxofs2d/button_03.mdl' )

ENT.MaxProgress 		= 500
ENT.MaxFluid			= 500

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "StillOn" )
	self:NetworkVar( "Int", 0, "Progress" )
	self:NetworkVar( "Int", 1, "FluidAmount" )
	self:NetworkVar( "String", 0, "ItemID" )
end