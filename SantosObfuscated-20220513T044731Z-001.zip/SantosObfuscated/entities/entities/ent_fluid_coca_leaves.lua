--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	AddCSLuaFile()
end

ENT.Base = "ent_base_fluid"
ENT.Model = Model( "models/props_junk/garbage_bag001a.mdl" )

function ENT:ConfigInit()
	if SERVER then
		self:SetModel( self.Model )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
		self:PhysWake()

		self:SetFluidID( "Mulched Coca Leaves" )
		self:SetEffect( "dirtFx", Vector(-7.283790, -2.089086, -1.120362), Color(60, 25, 0, 255) )
		self:SetCarryAngles( Angle(-90, 180, 0), Angle(15, 180, 0) )
	end
end