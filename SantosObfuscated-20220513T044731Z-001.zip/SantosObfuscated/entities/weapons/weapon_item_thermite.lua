--[[
	Name: weapon_item_thermite.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName		= "Thermite"
SWEP.Author			= "Ultra"
SWEP.Base 			= "weapon_sck_base"
SWEP.Instructions	= ""
SWEP.Slot 			= 2
SWEP.HoldType 		= "slam"
SWEP.ViewModelFOV 	= 70
SWEP.ViewModelFlip 	= false
SWEP.UseHands 		= true
SWEP.ViewModel 		= "models/weapons/c_grenade.mdl"
SWEP.WorldModel 	= "models/weapons/w_grenade.mdl"
SWEP.ShowViewModel 	= false
SWEP.ShowWorldModel = false

SWEP.VElements = {
	["element_name"] = { type = "Model", model = "models/props_junk/flare.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(3.581, 2.482, 0), angle = Angle(2.492, 0.953, 179.277), size = Vector(1.435, 1.435, 1.435), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/props_canal/metalcrate001d", skin = 0, bodygroup = {} }
}
SWEP.WElements = {
	["element_name"] = { type = "Model", model = "models/props_junk/flare.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(3.188, 1.764, 0), angle = Angle(12.571, -18.893, -177.167), size = Vector(1.146, 1.146, 1.146), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/props_canal/metalcrate001d", skin = 0, bodygroup = {} }
}

SWEP.WeaponName = "weapon_item_thermite"
SWEP.ItemName = "Thermite"

function SWEP:PrimaryAttack()
	if self:GetNextPrimaryFire() > CurTime() then return end
	self:SetNextPrimaryFire( CurTime() +2 )
	self:SendWeaponAnim( ACT_VM_MISSCENTER )

	if not IsFirstTimePredicted() then return end
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	if CLIENT then return end

	local tr = util.TraceLine{
		start = self.Owner:GetShootPos(),
		endpos = self.Owner:GetShootPos() +self.Owner:GetAimVector() *64,
		filter = { self, self.Owner }
	}
	local ent = tr.Entity
	
	if IsValid( ent ) and ent.CanAttachThermite and ent.ThermitePoints then
		local lPos = ent:WorldToLocal( tr.HitPos )

		local best, r = nil, math.huge
		for k, v in pairs( ent.ThermitePoints ) do
			local d = lPos:Distance( v.pos )
			if d < r then
				best = k
				r = d
			end	
		end
		
		if not best then return end
		if r > 16 then return end

		if ent:CanAttachThermite( self.Owner, best ) then
			--We have an empty slot and we clicked near it, time to place
			ent:AttachThermite( self.Owner, best )
			self:TakeInventoryAmmo()
		end
	end
end

function SWEP:SecondaryAttack()
end

function SWEP:TakeInventoryAmmo()
	if SERVER then
		local count = 0
		for itemID, num in pairs( self.Owner:GetInventory() or {} ) do
			if not GAMEMODE.Inv:GetItem( itemID or "" ) then continue end
			if GAMEMODE.Inv:GetItem( itemID ).EquipGiveClass == self.WeaponName then
				count = count +num
			end
		end

		for slotName, itemID in pairs( self.Owner:GetEquipment() or {} ) do
			if not GAMEMODE.Inv:GetItem( itemID or "" ) then continue end
			if GAMEMODE.Inv:GetItem( itemID ).EquipGiveClass == self.WeaponName then
				count = count +1
			end
		end

		if count > 1 then
			GAMEMODE.Inv:TakePlayerItem( self.Owner, self.ItemName, 1 )
		else
			if count > 0 then
				if GAMEMODE.Inv:PlayerHasItemEquipped( self.Owner, self.ItemName ) then
					for slotName, itemID in pairs( self.Owner:GetEquipment() or {} ) do
						if itemID ~= self.ItemName then continue end
						GAMEMODE.Inv:DeletePlayerEquipItem( self.Owner, slotName )
					end
				end
			end
		end
	end
end

if CLIENT then
	function SWEP:DrawHUD()
		local ent = LocalPlayer():GetEyeTrace().Entity
		if not IsValid( ent ) or not ent:GetNW2Bool( "ThermiteEnabled" ) then return end
		if ent:GetPos():DistToSqr( LocalPlayer():GetPos() ) > 16384 then return end
		
		for i = 1, ent:GetNW2Int( "ThermiteSlots", 0 ) do
			if ent:GetNW2Bool( "ThermiteSlot".. i ) then continue end

			local pos = ent:LocalToWorld( ent:GetNW2Vector("ThermiteSlot".. i.. "_pos", Vector(0, 0, 0))):ToScreen()
			draw.SimpleTextOutlined(
				"Place Thermite",
				"Trebuchet18",
				pos.x,
				pos.y,
				color_white,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_CENTER,
				1,
				color_black
			)
		end
	end
end