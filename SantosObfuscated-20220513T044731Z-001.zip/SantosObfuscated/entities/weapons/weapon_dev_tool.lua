--[[
	Name: weapon_wrench.lua
	For: SantosRP
	By: Xray
]]--

if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName		= "Santos Developer Tool - Entity Inspector"
SWEP.Author			= "Xray"
SWEP.Instructions	= "Entity Inspector."
SWEP.Base 			= "weapon_base"
SWEP.ViewModel 		= "models/weapons/v_pistol.mdl"
SWEP.WorldModel 	= "models/weapons/w_pistol.mdl"
SWEP.ViewModelFOV	= 55

SWEP.Spawnable		= false
SWEP.Slot 			= 5
SWEP.UseHands 		= true

SWEP.HoldType 		= "slam"

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"
SWEP.ShowWorldModel 		= false
SWEP.ShowViewModel 			= false

local selected = {};
local lastCurTime = CurTime();

function SWEP:SetupDataTables()
end

local modes = {
	{
		["name"] = "Entity Inspector", 
		["funcs"] = {
			["Init"] = function(ply, wep)
				wep.selected = {};
			end,
			["Destruct"] = function(ply, wep)
				wep.selected = {};
			end,
			["PrimaryAttack"] = function(ply, wep)
				wep.selected = {};
				if SERVER then
					local tr = ply:GetEyeTrace();
					local ent = tr.Entity;

					if not tr.Entity or not IsValid( ent ) then 
						if tr.HitPos then
							ply:EmitSound("UI/buttonclick.wav");
							debugoverlay.Box( tr.HitPos, Vector(-10, -10, -10), Vector(10, 10, 10), 30, Color( 255, 0, 0 ) )

							ply:ChatPrint("Hit Pos: Vector(" .. tr.HitPos.x .. ", " ..tr.HitPos.y .. ", " .. tr.HitPos.z .. ")");
						else
							ply:ChatPrint("No Target found...");
							ply:EmitSound("buttons/combine_button_locked.wav"); 
						end

						return; 
					end;
					ply:EmitSound("UI/buttonclick.wav");
	
					ply:ChatPrint("Check you console, information has been printed there.");
					ply:ChatPrint("["..ent:GetClass() .. "] [ENT-".. ent:EntIndex().."|MCID-".. ent:MapCreationID() .."]");
					ply:ChatPrint("=================================")
					ply:ChatPrint("Model: " .. ent:GetModel());
					if ent:IsVehicle() then
						ply:ChatPrint("Vehicle Class: " .. ent:GetVehicleClass() or ent.UID);
					end
					ply:ChatPrint("Current Skin: " .. ent:GetSkin());
					ply:ChatPrint("Skin Count: " .. ent:SkinCount());
					for k, v in pairs(ent:GetMaterials())do
						ply:ChatPrint("\t[".. k .."] = \"" .. v .. "\"");
					end
					ply:ChatPrint("Position: " .. ent:GetPos().x .. ", " .. ent:GetPos().y .. "," .. ent:GetPos().z);
					ply:ChatPrint("Angle: " .. ent:GetAngles().x .. ", " .. ent:GetAngles().y .. "," .. ent:GetAngles().z);
					ply:ChatPrint("Hit Pos: " .. tr.HitPos.x .. ", " ..tr.HitPos.y .. "," .. tr.HitPos.z);
					ply:ChatPrint("Relative Position of Hit: " .. (tr.HitPos.x - ent:GetPos().x) .. ", " .. (tr.HitPos.y - ent:GetPos().y) .. ", " .. (tr.HitPos.z - ent:GetPos().z));
					
					table.insert(wep.selected, ent);
				end
			end
		},
	},
	{
		["name"] = "Remove", 
		["funcs"] = {
			["PrimaryAttack"] = function(ply, wep)
				wep.selected = {};
				if CLIENT then
					wep:EmitSound("UI/buttonclick.wav");
				end
				if SERVER then
					-- Spawn Entity...
					local tr = util.TraceLine( {
						start = ply:EyePos(),
						endpos = ply:EyePos() + ply:EyeAngles():Forward() * 10000,
						filter = function( ent ) if (ent ~= ply) then return true; end end
					} );
					local ent = tr.Entity;
					if IsValid( ent ) and not ent:IsPlayer() then
						if ent.IsMapProp then return end
						ent:Remove();
					end
				end
			end
		},
	},
	{
		["name"] = "Print Position Collection", 
		["funcs"] = {
			["Init"] = function(ply, wep)
				wep.selected = {};
			end,
			["Destruct"] = function(ply, wep)
				wep.selected = {};
			end,
			["PrimaryAttack"] = function(ply, wep)
				if CLIENT then
					wep:EmitSound("UI/buttonclick.wav");
				end
				if SERVER then
					local tr = util.TraceLine( {
						start = ply:EyePos(),
						endpos = ply:EyePos() + ply:EyeAngles():Forward() * 10000,
						filter = function( ent ) if (ent ~= ply) then return true; end end
					} );
					table.insert(wep.selected, {pos = tr.HitPos});
					print("{")
					for k, v in pairs(wep.selected)do
						print("\t{ pos = Vector(".. tostring(v.pos.x) .. ", " .. tostring(v.pos.y) .. ", " .. tostring(v.pos.z)  .."), ang = Angle(0, 0, 0) },");
					end
					print("}")
				end
			end
		},
	},
	{
		["name"] = "Add Mine Spawner", 
		["funcs"] = {
			["Init"] = function(ply, wep)
				wep.selected = {};
				if CLIENT then
					if wep.GhostEnt and IsValid( wep.GhostEnt ) then
						wep.GhostEnt:Remove();
						wep.GhostEnt = nil;
					end
					wep.GhostEnt = ents.CreateClientProp()
					wep.GhostEnt:SetModel("models/props_canal/rock_riverbed02c.mdl")
					wep.GhostEnt:Spawn()
					wep.GhostEnt:SetMaterial("models/wireframe")
				end
			end,
			["Destruct"] = function(ply, wep)
				wep.selected = {};
				if CLIENT then
					if wep.GhostEnt and IsValid( wep.GhostEnt ) then
						wep.GhostEnt:Remove();
						wep.GhostEnt = nil;
					end
				end
			end,
			["Holster"] = function(ply, wep)
				wep.selected = {};
				if CLIENT then
					if wep.GhostEnt and IsValid( wep.GhostEnt ) then
						wep.GhostEnt:Remove();
						wep.GhostEnt = nil;
					end
				end
			end,
			["PrimaryAttack"] = function(ply, wep)
				wep.selected = {};
				if CLIENT then
					if IsValid( wep.GhostEnt ) then wep:EmitSound("buttons/combine_button_locked.wav"); return; end;
					wep:EmitSound("UI/buttonclick.wav");
				end

				if SERVER then
					-- Spawn Entity...
					local tr = util.TraceLine( {
						start = ply:EyePos(),
						endpos = ply:EyePos() + ply:EyeAngles():Forward() * 10000,
						filter = function( ent ) if (ent ~= ply) then return true; end end
					} );
					local ent = ents.Create("ent_mine_base");
					ent:SetPos( tr.HitPos );
					ent:Spawn();
					ply:AddNote("Created a Mine, if you are ready to save it then goto the save option!");
				end
			end,
			["Think"] = function(wep)
				if CLIENT then
					local tr = util.TraceLine( {
						start = LocalPlayer():EyePos(),
						endpos = LocalPlayer():EyePos() + LocalPlayer():EyeAngles():Forward() * 10000,
						filter = function( ent ) if (ent ~= ply) then return true; end end
					} );
					if wep.GhostEnt and IsValid( wep.GhostEnt ) then
						wep.GhostEnt:SetPos( tr.HitPos );
					end
				end
			end
		},
	},
	{
		["name"] = "Save Mine Spawner", 
		["funcs"] = {
			["Init"] = function(ply, wep)
				wep.selected = {};
			end,
			["Destruct"] = function(ply, wep)
				wep.selected = {};
			end,
			["PrimaryAttack"] = function(ply, wep)
				if SERVER then
					wep:EmitSound("UI/buttonclick.wav");
					ply:AddNote("Saved all mines!");
					(GAMEMODE or GM).Mining:SaveAllMines();
					for k, v in pairs(ents.FindByClass("ent_mine_base"))do
						v:Remove();
					end
					GAMEMODE.Mining:StartTimer();
				end
			end
		},
	},
	{
		["name"] = "Clear Mine Spawner", 
		["funcs"] = {
			["Init"] = function(ply, wep)
				wep.selected = {};
			end,
			["Destruct"] = function(ply, wep)
				wep.selected = {};
			end,
			["PrimaryAttack"] = function(ply, wep)
				if SERVER then
					-- Delete File and create it again.
					(GAMEMODE or GM).Mining:ForgetAllMines();
					(GAMEMODE or GM).Mining:ResetMines();
					ply:AddNote("Forgot all mines & cleaned up the map of mines!");
				end
			end
		},
	},
}; 
local curMode = modes[1];
function SWEP:PrimaryAttack()
	if lastCurTime + 1 <= CurTime() then
		lastCurTime = CurTime();

		if type(curMode) == "table" then
			if type(curMode["funcs"]) == "table" and isfunction(curMode["funcs"]["PrimaryAttack"]) then
				curMode["funcs"]["PrimaryAttack"](self.Owner, self);
				print (curMode["name"], "- PrimaryAttack", tostring(SERVER), tostring(CLIENT))
			end
		end
	end
end

if CLIENT then
	hook.Add("PreDrawHalos", "Dev.Halo", function()
		if not IsValid( LocalPlayer() ) or 
		not IsValid( LocalPlayer():GetActiveWeapon() ) or 
		LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_dev_tool" then return end;
		print("Rendering halo")
		halo.Add(table.GetKeys(LocalPlayer():GetActiveWeapon().selected or {}), Color(0, 255, 0), 10, 10, 2, true, true)
	end)
end

local menu = nil;
function SWEP:SecondaryAttack()
	if menu ~= nil then
		menu = nil;
	end
	if CLIENT and menu == nil then
		menu = DermaMenu();
		for k, v in pairs(modes) do
			menu:AddOption( v["name"], function()
				if curMode and type(curMode["funcs"]) == "table" and isfunction(curMode["funcs"]["Destruct"]) then 
					curMode["funcs"]["Destruct"](self.Owner, self);
				end

				curMode = v;
				net.Start("dtll");
					net.WriteString(v["name"]);
				net.SendToServer();

				if curMode and type(curMode["funcs"]) == "table" and isfunction(curMode["funcs"]["Init"]) then 
					v["funcs"]["Init"](self.Owner, self); 
				end
				
				menu = nil; 
			end);
		end
		menu:AddOption( "Close", function() menu = nil; end);
		menu:Open()
	end
end

function SWEP:Think()
	if type(curMode) == "table" and isfunction(curMode["funcs"]["Think"]) then 
		curMode["funcs"]["Think"](wep);
	end
end

function SWEP:Holster()
	if type(curMode) == "table" and isfunction(curMode["funcs"]["Holster"]) then 
		return curMode["funcs"]["Holster"](self.Owner, self) or true;
	end
	return true;
end

function SWEP:Reload()
	if type(curMode) == "table" and isfunction(curMode["funcs"]["Reload"]) then 
		return curMode["funcs"]["Reload"](self.Owner, self) or true;
	end
	return;
end

function SWEP:FireAnimationEvent( _, _, intEvent )
	if intEvent == 5001 or intEvent == 6001 then return true end
end

function SWEP:DrawHUD()
end

if SERVER then
	util.AddNetworkString("dtll")
	net.Receive("dtll", function(len, ply)
		local name = net.ReadString();
		
		if ply:GetActiveWeapon() == nil or ply:GetActiveWeapon():GetClass() ~= "weapon_dev_tool" then
			ply:Kick("Malicious Packet!");
			return;
		end

		if curMode and type(curMode["funcs"]) == "table" and isfunction(curMode["funcs"]["Destruct"]) then 
			curMode["funcs"]["Destruct"](ply, ply:GetActiveWeapon());
		end
		for k, v in pairs(modes) do
			if v["name"] == name then
				curMode = v;
				
				if curMode and type(curMode["funcs"]) == "table" and isfunction(curMode["funcs"]["Init"]) then 
					v["funcs"]["Init"](ply, ply:GetActiveWeapon()); 
				end
				return;
			end
		end
		ply:Kick("Malicious Packet!");
	end)
end