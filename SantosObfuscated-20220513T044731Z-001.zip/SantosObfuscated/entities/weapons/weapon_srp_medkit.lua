--[[
	Name: weapon_srp_medkit.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName		= "Medkit"
SWEP.Author			= "Ultra"
SWEP.Instructions	= "Left Click: Apply Bandages"

SWEP.ViewModel		= Model( "models/weapons/c_medkit.mdl" )
SWEP.WorldModel		= Model( "models/weapons/w_medkit.mdl" )
SWEP.ViewModelFOV	= 54

SWEP.Spawnable		= false
SWEP.Slot 			= 5
SWEP.UseHands 		= true

SWEP.HoldType 		= "slam"

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"
SWEP.ShowWorldModel 		= false
SWEP.ShowViewModel 			= false

local HealSound = Sound( "HealthKit.Touch" )
local DenySound = Sound( "WallHealth.Deny" )


function SWEP:Initialize()
	self:SetHoldType( "slam" )
end

function SWEP:OnRemove()
	timer.Stop( "weapon_idle".. self:EntIndex() )
end

function SWEP:Holster()
	timer.Stop( "weapon_idle".. self:EntIndex() )
	return true
end

function SWEP:TakeInventoryAmmo()
	if CLIENT then return end
	local govItem = "Government Issue Medical Supplies"
	local fdItem = "FD Issue Medical Supplies"
	local civItem = "Medical Supplies"

	if not GAMEMODE.Inv:TakePlayerItem( self.Owner, govItem, 1 ) then
		if not GAMEMODE.Inv:TakePlayerItem( self.Owner, fdItem, 1 ) then
			GAMEMODE.Inv:TakePlayerItem( self.Owner, civItem, 1 )
		end
	end

	if GAMEMODE.Inv:GetPlayerItemAmount( self.Owner, govItem ) <= 0 then
		if GAMEMODE.Inv:GetPlayerItemAmount( self.Owner, fdItem ) <= 0 then
			if GAMEMODE.Inv:GetPlayerItemAmount( self.Owner, civItem ) <= 0 then
				local has, slot = GAMEMODE.Inv:PlayerHasItemEquipped( self.Owner, "First Aid Kit" )
				if not has then
					has, slot = GAMEMODE.Inv:PlayerHasItemEquipped( self.Owner, "Government Issue First Aid Kit" )
				end
				if not has then
					has, slot = GAMEMODE.Inv:PlayerHasItemEquipped( self.Owner, "FD Issue First Aid Kit" )
				end

				if has then
					if GAMEMODE.Inv:GivePlayerItem( self.Owner, self.Owner:GetEquipSlot(slot) ) then
						GAMEMODE.Inv:DeletePlayerEquipItem( self.Owner, slot )
					end
				end
			end
		end
	end
end

function SWEP:HasInventoryAmmo()
	local govItem = "Government Issue Medical Supplies"
	local fdItem = "FD Issue Medical Supplies"
	local civItem = "Medical Supplies"

	if SERVER then
		if GAMEMODE.Inv:GetPlayerItemAmount( self.Owner, govItem ) > 0 then return true end
		if GAMEMODE.Inv:GetPlayerItemAmount( self.Owner, fdItem ) > 0 then return true end
		return GAMEMODE.Inv:GetPlayerItemAmount( self.Owner, civItem ) > 0
	else
		if self.Owner ~= LocalPlayer() then return true end
		if GAMEMODE.Inv:PlayerHasItem( govItem, 1 ) then return true end
		if GAMEMODE.Inv:PlayerHasItem( fdItem, 1 ) then return true end
		if GAMEMODE.Inv:PlayerHasItem( civItem, 1 ) then return true end
		return false
	end
end

function SWEP:CanHeal( entTarget )
	local max = GAMEMODE.Jobs:GetNumPlayers( JOB_EMS ) > 0 and 0.33 or 1

	if SERVER then
		if hook.Call( "GamemodeCanPlayerHealPlayer", GAMEMODE, self.Owner, entTarget ) == false then
			return false
		end
		
		if GAMEMODE.PlayerDamage:PlayerHasDamagedLimbs( entTarget, true, max ) then
			return true
		end

		if entTarget:Health() < entTarget:GetMaxHealth() *max then
			return true
		end

		if GAMEMODE.Jobs:GetNumPlayers( JOB_EMS ) <= 0 then
			if GAMEMODE.PlayerDamage:PlayerHasBrokenBone( entTarget ) then
				return true
			end

			if GAMEMODE.PlayerDamage:IsPlayerBleeding( entTarget ) then
				return true
			end
		end

		return false
	else
		if entTarget:Health() >= (100 *max) then
			return false
		end
	end

	return true
end

function SWEP:HealTarget( intAmount, eEnt )
	local max = GAMEMODE.Jobs:GetNumPlayers( JOB_EMS ) > 0 and 0.33 or 1
	if self.Owner:Health() < self.Owner:GetMaxHealth() *max then
		intAmount = math.Clamp( self.Owner:Health() +intAmount, 0, self.Owner:GetMaxHealth() *max )

		local diff = self.Owner:GetMaxHealth() *max
		diff = diff -self.Owner:Health()
		diff = intAmount -diff

		if diff > 0 then
			self:HealTargetLimbs( eEnt, diff )
		end
	else
		return self:HealTargetLimbs( eEnt, intAmount  )
	end

	eEnt:SetHealth( intAmount )
end

function SWEP:HealTargetLimbs( pPlayer, intAmount )
	local max = GAMEMODE.Jobs:GetNumPlayers( JOB_EMS ) > 0 and 0.33 or 1
	local num = intAmount
	local cur
	for k, v in pairs( GAMEMODE.PlayerDamage:GetLimbs() ) do
		cur = GAMEMODE.PlayerDamage:GetPlayerLimbHealth( pPlayer, k )
		if cur >= v.MaxHealth *max then continue end
		
		if num > (v.MaxHealth *max) -cur then
			GAMEMODE.PlayerDamage:SetPlayerLimbHealth( pPlayer, k, v.MaxHealth *max )
			num = num -((v.MaxHealth *max) -cur)
		else
			GAMEMODE.PlayerDamage:SetPlayerLimbHealth( pPlayer, k, cur +num )
			num = 0
			break
		end
	end

	return num ~= intAmount, num
end

function SWEP:BandagePlayerLimb( pPlayer )
	local numEMS = GAMEMODE.Jobs:GetNumPlayers( JOBS_EMS )
	for k, v in pairs( GAMEMODE.PlayerDamage:GetLimbs() ) do
		local ret
		if GAMEMODE.PlayerDamage:IsPlayerLimbBleeding( pPlayer, k ) then
			if GAMEMODE.PlayerDamage:PlayerLimbHasBandage( pPlayer, k ) then continue end

			if numEMS <= 0 then
				GAMEMODE.PlayerDamage:SetPlayerLimbBleeding( pPlayer, k, false )
			else
				GAMEMODE.PlayerDamage:ApplyPlayerLimbBandage( pPlayer, k, GAMEMODE.Config.BleedBandageDuration )
			end

			ret = true
		end
		
		if numEMS <= 0 then
			if GAMEMODE.PlayerDamage:IsPlayerLimbBroken( pPlayer, k ) then
				GAMEMODE.PlayerDamage:SetPlayerLimbBroken( pPlayer, k, false )
				ret = true
			end
		end
		
		if ret then return true end
	end
	return false
end

function SWEP:PrimaryAttack()
	if CLIENT then return end
	if not IsFirstTimePredicted() then return end
	if not self:HasInventoryAmmo() then return end

	local tr = util.TraceLine{
		start = self.Owner:GetShootPos(),
		endpos = self.Owner:GetShootPos() +self.Owner:GetAimVector() *64,
		filter = self.Owner
	}
	local ent = tr.Entity

	if not IsValid( ent ) then --self healing
		--HEAL
		local healed
		if self:CanHeal( self.Owner ) then
			self:HealTarget( 30, self.Owner )
			healed = true

			if self:BandagePlayerLimb( self.Owner ) then
				healed = true
			end
		end

		if healed then
			self.Owner:EmitSound( HealSound )
			self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
			self:SetNextPrimaryFire( CurTime() +self:SequenceDuration() +0.5 )
			self.Owner:SetAnimation( PLAYER_ATTACK1 )
			timer.Create( "weapon_idle".. self:EntIndex(), self:SequenceDuration(), 1, function() if IsValid( self ) then self:SendWeaponAnim( ACT_VM_IDLE ) end end )
			self:TakeInventoryAmmo()
		else
			self.Owner:EmitSound( DenySound )
			self:SetNextPrimaryFire( CurTime() +1 )
		end
	elseif ent:IsPlayer() then
		local healed
		if self:CanHeal( ent ) then
			self:HealTarget( 30, ent )
			healed = true

			if self:BandagePlayerLimb( ent ) then
				healed = true
			end
		end

		if healed then
			ent:EmitSound( HealSound )
			self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
			self:SetNextPrimaryFire( CurTime() +self:SequenceDuration() +0.5 )
			self.Owner:SetAnimation( PLAYER_ATTACK1 )
			timer.Create( "weapon_idle".. self:EntIndex(), self:SequenceDuration(), 1, function() if IsValid( self ) then self:SendWeaponAnim( ACT_VM_IDLE ) end end )
			self:TakeInventoryAmmo()
		else
			self.Owner:EmitSound( DenySound )
			self:SetNextPrimaryFire( CurTime() +1 )
		end
	end
end

function SWEP:SecondaryAttack()
end