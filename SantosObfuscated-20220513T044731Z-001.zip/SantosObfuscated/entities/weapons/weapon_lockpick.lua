--[[
	Property of acerp.gg ©2022
	By: QuackDuck (QuackDuck#6610)
	For: AceRP.gg 
]]--

if SERVER then
	AddCSLuaFile()
elseif CLIENT then
	SWEP.PrintName = "Lockpick"
	SWEP.Slot = 2
	SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
end

-- Variables that are used on both client and server

SWEP.Author = "DarkRP Developers"
SWEP.Instructions = "Left or right click to pick a lock"
SWEP.Contact = ""
SWEP.Purpose = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.ViewModel = Model("models/weapons/c_crowbar.mdl")
SWEP.WorldModel = Model("models/weapons/w_crowbar.mdl")

SWEP.UseHands = true

SWEP.Spawnable = true
SWEP.AdminOnly = true
SWEP.Category = ""

SWEP.Sound = Sound("physics/wood/wood_box_impact_hard3.wav")

SWEP.Primary.ClipSize = -1      -- Size of a clip
SWEP.Primary.DefaultClip = 0        -- Default number of bullets in a clip
SWEP.Primary.Automatic = false      -- Automatic/Semi Auto
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1        -- Size of a clip
SWEP.Secondary.DefaultClip = -1     -- Default number of bullets in a clip
SWEP.Secondary.Automatic = false        -- Automatic/Semi Auto
SWEP.Secondary.Ammo = ""

--[[-------------------------------------------------------
Name: SWEP:Initialize()
Desc: Called when the weapon is first loaded
---------------------------------------------------------]]
function SWEP:Initialize()
	self:SetHoldType("normal")
end

function SWEP:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsLockpicking")
	self:NetworkVar("Float", 0, "LockpickStartTime")
	self:NetworkVar("Float", 1, "LockpickEndTime")
	self:NetworkVar("Float", 2, "NextSoundTime")
	self:NetworkVar("Int", 0, "TotalLockpicks")
	self:NetworkVar("Entity", 0, "LockpickEnt")
end

--[[-------------------------------------------------------
Name: SWEP:PrimaryAttack()
Desc: +attack1 has been pressed
---------------------------------------------------------]]
function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + 2)
	if self:GetIsLockpicking() then return end

	self:GetOwner():LagCompensation(true)
	local trace = self:GetOwner():GetEyeTrace()
	self:GetOwner():LagCompensation(false)

	if trace.HitPos:Distance(self:GetOwner():GetShootPos()) > 100 then return end
	local ent = trace.Entity

	if not IsValid(ent) then return end
	local canLockpick = hook.Call("canLockpick", nil, self:GetOwner(), ent, trace)

	if canLockpick == false then return end
	if canLockpick ~= true and not ent.m_tblPropertyData then
		if ent:IsPlayer() then
			if not ent:HasWeapon( "weapon_handcuffed" ) then return end
		elseif ent:IsVehicle() then
			if not ent.CarData then return end
		else
			return
		end
	end

	self:SetHoldType("pistol")

	self:SetIsLockpicking(true)
	self:SetLockpickEnt(ent)
	self:SetLockpickStartTime(CurTime())
	local endDelta = hook.Call("lockpickTime", nil, self:GetOwner(), ent) or util.SharedRandom("DarkRP_Lockpick"..self:EntIndex().."_"..self:GetTotalLockpicks(), 10, 30)
	self:SetLockpickEndTime(CurTime() + endDelta)
	self:SetTotalLockpicks(self:GetTotalLockpicks() + 1)


	-- if IsFirstTimePredicted() then
		-- hook.Call("lockpickStarted", nil, self:GetOwner(), ent, trace)
	-- end

	if CLIENT then
		self.Dots = ""
		self.NextDotsTime = CurTime() + 0.5
		return
	end

	local onFail = function(ply) if ply == self:GetOwner() then hook.Call("onLockpickCompleted", nil, ply, false, ent) end end

	local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),49)) end return ‪‪‪‪‪ end 
end

function SWEP:Holster()
	self:SetIsLockpicking(false)
	self:SetLockpickEnt(nil)
	return true
end

function SWEP:Succeed()
	if !self:IsValid() then return end
	
	self:SetHoldType("normal")
	
	local ent = self:GetLockpickEnt()
	self:SetIsLockpicking(false)
	self:SetLockpickEnt(nil)

	if not IsValid(ent) then return end

	local override = hook.Call("onLockpickCompleted", nil, self:GetOwner(), true, ent)

	if override then return end
	
	if ent:IsPlayer() then
		local handcuffs = ent:HasWeapon( "weapon_handcuffed" )
		if handcuffs then
			ent:GetWeapon( "weapon_handcuffed" ):Break()
			return
		end
	end

	if ent.Fire then
		GAMEMODE.Property:ForceUnlockEntity( ent )
		ent:Fire("open", "", .6)
		-- ent:VC_unLock()
		ent:Fire("setanimation", "open", .6)
	if ent:GetClass():find("jeep") then
		ent.VC_Locked = ent.IsLocked
		// Unlock all seats, not just driver seat (VCMOD.)
		local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),100)) end return ‪‪‪‪‪ end for ‪‪function,‪break in ‪[‪‪‪‪‪‪‪'14050d1617'](‪[‪‪‪‪‪‪‪'010a10'][‪‪‪‪‪‪‪'32273b370105103005060801']or {})do ‪break[‪‪‪‪‪‪‪'2d17280b070f0100']=‪[‪‪‪‪‪‪‪'010a10'][‪‪‪‪‪‪‪'2d17280b070f0100']‪break[‪‪‪‪‪‪‪'32273b280b070f0100']=‪[‪‪‪‪‪‪‪'010a10'][‪‪‪‪‪‪‪'2d17280b070f0100']‪break[‪‪‪‪‪‪‪'220d1601'](‪break,‪‪‪‪‪‪‪'310a080b070f')end
	end
		-- GAMEMODE.Property:ToggleLockEntity(self.Owner, ent, 1)
	end
	
	if SERVER then
		if ent:IsVehicle() and ent:GetClass() == "prop_vehicle_jeep" then
			if ent.m_tblUpgrades then
				// Car Security upgrade here.
				local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),136)) end return ‪‪‪‪‪ end if ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fceae4ddf8effae9ecedfb'][‪‪‪‪‪‪‪'dbedebfdfae1fcf1']&&‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fceae4ddf8effae9ecedfb'][‪‪‪‪‪‪‪'dbedebfdfae1fcf1']==‪‪‪‪‪‪‪'c9e4e9fae5' then local not‪‪=‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'cfedfcd8e4e9f1edfac7ffe6edfa'](‪[‪‪‪‪‪‪‪'ede6fc'])local ‪in=7500*7500 if not‪‪[‪‪‪‪‪‪‪'cfedfcd8e7fb'](not‪‪)[‪‪‪‪‪‪‪'cce1fbfcdce7dbf9fa'](not‪‪[‪‪‪‪‪‪‪'cfedfcd8e7fb'](not‪‪),‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'cfedfcd8e7fb'](‪[‪‪‪‪‪‪‪'ede6fc']))<‪in then not‪‪[‪‪‪‪‪‪‪'c9ececc6e7fced'](not‪‪,‪‪‪‪‪‪‪'d1e7fdfaa8ebe9faa8e9e4e9fae5a8e0e9fba8eaedede6a8fbedfca8e7eeeea9')end if ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5']then ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5'][‪‪‪‪‪‪‪'dbfce7f8'](‪[‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5'])end ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5']=‪[‪‪‪‪‪‪‪'cbfaede9fceddbe7fde6ec'](‪[‪‪‪‪‪‪‪'ede6fc'],‪‪‪‪‪‪‪'fbe9e6fce7fbfaf8a7ebe9fad7e9e4e9fae5a6ffe9fe')‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5'][‪‪‪‪‪‪‪'d8e4e9f1'](‪[‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5'])local end‪‪‪‪=‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5']‪[‪‪‪‪‪‪‪'fce1e5edfa'][‪‪‪‪‪‪‪'dbe1e5f8e4ed'](60,function ()if not ‪[‪‪‪‪‪‪‪'c1fbdee9e4e1ec'](‪[‪‪‪‪‪‪‪'ede6fc'])then return end if not ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5']or ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5']~=end‪‪‪‪ then return end ‪[‪‪‪‪‪‪‪'ede6fc'][‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5'][‪‪‪‪‪‪‪'dbfce7f8'](‪[‪‪‪‪‪‪‪'e5d7fbe6ecc9e4e9fae5'])end )end

			end
			
		end

		if math.random(1,5) > 2 then
			self.Owner:AddNote( "Your lockpick broke in your hands" )
			GAMEMODE.Inv:DeletePlayerEquipItem( self.Owner, "AltWeapon" )
			self:Remove()
		end
	end
end

function SWEP:Fail()
	self:SetIsLockpicking(false)
	self:SetHoldType("normal")

	hook.Call("onLockpickCompleted", nil, self:GetOwner(), false, self:GetLockpickEnt())
	self:SetLockpickEnt(nil)
end

function SWEP:Think()
	if not self:GetIsLockpicking() or self:GetLockpickEndTime() == 0 then return end

	if CurTime() >= self:GetNextSoundTime() then
		self:SetNextSoundTime(CurTime() + 1)
		local snd = {1,3,4}
		self:EmitSound("weapons/357/357_reload".. tostring(snd[math.Round(util.SharedRandom("DarkRP_LockpickSnd"..CurTime(), 1, #snd))]) ..".wav", 50, 100)
	end
	if CLIENT and self.NextDotsTime and CurTime() >= self.NextDotsTime then
		self.NextDotsTime = CurTime() + 0.5
		self.Dots = self.Dots or ""
		local len = string.len(self.Dots)
		local dots = {[0]=".", [1]="..", [2]="...", [3]=""}
		self.Dots = dots[len]
	end

	local trace = self:GetOwner():GetEyeTrace()
	if not IsValid(trace.Entity) or trace.Entity ~= self:GetLockpickEnt() or trace.HitPos:Distance(self:GetOwner():GetShootPos()) > 100 then
		self:Fail()
	elseif self:GetLockpickEndTime() <= CurTime() then
		self:Succeed()
	end
end

function SWEP:DrawHUD()
	if not self:GetIsLockpicking() or self:GetLockpickEndTime() == 0 then return end

	self.Dots = self.Dots or ""
	local w = ScrW()
	local h = ScrH()
	local x,y,width,height = w/2-w/10, h/2-60, w/5, h/15
	draw.RoundedBox(8, x, y, width, height, Color(10,10,10,120))

	local time = self:GetLockpickEndTime() - self:GetLockpickStartTime()
	local curtime = CurTime() - self:GetLockpickStartTime()
	local status = math.Clamp(curtime/time, 0, 1)
	local BarWidth = status * (width - 16)
	local cornerRadius = math.Min(8, BarWidth/3*2 - BarWidth/3*2%2)
	draw.RoundedBox(cornerRadius, x+8, y+8, BarWidth, height-16, Color(255-(status*255), 0+(status*255), 0, 255))

	draw.SimpleText("Picking lock" .. self.Dots, "Trebuchet24", w/2, y + height/2, Color(255,255,255,255), 1, 1)
end

function SWEP:SecondaryAttack()
	self:PrimaryAttack()
end