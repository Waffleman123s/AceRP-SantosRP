--[[
	Name: weapon_phone.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName		= "Phone"
SWEP.Author			= "Ultra"
SWEP.Instructions	= "Hold walk to use the mouse (Default: Left Alt)"
SWEP.Base 			= "weapon_sck_base"
SWEP.ViewModel		= "models/weapons/v_pistol.mdl"
SWEP.WorldModel		= "models/weapons/w_pistol.mdl"
SWEP.ViewModelFOV 	= 63.673394301642

SWEP.Spawnable		= false
SWEP.Slot 			= 0
SWEP.UseHands 		= true

SWEP.HoldType 		= "slam"

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"
SWEP.ShowWorldModel 		= false
SWEP.ShowViewModel 			= false

SWEP.IronSightsPos 			= Vector( 4, -26, 6.8 )
SWEP.IronSightsAng 			= Vector( 70.232, 13.593, 80 )

SWEP.VElements = {
	["phone"] = { type = "Model", model = "models/lt_c/tech/cellphone.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(7.27, 2.5, -0.9), angle = Angle(16, 164, -96.5), size = Vector(1.371, 1.371, 1.371), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}
SWEP.WElements = {
	["phone"] = { type = "Model", model = "models/lt_c/tech/cellphone.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(5.129, 1.628, -1.843), angle = Angle(114.292, 26.113, 11.876), size = Vector(1.32, 1.32, 1.32), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}

local function ClearInput()
	if not GAMEMODE.Gui.m_pnlPhone then return end
	
	if vgui3D.GetInputWindows()[GAMEMODE.Gui.m_pnlPhone] then
		GAMEMODE.Gui.m_pnlPhone:OnInputLost()
		gui.EnableScreenClicker( false )
	end
	vgui3D.GetInputWindows()[GAMEMODE.Gui.m_pnlPhone] = nil
end

local function EnableInput()
	if not GAMEMODE.Gui.m_pnlPhone then return end
	
	if not vgui3D.GetInputWindows()[GAMEMODE.Gui.m_pnlPhone] then
		GAMEMODE.Gui.m_pnlPhone:OnInputGained()
		GAMEMODE.Gui.m_pnlPhone:RequestFocus()
	end
	
	vgui3D.GetInputWindows()[GAMEMODE.Gui.m_pnlPhone] = true
	gui.EnableScreenClicker( true )
end

function SWEP:Initialize()
	self.BaseClass.Initialize( self )
	self:SetDeploySpeed( 1.25 )
end

function SWEP:PrimaryAttack()
end

function SWEP:SecondaryAttack()
end

function SWEP:OnRemove()
	self.BaseClass.OnRemove( self )
	if CLIENT then
		ClearInput()
	end
end

do
	local lastPress = 0
	function SWEP:Think()
		if SERVER then return end
		if LocalPlayer() ~= self.Owner then return end
		if LocalPlayer():GetActiveWeapon() == self then
			GAMEMODE.Gui.m_pnlPhone.m_entWep = self
			
			if LocalPlayer():KeyPressed( IN_WALK ) and CurTime() > lastPress then
				if vgui3D.GetInputWindows()[GAMEMODE.Gui.m_pnlPhone] then
					ClearInput()
				else
					EnableInput()
				end
				lastPress = CurTime() +0.1
			end
		else
			ClearInput()
		end
	end
end

function SWEP:CalcViewModelView( _, _, _, vecPos, angAngs )
	if self.IronSightsAng then
		angAngs = angAngs *1
		angAngs:RotateAroundAxis( angAngs:Right(), self.IronSightsAng.x )
		angAngs:RotateAroundAxis( angAngs:Up(), self.IronSightsAng.y )
		angAngs:RotateAroundAxis( angAngs:Forward(), self.IronSightsAng.z )
	end

	vecPos = vecPos +self.IronSightsPos.x *angAngs:Right()
	vecPos = vecPos +self.IronSightsPos.y *angAngs:Forward()
	vecPos = vecPos +self.IronSightsPos.z *angAngs:Up()
	return vecPos, angAngs
end

function SWEP:PreDrawViewModel( entVM, entWep, pPlayer )
	render.SetBlend( 0 )

	self.ViewModelFOV = LocalPlayer():GetFOV()

	local normal = entVM:LocalToWorldAngles( Angle(-110, 160, 180) ):Up() *1
	local distance = normal:Dot( entVM:LocalToWorld(Vector(29.4, 0, 0)) -normal )

	if not self.m_bClipped then
		render.EnableClipping( true )
		render.PushCustomClipPlane( normal, distance )
		self.m_bClipped = true 
	end
end

function SWEP:ViewModelDrawn( ... )
	local vm = self.Owner:GetViewModel()
	if not IsValid( vm ) then return end
	
	if not self.VElements then return end
	if self.NoDrawParts_VM then return end
	
	if self.m_bClipped then
		render.EnableClipping( false )
	end
	
	self:UpdateBonePositions( vm )

	if not self.vRenderOrder then
		-- we build a render order because sprites need to be drawn after models
		self.vRenderOrder = {}

		for k, v in pairs( self.VElements ) do
			if v.type == "Model" then
				table.insert( self.vRenderOrder, 1, k )
			elseif v.type == "Sprite" or v.type == "Quad" then
				table.insert( self.vRenderOrder, k )
			end
		end
	end

	for k, name in ipairs( self.vRenderOrder ) do
		local v = self.VElements[name]
		if not v then self.vRenderOrder = nil break end
		if v.hide then continue end
		
		local model = v.modelEnt
		local sprite = v.spriteMaterial
		if not v.bone then continue end
		
		local pos, ang = self:GetBoneOrientation( self.VElements, v, vm )
		if not pos then continue end
		if v.type == "Model" and IsValid( model ) then
			model:SetPos( pos +ang:Forward() *v.pos.x +ang:Right() *v.pos.y +ang:Up() *v.pos.z )
			ang:RotateAroundAxis( ang:Up(), v.angle.y )
			ang:RotateAroundAxis( ang:Right(), v.angle.p )
			ang:RotateAroundAxis( ang:Forward(), v.angle.r )
			model:SetAngles( ang )

			local matrix = Matrix()
			matrix:Scale( v.size )
			model:EnableMatrix( "RenderMultiply", matrix )
			
			if v.material == "" then
				model:SetMaterial( "" )
			elseif model:GetMaterial() ~= v.material then
				model:SetMaterial( v.material )
			end
			
			if v.skin and v.skin ~= model:GetSkin() then
				model:SetSkin( v.skin )
			end
			
			if v.bodygroup then
				for k, v in pairs( v.bodygroup ) do
					if model:GetBodygroup( k ) ~= v then
						model:SetBodygroup( k, v )
					end
				end
			end
			
			if v.surpresslightning then
				render.SuppressEngineLighting( true )
			end
			
			render.SetColorModulation( v.color.r /255, v.color.g /255, v.color.b /255 )
			render.SetBlend( v.color.a /255 )
			model:DrawModel()
			render.SetBlend( 1 )
			render.SetColorModulation( 1, 1, 1 )
			
			if v.surpresslightning then
				render.SuppressEngineLighting( false )
			end
		elseif v.type == "Sprite" and sprite then
			local drawpos = pos +ang:Forward() *v.pos.x +ang:Right() *v.pos.y +ang:Up() *v.pos.z
			render.SetMaterial( sprite )
			render.DrawSprite( drawpos, v.size.x, v.size.y, v.color )
		elseif v.type == "Quad" and v.draw_func then
			local drawpos = pos +ang:Forward() *v.pos.x +ang:Right() *v.pos.y +ang:Up() *v.pos.z
			ang:RotateAroundAxis( ang:Up(), v.angle.y )
			ang:RotateAroundAxis( ang:Right(), v.angle.p )
			ang:RotateAroundAxis( ang:Forward(), v.angle.r )
			
			cam.Start3D2D( drawpos, ang, v.size )
				v.draw_func( self )
			cam.End3D2D()
		end
	end

	if self.m_bClipped then
		render.EnableClipping( true )
	end
end

do
	local camoffset = Vector( -3.44, -1.755, 0.6 )
	local angOffset = Angle( 0, 90, 0 )
	function SWEP:CalcScreenContext( entVM )
		if not self.VElements then return end
		if not self.VElements["phone"] then return end
		if not self.VElements["phone"].modelEnt then return end
		local elm = self.VElements["phone"]
		local mdl = elm.modelEnt

		local pos, ang = self:GetBoneOrientation( self.VElements, elm, entVM )
		pos = pos +(ang:Forward() *elm.pos.x +ang:Right() *elm.pos.y +ang:Up() *elm.pos.z)
		mdl:SetPos( pos )

		ang:RotateAroundAxis( ang:Up(), elm.angle.y )
		ang:RotateAroundAxis( ang:Right(), elm.angle.p )
		ang:RotateAroundAxis( ang:Forward(), elm.angle.r )
		mdl:SetAngles( ang )

		pos = mdl:LocalToWorld( camoffset )
		ang = mdl:LocalToWorldAngles( angOffset )
		return pos, ang, 0.0111
	end
end

function SWEP:PostDrawViewModel( entVM )
	if self.m_bClipped then
		render.PopCustomClipPlane()
		render.EnableClipping( false )
		self.m_bClipped = false
	end
	render.SetBlend( 1 )

	if not self.VElements then return end
	if not self.VElements["phone"] then return end
	if not self.VElements["phone"].modelEnt then return end
	local elm = self.VElements["phone"]
	local mdl = elm.modelEnt
	
	if not IsValid( mdl ) then return end
	
	local normalR = mdl:GetAngles():Right()
	local normalL = mdl:GetAngles():Right() *-1
	local normalB = mdl:GetAngles():Forward() *-1
	local normalT = mdl:GetAngles():Forward()
	
	local posR = normalR:Dot( mdl:LocalToWorld(Vector(0, 1.8, 0)) )
	local posL = normalL:Dot( mdl:LocalToWorld(Vector(0, -1.8, 0)) )
	local posB = normalB:Dot( mdl:LocalToWorld(Vector(3.2, 0, 0)) )
	local posT = normalT:Dot( mdl:LocalToWorld(Vector(-3.45, 0, 0)) )
	
	render.EnableClipping( true )
	render.PushCustomClipPlane( normalT, posT )
	render.PushCustomClipPlane( normalB, posB )
	render.PushCustomClipPlane( normalL, posL )
	render.PushCustomClipPlane( normalR, posR )

	local old = render.GetToneMappingScaleLinear()
	render.SetToneMappingScaleLinear( Vector(0.55, 0.55, 0.55) )
	render.SuppressEngineLighting( true )
	local pos, ang, scale = self:CalcScreenContext( entVM )
	if pos then
		vgui3D.Start3D2D( pos, ang, scale )
			vgui3D.Paint3D2D( GAMEMODE.Gui.m_pnlPhone )
		vgui3D.End3D2D()
	end
	render.SuppressEngineLighting( false )
	render.SetToneMappingScaleLinear( old )
	
	render.PopCustomClipPlane()
	render.PopCustomClipPlane()
	render.PopCustomClipPlane()
	render.PopCustomClipPlane()
	render.EnableClipping( false )
end