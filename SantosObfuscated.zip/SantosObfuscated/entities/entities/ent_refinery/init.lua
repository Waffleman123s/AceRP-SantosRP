--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

local refinableTbl = {
	["Cut Diamond"] = {ItemID = "Mineral Diamond", timeSecs = 45 },
	["Gold Ingot"] = {ItemID = "Mineral Gold", timeSecs = 30 },
	["Iron Ingot"] = {ItemID = "Mineral Iron", timeSecs = 10 },
}
local CAP_MINERALS = 5;

sound.Add( {
	name = "refinery_start",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 80,
	pitch = { 95, 110 },
	sound = "crusher/crusher_startup_2_5.wav"
} )
sound.Add( {
	name = "refinery_stop",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 80,
	pitch = { 95, 110 },
	sound = "crusher/crusher_stop.wav"
} )
sound.Add( {
	name = "refinery_idle",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 80,
	pitch = { 95, 110 },
	sound = "crusher/crusher_idle.wav"
} )
sound.Add( {
	name = "refinery_crushing",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 80,
	pitch = { 95, 110 },
	sound = "crusher/crusher_crushing.wav"
} )

function ENT:Initialize()
	self:SetModel( "models/crusher/crusher.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:PhysWake()

	self.refiningTbl = {};
	self.refinedTbl = {};

	self.sound_idle = false;
	self.sound_crush = false;
end

function ENT:OnRemove()
	self:StopSound("refinery_start")
	self:StopSound("refinery_stop")
	self:StopSound("refinery_idle")
	self:StopSound("refinery_crushing")
end

function ENT:Think()
	if self.engineOn then
		if not self.sound_idle then
			self.sound_idle = true;
			self:EmitSound("refinery_idle");
		end
	else
		self:StopSound("refinery_idle")
		self:StopSound("refinery_crushing")
		self.sound_idle = false;
		self.sound_crush = false;
		return;
	end

	if self.working then
		if not self.sound_crush then
			self.sound_crush = true;
			self:EmitSound("refinery_crushing");
		end
		for k, v in pairs(self.refiningTbl) do
			local data = {
				timeSecs = 1,
			};
			for endItem, d in pairs(refinableTbl) do
				if d.ItemID == v[1] then
					data = {
						StartTime = v[2],
						ItemID = d.ItemID,
						timeSecs = d.timeSecs,
						RewardItem = endItem
					};
					break;
				end
			end

			local dueTime = tonumber(v[2]) + data.timeSecs;
			if dueTime <= CurTime() then
				table.insert(self.refinedTbl, {data.ItemID, data.RewardItem});
				table.remove(self.refiningTbl, k);
				return;
			end
		end
	else
		self:StopSound("refinery_crushing");
		self.sound_crush = false;
		return;
	end

	if #table.GetKeys(self.refiningTbl) == 0 then
		self.working = false;
		self.lastWorked = CurTime();
		timer.Simple(math.random(3,5), function()
			if not self.working then
				self:StopEngine();
			end
		end)
	end
end

function ENT:Use(ply, caller)
	-- if self.CreatedBy ~= nil and self.CreatedBy ~= ply then
	-- 	ply:AddNote("Refinery Locked.");
	-- 	return;
	-- end

	if #self.refinedTbl == 0 then
		ply:AddNote("No minerals have been refined.");
		return;
	end
	for k, v in pairs(self.refinedTbl)do
		ply:AddNote("Refined " .. v[1]);
		
        GAMEMODE.Inv:GivePlayerItem( ply, v[2], 1 ); -- Santos RP Port...
	end
	self.refinedTbl = {};
end

function ENT:Touch(ent)
	if self.lastTouch ~= nil and self.lastTouch + 1 > CurTime() then return; end;
	self.lastTouch = CurTime();
	if ent:GetClass() == "prop_physics_multiplayer" and ent.IsItem then
		if CAP_MINERALS <= #self.refiningTbl then
			if ent.CreatedBy then
				ent.CreatedBy:AddNote("Refinery full!");
			end

			return;
		end
		for k, v in pairs(refinableTbl)do
			if v.ItemID == ent.ItemID then
				table.insert(self.refiningTbl, {ent.ItemID, CurTime()})
				ent:Remove();
				self:StartEngine(); -- Dup glitch?
				return;
			end
		end
	end
end

function ENT:StartEngine()
	if self.starting then return end;
	if not self.engineOn then
		self.starting = true;
		self:EmitSound("refinery_start")
		timer.Simple(2.5, function()
			self.engineOn = true;
			self.starting = false;
		end)
	end
	if not self.working then
		timer.Simple(math.random(1,2), function()
			self.working = true;
		end)
	end
end

function ENT:StopEngine()
	self:EmitSound("refinery_stop")
	self.engineOn = false;
end