--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/mark2580/gtav/garage_stuff/custom_engine.mdl" )
ENT.SoundMedkit1 	= Sound( "items/smallmedkit1.wav" )
ENT.SoundFXTable 	= {
	Sound( "npc/dog/dog_servo8.wav" ),
	Sound( "npc/dog/dog_servo7.wav" ),
	Sound( "npc/dog/dog_servo12.wav" ),
}