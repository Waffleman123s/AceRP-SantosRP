--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra
]]--

include "shared.lua"

function ENT:Initialize()
end

function ENT:Think()
end

function ENT:Draw()
	self:DrawModel()
end