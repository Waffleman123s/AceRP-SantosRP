--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	local mdl, _ = table.Random( self.Models )
	self:SetModel( mdl )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetTrigger( true )
	self:PhysWake()

	self.m_intTouchDelay = CurTime() +5
	self.BlockPhysGun = true
end

function ENT:StartTouch( eEnt )
	if self.m_intTouchDelay > CurTime() then return end
	if not IsValid( eEnt ) or not eEnt:IsVehicle() or not eEnt.IsMailTruck then return end
	if self.ParentMailTruck == eEnt then
		self:Remove()
		local snd, _ = table.Random( self.Sounds )
		eEnt:EmitSound( snd )
	end
end