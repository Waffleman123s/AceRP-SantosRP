--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Models 			= {
	Model( "models/props_junk/cardboard_box004a.mdl" ),
	Model( "models/props_junk/cardboard_box003a.mdl" ),
	Model( "models/props_junk/cardboard_box002a.mdl" ),
	Model( "models/props_junk/cardboard_box001a.mdl" ),
}

ENT.Sounds = {
	Sound( "physics/cardboard/cardboard_box_impact_soft1.wav" ),
	Sound( "physics/cardboard/cardboard_box_impact_soft2.wav" ),
	Sound( "physics/cardboard/cardboard_box_impact_soft3.wav" ),
	Sound( "physics/cardboard/cardboard_box_impact_soft4.wav" ),
	Sound( "physics/cardboard/cardboard_box_impact_soft5.wav" ),
	Sound( "physics/cardboard/cardboard_box_impact_soft6.wav" ),
	Sound( "physics/cardboard/cardboard_box_impact_soft7.wav" ),
}