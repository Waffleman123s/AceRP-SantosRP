--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_junk/meathook001a.mdl" )
ENT.SoundFishFlap 	= Sound( "npc/crow/hop2.wav" )
ENT.SoundBaitHooked = Sound( "weapons/crossbow/hit1.wav" )
ENT.WaterSounds 	= {
	Sound( "player/footsteps/slosh1.wav" ),
	Sound( "player/footsteps/slosh2.wav" ),
	Sound( "player/footsteps/slosh3.wav" ),
	Sound( "player/footsteps/slosh4.wav" ),
}
ENT.BobberSounds = {
	Sound( "ambient/water/drip1.wav" ),
	Sound( "ambient/water/drip2.wav" ),
	Sound( "ambient/water/drip3.wav" ),
	Sound( "ambient/water/drip4.wav" ),
}

function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "BaitID" )
	self:NetworkVar( "String", 1, "CatchID" )
end

function ENT:HasCatch()
	return self:GetCatchID() ~= ""
end

function ENT:HasBait()
	return self:GetBaitID() ~= ""
end
