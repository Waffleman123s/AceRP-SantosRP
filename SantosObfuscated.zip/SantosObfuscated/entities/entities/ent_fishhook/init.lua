--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:SetModelScale( 0.25 )
	self:PhysicsInitSphere( 2 )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )

	local phys = self:GetPhysicsObject()
	if not IsValid( phys ) then
		error( "Unable to initialize physics for ent_fishhook!" )
	end

	self:PhysWake()
	self:SetTrigger( true )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )

	local phys = self:GetPhysicsObject()
	phys:SetMaterial( "ice" )
	phys:SetMass( 10 )
	phys:SetDamping( 5, 10 )

	self:NextThink( CurTime() +1 )
end

function ENT:OnRemove()
	if self:GetBaitID() then
		--Drop the bait item on the ground
		local owner = IsValid( self:GetOwner() ) and IsValid( self:GetOwner().Owner )
		owner = owner and self:GetOwner().Owner or nil

		GAMEMODE.Inv:MakeItemDrop( owner, self:GetBaitID(), 1, owner and true )
	end
end

function ENT:Think()
	if not self:HasCatch() then
		return self:ThinkNoFish()
	else
		return self:ThinkHasFish()
	end
end

function ENT:ThinkHasFish()
	local level = self:WaterLevel()
	--Fish out of water!
	if level < 1 then
		--make the fish jump around 
		self:EmitSound( self.SoundFishFlap, 60, math.random(80, 110), 0.66 )
		self:GetPhysicsObject():SetVelocity( self:GetPhysicsObject():GetVelocity() +Vector(
			math.random(-100, 100),
			math.random(-100, 100),
			math.random(100, 350)
		) )

		self:NextThink( CurTime() +1 )
		return true
	end

	if self.m_intCatchTime and CurTime() > self.m_intCatchTime then
		self.m_intCatchTime = nil
		self:SetCatchID( "" )
		self:NextThink( CurTime() +math.Rand(6, 10) )
		return true
	end
	
	--let the player know they have a fish!
	local snd, _ = table.Random( self.BobberSounds )
	self:EmitSound( snd, 60, 100, 0.66 )

	--get the water surface
	local pos = util.TraceLine{
		start = self:GetPos(),
		endpos = self:GetPos() +Vector( 0, 0, 1e9 ),
		mask = bit.bor( MASK_WATER, MASK_SOLID ),
	}
	pos = util.TraceLine{
		start = pos.HitPos -Vector( 0, 0, 1 ),
		endpos = pos.HitPos -Vector( 0, 0, 1e9 ),
		mask = bit.bor( MASK_WATER ),
	}

	if pos.Hit then
		local effectdata = EffectData()
		effectdata:SetOrigin( pos.HitPos )
		effectdata:SetScale( 4 )
		util.Effect( "waterripple", effectdata )
	end

	self:NextThink( CurTime() +math.Rand(1.2, 3) )
	return true
end

function ENT:ThinkNoFish()
	if not self:HasBait() then return end
	if self.m_intThinkIgnore and self.m_intThinkIgnore > CurTime() then return end
	local level = self:WaterLevel()

	if level < 1 then
		self:NextThink( CurTime() +1 )
		return true
	end

	local fish = self:AttemptGetCatch()
	if not fish then
		self:NextThink( CurTime() +math.random(13, 19) )
		return true
	end

	self:SetCatchID( fish.Name )
	self:SetBaitID( "" ) --consume the bait
	--the fish gets away after this moment in time
	self.m_intCatchTime = CurTime() +math.random( 6, 30 )
end

function ENT:AttemptGetCatch()
	--calc the player's fishing skill curve
	local plLevel = GAMEMODE.Skills:GetPlayerLevel( self:GetOwner().Owner, "Fishing" )
	local maxLevel = GAMEMODE.Skills:GetMaxLevel( "Fishing" )
	local weight = 0.35

	local skillCurve = 1 -(2 ^-(plLevel /(0.32 *maxLevel)) *(weight *100))
	skillCurve = (100 -skillCurve) /100
	local skillScalar = math.max( skillCurve -1, 0 )

	--rng chance
	local valSkill = math.random( 1, 100 )
	--print( valSkill, math.ceil(Lerp(skillScalar, 45, 100)) )
	if valSkill < math.Clamp( math.ceil(Lerp(skillScalar, 45, 100)), 0, 100 ) then return end --No bite!
	
	local fish, weights = {}, {}
	local weightSum = 0
	for itemID, data in pairs( GAMEMODE.Inv:GetItems() ) do
		if not data.FishingData or data.FishingData.IsBait then continue end
		fish[#fish +1] = data

		--calc the skill weight for this fish
		local curve = 1 -(2 ^-(plLevel /(0.32 *maxLevel)) *(data.FishingData.SkillWeight *100))
		curve = (100 -curve) /100
		local scalar = math.max( curve -1, 0 )
		local baseChance = data.FishingData.ChanceWeight

		--Does this fish like the bait we used?
		if data.FishingData.Bait and data.FishingData.Bait[self:GetBaitID()] then
			--Add this to the base amount
			baseChance = baseChance +data.FishingData.Bait[self:GetBaitID()].Chance
		end

		--scale weight with skill
		weights[#fish] = baseChance +(baseChance *-scalar)
		weightSum = weightSum +weights[#fish]
	end

	--Pick a fish!
	local rand = math.Rand( 0, weightSum )
	local sum = 0
	for i = 1, #fish do
		sum = sum +weights[i]

		if rand <= sum then
			return fish[i]
		end
	end
end

function ENT:StartTouch( entOther )
	if self:HasCatch() or self:WaterLevel() > 0 then return end
	
	if not IsValid( entOther ) or not entOther.IsItem then return end
	if entOther.m_bRemoveWaiting then return end
	if entOther:GetPlayerOwner() ~= self:GetOwner().Owner then return end
	local data = GAMEMODE.Inv:GetItem( entOther.ItemID )
	if not data or not data.FishingData then return end
	
	if data.FishingData.IsBait then
		if self:BaitHook( data ) then
			entOther.m_bRemoveWaiting = true
			entOther.ItemTakeBlocked = true
			SafeRemoveEntityDelayed( entOther, 0 )
		end
	end
end

function ENT:BaitHook( tblItemData )
	if self:HasBait() or self:HasCatch() then return false end
	self:SetBaitID( tblItemData.Name )
	self:EmitSound( self.SoundBaitHooked, 60, 100, 0.33 )
	return true
end