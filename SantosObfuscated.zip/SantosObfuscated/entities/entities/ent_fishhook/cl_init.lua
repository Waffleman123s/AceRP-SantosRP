--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra
]]--

include "shared.lua"

function ENT:Initialize()
end

function ENT:OnRemove()
	if self.m_entFish then
		self.m_entFish:Remove()
		self.m_entFish = nil
	end

	if self.m_entBait then
		self.m_entBait:Remove()
		self.m_entBait = nil
	end
end

function ENT:Think()
	if self:GetCatchID() and self:GetCatchID() ~= "" then
		if not self.m_entFish then
			self.m_entFish = ClientsideModel( GAMEMODE.Inv:GetItem(self:GetCatchID()).Model, RENDERGROUP_BOTH )
			self.m_entFish:SetPos( self:GetPos() )
			self.m_entFish:SetAngles( self:LocalToWorldAngles(Angle(0, 0, 0)) )
			self.m_entFish:SetParent( self )		
		end

		if self.m_entBait then
			self.m_entBait:Remove()
			self.m_entBait = nil
		end
	elseif self:GetBaitID() and self:GetBaitID() ~= "" then
		if not self.m_entBait then
			self.m_entBait = ClientsideModel( GAMEMODE.Inv:GetItem(self:GetBaitID()).Model, RENDERGROUP_BOTH )
			self.m_entBait:SetPos( self:GetPos() )
			self.m_entBait:SetAngles( self:LocalToWorldAngles(Angle(0, 0, 0)) )
			self.m_entBait:SetParent( self )
		end

		if self.m_entFish then
			self.m_entFish:Remove()
			self.m_entFish = nil
		end
	else
		if self.m_entFish then
			self.m_entFish:Remove()
			self.m_entFish = nil
		end

		if self.m_entBait then
			self.m_entBait:Remove()
			self.m_entBait = nil
		end
	end
end

function ENT:Draw()
	self:DrawModel()
end