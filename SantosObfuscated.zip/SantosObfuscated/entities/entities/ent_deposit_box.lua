--[[
	Name: ent_padlock.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then AddCSLuaFile() end

ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""
ENT.RenderGroup 	= RENDERGROUP_BOTH

function ENT:Initialize()
	self:DrawShadow( false )
	
	if CLIENT then return end
	self:SetModel( "models/props_c17/consolebox05a.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )

	self.m_entLock = ents.Create( "ent_padlock" )
	self.m_entLock:SetPos( self:LocalToWorld(Vector("13.593749 -6.784181 5.327133")) )
	self.m_entLock:SetAngles( self:LocalToWorldAngles(Angle("-67.632 51.914 -61.537")) )
	self.m_entLock:Setup(
		50,
		nil, --Reset
		nil, --CanBreak
		--CanReset
		function( eEnt )
			return false
		end,
		--OnBreak
		function()
			if not IsValid( self ) then return end
			self.ItemTakeBlocked = false
			self.m_entLock:Remove()
		end,
		nil --OnReset()
	)
	self.m_entLock:Spawn()
	self.m_entLock:Activate()
	self.m_entLock.BlockPhysGun = true
	self.m_entLock:SetDTBool( GAMEMODE.Map.DT_IS_MAP_PROP, true )
	self:DeleteOnRemove( self.m_entLock )

	--Add deposit box item data so we can pick this up like a normal item
	self.IsItem = true
	self.ItemID = "Stolen Safety Deposit Box"
	self.Illegal = true
	self.ItemData = GAMEMODE.Inv:GetItem( self.ItemID )
	self.ItemTakeBlocked = true
	self.NoItemDamage = true
end