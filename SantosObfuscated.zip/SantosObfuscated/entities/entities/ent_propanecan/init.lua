--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	--self:SetTrigger( true )
	self:PhysWake()
end

function ENT:OnRemove()
	--[[if GAMEMODE.EntityDamage:GetItemHealth( self ) <= 0 then
		self:Explode()
	end]]--
end

function ENT:Explode()
	if self.m_bExploded then return end
	local data = EffectData()
	data:SetOrigin( self:GetPos() )
	util.Effect( "Explosion", data )
	util.BlastDamage( self, self, self:GetPos(), 48, 45 )
	self.m_bExploded = true
end