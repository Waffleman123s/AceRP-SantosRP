--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetUseType( SIMPLE_USE )
	self.CollidesWithCars = false
	--self:CollisionRulesChanged()
	--loop through all cars
	self:PhysWake()
end

function ENT:SetAmount( intAmount )
	local model = self.ValueModels[0]

	for _, tbl in ipairs( self.ValueModels ) do
		for k, v in pairs( tbl ) do
			if k <= intAmount then
				model = v
			end
			
			break
		end
	end

	self:SetModel( model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )

	self:SetMoney( intAmount )
end