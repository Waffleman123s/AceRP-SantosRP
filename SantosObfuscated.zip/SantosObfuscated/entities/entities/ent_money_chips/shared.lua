--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.ValueModels 	= {
	{ [0] = Model("models/props_lab/box01a.mdl") },
	{ [1000] = Model("models/props_junk/cardboard_box004a.mdl") },
	{ [10000] = Model("models/props_junk/cardboard_box003a.mdl") },
}

function ENT:SetupDataTables()
	self:NetworkVar( "Int", 0, "Money" )
end