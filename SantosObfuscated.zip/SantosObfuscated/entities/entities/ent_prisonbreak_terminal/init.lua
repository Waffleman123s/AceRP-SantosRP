--[[
	Name: init.lua
	For: SantosRP
	By: Pcwizdan
	Edited: xrayhunter
]]
--
AddCSLuaFile"cl_init.lua"
AddCSLuaFile"shared.lua"
include"shared.lua"

sound.Add( {
	name = "alarmnoise",
	channel = CHAN_STREAM,
	volume = 1.0,
	level = 80,
	pitch = { 95, 110 },
	sound = "ambient/alarms/alarm1.wav"
} )

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetTrigger(false)
	self:PhysWake()
	
	self:SetNWEntity("ActiveHacker",nil) --only 1 at a time track distance
	self:SetNWFloat("EndTimeHacking",-1)
	self.LockoutControls = false
end

function ENT:DoPrisonBreak()
	local prop = GAMEMODE.Map:GetMapProp( "prisonbreak_terminals" )

	for k, v in pairs(prop.JailDoors) do
		local e = ents.GetMapCreatedEntity(v)
		if IsValid(e) then
			e.IsLocked = false
			e:Fire("Unlock")
			e:Fire("Open")
		end
	end
	for k, v in pairs(prop.SecurityDoors) do
		local e = ents.GetMapCreatedEntity(v)
		if IsValid(e) then
			e.IsLocked = false
			e:Fire("Unlock")
			e:Fire("Open")
		end
	end
	--entUnlocker:Fire("use") --hope it works
	self.LockoutControls = true
	_G.JAILBREAK_ACTIVE = true
		
	timer.Simple(prop.PrisonBreakReleaseTimer or 120,function ()
		-- hook.Remove("PlayerUse","PrisonBreak_LockoutControls")
		self.LockoutControls = false 
		_G.JAILBREAK_ACTIVE = false
		for k, v in pairs(prop.JailDoors) do--close/lock all doors and it should auto tp anyone back who didnt successfully leave pd.
			local e = ents.GetMapCreatedEntity(v)
			if IsValid(e) then
				e.IsLocked = true
				e:Fire("Close")
				e:Fire("Lock")
			end
		end
		for k, v in pairs(prop.SecurityDoors) do--close/lock all doors and it should auto tp anyone back who didnt successfully leave pd.
			local e = ents.GetMapCreatedEntity(v)
			if IsValid(e) then
				e.IsLocked = true
				e:Fire("Close")
				e:Fire("Lock")
			end
		end
		
		-- local alarm = ents.GetMapCreatedEntity(3316)
		-- alarm:Fire("Use")
	end)
end


hook.Add("PlayerUse","PrisonBreak_LockoutControls",function (ply,ent)
	if not _G.JAILBREAK_ACTIVE then return end
	if not ent.lastUsed or ent.lastUsed + 1 < CurTime() then
		ent.lastUsed = CurTime();
	else
		return false;
	end
	local prop = GAMEMODE.Map:GetMapProp( "prisonbreak_terminals" )
	local id = ent:MapCreationID()
	if table.HasValue(prop.SecurityControls, id) then --all control room controls (except alarm) get locked down for a time period.
		ply:AddNote("Seems that the buttons are non-responsive, like someone has hacked the system.");
		return false
	end
end)



function ENT:HackingSuccess()
	local entAct = self:GetNWEntity("ActiveHacker")
	entAct:AddNote("You completed the prison hack - prison break initiated.")
	self:StopSound( "alarmnoise" )
	self:SetNWEntity("ActiveHacker",nil)
	self:SetNWFloat("EndTimeHacking",-1)
	self.LockoutControls = true

	self:DoPrisonBreak()
end

function ENT:HackingFailed()
	local entAct = self:GetNWEntity("ActiveHacker")
	entAct:AddNote("You failed the hacking process.")
	self:SetNWEntity("ActiveHacker",nil)
	self:SetNWFloat("EndTimeHacking",-1)

	self:StopSound( "alarmnoise" )
end
-- ambient/alarms/alarm1.wav

function ENT:HackingBegin(entAct) 
	-- alarm:Fire("Use")
	local prop = GAMEMODE.Map:GetMapProp( "prisonbreak_terminals" )
	self:EmitSound( "alarmnoise" )
	self:SetNWEntity("ActiveHacker",entAct)
	self:SetNWFloat("EndTimeHacking",CurTime() + prop.PrisonHackingTimer)
	entAct:AddNote("You began the prison break hack.")

	GAMEMODE.Jobs:GetJobByID( JOB_POLICE ):TextAllPlayers( "Dispatch ", "10-99 Prison Break" )
end

--ACCEPT INPUT use to start hack etc do think
function ENT:AcceptInput(strInput,entAct,entCall,data)
	if not self.lastInput or self.lastInput + 1 < CurTime() then
		self.lastInput = CurTime();
	else
		return;
	end
	if string.lower(strInput)=="use" and entAct and entAct:IsPlayer() then
		--start hack
		if not IsValid(self:GetNWEntity("ActiveHacker")) then --new hacker
			if table.HasValue({2, 3, 4, 1002}, GAMEMODE.Jobs:GetPlayerJobID(entAct)) then
				entAct:AddNote( "You cannot start a prison break!" );
				return;
			end
			-- GAMEMODE.Config.PrisonBreak_MinCops
			if GAMEMODE.Jobs:GetNumPlayers( JOB_POLICE ) < 0 then
				entAct:AddNote( "There must be at least ".. GAMEMODE.Config.PrisonBreak_MinCops.. " active police to start a prison break!." )	
				return
			end
			if _G.JAILBREAK_ACTIVE then
				entAct:AddNote("The system is down, since it was hacked recently.");
				return;
			end
			self:HackingBegin(entAct)
		else			
			if table.HasValue({2, 3, 4, 1002}, GAMEMODE.Jobs:GetPlayerJobID(entAct)) then
				entAct:AddNote( "You have terminated the hacking of the prison break!" );
				if GAMEMODE.Config.PrisonBreak_ShouldPayTerminator then
					local ran = math.random(GAMEMODE.Config.PrisonBreak_Payment[1], GAMEMODE.Config.PrisonBreak_Payment[2]);
					entAct:AddNote("You earned $" .. ran .. " for stopping the prison break.")
					entAct:AddBankMoney(ran);	
				end
				self:HackingFailed();
				return;
			end
			entAct:AddNote( "The terminal is already being hacked!" )
		end
		
	end
end

function ENT:Think()
	--TODO: Check radius of hacker
	local hacker = self:GetNWEntity("ActiveHacker")
	local endTime = self:GetNWFloat("EndTimeHacking")
	if IsValid(hacker) then
		local pos = hacker:GetPos()
		if not hacker:Alive() 
		or self.Entity:GetPos():Distance(pos) > self.HackingMaxTether 
		then --death or distance
			self:HackingFailed()
		elseif endTime ~=-1 and endTime < CurTime() then
			self:HackingSuccess()
		end
	end
end

--uuh idk
function ENT:Explode()
	if self.m_bExploded then return end
	local data = EffectData()
	data:SetOrigin(self:GetPos())
	util.Effect("Explosion", data)
	util.BlastDamage(self, self, self:GetPos(), 48, 45)
	self.m_bExploded = true
end