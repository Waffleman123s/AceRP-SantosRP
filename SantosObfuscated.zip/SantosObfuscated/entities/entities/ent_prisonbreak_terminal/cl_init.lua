--[[
	Name: cl_init.lua
	For: SantosRP
	By: Pcwizdan
]]--

include "shared.lua"

local HackerTerminalInstance = nil

function ENT:Initialize()
	self.PrisonPassword = tostring(math.random(1111111111111,9999999999999)) --"73459912476858312412"
	HackerTerminalInstance = self
end

function ENT:Think()
end

local HackDuration = 4*60
local GarbleString = "1234567890"
local function GarbleFadeIn(str,endTime,HackDuration)
	local nstr = str..""
	local size = string.len(str)
	local timeScale = math.Clamp((endTime - CurTime())/HackDuration,0,1)
	if timeScale == 1 then return str end
	
	local nGarble = math.floor(size*timeScale)
	
	for i=1, nGarble do
		local si = math.random(1,size)
		local nRand = math.random(1,string.len(GarbleString))
		local nChar = string.sub(GarbleString,nRand,nRand)
		nstr = string.SetChar(nstr,si,nChar)
	end

	return nstr
end
--self:GetNWFloat("EndTimeHacking")
function ENT:Draw()
	self:DrawModel()
	local LP = LocalPlayer()
	if !IsValid(LP) then return end -- or LP!=self:GetNWEntity("ActiveHacker") then return end --only hacker
	--if GAMEMODE.Jobs:GetPlayerJobID(LP) == JOB_POLICE then return end --no police
	--draw some other 3d2d bullshit here
	local endTime = self:GetNWFloat("EndTimeHacking")
	
	cam.Start3D2D(self.Entity:GetPos() + self.Entity:GetForward()*30 +self.Entity:GetUp()*70,self.Entity:GetAngles()+Angle(0,90,90),.2)
		surface.SetDrawColor(255,255,255,255)
		draw.DrawText("Prison Terminal : Active","Default",0,0,color_white,TEXT_ALIGN_CENTER)
		if endTime != -1 then
			if CurTime()<endTime then
				draw.DrawText("Cracking access password: "..GarbleFadeIn(self.PrisonPassword,endTime,self.HackingDuration),"Default",0,30,Color(0,255,0,255),TEXT_ALIGN_CENTER)
			else
				draw.DrawText("Hack completed!","Default",0,30,Color(0,255,0,255),TEXT_ALIGN_CENTER)
			end
		end
	cam.End3D2D()
end

local icon = Material("icon16/application_xp_terminal.png")
hook.Add("HUDPaint","prisonbreak_terminal_esp",function ()
	local LP = LocalPlayer()
	if not IsValid(LP) or not IsValid( HackerTerminalInstance ) then return end
	local myPos = LP:GetPos()
	local pos = HackerTerminalInstance:GetPos() + Vector(0,0,32)
	local dist = pos:Distance(myPos)
	if (GAMEMODE.Jobs:GetPlayerJobID(LP) == JOB_POLICE) and (HackerTerminalInstance:GetNWFloat('EndTimeHacking') != -1) then
		
		
		if dist < 550 then --disappear when near
			HackerTerminalVisibleNotice = false
		end
		local x = ScrW()*.7
		local y = ScrH()*.1
		surface.SetMaterial(icon)
		surface.DrawTexturedRect(x-16,y,16,16)
		draw.DrawText("Prisonbreak hack initiated!","Default",x,y,Color(255,0,0,255),TEXT_ALIGN_LEFT)
		return
	elseif !HackerTerminalVisibleNotice then
		return
	end
	local dist = pos:Distance(myPos)
	
	if dist < 550 then --disappear when near
		HackerTerminalVisibleNotice = false
	end
	local scr = pos:ToScreen()
	local x = scr.x
	local y = scr.y
	if scr.visible then
		surface.SetMaterial(icon)
		surface.DrawTexturedRect(x-16,y,16,16)
		draw.DrawText(tostring(math.floor(dist/16)).."ft","Default",x,y,Color(0,255,0,255),TEXT_ALIGN_LEFT)
	end
end)

