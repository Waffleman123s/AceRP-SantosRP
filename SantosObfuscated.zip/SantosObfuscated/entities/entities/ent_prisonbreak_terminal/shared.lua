--[[
	Name: shared.lua
	For: SantosRP
	By: Pcwizdan
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_lab/servers.mdl" )

ENT.HackingDuration = 240 --dev test |  production--1*60 --4minutes
ENT.HackingMaxTether = 550 --550 source units
ENT.LockoutControlsTime = 2*60

--TODO: Unlock regular doors to freedom in jail/police building.
--Some other stuff maybe?