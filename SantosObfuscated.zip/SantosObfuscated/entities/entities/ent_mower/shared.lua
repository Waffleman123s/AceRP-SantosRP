--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 				= "anim"
ENT.Base 				= "base_anim"
ENT.PrintName			= ""
ENT.Author				= ""
ENT.Purpose				= ""
ENT.Model 				= Model( "models/props/de_overpass/lawn_mower.mdl" )
ENT.SoundSputter 		= Sound( "ambient/machines/sputter1.wav" )
ENT.SoundSpinDown 		= Sound( "ambient/machines/spindown.wav" )

util.PrecacheModel( "models/maxofs2d/button_03.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "On" )
	self:NetworkVar( "Bool", 1, "OverGrass" )
end