--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

local powerBtnData = { mdl = 'models/maxofs2d/button_03.mdl', pos = Vector('-7.563477 -3.506348 18.850880'), ang = Angle('0 -180 0') }
local powerBtnScale = 0.2

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )

	local phys = self:GetPhysicsObject()
	if not IsValid( phys ) then
		error( "Unable to initialize physics for ent_mower!" )
	end
	self:PhysWake()

	self.m_entBtnPower = ents.Create( "ent_button" )
	self.m_entBtnPower:SetModel( powerBtnData.mdl )
	self.m_entBtnPower:SetPos( self:LocalToWorld(powerBtnData.pos) )
	self.m_entBtnPower:SetAngles( self:LocalToWorldAngles(powerBtnData.ang) )
	self.m_entBtnPower:Spawn()
	self.m_entBtnPower:Activate()
	self.m_entBtnPower:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
	self.m_entBtnPower:SetModelScale( powerBtnScale )
	self.m_entBtnPower:SetIsToggle( true )
	self.m_entBtnPower:SetParent( self )
	self.m_entBtnPower.BlockPhysGun = true
	self:DeleteOnRemove( self.m_entBtnPower )

	self.m_entBtnPower:SetCallback( function( _, pPlayer, bToggle )
		self:SetOn( bToggle )
		if self:GetOn() then
			self.m_entBtnPower:EmitSound( self.SoundSputter, 60, 110, 0.75 )
		else
			self.m_entBtnPower:EmitSound( self.SoundSpinDown, 60, 130, 0.75 )
		end
	end )
	self.m_entBtnPower:SetCanUseCallback( function( _, pPlayer )
		return GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_CITYWORKER
	end )

	self.m_tblShadowParams = {}
	self.Phys = self:GetPhysicsObject()

	--self:SetCustomCollisionCheck( true )
	self:SetTrigger( true )
	self:NextThink( CurTime() +1 )
	self:StartMotionController()
end

local down = Vector( 0, 0, -16 )
local up = Vector( 8 )
function ENT:Think()
	local Hold = IsValid( self.m_pPlayerHolding )
	if Hold and (self.m_pPlayerHolding:IsIncapacitated() or self.m_pPlayerHolding:InVehicle()) then
		self.m_pPlayerHolding = nil
		Hold = false
	end

	if Hold then
		if self.m_bUseBlock and not self.m_pPlayerHolding:KeyDown( IN_USE ) then
			self.m_bUseBlock = false
		end

		if not self.m_pPlayerHolding:Alive() then
			self.m_pPlayerHolding = nil
			return
		end
	end

	if not self:GetOn() then return end
	if CurTime() > (self.m_intLastTick or 0) then
		self.m_intLastTick = CurTime() +0.5

		local mowing
		for k, v in pairs( ents.FindInBox(self:LocalToWorld(self:OBBMins() +down), self:LocalToWorld(self:OBBMaxs()) +up) ) do
			if v:GetClass() == "ent_mowable_grass" then
				if self:GetVelocity():Length() <= 5 then return end
				self:SetOverGrass( true )
				self.m_entMowing = v
				mowing = true
				break
			end
		end

		self:SetOverGrass( mowing )
		if not mowing then
			self.m_entMowing = nil
		end
	end

	if CurTime() > (self.m_intLastMow or 0) then
		self.m_intLastMow = CurTime() +0.1

		if IsValid( self.m_entMowing ) then
			self.m_entMowing:AddMowTick( self )
		else
			self.m_entMowing = nil
		end
	end
end

function ENT:OnGrassMowed( entGrass )
end

function ENT:CanPlayerPickup( pPlayer, bCanUse )
	if self:GetOn() then return false end
	return bCanUse
end

function ENT:CanPlayerUse( pPlayer )
	return true
end

function ENT:CanSendToLostAndFound()
	return false
end

function ENT:PhysicsSimulate( pPhys, intDeltaTime )
	local Hold = IsValid( self.m_pPlayerHolding )

	if Hold and IsValid( pPhys ) then
		local eyeAng = self.m_pPlayerHolding:EyeAngles()
		eyeAng.p = eyeAng.p
		eyeAng.r = 0
		self.m_tblShadowParams.angle = eyeAng

		pPhys:Wake()

		local vec = self.m_pPlayerHolding:GetAimVector()
		vec.z = 0
		vec:Normalize()
		local pos = self.m_pPlayerHolding:GetShootPos() +Vector(0, 0, -48) +(84 *vec)
		local tr = util.TraceLine{
			start = pos,
			endpos = pos +Vector( 0, 0, eyeAng.p <= 18 and 0 or -96 ),
			filter = function( ent )
				if ent == self or ent == self:GetPlayerOwner() or ent:GetClass() == "ent_mowable_grass" then return false end
			end,
		}

		if tr.HitWorld then
			pos = tr.HitPos -Vector( 0, 0, 12 )
			self.m_tblShadowParams.p = 0
		end
		
		self.m_tblShadowParams.secondstoarrive = 0.2
		self.m_tblShadowParams.pos = pos
		self.m_tblShadowParams.maxangular = 16384
		self.m_tblShadowParams.maxangulardamp = 16384
		self.m_tblShadowParams.maxspeed = 16384
		self.m_tblShadowParams.maxspeeddamp = 16384
		self.m_tblShadowParams.dampfactor = 0.9
		self.m_tblShadowParams.teleportdistance = 0
		self.m_tblShadowParams.deltatime = intDeltaTime
		pPhys:ComputeShadowControl( self.m_tblShadowParams )
	end

	return
end

function ENT:Use( pPlayer )
	if self.m_pPlayerHolding and not self.m_bUseBlock then
		if pPlayer ~= self.m_pPlayerHolding then return end
		
		self.m_pPlayerHolding = nil
		pPlayer.m_bHoldingMower = false
		self.m_bUseBlock = true
		self.ItemTakeBlocked = false
		return
	end

	if pPlayer.m_bHoldingMower then return end
	pPlayer.m_bHoldingMower = true
	self.m_pPlayerHolding = pPlayer
	self.m_bUseBlock = true
	self.ItemTakeBlocked = true
	self.Phys:Wake()
	return true
end