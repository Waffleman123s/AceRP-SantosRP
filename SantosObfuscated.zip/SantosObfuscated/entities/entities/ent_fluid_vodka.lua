--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	AddCSLuaFile()
end

ENT.Base = "ent_base_fluid"
ENT.Model = Model( "models/props_junk/glassjug01.mdl" )
local snd = Sound( "ambient/water/leak_1.wav" )

function ENT:ConfigInit()
	if SERVER then
		self:SetModel( self.Model )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
		self:PhysWake()

		self:SetFluidID( "Vodka" )
		self:SetEffect( "waterFx", Vector(-0.088151, -0.650788, 8.061775), Color(255, 255, 255, 255) )
		self:SetCarryAngles( Angle(0, 180, 0), Angle(80, 180, 0) )
	end
	
	if CLIENT then self:SetPourSound( snd ) end
end