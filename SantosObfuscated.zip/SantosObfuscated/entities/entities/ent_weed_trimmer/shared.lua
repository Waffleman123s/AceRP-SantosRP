--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.TrimTime 		= 30
ENT.Model 			= "models/props_junk/MetalBucket02a.mdl"

util.PrecacheModel( "models/freeman/drugbale_large.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "Running" )
end