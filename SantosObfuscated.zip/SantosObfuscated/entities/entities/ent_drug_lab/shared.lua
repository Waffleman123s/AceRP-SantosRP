--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 				= "anim"
ENT.Base 				= "base_anim"
ENT.PrintName			= ""
ENT.Author				= ""
ENT.Purpose				= ""
ENT.Model 				= Model( "models/props/CS_militia/table_shed.mdl" )
ENT.SoundBurnerOff 		= Sound( "ambient/fire/mtov_flame2.wav" )
ENT.SoundWaterSpray 	= Sound( "ambient/water/water_spray1.wav" )
ENT.SoundBurnerSparks 	= {
	Sound( "ambient/energy/spark1.wav" ),
	Sound( "ambient/energy/spark3.wav" ),
	Sound( "ambient/energy/spark4.wav" ),
}

util.PrecacheModel( "models/maxofs2d/button_slider.mdl" )
util.PrecacheModel( "models/hunter/blocks/cube025x025x025.mdl" )
util.PrecacheModel( "models/maxofs2d/button_02.mdl" )

ENT.BurnerMaxFuel 		= 4
ENT.BurnerHeatPerTick	= 1
ENT.BurnerFuelPerTick 	= 0.005

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "BurnerOn" )
	self:NetworkVar( "Bool", 1, "BlenderOn" )

	self:NetworkVar( "Float", 0, "BurnerFuel" )
	self:NetworkVar( "Float", 1, "BlenderProgress" )

	self:NetworkVar( "String", 0, "BlendingID" )
end