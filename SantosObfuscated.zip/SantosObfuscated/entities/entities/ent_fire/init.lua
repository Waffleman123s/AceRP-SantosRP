--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

local fireSize = Vector( 1, 1, 1 ) *52
function ENT:Initialize()
	self:SetCollisionGroup( COLLISION_GROUP_WORLD )
	self:SetCollisionBounds( -fireSize, fireSize )
	self:PhysicsInitBox( -fireSize, fireSize )
	self:SetSolid( SOLID_BBOX )
	self:SetMoveType( MOVETYPE_NONE )

	local phys = self:GetPhysicsObject()
	if not IsValid( phys ) then
		error( "Unable to initialize physics for ent_fire!" )
	end	

	self:DrawShadow( false )
	self:SetTrigger( true )
	self:SetCustomCollisionCheck( true )

	self.m_intSpawnTime = CurTime()
	self.m_intLastBurn = 0
	self.m_intBurnInterval = 2
	self.m_intBurnDamage = 10
	self.m_intWaterHit = 0
	self.m_intHitsToRemove = 24
	self.AdminPhysGun = false;

	if self:WaterLevel() > 0 then
		self:Remove()
	end
end

function ENT:WaterHit( pPlayer, intPower )
	if self.IsMapProp then return end
	self.m_intWaterHit = self.m_intWaterHit +(intPower or 1)

	if self.m_intWaterHit >= self.m_intHitsToRemove then
		if self.m_bRemoved then return end
		self:Remove()
		self.m_bRemoved = true

		if not IsValid( pPlayer ) then return end
		if not pPlayer.m_intFireExtinguishCount then
			pPlayer.m_intFireExtinguishCount = 0
		end
		pPlayer.m_intFireExtinguishCount = pPlayer.m_intFireExtinguishCount +1

		if pPlayer.m_intFireExtinguishCount >= GAMEMODE.Config.FireExtinguishBonusCount then
			pPlayer:AddBankMoney( GAMEMODE.Config.FireBonus, "Firefighting bonus" )
			pPlayer:AddNote( "You earned a $".. GAMEMODE.Config.FireBonus.. " bonus for fighting a fire!" )
			pPlayer:AddNote( "This bonus has been sent to your bank account." )
			pPlayer.m_intFireExtinguishCount = 0
		end
	end
end

function ENT:StartTouch( entOther )
	if self.NeverBurn then return end
	if not IsValid( entOther ) or not entOther:IsPlayer() or entOther:IsOnFire() then return end
	if entOther:IsRagdolled() then return end
	entOther:Ignite( math.random(4, 10) )
end

--[[hook.Add( "ShouldCollide", "FireCollide", function( entA, entB )
	if not IsValid( entA ) or not IsValid( entB ) then return end
	if entA:GetClass() == "ent_fire" or entB:GetClass() == "ent_fire" then
		return false
	end
end )]]--