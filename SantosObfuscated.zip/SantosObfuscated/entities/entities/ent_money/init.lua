--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:SpawnFunction( pPlayer )
	local spawnPos = util.TraceLine{
		start = pPlayer:GetShootPos(),
		endpos = pPlayer:GetShootPos() +pPlayer:GetAimVector() *150,
		filter = pPlayer,
	}.HitPos

	return spawnPos +Vector(0, 0, 0)
end

function ENT:Initialize()
	self:SetUseType( SIMPLE_USE )
	self.CollidesWithCars = false
	--self:CollisionRulesChanged()
	--loop through all cars
end

function ENT:SetAmount( intAmount )
	local model = self.ValueModels[0]

	for _, tbl in ipairs( self.ValueModels ) do
		for k, v in pairs( tbl ) do
			if k <= intAmount then
				model = v
			end
			
			break
		end
	end

	self:SetModel( model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )

	self:SetMoney( intAmount )
end

function ENT:Use( pPlayer )
	if self.m_bUsed or self.m_bDissolving then return end
	local money = self:GetMoney()
	pPlayer:AddMoney( money, "Cash transfer" )
	pPlayer:AddNote( "You picked up $".. string.Comma(money) )
	
	self.m_bUsed = true
	self:Remove()
	hook.Call( "GamemodePlayerTakeMoney", {}, pPlayer, money, IsValid(self:GetPlayerOwner()) )
end