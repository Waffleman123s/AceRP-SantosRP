--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.ValueModels 	= {
	{ [0] = Model("models/props/cs_assault/Dollar.mdl") },
	{ [100] = Model("models/props/cs_assault/Money.mdl") },
	{ [100000] = Model("models/props/cs_assault/MoneyPallet03E.mdl") },
	{ [1000000] = Model("models/props/cs_assault/MoneyPallet.mdl") },
}

function ENT:SetupDataTables()
	self:NetworkVar( "Int", 0, "Money" )
end