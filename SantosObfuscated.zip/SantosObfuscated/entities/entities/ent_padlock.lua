--[[
	Name: ent_padlock.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then AddCSLuaFile() end

ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""
ENT.RenderGroup 	= RENDERGROUP_BOTH

function ENT:Initialize()
	self:SetRenderMode( RENDERMODE_TRANSALPHA )
	self:DrawShadow( false )
	
	if CLIENT then return end
	self:SetModel( "models/props_wasteland/prison_padlock001a.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
end

function ENT:Setup( intHealth, intResetTimer, fnCanBreak, fnCanReset, fnOnBreak, fnOnReset, fnOnTakeDamage )
	self.m_intMaxHealth = intHealth
	self.m_intHealth = intHealth
	self.m_intReset = intResetTimer
	self.m_fnCanBreak = fnCanBreak
	self.m_fnCanReset = fnCanReset
	self.m_fnOnBreak = fnOnBreak
	self.m_fnOnReset = fnOnReset
	self.m_fnOnTakeDamage = fnOnTakeDamage
end

function ENT:OnTakeDamage( pDamageInfo )
	local pl = pDamageInfo:GetAttacker()
	if not IsValid( pl ) or not pl:IsPlayer() then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pl ) ~= JOB_CIVILIAN then return end
	if not IsValid( pl:GetActiveWeapon() ) or pl:GetActiveWeapon():GetClass() ~= "weapon_item_saw" then return end
	if self.m_fnCanBreak and self.m_fnCanBreak( self, pl ) == false then return end
	if self.m_intHealth <= 0 then return end

	self.m_intHealth = math.max( self.m_intHealth -pDamageInfo:GetDamage(), 0 )
	local s = 1 -(self.m_intMaxHealth -self.m_intHealth) /self.m_intMaxHealth
	self:SetColor( Color(255 *s, 255 *s, 255 *s, 255) )

	if self.m_fnOnTakeDamage then
		self.m_fnOnTakeDamage( self, pDamageInfo )
	end
	if self.m_intHealth <= 0 then
		self:Break()
	end
end

function ENT:Break()
	self.m_intBreakTime = CurTime()
	self:SetColor( Color(0, 0, 0, 0) )
	self:SetNoDraw( true )
	self:EmitSound( "physics/metal/metal_box_break1.wav", 70, 100, 1 )
	if self.m_fnOnBreak then self.m_fnOnBreak() end
end

function ENT:Reset()
	self:SetNoDraw( false )
	self.m_intHealth = self.m_intMaxHealth
	self:SetColor( Color(255, 255, 255, 255) )
	if self.m_fnOnReset then self.m_fnOnReset() end
end

function ENT:IsBroken()
	return self.m_intHealth <= 0
end

function ENT:Think()
	if CLIENT then return end
	if self.m_intHealth > 0 then return end

	if CurTime() < (self.m_intLast or 0) then return end
	self.m_intLast = CurTime() +2

	if not self.m_intReset then return end
	if CurTime() > (self.m_intBreakTime +self.m_intReset) then
		if self.m_fnCanReset and self.m_fnCanReset( self ) == false then return end
		self:Reset()
	end
end