AddCSLuaFile"cl_init.lua"
AddCSLuaFile"shared.lua"
include"shared.lua"

function ENT:Initialize()
	self:SetModel("models/statetrooper/ram_tow_hook.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	-- self:SetColor(Color(0, 0, 0))
	self:SetTrigger(true)
	self.TargetLength = 10
	self.Length = 5
	self.Phys = self:GetPhysicsObject()
	self.Phys:SetMass(100)
	self.Phys:SetDamping(4, 4)
	self.Phys:Wake()
	self.AdminPhysGun = true
end

function ENT:SetExtended(b)
	if b then
		--Extend
		self:SetLength(300)
	else
		--Retract
		self:SetLength(5)
	end
end

function ENT:RopeStuff()
	if not IsValid(self.car:GetDriver()) then return end
	local p = self.car:GetDriver()
	if p:Team() ~= JOB_TOW then return end

	if p:KeyDown(IN_WALK) then
		self.TargetLength = self.TargetLength - 5

		if self.TargetLength < 10 then
			self.TargetLength = 10
		end
	elseif p:KeyDown(IN_SPEED) then
		self.TargetLength = self.TargetLength + 5

		if self.TargetLength > 70 then
			self.TargetLength = 70
		end
	elseif p:KeyDown(IN_JUMP) and p:KeyDown(IN_ATTACK) and IsValid(self:GetAttachedTo()) then
		self:Release()
	end
end

function ENT:Think()
	if not IsValid(self.m_pConst) or not IsValid(self.m_pRope) then return end

	if self.TargetLength > self.Length then
		self.Length = math.Approach(self.Length, self.TargetLength, 50)
	elseif self.TargetLength < self.Length then
		self.Length = math.Approach(self.Length, self.TargetLength, -15)
	end

	if IsValid(self:GetAttachedTo()) and not IsValid(self.m_pWeld) then
		self:Release()
	end

	-- if IsValid(self:GetAttachedTo()) and not IsValid(self.m_pNoCollide) then
	-- self.m_pNoCollide = constraint.NoCollide(self:GetAttachedTo(), self.car, 0, 0)
	-- end
	self.m_pConst:Fire("SetSpringLength", tostring(self.Length), 0)
	self.m_pRope:Fire("SetLength", tostring(self.Length), 0)
	self:NextThink(CurTime() + 0.1)
	self:RopeStuff()
end

function ENT:PhysicsCollide(entOther)
	if self.m_bDisabled then return end
	if self.Last then return end
	entOther = entOther.HitEntity
	if entOther == self.Vehicle then return end
	if entOther.IsTow then return end
	if entOther.TowBlocked then return end

	if IsValid(entOther) and entOther:IsVehicle() and not IsValid(entOther:GetDriver()) then
		if entOther.CarData and entOther.UID then
			if not IsValid(self:GetAttachedTo()) then
				if entOther ~= self.Last then
					--Garry: Tried to activate constraint in physics callback! This could cause crashes! Ignoring!
					timer.Simple(0, function()
						if not IsValid(self) or not IsValid(entOther) then return end
						self:SetAttachedTo(entOther)
						if not entOther.OldCG then
							entOther.OldCG = entOther:GetCollisionGroup()
							entOther:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
						end
					end)
					-- entOther.OldMass = entOther:GetPhysicsObject():GetMass()
					-- entOther:GetPhysicsObject():SetMass(64)
				end
			end
		end
	end
end

function ENT:SetLength(len)
	self.TargetLength = len
end

function ENT:SetDisabled(b)
	self.m_bDisabled = b
end

function ENT:Use(a, c)
	if c:Team() == JOB_TOW then
		self:Release()
	end

	if c:IsStaff() then
		self:Release()
	end
end

function ENT:Release()
	if not IsValid(self:GetAttachedTo()) then return end
	self:EmitSound("weapons/crowbar/crowbar_impact1.wav")

	if IsValid(self.m_pWeld) then
		self.m_pWeld:Remove()
	end

	-- print(constraint.RemoveConstraints( self:GetAttachedTo(), "NoCollide" ))
	-- if IsValid(self.m_pNoCollide) then
	-- self.m_pNoCollide:Remove()
	-- self:GetAttachedTo():SetPos(self:LocalToWorld(Vector(0, -160, 50)))
	-- end
		if IsValid(self:GetAttachedTo()) and self:GetAttachedTo().OldCG then
			self:GetAttachedTo():SetCollisionGroup(self:GetAttachedTo().OldCG)
			self:GetAttachedTo().OldCG = nil
		end
		
		if IsValid(self:GetAttachedTo()) then
		-- if self:GetAttachedTo().OldMass then
		-- self:GetAttachedTo():GetPhysicsObject():SetMass(self:GetAttachedTo().OldMass)
		-- end
		self:GetAttachedTo():SetHandbrake(false)
		-- self:GetAttachedTo().OldMass = nil
	end

	if self.m_funcOnRelease then
		self.m_funcOnRelease(self, self:GetAttachedTo())
	end

	self:GetPhysicsObject():SetMass(64)
	self:SetAttachedTo(NULL)
	self:GetPhysicsObject():RecheckCollisionFilter()

	timer.Simple(4, function()
		if not IsValid(self) then return end
		self.Last = nil
	end)
end

function ENT:AttachChanged(s, old, new)
	if IsValid(new) then
		new:SetHandbrake(false)
		self:EmitSound("weapons/crossbow/hit1.wav")
		self:GetPhysicsObject():SetMass(64)
		constraint.RemoveConstraints(new, "Weld")
		self.m_pWeld = constraint.Weld(new, self, 0, 0, 0)
		constraint.AddConstraintTable(new, self.m_pWeld)
		self.Last = new

		new:CallOnRemove("UnHook", function()
			if IsValid(self) and self.Last == new then
				self:Release()
			end
		end)
	else
		if IsValid(old) then
			old:SetHandbrake(false)
			old:RemoveCallOnRemove("UnHook")
		end
	end

	if self.m_funcOnAttach then
		self.m_funcOnAttach(self, old, new)
	end

	self:GetPhysicsObject():RecheckCollisionFilter()
end