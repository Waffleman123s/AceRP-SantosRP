--[[
	Name: init.lua
	For: SantosRP
	By: Ultra

	items/nvg_off.wav
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:SetMaterial( "models/props_canal/metalcrate001d" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:PhysWake()

	self:EmitSound( "items/nvg_on.wav", 60, 100, 0.66 )

	--Add thermite item data so we can pick this up like a normal item
	self.IsItem = true
	self.ItemID = "Thermite"
	self.Illegal = true
	self.ItemData = GAMEMODE.Inv:GetItem( self.ItemID )
	self.NoItemDamage = true
end

function ENT:IgniteThermite( intDuration )
	self.m_bLit = true
	self.ItemTakeBlocked = true
	self:SetBurning( true )
	timer.Simple( intDuration, function()
		if not IsValid( self ) then return end
		self:SetBurning( false )
	end )
end