if SERVER then
	AddCSLuaFile()
end

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = ""
ENT.Author = ""
ENT.Purpose = ""

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/tobadforyou/surveillance_camera.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_NONE)
		self:SetUseType(SIMPLE_USE)
		self.cur = self:GetAngles()
		self.y = self:GetAngles().y
		self.move = false
	end

	function ENT:Setup(isCop)
		GAMEMODE.Module:GetModule("cctv_cameras"):RegisterCamera(self, isCop)
	end

	function ENT:Use(a, c)
		if c == self:GetPlayerOwner() then
			self.move = not self.move
			self.s = CurTime()
			self.cur = self:GetAngles()
		end
	end

	function ENT:Think()
		if not self.move then return end
		local fraction = (CurTime() - self.s) / 0.1
		self.y = math.sin(CurTime() / 1.2) * 15
		fraction = math.Clamp(fraction, 0, 1)
		local ang = LerpAngle(fraction, self.cur, Angle(self.cur.p, self.cur.y + self.y, self.cur.r))
		self:SetAngles(ang)
	end

	function ENT:UpdateTransmitState()
		return TRANSMIT_ALWAYS
	end
end

if not CLIENT then return end

function ENT:Draw()
	self:DrawModel()
end