--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_equipment/gas_pump_p16.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Entity", 0, "Attached" )
end