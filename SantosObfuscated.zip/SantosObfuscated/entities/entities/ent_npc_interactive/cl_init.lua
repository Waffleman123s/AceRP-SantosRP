--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra
]]--

include "shared.lua"
ENT.RenderGroup = RENDERGROUP_OPAQUE