--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Base = "base_anim" 
ENT.Type = "anim"
ENT.AutomaticFrameAdvance = true

function ENT:SetNPCData( tblNPCData )
	self.m_tblNPCData = tblNPCData
end

function ENT:RunAnimation()
	if RealTime() > self.m_intLastAnim +self.m_intAnimDur then
		self.m_intLastAnim = RealTime()
	end

	self:SetSequence( self.m_intSeq )
	self:SetCycle( math.Clamp((RealTime() -self.m_intLastAnim) /self.m_intAnimDur, 0, 1) )
end