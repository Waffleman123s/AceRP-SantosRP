--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( "models/alyx.mdl" )
	self:SetSolid( SOLID_BBOX ) 
	self:SetUseType( SIMPLE_USE )
	self.m_flHealth = 100

	GAMEMODE.Util:NextTick( function()
		if not IsValid( self ) then return end
		self.m_intSeq = self:SelectWeightedSequence(ACT_IDLE) or 0
		self:ResetSequence( self.m_intSeq )
		self:SetPlaybackRate( 0.8 )
	end )
end

function ENT:OnTakeDamage( pDamageInfo )
	if self.m_bBeingRobbed and not IsValid( self.m_entDeathRag ) then
		self.m_flHealth = math.max( self.m_flHealth -pDamageInfo:GetDamage(), 0 )

		if self.m_flHealth <= 0 then
			self:OnKilled( pDamageInfo )
		end
	end

	pDamageInfo:ScaleDamage( 0 )
end

function ENT:AcceptInput( strName, entActivator, entCaller )
	if not IsValid( entCaller ) or not entCaller:IsPlayer() then return end
	if entCaller:IsIncapacitated() then return end
	if IsValid( self.m_entDeathRag ) or self.m_bBeingRobbed then return end
	if strName ~= "Use" then return end
	if not self.m_tblNPCData then return end

	entCaller.m_entTalkingNPC = self
	self.m_tblNPCData:OnPlayerTalk( self, entCaller )
end

function ENT:OnKilled( pDamageInfo )
	self:SetNoDraw( true )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	self:CreateDeathRagdoll()

	self.m_intTimerName = "NPCAutoRevive".. tostring( self )
	timer.Create( self.m_intTimerName, GAMEMODE.Config.NPCRobbery_NPCAutoReviveTime, 1, function()
		if not IsValid( self ) or not IsValid( self.m_entDeathRag ) then return end
		if GAMEMODE.Jobs:GetNumPlayers( JOB_EMS ) > 0 then return end
		self:ReviveNPC()
	end )

	hook.Call( "GamemodeOnNPCKilled", GAMEMODE, self, pDamageInfo:GetAttacker(), pDamageInfo:GetInflictor() )
end

function ENT:CreateDeathRagdoll()
	if IsValid( self.m_entDeathRag ) then return end
	
	local ragdoll = ents.Create( "prop_ragdoll" )
	ragdoll:SetPos( self:GetPos() +(vector_up *6))
	ragdoll:SetAngles( self:GetAngles() )
	ragdoll:SetModel( self:GetModel() )
	ragdoll:SetSkin( self:GetSkin() )
	ragdoll:SetOwner( self )
	ragdoll.IsNPCOwner = true
	ragdoll:Spawn()
	ragdoll:Activate()
	ragdoll:SetCollisionGroup( COLLISION_GROUP_VEHICLE )
	ragdoll.AdminPhysGun = true

	self:DeleteOnRemove( ragdoll )
	self.m_entDeathRag = ragdoll
	
	-- Copy bodygroups
	for k, v in pairs( self:GetBodyGroups() ) do
		ragdoll:SetBodygroup( v.id, self:GetBodygroup(v.id) )
	end
end

function ENT:ReviveNPC()
	if not IsValid( self.m_entDeathRag ) then return end
	self.m_entDeathRag:GetOwner():SetNoDraw( false )
	self.m_entDeathRag:GetOwner():SetCollisionGroup( COLLISION_GROUP_NONE )
	self.m_entDeathRag:Remove()
	
	timer.Destroy( self.m_intTimerName )
	self.m_intTimerName = nil
	self.m_flHealth = 100
end

hook.Add( "GamemodeDefibHitRagdoll", "ReviveNPCRagdoll", function( entDefib, entNPCRag )
	if not entNPCRag.IsNPCOwner then return end
	entNPCRag:GetOwner():ReviveNPC()
end )