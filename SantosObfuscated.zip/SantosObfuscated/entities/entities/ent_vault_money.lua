--[[
	Name: ent_vault_money.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then AddCSLuaFile() end

ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""
ENT.RenderGroup 	= RENDERGROUP_BOTH

function ENT:Initialize()
	if CLIENT then return end
	self:SetModel( "models/props/cs_assault/moneypallet03.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	--self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
	self:SetUseType( SIMPLE_USE )
end

function ENT:Setup( intNumBags )
	self.m_intNumBags = intNumBags
end

if SERVER then
	function ENT:Use( pPlayer )
		if self.m_pPlayerUsing then return end
		if not pPlayer:IsPlayer() then return end
		if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_CIVILIAN then return end

		if not GAMEMODE.Inv:CanGivePlayerItem( pPlayer, "Stolen Money", 1 ) then
			pPlayer:AddNote( "You can't carry any more money!" )
			return
		end
		
		self.m_intStartTime = CurTime()
		self.m_pPlayerUsing = pPlayer
		pPlayer.m_bTakingVaultMoney = true
		pPlayer.m_entVaultMoneyRef = self
		pPlayer:Freeze( true )

		GAMEMODE.Net:NewEvent( "ent", "vmp_take" )
			net.WriteBool( true )
			net.WriteFloat( self.m_intStartTime )
			net.WriteFloat( GAMEMODE.Config.BankRobbery_MoneyTakeTime )
		GAMEMODE.Net:FireEvent( pPlayer )
	end

	function ENT:OnRemove()
		if IsValid( self.m_pPlayerUsing ) then
			self.m_pPlayerUsing:Freeze( false )	
			GAMEMODE.Net:NewEvent( "ent", "vmp_take" )
				net.WriteBool( false )
			GAMEMODE.Net:FireEvent( self.m_pPlayerUsing )			
		end
	end

	function ENT:Think()
		if not self.m_intStartTime then return end

		if CurTime() > self.m_intStartTime +GAMEMODE.Config.BankRobbery_MoneyTakeTime then
			if not IsValid( self.m_pPlayerUsing ) or not self.m_pPlayerUsing:Alive() or self.m_pPlayerUsing:IsRagdolled() then
				if IsValid( self.m_pPlayerUsing ) then
					self.m_pPlayerUsing:Freeze( false )	
					GAMEMODE.Net:NewEvent( "ent", "vmp_take" )
						net.WriteBool( false )
					GAMEMODE.Net:FireEvent( self.m_pPlayerUsing )
				end

				self.m_pPlayerUsing = nil
				self.m_intStartTime = nil
				return
			end

			GAMEMODE.Net:NewEvent( "ent", "vmp_take" )
				net.WriteBool( false )
			GAMEMODE.Net:FireEvent( self.m_pPlayerUsing )
			self.m_pPlayerUsing:Freeze( false )
			self.m_pPlayerUsing.m_bTakingVaultMoney = nil
			self.m_pPlayerUsing.m_entVaultMoneyRef = nil
			self.m_intStartTime = nil

			if GAMEMODE.Inv:GivePlayerItem( self.m_pPlayerUsing, "Stolen Money", 1 ) then
				self.m_pPlayerUsing:AddNote( "You collected a bag of money!" )
				self.m_pPlayerUsing:EmitSound( "items/itempickup.wav" )
				self.m_intNumBags = self.m_intNumBags -1
				if self.m_intNumBags <= 0 then
					self:Remove()
					return
				end
			end

			self.m_pPlayerUsing = nil
		end
	end

	GAMEMODE.Net:RegisterEventHandle( "ent", "vmp_abort", function( intMsgLen, pPlayer )
		if not pPlayer.m_bTakingVaultMoney or not IsValid( pPlayer.m_entVaultMoneyRef ) then return end
		pPlayer.m_entVaultMoneyRef.m_intStartTime = nil
		pPlayer.m_entVaultMoneyRef.m_pPlayerUsing = nil
		pPlayer.m_bTakingVaultMoney = nil
		pPlayer.m_entVaultMoneyRef = nil
		pPlayer:Freeze( false )
		GAMEMODE.Net:NewEvent( "ent", "vmp_take" )
			net.WriteBool( false )
		GAMEMODE.Net:FireEvent( pPlayer )
	end )
else
	GAMEMODE.Net:RegisterEventHandle( "ent", "vmp_take", function( intMsgLen )
		local state = net.ReadBool()
		if state then
			local start = net.ReadFloat()
			local len = net.ReadFloat()
			local msgSent
			hook.Add( "HUDPaint", "PaintVaultMoneyHUD", function()
				if not LocalPlayer():Alive() or LocalPlayer():IsRagdolled() then return end
				if LocalPlayer():KeyDown( IN_SPEED ) and not msgSent then
					msgSent = true
					GAMEMODE.Net:NewEvent( "ent", "vmp_abort" )
					GAMEMODE.Net:FireEvent()	
				end


				local x, y = ScrW() /2, ScrH() /2
				local box_w = 350
				local box_h = 40

				if CurTime() < start +len then
					local perc = 1 -( (start +len -CurTime()) /len )
					
					local x = (ScrW() /2) -(box_w /2)
					local y = ScrH() -box_h *2
					
					draw.RoundedBox( 6, x, y, box_w, box_h, Color(0, 0, 0, 200) )
					draw.RoundedBox( 6, x +2, y +2, (box_w -4) *perc, box_h -4, Color(230, 60, 60) )
					draw.SimpleText( "Taking Money (Press Sprint To Stop)", "handcuffTextSmall", (box_w /2) +x, (box_h /2) +y, color_white, 1, 1 )
				end
			end )
		else
			hook.Remove( "HUDPaint", "PaintVaultMoneyHUD" )
		end
	end )
end