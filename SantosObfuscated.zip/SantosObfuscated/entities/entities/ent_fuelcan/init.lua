--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]
--
AddCSLuaFile"cl_init.lua"
AddCSLuaFile"shared.lua"
include"shared.lua"

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetTrigger(true)
	self:PhysWake()
end

function ENT:StartTouch(eEnt)
	if self.m_bTouched then return end

	if not self.used and eEnt:GetClass() == "bm2_generator" and eEnt.fuel < 1000 then
		self.used = true
		self:Remove()
		eEnt.fuel = math.Clamp(eEnt.fuel + 250, 0, 1000)
		eEnt:EmitSound("ambient/water/water_splash1.wav", 75, math.random(90, 110), 1)
	end

	if not IsValid(eEnt) or not eEnt:IsVehicle() or not eEnt.UID then return end

	if eEnt:GetFuel() < eEnt:GetMaxFuel() then
		eEnt:AddFuel(1)
		eEnt:EmitSound(self.SoundWaterSpray, 70, 70)
		self.m_bTouched = true
		self:Remove()
	end
end

function ENT:OnRemove()
	--[[if GAMEMODE.EntityDamage:GetItemHealth( self ) <= 0 then
		self:Explode()
	end]]
	--
end

function ENT:Explode()
	if self.m_bExploded then return end
	local data = EffectData()
	data:SetOrigin(self:GetPos())
	util.Effect("Explosion", data)
	util.BlastDamage(self, self, self:GetPos(), 48, 45)
	self.m_bExploded = true
end