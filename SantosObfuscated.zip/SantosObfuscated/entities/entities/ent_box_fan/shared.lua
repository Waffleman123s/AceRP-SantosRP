--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.ModelOff		= Model( "models/freeman/ventfan.mdl" )
ENT.ModelOn 		= Model( "models/freeman/ventfan_2.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "On" )
end