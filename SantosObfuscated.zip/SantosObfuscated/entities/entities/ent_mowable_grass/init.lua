--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	local grassSize = Vector( 98, 98, 8 )
	self:SetModel( self.Model )
	self:PhysicsInitBox( -grassSize, grassSize )

	self:SetCollisionGroup( COLLISION_GROUP_VEHICLE )
	self:SetCollisionBounds( -grassSize, grassSize )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	self:DrawShadow( false )
	self:SetTrigger( true )

	self.BlockPhysGun = true
	self.m_intMowTicks = 0
	self.m_intMaxMowTicks = 10 *3
end

function ENT:AddMowTick( entMower )
	if entMower:GetVelocity():Length() <= 5 then return end
	self.m_intMowTicks = self.m_intMowTicks +1
	self:SetPos(self:GetPos() + Vector(0, 0, -0.3))
	if self.m_intMowTicks >= self.m_intMaxMowTicks then
		entMower:OnGrassMowed( self )
		self:Remove()
	end
end