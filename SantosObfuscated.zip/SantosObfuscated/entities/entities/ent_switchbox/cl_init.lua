--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra
]]--

include "shared.lua"

function ENT:Initialize()
	self:SetAutomaticFrameAdvance( true )
	self.m_sndLoop = CreateSound( self, "ambient/machines/power_transformer_loop_2.wav" )
	self.m_sndLoop:SetSoundLevel( 60 )
end

function ENT:OnRemove()
	if self.m_entScreen then
		self.m_entScreen:Remove()
		self.m_entScreen = nil
	end
	
	if self.m_sndLoop then
		self.m_sndLoop:Stop()
	end
end

function ENT:Think()
	if not self:GetEnabled() and self.m_sndLoop:IsPlaying() then
		self.m_sndLoop:FadeOut( 0.5 )
	elseif self:GetEnabled() and not self.m_sndLoop:IsPlaying() then
		self.m_sndLoop:PlayEx( 0.75, 100 )
	end
end

local dist
function ENT:Draw()
	if self.m_entScreen then
		self.m_entScreen:DrawModel()
	else
		local ent = ClientsideModel( "models/props_lab/reciever01d.mdl", RENDERGROUP_OPAQUE )
		ent:SetPos( self:LocalToWorld(Vector("-0.930176 -4.966064 44.372963")) )
		ent:SetAngles( self:LocalToWorldAngles(Angle(0, 0, 0)) )
		ent:SetParent( self )
		ent:SetNoDraw( true )
		self.m_entScreen = ent
	end
	self:DrawModel()
	
	dist = LocalPlayer():GetPos():DistToSqr( self:GetPos() )
	if dist > 65536 then return end
	
	--Move the screen to account for lod changes that would hide it
	local offset = dist > 10000 and 0.1 or 0
	
	--Draw the counter screen
	local old = render.GetToneMappingScaleLinear()
	render.SetToneMappingScaleLinear( Vector(0.5, 0.5, 0.5) )
	render.SuppressEngineLighting( true )
		cam.Start3D2D( self:LocalToWorld(Vector(4.9 +offset, -10.08, 45.2)), self:LocalToWorldAngles(Angle(0, 90, 90)), 0.07 )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawRect( 0, 0, 70, 35)
			if self:GetRebootTime() ~= 0 then
				surface.SetTextColor( 20, 255, 20, 255 )
				surface.SetFont( "DermaLarge" )
				surface.SetTextPos( 1, 2 )
				surface.DrawText( GAMEMODE.Util:FormatTime( self:GetRebootTime() -(CurTime() -self:GetShutdownTime()) ) )
			end
		cam.End3D2D()
	render.SuppressEngineLighting( false )
	render.SetToneMappingScaleLinear( old )
end