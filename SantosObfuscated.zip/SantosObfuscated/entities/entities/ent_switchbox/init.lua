--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

local breaker = { pos = Vector('1.273571 6.242065 49.091743'), ang = Angle('-0.000 0.005 0.000'), scale = 0.33 }
local switches = {
	{ pos = Vector('0.255 0 50.5'), ang = Angle('-0.000 0.005 -90.000'), scale = 0.3 },
	{ pos = Vector('0.255 0 52.5'), ang = Angle('-0.000 0.005 -90.000'), scale = 0.3 },
	{ pos = Vector('0.255 0 54.5'), ang = Angle('-0.000 0.005 -90.000'), scale = 0.3 },
	{ pos = Vector('0.255 0 56.5'), ang = Angle('-0.000 0.005 -90.033'), scale = 0.3 },
	{ pos = Vector('0.255 0 58.5'), ang = Angle('-0.000 0.005 -90.000'), scale = 0.3 },
	{ pos = Vector('0.255 0 60.5'), ang = Angle('-0.000 0.005 -90.000'), scale = 0.3 },
	{ pos = Vector('0.255 0 62.5'), ang = Angle('-0.000 0.000 -90.000'), scale = 0.3 },
}

function ENT:Initialize()
	self:SetAutomaticFrameAdvance( true )
	self:SetModel( self.Model )
	self:PhysicsInitBox( Vector(-6, -12, 0), Vector(6, 12, 67) )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:PhysWake()

	self.m_intMinRebootTime = 90
	self.m_intMaxRebootTime = 120
	self.m_intCooldown = 60 *5
	
	self.m_tblSwitches = {}
	local min, max = Vector( -0.25, -0.66, -0.75 ), Vector( 0.25, 0.66, 0.75 )
	for k, v in pairs( switches ) do
		local ent = ents.Create( "ent_button" )
		ent:SetModel( "models/props_mining/switch01.mdl" )
		ent:Spawn()
		ent:Activate()

		ent:SetDTBool( GAMEMODE.Map.DT_IS_MAP_PROP, true )
		ent:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
		ent:SetPos( self:LocalToWorld(v.pos) )
		ent:SetAngles( self:LocalToWorldAngles(v.ang) )
		ent:SetModelScale( v.scale )
		ent:SetIsToggle( true )
		ent.BlockPhysGun = true
		ent.IsMapProp = true
		ent.m_intSwitchID = k
		ent:PhysicsInitBox( min, max )
		ent:GetPhysicsObject():EnableMotion( false )
		ent:ResetSequence( 1 )

		ent:SetCanUseCallback( function( eEnt, pPlayer )
			if not self.m_bDoorOpen then return false end
			if not self:GetEnabled() then return false end
			return true
		end )
		ent:SetCallback( function( eEnt, pPlayer, bOn )
			eEnt:ResetSequence( bOn and 2 or 1 )
			
			if bOn then
				for i = 1, eEnt.m_intSwitchID do
					if not self.m_tblSwitches[i]:GetOn() then
						eEnt:SetOn( false )
						self:FlipSwitches( false ) --They turned a switch on out of order
						return
					end
				end
				
				if eEnt.m_intSwitchID == #self.m_tblSwitches then
					self:OnSwitchGameSolved() --They flipped the last switch!
				end
			else
				--If they turn one off, flip them all off
				self:FlipSwitches( false )
				self.m_tblSwitchPattern = {}
			end
			
			eEnt:EmitSound( "buttons/lever7.wav", 60, 100, 0.4 )
		end )
		
		ent.m_entParent = self
		self:DeleteOnRemove( ent )
		self.m_tblSwitches[k] = ent
	end

	local ent = ents.Create( "ent_button" )
	ent:SetAutomaticFrameAdvance( true )
	ent:SetModel( "models/props_lab/tpswitch.mdl" )
	ent:Spawn()
	ent:Activate()
	
	ent:SetDTBool( GAMEMODE.Map.DT_IS_MAP_PROP, true )
	ent:SetIsToggle( true )
	ent.BlockPhysGun = true
	ent.IsMapProp = true
	ent:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
	ent:SetPos( self:LocalToWorld(breaker.pos) )
	ent:SetAngles( self:LocalToWorldAngles(breaker.ang) )
	ent:SetModelScale( breaker.scale )
	ent:PhysicsInitBox( Vector(-1, -2.75, -5), Vector(1, 2.75, 5.5) )
	ent:GetPhysicsObject():EnableMotion( false )
	
	ent:SetCanUseCallback( function( eEnt, pPlayer )
		if not self.m_bDoorOpen then return false end
		if not self.m_bBreakerOpen then return false end
		if not self:GetEnabled() then return false end
		if eEnt:GetOn() then
			if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_POLICE then
				return true
			end
			return false
		end
		return true
	end )
	ent:SetCallback( function( eEnt, pPlayer )
		if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_POLICE then
			if eEnt:GetOn() then
				self:OnBreakerReboot()
			end

			return
		end
		
		eEnt:ResetSequence( eEnt:LookupSequence("switch") )
		eEnt:EmitSound( "buttons/lever2.wav", 60, 100, 0.6 )
		timer.Simple( 1, function()
			if not IsValid( eEnt ) or not IsValid( self ) then return end
			eEnt:EmitSound( "ambient/energy/power_off1.wav", 60, 100, 1 )
			self:OnBreakerSwitched()
		end )
	end )
	
	ent.m_entParent = self
	self:DeleteOnRemove( ent )
	self.m_entBreaker = ent
	
	--Setup idle anim
	self:SetSequence( "idle" )
	self:SetCycle( 0 )
	self.m_bDoorOpen = false
	self:SetEnabled( true )
	self:ShuffleSwitches()
	self:LockDoor()
end

function ENT:SetRebootTimes( intMin, intMax, intCooldown )
	self.m_intMinRebootTime = intMin
	self.m_intMaxRebootTime = intMax
	self.m_intCooldown = intCooldown
end

function ENT:SetEvents( fnRun, fnFail, fnReboot )
	self.m_funcRunEvent = fnRun
	self.m_funcFailEvent = fnFail
	self.m_funcRebootEvent = fnReboot
end

function ENT:Use( eEnt, ... )
	if not IsValid( eEnt ) or not eEnt:IsPlayer() then return end
	if self.m_bDoorOpen then
		local ent = util.TraceLine{
			start = eEnt:GetShootPos(),
			endpos = eEnt:GetShootPos() +eEnt:GetAimVector() *64,
			filter = { self, eEnt },
		}.Entity
		
		if IsValid( ent ) and ent.m_entParent and ent.m_entParent == self then
			if ent.Use then ent:Use( eEnt, ... ) return end
		end
	end
	
	if self.m_bDoorOpen then
		self:CloseDoor()
	else
		self:OpenDoor()
	end
end

--Power box door
function ENT:LockDoor()
	self.m_bLocked = true
end

function ENT:UnlockDoor()
	self.m_bLocked = false
end

function ENT:CanOpenDoor()
	if self.m_bDoorMoving or self.m_bDoorOpen then return false end
	if self.m_intLastCooldown and self.m_intLastCooldown > CurTime() +self.m_intCooldown then return false end
	if self.m_bLocked then return false end
	return true
end

function ENT:GetCooldownTimeLeft()
	return math.max( (self.m_intLastCooldown or 0) -CurTime(), 0 )
end

function ENT:OpenDoor()
	if not self:CanOpenDoor() then return false end
	self.m_bDoorMoving = true

	local idx = self:LookupSequence( "openPowerBox" )
	self:ResetSequence( idx )
	timer.Simple( self:SequenceDuration(idx), function()
		if not IsValid( self ) then return end
		self.m_bDoorMoving = false
		self.m_bDoorOpen = true
		self:OnDoorOpen()
	end )
	return true
end

function ENT:CloseDoor( bForce )
	if not bForce then
		if self.m_bDoorMoving then return false end
	end
	if not self.m_bDoorOpen then return end
	self.m_bDoorMoving = true

	local idx = self:LookupSequence( "closePowerBox" )
	self:ResetSequence( idx )
	timer.Simple( self:SequenceDuration(idx), function()
		if not IsValid( self ) then return end
		self.m_bDoorMoving = false
		self.m_bDoorOpen = false
		self:OnDoorClose()
	end )
	return true
end

function ENT:OnDoorOpen()
	self:SetSequence( "hackPowerBox" )
	self:SetCycle( 0 )
end

function ENT:OnDoorClose()
	self:SetSequence( "idle" )
	self:SetCycle( 0 )
end

--Main breaker door
function ENT:OpenBreaker()
	if self.m_bBreakerMoving or not self.m_bDoorOpen then return end
	if self.m_bBreakerOpen then return end
	self.m_bBreakerMoving = true

	local idx = self.m_entBreaker:LookupSequence( "open" )
	self.m_entBreaker:ResetSequence( idx )
	timer.Simple( self.m_entBreaker:SequenceDuration(idx), function()
		if not IsValid( self ) then return end
		self.m_bBreakerMoving = false
		self.m_bBreakerOpen = true
		self:OnBreakerOpen()
	end )
end

function ENT:CloseBreaker()
	if not self.m_bBreakerOpen then return end
	
	self.m_entBreaker:SetOn( false )
	local idx = self.m_entBreaker:LookupSequence( "idle" )
	self.m_entBreaker:ResetSequence( idx )
	self.m_bBreakerMoving = false
	self.m_bBreakerOpen = false
	self:SetEnabled( true )
end

function ENT:OnBreakerOpen()
end

function ENT:OnBreakerClose()
end

function ENT:OnBreakerSwitched()
	self:SetEnabled( false )
	self:SetShutdownTime( CurTime() )
	self:SetRebootTime( math.random(self.m_intMinRebootTime, self.m_intMaxRebootTime) )
	timer.Create( "ent_switchbox_reboot"..self:EntIndex(), self:GetRebootTime(), 1, function()
		if not IsValid( self ) then return end
		self:OnBreakerReboot()
	end )
	
	self.m_funcRunEvent( self )
end

function ENT:Reset()
	timer.Destroy( "ent_switchbox_reboot"..self:EntIndex() )
	self:CloseDoor( true )
	self:CloseBreaker()
	self:FlipSwitches( false )
	self:ShuffleSwitches()
	self:SetShutdownTime( 0 )
	self:SetRebootTime( 0 )
end

function ENT:OnBreakerReboot()
	self:Reset()
	if self.m_intCooldown then
		self.m_intLastCooldown = CurTime()
	end
	self:LockDoor()
	self.m_funcRebootEvent( self )
end

--Switch game
function ENT:FlipSwitches( bOn )
	local bSnd
	local numChanged = 0
	for k, v in pairs( self.m_tblSwitches ) do
		if v:GetOn() ~= bOn then
			if not bSnd then
				v:EmitSound( "buttons/lever7.wav", 60, 100, 0.4 )
				bSnd = true
			end
			numChanged = numChanged +1
		end
		
		v:SetOn( bOn )
		v:ResetSequence( bOn and 2 or 1 )
	end
	
	if not bOn then
		self:CloseBreaker()
		if numChanged > 0 then
			self:EmitSound( "ambient/energy/zap".. math.random(5, 9).. ".wav", 60, math.random(80, 110), 0.5 )
		end
	end
end

function ENT:ShuffleSwitches()
	local new = {}
	for k, v in RandomPairs( self.m_tblSwitches ) do
		new[#new +1] = v
		v.m_intSwitchID = #new
	end
	self.m_tblSwitches = new
end
	
function ENT:OnSwitchGameSolved()
	self:OpenBreaker()
end