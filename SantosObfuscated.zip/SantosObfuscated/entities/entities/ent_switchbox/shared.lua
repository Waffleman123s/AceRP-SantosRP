--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.RenderGroup 	= RENDERGROUP_OPAQUE
ENT.Model 			= Model( "models/props_c17/powerbox.mdl" )
ENT.SwitchModel 	= Model( "models/props_mining/switch01.mdl" )
ENT.BreakerModel 	= Model( "models/props_lab/tpswitch.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "Enabled" )
	self:NetworkVar( "Float", 0, "ShutdownTime" )
	self:NetworkVar( "Float", 1, "RebootTime" )
end