--[[
	Name: cl_init.lua
	For: SantosRP
	By: Ultra
]]--

include "shared.lua"

local waterSound = Sound( "ambient/levels/canals/dam_water_loop2.wav" )
local Mat = CreateMaterial( "FireHose", "VertexLitGeneric", {
	["$basetexture"] = "color/white",
	["$vertexcolor"] = "1",
	["$color"] = "{162 113 17}",
	["$nocull"] = "0",
} )

function ENT:Initialize()
	self.m_pWaterSound = CreateSound( self, waterSound )
	self.m_pWaterSound:ChangePitch( 255, 0 )
	self.m_pWaterSound:SetSoundLevel( 80 )
	hook.Add( "PostDrawTranslucentRenderables", self, self.PostDrawTranslucentRenderables )
end

function ENT:OnRemove()
	if self.m_pWaterSound then self.m_pWaterSound:Stop() end
end

function ENT:Think()
	local Car = self:GetOwner()
	if IsValid( Car ) and not IsValid( Car.Hose) then Car.Hose = self end

	if self:GetOn() then
		if not self.m_pWaterSound:IsPlaying() then
			self.m_pWaterSound:PlayEx( 0.25, 255 )
			ParticleEffectAttach( "firehose_jet", PATTACH_ABSORIGIN_FOLLOW, self, 0 )
		end
	else
		if self.m_pWaterSound:IsPlaying() then
			self.m_pWaterSound:Stop()
			self:StopParticles()
		end
	end
end

local colBlack = Color( 0, 0, 0, 255 )
function ENT:DrawBar( intX, intY, intW, intH, colColor, intCur, intMax )
	surface.SetDrawColor( colBlack )
	surface.DrawRect( intX, intY, intW, intH )

	local padding = 1
	local wide = (intCur /intMax) *(intW -(padding *2))
	surface.SetDrawColor( colColor )
	surface.DrawRect( intX +padding, intY +padding, wide, intH -(padding *2) )
end

local col = Color( 0, 56, 96, 255 )
function ENT:DrawScreen()
	if not IsValid( self:GetOwner() ) then return end
	local level = self:GetWaterLevel() 
	local camPos = self:GetOwner():LocalToWorld( self:GetScreenPos() )
	local camAng = self:GetOwner():LocalToWorldAngles( self:GetScreenAngle() )
	cam.Start3D2D( camPos, camAng, 0.03 )
		self:DrawBar( 0, -(48 /2), 450, 100, col, level, self.MaxWaterTank )
		
		surface.SetFont( "DermaLarge" )
		surface.SetTextColor( 255, 255, 255, 255 )
		surface.SetTextPos( 5, -16 )
		surface.DrawText( ("Water Tank (%d/%d)"):format(level, self.MaxWaterTank) )
	cam.End3D2D()
end

function ENT:PostDrawTranslucentRenderables()
	self:DrawScreen()
end

function ENT:Draw()
	self:DrawModel()
	
	local Car = self:GetOwner()
	if not IsValid( Car ) then return end
	
	Car.Hose = self
	
	local Pos, Ang = self:GetPos(), self:GetAngles()
	local Pos2 = Car:LocalToWorld(self:GetAttPos())
	
	local CurvePos1 = Pos2 +(Car:GetUp() *self:GetCurve1().z +Car:GetRight() *self:GetCurve1().y +Car:GetForward()* self:GetCurve1().x)
	local CurveAng1 = Car:LocalToWorldAngles( Angle(self:GetAttAng().x, self:GetAttAng().y, self:GetAttAng().z) )
	
	local CurvePos2 = Pos +(self:GetForward() *self:GetCurve2().x +self:GetRight() *self:GetCurve2().y +self:GetUp() *self:GetCurve2().z)
	local CurveAng2 = self:LocalToWorldAngles( Angle(0, 180, 0) )
	
	self:SetRenderBoundsWS( Pos, Pos2 )
	
	local Curve = nil
	if EyePos():Distance( self:GetPos() ) > GAMEMODE.Config.RenderDist_Level1 then	
		Curve = GAMEMODE.Util:BezierCurve( CurvePos1, CurveAng1, CurvePos2, CurveAng2, 30, 3 )
	else
		Curve = GAMEMODE.Util:BezierCurve( CurvePos1, CurveAng1, CurvePos2, CurveAng2, 30, 16 )
	end
	
	render.SetMaterial( Mat )
	render.ResetModelLighting( 0.2, 0.2, 0.2 )
	GAMEMODE.Util:CurveToMesh( Curve, 11, 10 )
end