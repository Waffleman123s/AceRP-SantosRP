--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/devonjones/santos/nozzle.mdl" )
ENT.MaxWaterTank	= 5000
ENT.PumpSpeed		= 28

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "On" )
	self:NetworkVar( "Vector", 0, "AttPos" )
	self:NetworkVar( "Vector", 1, "AttAng" )
	self:NetworkVar( "Vector", 2, "Curve1" )
	self:NetworkVar( "Vector", 3, "Curve2" )
	self:NetworkVar( "Vector", 4, "ScreenPos" )
	self:NetworkVar( "Angle", 0, "ScreenAngle" )
	self:NetworkVar( "Float", 0, "WaterLevel" )
end