--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

local MAX_HOSE_DISTANCE = 1024

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )

	local phys = self:GetPhysicsObject()
	if not IsValid( phys ) then
		error( "Unable to initialize physics for ent_firesupplyhose!" )
	end

	self.Phys = phys
	self.Phys:EnableGravity( false )
	
	self.LastTouch = CurTime()
	self.m_intLastFire = 0
	self.m_intLastCheck = 0
	self.m_intCheckInterval = 0.25
	self.m_bPosSet = true
	
	self:NextThink( CurTime() +1 )
	self.AdminPhysGun = true
	self:StartMotionController()
end

function ENT:SetSlotID( intID )
	self.m_intSlot = intID
end

function ENT:PhysicsSimulate( phys, intDeltaTime )
	local Hold = IsValid( self.m_pPlayerHolding )

	if Hold and IsValid( phys ) then
		self.m_tblShadowParams = self.m_tblShadowParams or {}
		local eyeAng = self.m_pPlayerHolding:EyeAngles()
		eyeAng.p = eyeAng.p *1
		self.m_tblShadowParams.angle = eyeAng -Angle(3, 0, 0)

		phys:Wake()

		local newpos = self.m_pPlayerHolding:GetShootPos() +
			(self.m_pPlayerHolding:GetAimVector() *34) +
			self:GetAngles():Right() *10 +
			self:GetAngles():Up() *-12

		self.m_tblShadowParams.secondstoarrive = 0.01
		self.m_tblShadowParams.pos = newpos
		self.m_tblShadowParams.maxangular = 1000000
		self.m_tblShadowParams.maxangulardamp = 1000000
		self.m_tblShadowParams.maxspeed = 1000000
		self.m_tblShadowParams.maxspeeddamp = 1000000
		self.m_tblShadowParams.dampfactor = 0.8
		self.m_tblShadowParams.teleportdistance = 0
		self.m_tblShadowParams.deltatime = intDeltaTime
		phys:ComputeShadowControl( self.m_tblShadowParams )
	end

	return
end

function ENT:AttachedToHydrant()
	return IsValid( self.m_entSnappedTo )
end

function ENT:Think()
	if not IsValid( self:GetOwner() ) then self:Remove() end
	local Hold = IsValid( self.m_pPlayerHolding )
	local Parent = self:GetParent()

	if not Hold and self.m_bPosSet then
		if not IsValid( self.m_entSnappedTo ) then
			local HosePos, HoseAng = self:GetOwner():GetHoseSlot( self.m_intSlot )
			if self:GetPos():Distance( HosePos ) > 8 then --what the fuck
				self.m_bPosSet = false
			end
		else
			if self:GetPos():Distance( self:GetOwner():GetPos() ) > MAX_HOSE_DISTANCE then
				self.m_bPosSet = false --Snap back to the truck
				self.m_entSnappedTo = nil
				self:EmitSound( ("weapons/crowbar/crowbar_impact%d.wav"):format(math.random(1,2)), 60, 100, 0.75 )
				self.m_bSnapAway = true
			else
				local switch = self:GetOwner().m_entPumpSwitch
				if IsValid( switch ) and switch:GetOn() and CurTime() > (self.m_intLastPumpTime or 0) then
					self:SetWaterLevel( math.min(self:GetWaterLevel() +self.PumpSpeed, self.MaxWaterTank) )
					self.m_intLastPumpTime = CurTime() +0.25
				end
			end
		end
	elseif not Hold and (not self.m_bPosSet or not self.Phys:IsAsleep()) then	
		self.Phys:Sleep()
		self.Phys:EnableMotion( false )

		--Look for a nearby hydrant to snap on to
		local found
		if not self.m_bSnapAway and self:GetPos():Distance( self:GetOwner():GetPos() ) < MAX_HOSE_DISTANCE then
			local data = ents.FindInSphere( self:GetPos(), 32 )
			for k, v in pairs( data ) do
				if v:GetModel() == "models/props/cs_assault/firehydrant.mdl" then
					found = v
					break
				end
			end
		end
		
		if IsValid( found ) then
			--We want to snap on to this hydrant
			self:SetPos( found:LocalToWorld(Vector('0.022288 -6.801485 19.237545')) )
			self:SetAngles( found:LocalToWorldAngles(Angle('-0.028 89.654 -0.015')) )
			self:SetParent( found )
			self:EmitSound( "buttons/lever3.wav", 60, 100, 0.75 )
			self.m_entSnappedTo = found
		else
			--Snap on the truck
			self:SetParent( nil )
			local HosePos, HoseAng = self:GetOwner():GetHoseSlot( self.m_intSlot )
			self:SetPos( HosePos )
			self:SetAngles( HoseAng )
			self:SetParent( self:GetOwner() )
			self.m_entSnappedTo = nil
			self.m_bSnapAway = nil
		end

		self.m_bUseBlock = false
		self.m_bPosSet = true
	elseif Hold then
		if IsValid( self.m_entSnappedTo ) then
			self.m_entSnappedTo = nil
			self:EmitSound( ("weapons/crowbar/crowbar_impact%d.wav"):format(math.random(1,2)), 60, 100, 0.75 )
		end

		if self:GetPos():Distance( self:GetOwner():GetPos() ) > MAX_HOSE_DISTANCE or self.m_pPlayerHolding:InVehicle() or self.m_pPlayerHolding:IsIncapacitated() then
			self.m_pPlayerHolding = nil
			return
		end

		self.m_bPosSet = false
		if self.m_bUseBlock and not self.m_pPlayerHolding:KeyDown( IN_USE ) then
			self.m_bUseBlock = false
		end
	end
	
	self:NextThink( CurTime() )

	return true
end

function ENT:Use( user )
	if IsValid( user.m_entHoldingFireHose ) and user.m_entHoldingFireHose ~= self then return end
	if self.m_pPlayerHolding and not self.m_bUseBlock then
		if IsValid( self.m_pPlayerHolding ) then
			self.m_pPlayerHolding.m_entHoldingFireHose = nil
		end
		self.m_pPlayerHolding = nil
		self.m_bUseBlock = true
		return
	end

	user.m_entHoldingFireHose = self
	self.LastTouch = CurTime() +1
	self:SetParent( nil )
	self.Phys:EnableMotion( true )
	self.Phys:Wake()
	
	self.m_pPlayerHolding = user
	self.m_bUseBlock = true
end