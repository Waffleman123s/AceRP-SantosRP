--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	
	local triggerSize = Vector( 1, 1, 2 ) *8
	self:SetCollisionGroup( COLLISION_GROUP_NONE )
	self:DrawShadow( false )
	self:SetSolid( SOLID_BBOX )
	self:SetTrigger( true )
	self:SetMoveType( MOVETYPE_NONE )
	self.IsMapProp = true
	self.BlockPhysGun = true
	self:EmitSound( self.SoundStress1 )
	self:SetModel("models/props/cs_assault/firehydrant.mdl")

	self:SetCollisionBounds( triggerSize *-1, triggerSize )
end

function ENT:Think()
	if not self.m_intAttachTime then return end

	if not IsValid( self.m_entAttached ) or self.m_entAttached.Owner:GetPos():Distance( self:GetPos() ) > 200 then
		self.m_intAttachTime = nil
		self:RemoveWrench()
		return
	end
	
	if CurTime() > self.m_intAttachTime +self.FixDuration then
		self.m_intAttachTime = nil
		if IsValid( self.m_entAttached ) and self.m_entAttached.OnWrenchRemoved then
			self.m_entAttached:OnWrenchRemoved( self )
		end
		self.m_entRemovedBy = self.m_entAttached.Owner
		sound.Play( self.SoundStress4, self:GetPos(), 70 )
		self:Remove()
	end
end

function ENT:AttachWrench( entWep )
	if IsValid( self.m_entAttached ) then
		return
	end

	self.m_entAttached = entWep
	self.m_intAttachTime = CurTime()
	self:SetWrenchAttached( true )
	self:SetAttachTime( CurTime() )
	self:EmitSound( self.SoundImpact )

	if IsValid( self.m_entAttached ) and self.m_entAttached.OnWrenchAttached then
		self.m_entAttached:OnWrenchAttached( self )
		entWep:SetAttachDuration( self.FixDuration )
	end
end

function ENT:RemoveWrench()
	if not self.m_entAttached then return end
	if IsValid( self.m_entAttached ) and self.m_entAttached.OnWrenchRemoved then
		self.m_entAttached:OnWrenchRemoved( self )
	end

	self:EmitSound( self.SoundStress2 )
	
	self.m_entAttached = nil
	self.m_intAttachTime = nil
	self:SetWrenchAttached( false )
	self:SetAttachTime( 0 )
end