--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.FixDuration		= 12
ENT.Model 			= Model( "models/props_junk/garbage_metalcan002a.mdl" )
ENT.SoundStress1 	= Sound( "ambient/materials/metal_stress1.wav" )
ENT.SoundStress2 	= Sound( "ambient/materials/metal_stress2.wav" )
ENT.SoundStress4 	= Sound( "ambient/materials/metal_stress4.wav" )
ENT.SoundImpact 	= Sound( "weapons/crowbar/crowbar_impact1.wav" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "WrenchAttached" )
	self:NetworkVar( "Float", 0, "AttachTime" )
end