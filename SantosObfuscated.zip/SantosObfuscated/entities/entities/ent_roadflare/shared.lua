--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_junk/flare.mdl" )
ENT.FireSound 		= Sound( "weapons/flaregun/fire.wav" )
ENT.BurnTime 		= 3 *60

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "Lit" )
end