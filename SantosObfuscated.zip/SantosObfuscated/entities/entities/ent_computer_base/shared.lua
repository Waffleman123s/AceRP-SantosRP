--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/testmodels/macbook_pro.mdl" )

ENT.m_intMaxRenderRange = 256
ENT.HideDragOverlay = true