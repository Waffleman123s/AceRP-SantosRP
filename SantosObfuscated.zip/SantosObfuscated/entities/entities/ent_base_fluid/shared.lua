--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.MaxFluid 		= 500
ENT.Model 			= Model( "models/props_junk/garbage_bag001a.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "Pouring" )
	self:NetworkVar( "String", 0, "DisplayText" )
end