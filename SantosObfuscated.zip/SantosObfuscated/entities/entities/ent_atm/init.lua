--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( "models/props_unique/atm01.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:PhysWake()
end

function ENT:PlayerMakeDeposit( pPlayer, intAmount )
	if pPlayer:GetPos():Distance( self:GetPos() ) >self.m_intMaxUseRange then return end

	local amount = math.min( intAmount, pPlayer:GetMoney() )
	pPlayer:TakeMoney( amount, "ATM deposit" )
	pPlayer:AddBankMoney( amount, "In-person deposit" )
	pPlayer:AddNote( "You deposited $".. string.Comma(amount) )
	pPlayer.m_intLastATMAction = CurTime() +3
end

function ENT:PlayerMakeWithdraw( pPlayer, intAmount )
	if pPlayer:GetPos():Distance( self:GetPos() ) >self.m_intMaxUseRange then return end
	
	local amount = math.min( intAmount, pPlayer:GetBankMoney() )
	pPlayer:TakeBankMoney( amount, "In-person withdrawal" )
	pPlayer:AddMoney( amount, "ATM withdrawal" )
	pPlayer:AddNote( "You withdrew $".. string.Comma(amount) )
	pPlayer.m_intLastATMAction = CurTime() +3
end

function ENT:PlayerMakeTransfer( pPlayer, intAmount, strPhoneNum )
	if pPlayer:GetPos():Distance( self:GetPos() ) >self.m_intMaxUseRange then return end

	local foundPlayer
	for k, v in pairs( player.GetAll() ) do
		if aphone.GetNumber(v:aphone_GetID()) == strPhoneNum then
			foundPlayer = v
			break
		end
	end

	if not IsValid( foundPlayer ) or foundPlayer == pPlayer then
		pPlayer:AddNote( "Unable to locate target bank account!" )
		return
	end
	
	local amount = math.min( intAmount, pPlayer:GetBankMoney() )
	pPlayer:TakeBankMoney( amount, "ATM wire transfer to account #".. strPhoneNum )
	foundPlayer:AddBankMoney( amount, "ATM wire transfer from account #".. GAMEMODE.Player:GetGameVar(pPlayer, "phone_number", "") )
	pPlayer:AddNote( "You transfered $".. string.Comma(amount).. " to account #".. strPhoneNum )
	pPlayer.m_intLastATMAction = CurTime() +3
end