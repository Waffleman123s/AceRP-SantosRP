ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Flashbang"
ENT.Author = "Siminov"
ENT.Information	= "Flashes Everything In View"
ENT.Category = "Firearms Source Weapons"

ENT.Spawnable = true
ENT.AdminSpawnable = true