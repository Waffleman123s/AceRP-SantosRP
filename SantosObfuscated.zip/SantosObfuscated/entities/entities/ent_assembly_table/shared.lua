--[[
Original Creators: MazeRP Development Team
Modified and reworked by: GNetRP Development Team
Legal Information: Legal@gnetrp.com
Extra Information: www.gnetrp.com or www.gnetrp.gg | https://discord.gg/2Mnk937aMn | @Tylr#9999 STEAM_0:1:71010553 @Krusty STEAM_0:1:164681911 @Meaty#8863 STEAM_0:1:151895828 | https://github.com/TylrDevs | https://github.com/gnetrp |
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/mosi/fallout4/furniture/workstations/weaponworkbench01.mdl" )