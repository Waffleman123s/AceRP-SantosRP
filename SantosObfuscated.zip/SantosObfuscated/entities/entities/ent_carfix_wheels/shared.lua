--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_vehicles/carparts_wheel01a.mdl" )
ENT.SoundServo2 	= Sound( "npc/dog/dog_servo12.wav" )
ENT.SoundFXTable 	= {
	Sound( "npc/dog/dog_servo8.wav" ),
	Sound( "npc/dog/dog_servo7.wav" ),
}