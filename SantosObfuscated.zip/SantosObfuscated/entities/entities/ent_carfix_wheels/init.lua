--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetTrigger( true )
	self:PhysWake()
end

function ENT:StartTouch( eEnt )
	if not IsValid( eEnt ) or not eEnt:IsVehicle() or not eEnt.UID then return end
	if self.m_bUsed then return end
	if not self.m_intLastTouch then self.m_intLastTouch = 0 end
	if CurTime() <= self.m_intLastTouch then return end
	self.m_intLastTouch = CurTime() +1
	
	if GAMEMODE.Cars:FixVehicleWheels( eEnt ) then
		SafeRemoveEntityDelayed( self, 0 )
		self.m_bUsed = true
		self.m_bRemoveWaiting = true
		self.ItemTakeBlocked = true

		local posLocal = eEnt:WorldToLocal( self:GetPos() )
		local idx = 1
		eEnt:EmitSound( self.SoundServo2 )
		local sounds = self.SoundFXTable
		timer.Create( ("EmitSound%p"):format(self), 1, 2, function()
			if not IsValid( eEnt ) then return end
			eEnt:EmitSound( sounds[idx] )
			idx = idx +1
		end )
	end
end