--[[
	Name: init.lua
	For: SantosRP
	By: Ultra
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetCollisionGroup( COLLISION_GROUP_NONE )
	self:DrawShadow( false )
	self:SetSolid( SOLID_BBOX )
	self:SetTrigger( true )
	self:SetMoveType( MOVETYPE_NONE )
	self.IsMapProp = true

	self:SetCollisionBounds( self.m_vecMins, self.m_vecMaxs )
end

function ENT:Setup( vecMins, vecMaxs, funcFilter, funcActionStart, funcActionEnd, entTarget )
	self.m_fnActionStart = funcActionStart
	self.m_fnActionEnd = funcActionEnd
	self.m_fnFilter = funcFilter
	self.m_vecMins = vecMins
	self.m_vecMaxs = vecMaxs
	self.m_entTarget = entTarget
end

function ENT:UpdateTransmitState()
	return TRANSMIT_NEVER
end

function ENT:StartTouch( entOther )
	if not self.m_fnFilter( entOther ) then return end
	self.m_fnActionStart( entOther, self.m_entTarget )
end

function ENT:EndTouch( entOther )
	self.m_fnActionEnd( entOther, self.m_entTarget )
end