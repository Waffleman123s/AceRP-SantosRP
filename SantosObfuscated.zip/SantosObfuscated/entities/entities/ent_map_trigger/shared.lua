--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "brush"
ENT.Base 			= "base_brush"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""