--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/devonjones/santos/nozzle.mdl" )
ENT.WaterConsumptionRate = 2
PrecacheParticleSystem "firehose_jet"

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "On" )
	self:NetworkVar( "Vector", 0, "AttPos" )
	self:NetworkVar( "Vector", 1, "AttAng" )
	self:NetworkVar( "Vector", 2, "Curve1" )
	self:NetworkVar( "Vector", 3, "Curve2" )
end