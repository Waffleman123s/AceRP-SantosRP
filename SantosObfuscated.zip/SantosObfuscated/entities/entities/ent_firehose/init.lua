AddCSLuaFile"cl_init.lua"
AddCSLuaFile"shared.lua"
include"shared.lua"
local MAX_HOSE_DISTANCE = 2048

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	local phys = self:GetPhysicsObject()

	if not IsValid(phys) then
		error("Unable to initialize physics for ent_firehose!")
	end

	self.Phys = phys
	self.Phys:EnableGravity(false)
	self.LastTouch = CurTime()
	self.m_intLastFire = 0
	self.m_intLastCheck = 0
	self.m_intCheckInterval = 0.115
	self.m_bPosSet = true
	self:NextThink(CurTime() + 1)
	self.AdminPhysGun = true
	self:StartMotionController()
end

function ENT:SetSupplyHose(ent)
	self.m_entSupply = ent
end

function ENT:SetSlotID(intID)
	self.m_intSlot = intID
end

function ENT:PhysicsSimulate(phys, intDeltaTime)
	local Hold = IsValid(self.m_pPlayerHolding)

	if Hold and IsValid(phys) then
		self.m_tblShadowParams = self.m_tblShadowParams or {}
		local eyeAng = self.m_pPlayerHolding:EyeAngles()
		eyeAng.p = eyeAng.p * 1
		self.m_tblShadowParams.angle = eyeAng - Angle(3, 0, 0)
		phys:Wake()
		local newpos = self.m_pPlayerHolding:GetShootPos() + (self.m_pPlayerHolding:GetAimVector() * 34) + self:GetAngles():Right() * 10 + self:GetAngles():Up() * -12
		self.m_tblShadowParams.secondstoarrive = 0.01
		self.m_tblShadowParams.pos = newpos
		self.m_tblShadowParams.maxangular = 1000000
		self.m_tblShadowParams.maxangulardamp = 1000000
		self.m_tblShadowParams.maxspeed = 1000000
		self.m_tblShadowParams.maxspeeddamp = 1000000
		self.m_tblShadowParams.dampfactor = 0.8
		self.m_tblShadowParams.teleportdistance = 0
		self.m_tblShadowParams.deltatime = intDeltaTime
		phys:ComputeShadowControl(self.m_tblShadowParams)
	end

	return
end

function ENT:Think()
	if not IsValid(self:GetOwner()) then
		self:Remove()
	end

	local Hold = IsValid(self.m_pPlayerHolding)
	local Parent = self:GetParent()

	if not Hold and self.m_bPosSet then
		if self:GetOn() then
			self:SetOn(false)
		end

		local HosePos, HoseAng = self:GetOwner():GetHoseSlot(self.m_intSlot)

		--what the fuck
		if self:GetPos():Distance(HosePos) > 8 then
			self.m_bPosSet = false
		end
	elseif not Hold and (not self.m_bPosSet or not self.Phys:IsAsleep()) then
		self.Phys:Sleep()
		self.Phys:EnableMotion(false)
		local HosePos, HoseAng = self:GetOwner():GetHoseSlot(self.m_intSlot)
		self:SetPos(HosePos)
		self:SetAngles(HoseAng)
		self:SetParent(self:GetOwner())
		self.m_bUseBlock = false
		self.m_bPosSet = true
	elseif Hold then
		if self:GetPos():Distance(self:GetOwner():GetPos()) > MAX_HOSE_DISTANCE or self.m_pPlayerHolding:InVehicle() or self.m_pPlayerHolding:IsIncapacitated() then
			self.m_pPlayerHolding = nil

			return
		end

		self.m_bPosSet = false

		if self.m_bUseBlock and not self.m_pPlayerHolding:KeyDown(IN_USE) then
			self.m_bUseBlock = false
		end

		local supply = self.m_entSupply

		if IsValid(supply) and self.m_pPlayerHolding:KeyDown(IN_ATTACK2) and supply:GetWaterLevel() >= self.WaterConsumptionRate then
			self:FireWater()

			if not self:GetOn() then
				self:SetOn(true)
			end
		else
			self.m_intLastCheck = CurTime()

			if self:GetOn() then
				self:SetOn(false)
			end
		end
	end

	self:NextThink(CurTime())

	return true
end

function ENT:Use(user)
	if IsValid(user.m_entHoldingFireHose) and user.m_entHoldingFireHose ~= self then return end

	if self.m_pPlayerHolding and not self.m_bUseBlock then
		if IsValid(self.m_pPlayerHolding) then
			self.m_pPlayerHolding.m_entHoldingFireHose = nil
		end

		self.m_pPlayerHolding = nil
		self.m_bUseBlock = true

		return
	end

	user.m_entHoldingFireHose = self
	self.LastTouch = CurTime() + 1
	self:SetParent(nil)
	self.Phys:EnableMotion(true)
	self.Phys:Wake()
	self.m_pPlayerHolding = user
	self.m_bUseBlock = true
end

local waterSize = 2

function ENT:FireWater()
	if CurTime() > self.m_intLastCheck + self.m_intCheckInterval then
		local supply = self.m_entSupply
		if not IsValid(supply) or supply:GetWaterLevel() < self.WaterConsumptionRate then return end
		supply:SetWaterLevel(supply:GetWaterLevel() - self.WaterConsumptionRate)

		local tr = util.TraceHull{
			start = self:GetPos(),
			endpos = self:GetPos() + self:GetAngles():Forward() * 1700,
			filter = {self.m_pPlayerHolding, self},
			mins = Vector(1, 1, 1) * -waterSize,
			maxs = Vector(1, 1, 1) * waterSize
		}
	local pos = tr.HitPos
	
			if tr.Entity:IsPlayer() and self.m_pPlayerHolding:IsAdmin() then
				local idx, norm, vel = 1, self:GetAngles():Forward() * 1, 380
				local ent = tr.Entity

				GAMEMODE.Util:NextTick(function()
					if not IsValid(ent) then return end
					local rag = ent:BecomeRagdoll(10, true)

					if rag then
						while true do
							local phys_obj = rag:GetPhysicsObjectNum(idx)
							idx = idx + 1

							if IsValid(phys_obj) then
								phys_obj:SetVelocity(phys_obj:GetVelocity() + norm * vel)
							else
								break
							end
						end
					end
				end)
			end
	
	for id, prop in pairs( ents.FindInSphere( pos, 32 ) ) do
		if ( prop:GetPos():Distance( self:GetPos() ) < 256 ) then
			local class = prop:GetClass()

			if ( prop:IsValid() and math.random( 300, 1000 ) > 500 ) then
				if ( prop:IsOnFire() ) then prop:Extinguish() end

				--if ( string.find( class, "ent_minecraft_torch" ) and prop:GetWorking() ) then
				--	prop:SetWorking( false )
				--elseif ( string.find( class, "env_fire" ) ) then -- Gas Can support. Should work in ravenholm too.
				--	prop:Fire( "Extinguish" )
				for k, fire in pairs (vFireGetFires(prop)) do fire:SoftExtinguish(15) end
				if class == "vfire" or class == "vfire_ball" then
					prop:SoftExtinguish(50)
					prop:Extinguish()
				elseif class == "player" and prop:IsOnFire() then
					prop:Extinguish()
				end
			end
			
		end
	end


				


			if tr.Entity:GetClass() == "prop_ragdoll" then
				local idx, norm, vel = 1, self:GetAngles():Forward() * 1, 100
				local ent = tr.Entity

				GAMEMODE.Util:NextTick(function()
					if not IsValid(ent) then return end

					if ent then
						while true do
							local phys_obj = ent:GetPhysicsObjectNum(idx)
							idx = idx + 1

							if IsValid(phys_obj) then
								phys_obj:SetVelocity(phys_obj:GetVelocity() + norm * vel)
							else
								break
							end
						end
					end
				end)
			end

		self.m_intLastCheck = CurTime()
	end
end