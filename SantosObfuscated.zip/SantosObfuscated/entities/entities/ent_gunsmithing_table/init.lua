--[[
Original Creators: MazeRP Development Team
Modified and reworked by: GNetRP Development Team
Legal Information: Legal@gnetrp.com
Extra Information: www.gnetrp.com or www.gnetrp.gg | https://discord.gg/2Mnk937aMn | @Tylr#9999 STEAM_0:1:71010553 @Krusty STEAM_0:1:164681911 @Meaty#8863 STEAM_0:1:151895828 | https://github.com/TylrDevs | https://github.com/gnetrp |
]]--

AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
include "shared.lua"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:PhysWake()
end

function ENT:AcceptInput( strName, entActivator, entCaller )
	if not IsValid( entCaller ) or not entCaller:IsPlayer() then return end
	if strName ~= "Use" then return end

	entCaller.m_entUsedCraftingEnt = self
	GAMEMODE.Net:ShowNWMenu( entCaller, "gunsmithing_table" )
end