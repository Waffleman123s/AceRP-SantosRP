--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/props_c17/light_decklight01_off.mdl" )
ENT.ModelOn 		= Model( "models/props_c17/light_decklight01_on.mdl" )

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "On" )
end