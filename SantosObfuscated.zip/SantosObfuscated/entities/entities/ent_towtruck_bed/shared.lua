--[[
	Name: shared.lua
	For: SantosRP
	By: Ultra
]]--

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ""
ENT.Author			= ""
ENT.Purpose			= ""
ENT.Model 			= Model( "models/sentry/flatbed_bed.mdl" )
ENT.SoundStart 		= Sound( "plats/crane/vertical_start.wav" )
ENT.SoundOff 		= Sound( "plats/crane/vertical_stop.wav" )
ENT.SoundWinchLoop 	= Sound( "vehicles/tank_turret_loop1.wav" )
ENT.SoundWinchStart = Sound( "vehicles/tank_turret_start1.wav" )
ENT.SoundWinchStop 	= Sound( "vehicles/tank_turret_stop1.wav" )
ENT.SoundLever 		= Sound( "buttons/lever7.wav" )
ENT.SoundLatch		= Sound( "buttons/latchunlocked2.wav" )
ENT.BlockDrag 		= true

function ENT:SetupDataTables()
end