if SERVER then
	AddCSLuaFile()
end

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = ""
ENT.Author = ""
ENT.Purpose = ""

if SERVER then
	util.AddNetworkString("cctv_view")

	function ENT:Initialize()
		self:SetModel("models/unconid/pc_models/monitors/lcd_ultrawide_curved.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_NONE)
		self:SetUseType(SIMPLE_USE)
	end

	function ENT:SetCop()
		self.IsCop = true
	end

	net.Receive("cctv_view", function(l, p)
		local bool = net.ReadBool()
		p.InCCTV = bool

		if not bool then
			hook.Remove("SetupPlayerVisibility", "ShowCCTV_Stuff" .. p:SteamID())
		end
	end)

	function ENT:Use(a, c)
		if c.InCCTV then return end
		if self.IsCop and c:Team() ~= JOB_POLICE then return end
		local cams = {}

		if self.IsCop then
			cams = GAMEMODE.Module:GetModule("cctv_cameras"):GetCamerasFor(nil, c, true)
		else
			cams = GAMEMODE.Module:GetModule("cctv_cameras"):GetCamerasFor(self.CreatedBy, c, false)
		end

		local sid = c:SteamID()

		hook.Add("SetupPlayerVisibility", "ShowCCTV_Stuff" .. sid, function(pPlayer, pViewEntity)
			if not IsValid(pPlayer) then
				hook.Remove("SetupPlayerVisibility", "ShowCCTV_Stuff" .. sid)

				return
			end

			for k, v in pairs(cams) do
				if IsValid(v) then
					AddOriginToPVS(v:GetPos())
				end
			end

			if IsValid(pViewEntity) then
				AddOriginToPVS(pViewEntity:GetPos())
			end
		end)

		net.Start("cctv_view")
		net.WriteEntity(self)
		net.WriteTable(cams)
		net.Send(c)
		c.CurrentCam = self
		c.UsePos = c:GetPos()
	end
end

if not CLIENT then return end

function ENT:Draw()
	self:DrawModel()
end

local CurrentCamera

local function getfirst(tab)
	for k, v in pairs(tab) do
		return k, v
	end
end

function NextCam(tab)
	local curcam = CurrentCamera.Camera
	local nextid, nextcam = next(tab, CurrentCamera.ID)

	if not nextcam then
		nextid, nextcam = getfirst(tab)
	end

	CurrentCamera = {
		ID = nextid,
		Camera = nextcam
	}

	_GCurrent = CurrentCamera
end

local function getlist(tab)
	local t = {}

	for k, v in pairs(tab) do
		table.insert(t, v)
	end

	return t
end

function PrevCam(tab)
	local curcam = CurrentCamera.Camera
	local list = getlist(tab)
	local check = 1

	for k, v in pairs(list) do
		if v == curcam then
			check = k - 1
		end
	end

	local prevcam = list[check]
	local previd = table.KeyFromValue(tab, prevcam)

	if not prevcam then
		prevcam = list[#list]
		previd = table.KeyFromValue(tab, prevcam)
	end

	CurrentCamera = {
		ID = previd,
		Camera = prevcam
	}

	_GCurrent = CurrentCamera
end

_GCams = {}
_GCurrent = {}
CurrentCamera = {}

net.Receive("cctv_view", function()
	local monitor = net.ReadEntity()
	_GCams = net.ReadTable()
	if table.Count(_GCams) <= 0 then return GAMEMODE.HUD:AddNote("You have no cameras setup to view.", 0, 5) end
	GAMEMODE.HUD:AddNote("Press 'TAB' to exit the viewer.", 0, 5)
	net.Start("cctv_view")
	net.WriteBool(true)
	net.SendToServer()

	for k, v in pairs(_GCams) do
		CurrentCamera = {
			ID = k,
			Camera = v
		}

		break
	end

	if _GCurrent and _GCurrent.Camera then
		CurrentCamera = _GCurrent
	end

	hook.Add("InputMouseApply", "CCTV_Cameras", function(cmd)
		cmd:SetMouseX(0)
		cmd:SetMouseY(0)

		return true
	end)

	hook.Add("CalcView", "CCTV_Cameras", function(ply, pos, angles, fov)
		if not IsValid(CurrentCamera.Camera) then return end -- ??? 
		CurrentCamera.Camera:SetNoDraw(true)
		local view = {}
		view.origin = CurrentCamera.Camera:GetPos()
		view.angles = CurrentCamera.Camera:GetAngles()
		view.fov = fov
		view.drawviewer = true

		return view
	end)

	hook.Add("HUDPaint", "CCTV_Cameras", function()
		surface.SetFont("Trebuchet24")
		local tw, th = surface.GetTextSize("Left Click - Next Camera / Right Click - Previous Camera")
		draw.RoundedBox(0, 122.5, 2.5, tw + 10, th + 5, Color(22, 22, 22, 200))
		draw.SimpleText("Left Click - Next Camera / Right Click - Previous Camera", "Trebuchet24", 125, 5, Color(255, 255, 255))
		local tw, th = surface.GetTextSize("Camera ID " .. CurrentCamera.ID)
		draw.RoundedBox(0, ScrW() / 2 - tw, 2.5, tw + 10, th + 5, Color(22, 22, 22, 200))
		draw.SimpleText("Camera ID " .. CurrentCamera.ID, "Trebuchet24", ScrW() / 2 - tw + 2.5, 2.5, Color(255, 255, 255))
	end)

	local Actioned = 0

	hook.Add("Think", "CCTV_Cameras", function()
		if input.IsKeyDown(KEY_TAB) or not IsValid(monitor) then
			hook.Remove("Think", "CCTV_Cameras")
			hook.Remove("CalcView", "CCTV_Cameras")
			hook.Remove("InputMouseApply", "CCTV_Cameras")
			hook.Remove("HUDPaint", "CCTV_Cameras")

			for k, v in pairs(_GCams) do
				if IsValid(v) then
					v:SetNoDraw(false)
				end
			end

			net.Start("cctv_view")
			net.WriteBool(false)
			net.SendToServer()
		else
			if LocalPlayer():KeyPressed(IN_ATTACK) and (Actioned or 0) < CurTime() then
				Actioned = CurTime() + 0.3
				NextCam(_GCams)
			elseif LocalPlayer():KeyPressed(IN_ATTACK2) and (Actioned or 0) < CurTime() then
				Actioned = CurTime() + 0.3
				PrevCam(_GCams)
			end
		end
	end)
end)