ENT.Type = "anim";
ENT.Base = "base_gmodentity";

ENT.PrintName		= "Mine Base [DO NOT SPAWN]";
ENT.Author			= "xrayhunter";
ENT.Contact			= "OBVIOUSLY XRAYHUNTER....";
ENT.Purpose			= "Um.. it's an mine... what do you think?";
ENT.Instructions	= "*cough*... it's an mine...";
