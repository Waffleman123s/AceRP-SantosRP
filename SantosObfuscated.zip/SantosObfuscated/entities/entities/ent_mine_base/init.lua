include ("shared.lua");
AddCSLuaFile ("shared.lua");
AddCSLuaFile ("cl_init.lua");

local FALLBACK_ITEM = "Mineral Stone";
local MINING_WEAPONS = {"weapon_pickaxe", "cms_drill"};
local CHANCE_OF_EXVATING = 55;
local CHANCE_OF_EXVATING_STONE = 15;
local PULL_STONE_FROM_HEATH = false;

function ENT:Initialize()
	self:SetModel( "models/props_canal/rock_riverbed02c.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )      -- Make us work with physics,
	self:SetMoveType( MOVETYPE_VPHYSICS )   -- after all, gmod is a physics
    self:SetSolid( SOLID_VPHYSICS )         -- Toolbox
    
    self.BlockPhysGun = true
    
    local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
        phys:Wake()
        phys:EnableMotion( false )
    end

    self.maxhealth = 1;

    self:Setup({
        {itemID = "Mineral Iron", amount = math.random(0, 15), rare = 0.35}, 
        {itemID = "Mineral Gold", amount = math.random(0, 6), rare = 0.15}, 
        {itemID = "Mineral Diamond", amount = math.random(0, 4), rare = 0.1},
    });
end

function ENT:OnTakeDamage( dmginfo )
	-- Make sure we're not already applying damage a second time
    -- This prevents infinite loops
    if not IsValid( dmginfo:GetAttacker() ) or not dmginfo:GetAttacker():IsPlayer() or not IsValid( dmginfo:GetAttacker():GetActiveWeapon() ) or not table.HasValue(MINING_WEAPONS, dmginfo:GetAttacker():GetActiveWeapon():GetClass()) then return; end
    
    local item = nil;
    local amount = 0;
    if math.random(0, 100) > math.abs(100 - CHANCE_OF_EXVATING) then
        local index = math.random(0, #self.items);
        if index > 0 and index <= #self.items then
            item = self.items[index].itemID;

            amount = math.ceil(math.random(0, self.items[index].amount) * (self.items[index].rare or 0.25));
            
            if self.items[index].amount > 0 then
                self.items[index].amount = self.items[index].amount - amount;
                if self.items[index].amount <= 0 then
                    table.remove(self.items, index);
                end
            else
                table.remove(self.items, index);
                item = nil;
            end
        end
    end

    if item == nil and math.random(0, 100) > (100 - CHANCE_OF_EXVATING_STONE) then
        item = FALLBACK_ITEM;
        amount = math.random(0, 3);
    
        if PULL_STONE_FROM_HEATH then
            self.maxhealth = self.maxhealth - amount;
        end
    end

    if item ~= nil and amount > 0 then
        dmginfo:GetAttacker():AddNote("You have mined " .. amount .. " " .. item);
        GAMEMODE.Inv:GivePlayerItem( dmginfo:GetAttacker(), item, amount ); -- Santos RP Port...
    end

    local itemCount = 0;
    for k, v in pairs(self.items)do
        if v.amount then
            itemCount = itemCount + v.amount;
        end
    end

    if itemCount <= self.maxhealth / 3 then
        self:SetModel("models/props_canal/rock_riverbed02b.mdl");
        self:DropToFloor();
    elseif itemCount <= self.maxhealth / 2 then
        self:SetModel("models/props_canal/rock_riverbed02a.mdl")
        self:DropToFloor();
    end

    if #self.items <= 0 then
        self:Remove();
        return;
    end

end

function ENT:Setup(items)
    -- item { itemID = "name", amount =  5 }
    self.maxhealth = 0;
    if type(items) == "table" then
        for k, v in pairs(items)do
            if v.itemID ~= nil then continue; end;
            if v.amount == nil then v.amount = 1; end; -- Auto fix...
            v.rare = v.rare or 0.25;
            v.amount = v.amount + (math.floor(math.random(1, 100) * v.rare));
        end
        self.items = items;
        local itemCount = 0;
        for k, v in pairs(self.items)do
            if v.amount then
                itemCount = itemCount + v.amount;
            end
        end
        self.maxhealth = itemCount;
    end

end

function ENT:Think()
    -- We don't need to think, we are just a prop after all!
end