include ("shared.lua");
 
--[[---------------------------------------------------------
   Name: Draw
   Purpose: Draw the model in-game.
   Remember, the things you render first will be underneath!
---------------------------------------------------------]]
function ENT:Draw()
    -- self.BaseClass.Draw(self)  -- We want to override rendering, so don't call baseclass.
    if self:GetPos():Distance( LocalPlayer():GetPos() ) <= 1500 then
        self:DrawModel()       -- Draw the model.
    end
end
