--[[
	Name: weapon_item_fishing_rod.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	AddCSLuaFile()
end

SWEP.RenderGroup = RENDERGROUP_BOTH

SWEP.PrintName		= "Fishing Rod"
SWEP.Author			= "Ultra"
SWEP.Base 			= "weapon_sck_base"
SWEP.Instructions	= "Left click to cast, Right click to reel back in.\nTouch the hook against items to try and bait the hook.\nNot all items work as bait!"

SWEP.ViewModel		= "models/weapons/c_crowbar.mdl"
SWEP.WorldModel		= "models/weapons/w_crowbar.mdl"
SWEP.ViewModelFOV	= 75
SWEP.Slot 			= 2
SWEP.UseHands 		= true

SWEP.HoldType 		= "melee2"
SWEP.ShowWorldModel = false
SWEP.ShowViewModel 	= false
SWEP.Secondary.Automatic = true

SWEP.WElements = {
	["element_name2"] = { type = "Model", model = "models/props_c17/oildrum001.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(4.061, 2.397, -3.507), angle = Angle(0, 0, -90), size = Vector(0.101, 0.101, 0.101), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} },
	["element_name"] = { type = "Model", model = "models/props_c17/signpole001.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(3.375, 1.58, -33.683), angle = Angle(0, 0, 0), size = Vector(0.384, 0.384, 0.384), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}
SWEP.VElements = {
	["element_name2"] = { type = "Model", model = "models/props_c17/oildrum001.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(4.743, 2.256, -3.51), angle = Angle(0, 0, -89.795), size = Vector(0.123, 0.123, 0.123), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} },
	["element_name"] = { type = "Model", model = "models/props_c17/signpole001.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(13.159, 1.363, -45.656), angle = Angle(12.664, -0.064, 0.211), size = Vector(0.5, 0.5, 0.5), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}

function SWEP:SetupDataTables()
	self:NetworkVar( "Entity", 0, "FishHook" )
end

function SWEP:OnRemove()
	if IsValid( self.m_pRope ) then self.m_pRope:Remove() end
	if IsValid( self.m_pConst ) then self.m_pConst:Remove() end
	if IsValid( self.m_entHook ) then self.m_entHook:Remove() end
end

function SWEP:Holster()
	if IsValid( self.m_pRope ) then self.m_pRope:Remove() end
	if IsValid( self.m_pConst ) then self.m_pConst:Remove() end
	if IsValid( self.m_entHook ) then self.m_entHook:Remove() end
	return true
end

function SWEP:Deploy()
	if SERVER and not IsValid( self.m_entHook ) then
		self.m_entHook = ents.Create( "ent_fishhook" )
		self.m_entHook:SetPos( self.Owner:GetShootPos() +self.Owner:GetAimVector() * 40 )
		self.m_entHook:SetOwner( self )
		self.m_entHook:Spawn()
		self.m_entHook:Activate()
		self:SetFishHook( self.m_entHook )

		self.m_intLength = 1
		
		local pRope, pConst = constraint.Elastic( 
			self.Owner, self.m_entHook,  
			0, 0,
			Vector( 0, 0, 64 ), Vector( 0, 0, 0 ),
			80, 60, 25,
			"cable/cable",
			0,
			true
		)

		self.m_entHook:DeleteOnRemove( pRope )
		self.m_pRope = pRope
		self.m_pConst = pConst
	end

	return true
end

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire( CurTime() +5 )
	if CLIENT then return end
	if self.m_intLength > 10 or self.m_entHook:HasCatch() then return end
	
	self.m_intLength = 1000
	self.m_pRope:Fire( "SetSpringLength", self.m_intLength )
	self.m_bApplyHookVel = true

	self.m_sndCast = CreateSound( self.Owner, "santosrp/fishing_throw.mp3" )
	self.m_sndCast:PlayEx( 0.25, 100 )
	
	self.m_entHook.m_intThinkIgnore = CurTime() +math.random(6, 12)
end

function SWEP:SecondaryAttack()
	if CLIENT or not IsValid( self.m_pRope ) or not IsValid( self.m_entHook ) then return end
	if self.m_intLastReel and self.m_intLastReel > CurTime() then return end
	if self.m_intLength <= 1 then return end

	self.m_intLength = math.Clamp( self.m_intLength -10, 1, 750 )
	self.m_pRope:Fire( "SetSpringLength", self.m_intLength )
	
	if self.m_intLength < 20 and not self.m_intCatchDelay then
		local fish = self.m_entHook:GetCatchID()
		
		if fish and fish ~= "" then
			self.m_intCatchDelay = CurTime() +math.random( 4, 7 )
		end
	end
	
	if not self.m_sndReel then
		self.m_sndReel = CreateSound( self.Owner, "santosrp/fishing_reel.mp3" )
		self.m_sndReel:Play()
	end
	self.m_intLastReel = CurTime() +0.1
end

function SWEP:Think()
	if CLIENT then return end
	
	if IsValid( self.m_entHook ) then
		if self.m_bApplyHookVel then
			self.m_entHook:GetPhysicsObject():SetVelocity( (self.Owner:GetAimVector() *2 +vector_up /2) *1000 )
			self.m_entHook:PhysWake()
			self.m_bApplyHookVel = false
		else
			if self.m_entHook:GetVelocity():Length() < 10 and self.m_sndCast then
				self.m_sndCast:Stop()
			end
		end

		if self.m_sndReel and self.m_intLastReel < CurTime() -0.1 then
			self.m_sndReel:Stop()
			self.m_sndReel = nil
		end
		
		if self.m_intLength < 20 then
			if self.m_intCatchDelay and CurTime() > self.m_intCatchDelay then
				local fish = self.m_entHook:GetCatchID()
				
				if fish and fish ~= "" then
					if not GAMEMODE.Inv:GivePlayerItem( self.Owner, fish, 1 ) then
						GAMEMODE.Inv:MakeItemDrop( self.Owner, fish, 1 )
					end

					self.m_entHook:SetCatchID( "" )
					GAMEMODE.Skills:GivePlayerXP( self.Owner, "Fishing", GAMEMODE.Inv:GetItem(fish).FishingData.GiveXP )
				end
				self.m_intCatchDelay = nil
			end
		end
	end
end

if SERVER then return end
local WOffPos = Vector( 3, 0, -20 )
local WOffAng = Angle( -90, 0, 0 )
local UpAng = Vector( 0, 0, 1 ):Angle()
local Mat = CreateMaterial( "fishLine", "VertexLitGeneric", {
	["$basetexture"] = "color/black",
	["$vertexcolor"] = "1",
} )

function SWEP:DrawWorldModelTranslucent()
	if not IsValid( self.Owner ) then self:DrawModel() return end
	local id = self.Owner:LookupBone( "ValveBiped.Bip01_R_Hand" )
	if not id then return end

	local entHook = self:GetFishHook()
	if IsValid( entHook ) then
		local pos, ang 	= self.Owner:GetBonePosition( id )
		local Rop = WOffPos *1
		local Roa = ang *1
		
		Roa:RotateAroundAxis( ang:Right(), WOffAng.p )
		Roa:RotateAroundAxis( ang:Forward(), WOffAng.r )
		Roa:RotateAroundAxis( ang:Up(), WOffAng.y )
		Rop:Rotate( ang )

		local Upp = entHook:GetUp()
		local BobPos = entHook:GetPos() +Upp *5 -entHook:GetRight() *1
		
		local data = self.WElements["element_name"]
		local mdl = self.WElements["element_name"].modelEnt
		local Pos2
		if not mdl then
			Pos2 = self:GetPos() +Roa:Forward() *40 +Roa:Up() *40
		else
			local posb, angb = self:GetBoneOrientation( self.WElements, self.WElements["element_name"], self )
			Pos2 = posb + angb:Forward() *1 +angb:Right() *0.5 +angb:Up() *-32
		end
		self:SetRenderBoundsWS( BobPos, Pos2 )
	
		local Curve = nil
		if EyePos():Distance( self:GetPos() ) > GAMEMODE.Config.RenderDist_Level1 then	
			Curve = GAMEMODE.Util:BezierCurve( BobPos, Upp:Angle(), Pos2, -UpAng, 20, 3 )
		else
			Curve = GAMEMODE.Util:BezierCurve( BobPos, Upp:Angle(), Pos2, -UpAng, 20, 16 )
		end
		
		render.SetMaterial( Mat )
		GAMEMODE.Util:CurveToMesh( Curve, 0.5, 3 )
	end
end

function SWEP:ViewModelDrawn()
	self.BaseClass.ViewModelDrawn( self )
	if not IsValid( self.Owner ) then self:DrawModel() return end
	local id = self.Owner:LookupBone( "ValveBiped.Bip01_R_Hand" )
	if not id then return end

	local entHook = self:GetFishHook()
	if IsValid( entHook ) then
		local pos, ang 	= self.Owner:GetBonePosition( id )
		local Rop = WOffPos *1
		local Roa = ang *1
		
		Roa:RotateAroundAxis( ang:Right(), WOffAng.p )
		Roa:RotateAroundAxis( ang:Forward(), WOffAng.r )
		Roa:RotateAroundAxis( ang:Up(), WOffAng.y )
		Rop:Rotate( ang )

		local Upp = entHook:GetUp()
		local BobPos = entHook:GetPos() +Upp *5 -entHook:GetRight() *1
		
		local data = self.VElements["element_name"]
		local mdl = self.VElements["element_name"].modelEnt
		local Pos2
		if not mdl then
			Pos2 = self:GetPos() +Roa:Forward() *40 +Roa:Up() *40
		else
			local posb, angb = self:GetBoneOrientation( self.VElements, self.VElements["element_name"], self.Owner:GetViewModel() )
			Pos2 = posb + angb:Forward() *13 +angb:Right() *1.5 +angb:Up() *-45
		end
		self:SetRenderBoundsWS( BobPos, Pos2 )
	
		local Curve = nil
		if EyePos():Distance( self:GetPos() ) > GAMEMODE.Config.RenderDist_Level1 then	
			Curve = GAMEMODE.Util:BezierCurve( BobPos, Upp:Angle(), Pos2, -UpAng, 20, 3 )
		else
			Curve = GAMEMODE.Util:BezierCurve( BobPos, Upp:Angle(), Pos2, -UpAng, 20, 16 )
		end
		
		render.SetMaterial( Mat )
		GAMEMODE.Util:CurveToMesh( Curve, 0.5, 3 )
	end
end