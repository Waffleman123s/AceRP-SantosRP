--[[
	Name: sh_medadmissions.lua
	For: SantosRP 
	By: Ultra
]]--

local App = {}
App.Name = "Admissions"
App.ID = "admissions.exe"
App.Panel = "SRPComputer_AppWindow_MedAdmissions"
App.Icon = "santosrp/computer/srp_admission_icon.png"
App.DekstopIcon = true
App.StartMenuIcon = true

GM.Apps:Register( App )

if SERVER then return end

local Panel = {}
function Panel:Init()
	self.m_pnlLabel = vgui3D.Create( "DLabel", self )
	self.m_pnlLabel:SetText( "No exam data available! Use the clipboard to record\npatient records before using this application." )
	self.m_pnlLabel:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabel:SetFont( "Trebuchet18" )
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlLabel:SizeToContents()
	self.m_pnlLabel:Center()
end
vgui.Register( "SRPComputer_AppWindow_MedAdmissions_NoData", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self.m_pnlAvatar = vgui3D.Create( "SRP_AvatarImg", self )
	self.m_pnlAvatar:SetSize( 32, 32 )
	
	self.m_pnlLabelName = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelName:SetText( "PlayerName" )
	self.m_pnlLabelName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelName:SetFont( "Trebuchet18" )
	
	self.m_pnlLabelOverview = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelOverview:SetText( "Patient condition at time of admission:" )
	self.m_pnlLabelOverview:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelOverview:SetFont( "Trebuchet18" )

	self.m_pnlLabelNotes = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelNotes:SetText( "Doctors Notes:" )
	self.m_pnlLabelNotes:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelNotes:SetFont( "Trebuchet18" )
	
	self.m_pnlNoteText = vgui3D.Create( "SRPPhone_TextEntry", self )
	self.m_pnlNoteText:SetMultiline( false )
	self.m_pnlNoteText:SetFont( "SRPTextMessageFontSmall" )
	self.m_pnlNoteText.PerformLayout = DTextEntry.PerformLayout
	self.m_pnlNoteText:SetMultiline( true )
	self.m_pnlNoteText:SetRoot( self:GetParent():GetParent():GetDesktop() )
	function self.m_pnlNoteText:AllowInput( val )
		if self:GetText():len() >= GAMEMODE.Config.MaxEMSNoteLen then
			return true
		end

		if val == "\\" then return true end
	end

	function self.m_pnlNoteText:OnKeyCodeTyped( intKey )
		local lines = string.Explode( "\n", self:GetValue() )
		if #lines +1 > 16 and intKey == KEY_ENTER then
			return true
		end
	end

	function self.m_pnlNoteText.OnChange( this )
	end

	self.m_pnlLabelDone = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelDone:SetText( "Patient Bill $%s" )
	self.m_pnlLabelDone:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelDone:SetFont( "Trebuchet18" )
	
	self.m_pnlBtnDischarge = vgui3D.Create( "DButton", self )
	self.m_pnlBtnDischarge:SetText( "Bill And Discharge Patient" )
	self.m_pnlBtnDischarge:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnDischarge:SetFont( "Trebuchet18" )
	self.m_pnlBtnDischarge.DoClick = function()
		GAMEMODE.Net:SendEMSBillRequest( self.m_pnlNoteText:GetValue() or "" )
	end
end

function Panel:SetData( tblData )
	self.m_tblData = tblData
	
	if not IsValid( tblData.player ) then return end
	self.m_pnlAvatar:SetPlayer( tblData.player )
	self.m_pnlLabelName:SetText( tblData.player:Nick() )

	local pay = GAMEMODE.Jobs:GetJobByID( JOB_EMS ):CalcHealPay( tblData )
	self.m_pnlLabelDone:SetText( ("Patient Bill $%s"):format(string.Comma(pay)) )
end

function Panel:DrawBar( intX, intY, intW, intH, intNum, intMax )
	surface.SetDrawColor( 0, 0, 0, 125 )
	surface.DrawRect( intX, intY, intW, intH )

	local scalar = 1 -((intMax -intNum) /intMax)
	surface.SetDrawColor( 255, 50, 50, 255 )
	surface.DrawRect( intX +1, intY +1, (intW -2) *scalar, intH -2 )

	draw.SimpleTextOutlined(
		intNum.. "/".. intMax.. "HP",
		"Trebuchet18",
		intX +(intW /2), intY,
		color_white,
		TEXT_ALIGN_CENTER,
		TEXT_ALIGN_TOP,
		2,
		color_black
	)
end

local MAT_BLEED = Material( "santosrp/ae_icons/Heavy Bleeding 48x48.png", "smooth" )
local MAT_BROKEN = Material( "santosrp/ae_icons/Broken Leg(s) 48x48.png", "smooth" )
function Panel:Paint( intW, intH )
	surface.SetDrawColor( 50, 50, 50, 150 )
	surface.DrawRect( 32 +5, 5 +16 -8, intW -10 -32 -5, 16 )
	
	surface.SetDrawColor( 0, 0, 0, 250 )
	surface.DrawRect( 5, 5, 32, 32 )
	
	local done = {}
	local barWide = 120
	local wide = 230
	local y = 32 +15 +self.m_pnlLabelOverview:GetTall()
	local x = 5
	
	draw.SimpleText(
		"Health",
		"Trebuchet18",
		x,
		y +2,
		color_white,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_TOP
	)

	self:DrawBar( wide -barWide -5, y +2, barWide, 18, self.m_tblData.health, 100 )
	y = y +21 +4
	surface.SetDrawColor( 0, 0, 0, 255 )
	surface.DrawRect( x, y -2, wide -(x *2), 1 )


	for k, v in pairs( self.m_tblData.limbs ) do
		if not GAMEMODE.PlayerDamage:GetLimbs()[k] then continue end
		if done[GAMEMODE.PlayerDamage:GetLimbs()[k].Name] then continue end
		done[GAMEMODE.PlayerDamage:GetLimbs()[k].Name] = true

		draw.SimpleText(
			GAMEMODE.PlayerDamage:GetLimbs()[k].Name,
			"Trebuchet18",
			x,
			y +2,
			color_white,
			TEXT_ALIGN_LEFT,
			TEXT_ALIGN_TOP
		)

		self:DrawBar( wide -barWide -5, y +2, barWide, 18, v.Health, GAMEMODE.PlayerDamage:GetLimbs()[k].MaxHealth )
				
		local isBroken = v.Broken
		local isBleeding = v.Bleeding
		if isBroken or isBleeding then
			local xi = x
			if isBroken then
				surface.SetMaterial( MAT_BROKEN )
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawTexturedRect( xi, y +20, 24, 24 )

				draw.SimpleText(
					"Broken!",
					"Trebuchet18",
					xi +32 +2, y +24,
					color_white,
					TEXT_ALIGN_LEFT,
					TEXT_ALIGN_TOP
				)

				local a, b = surface.GetTextSize( "Broken!" )
				xi = xi +32 +2 +a +10
			end

			if isBleeding then
				surface.SetMaterial( MAT_BLEED )
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawTexturedRect( xi, y +20, 24, 24 )

				draw.SimpleText(
					"Bleeding!",
					"Trebuchet18",
					xi +32 +2, y +24,
					color_white,
					TEXT_ALIGN_LEFT,
					TEXT_ALIGN_TOP
				)

				local a, b = surface.GetTextSize( "Bleeding!" )
				xi = xi +32 +2 +a +10
			end
			
			y = y +24 +2
		end

		y = y +21 +2
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawRect( x, y -1, wide -(x *2), 1 )
	end
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlAvatar:SetSize( 32, 32 )
	self.m_pnlAvatar:SetPos( 5, 5 )
	
	self.m_pnlLabelName:SizeToContents()
	self.m_pnlLabelName:SetPos( 32 +10, 5 +16 -(self.m_pnlLabelName:GetTall() /2) )
	
	self.m_pnlLabelOverview:SizeToContents()
	self.m_pnlLabelOverview:SetPos( 5, 10 +32 )

	self.m_pnlNoteText:SetSize( intW -self.m_pnlLabelOverview:GetWide() -15, intH -15 -self.m_pnlLabelOverview:GetTall() -32 )
	self.m_pnlNoteText:SetPos( 10 +self.m_pnlLabelOverview:GetWide(), 10 +self.m_pnlLabelOverview:GetTall() +32 )
	
	self.m_pnlLabelNotes:SizeToContents()
	self.m_pnlLabelNotes:SetPos( intW -5 -(self.m_pnlNoteText:GetWide() /2) -(self.m_pnlLabelNotes:GetWide() /2), 10 +32 )
	
	self.m_pnlBtnDischarge:SetSize( 220, 20 )
	self.m_pnlBtnDischarge:SetPos( 5, intH -5 -self.m_pnlBtnDischarge:GetTall() )
	
	self.m_pnlLabelDone:SizeToContents()
	self.m_pnlLabelDone:SetPos( 10, intH -5 -self.m_pnlBtnDischarge:GetTall() -self.m_pnlLabelDone:GetTall() )
end
vgui.Register( "SRPComputer_AppWindow_MedAdmissions_Form", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self:GetParent():SetTitle( App.Name )
	self:GetParent():SetSize( 600, 460 )
	self:GetParent():SetPos( 100, 25 )
	self:GetParent():RequestFocus()
	self:GetParent():MoveToFront()

	hook.Add( "GamemodeOnGetEMSClipboardData", "MedAdmissionsRefresh", function( tblData )
		if not self or not ValidPanel( self ) then return end
		if tblData and not IsValid( tblData.player ) then return end
		self:Refresh( tblData )
	end )

	self:Refresh( g_LastEMSClipData )
end

function Panel:Refresh( tblData )
	if self.m_pnlWindow and ValidPanel( self.m_pnlWindow ) then
		self.m_pnlWindow:Remove()
	end

	self.m_tblData = tblData

	if tblData then
		self.m_pnlWindow = vgui3D.Create( "SRPComputer_AppWindow_MedAdmissions_Form", self )
		self.m_pnlWindow:SetData( tblData )
	else
		self.m_pnlWindow = vgui3D.Create( "SRPComputer_AppWindow_MedAdmissions_NoData", self )
	end

	self:InvalidateLayout()
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlWindow:SetPos( 0, 0 )
	self.m_pnlWindow:SetSize( intW, intH )
end
vgui.Register( "SRPComputer_AppWindow_MedAdmissions", Panel, "EditablePanel" )