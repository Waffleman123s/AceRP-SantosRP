--[[
	Name: sh_meddb.lua
	For: SantosRP
	By: Ultra
]]--

local App = {}
App.Name = "Medical DB"
App.ID = "meddb.exe"
App.Panel = "SRPComputer_AppWindow_MedDB"
App.Icon = "santosrp/computer/srp_db_icon_new.png"
App.DekstopIcon = true
App.StartMenuIcon = true

GM.Apps:Register( App )

if SERVER then return end

local Panel = {}
function Panel:Init()
	self.m_intBarWide = 120
end

function Panel:SetData( tblData )
	self.m_tblData = tblData
end

function Panel:SetBarWide( intW )
	self.m_intBarWide = intW
end

function Panel:DrawBar( intX, intY, intW, intH, intNum, intMax )
	surface.SetDrawColor( 0, 0, 0, 125 )
	surface.DrawRect( intX, intY, intW, intH )

	local scalar = 1 -((intMax -intNum) /intMax)
	surface.SetDrawColor( 255, 50, 50, 255 )
	surface.DrawRect( intX +1, intY +1, (intW -2) *scalar, intH -2 )

	draw.SimpleTextOutlined(
		intNum.. "/".. intMax.. "HP",
		"Trebuchet18",
		intX +(intW /2), intY,
		color_white,
		TEXT_ALIGN_CENTER,
		TEXT_ALIGN_TOP,
		2,
		color_black
	)
end

local MAT_BLEED = Material( "santosrp/ae_icons/Heavy Bleeding 48x48.png", "smooth" )
local MAT_BROKEN = Material( "santosrp/ae_icons/Broken Leg(s) 48x48.png", "smooth" )
function Panel:Paint( intW, intH )
	if not self.m_tblData or not self.m_tblData.clipdata then return end
	
	local data = self.m_tblData.clipdata
	local done = {}
	local barWide = self.m_intBarWide
	local wide = self:GetWide()
	local y = 0
	local x = 5

	draw.SimpleText(
		"Condition at admission:",
		"Trebuchet18",
		x,
		y +2,
		color_white,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_TOP
	)
	y = y +20

	draw.SimpleText(
		"Health",
		"Trebuchet18",
		x,
		y +2,
		color_white,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_TOP
	)

	self:DrawBar( wide -barWide -5, y +2, barWide, 18, data.health, 100 )
	y = y +21 +4
	surface.SetDrawColor( 0, 0, 0, 255 )
	surface.DrawRect( x, y -2, wide -(x *2), 1 )

	for k, v in pairs( data.limbs ) do
		if not GAMEMODE.PlayerDamage:GetLimbs()[k] then continue end
		if done[GAMEMODE.PlayerDamage:GetLimbs()[k].Name] then continue end
		done[GAMEMODE.PlayerDamage:GetLimbs()[k].Name] = true

		draw.SimpleText(
			GAMEMODE.PlayerDamage:GetLimbs()[k].Name,
			"Trebuchet18",
			x,
			y +2,
			color_white,
			TEXT_ALIGN_LEFT,
			TEXT_ALIGN_TOP
		)

		self:DrawBar( wide -barWide -5, y +2, barWide, 18, v.health, GAMEMODE.PlayerDamage:GetLimbs()[k].MaxHealth )
				
		local isBroken = v.broken
		local isBleeding = v.bleeding
		if isBroken or isBleeding then
			local xi = x
			if isBroken then
				surface.SetMaterial( MAT_BROKEN )
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawTexturedRect( xi, y +20, 24, 24 )

				draw.SimpleText(
					"Broken!",
					"Trebuchet18",
					xi +32 +2, y +24,
					color_white,
					TEXT_ALIGN_LEFT,
					TEXT_ALIGN_TOP
				)

				local a, b = surface.GetTextSize( "Broken!" )
				xi = xi +32 +2 +a +10
			end

			if isBleeding then
				surface.SetMaterial( MAT_BLEED )
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawTexturedRect( xi, y +20, 24, 24 )

				draw.SimpleText(
					"Bleeding!",
					"Trebuchet18",
					xi +32 +2, y +24,
					color_white,
					TEXT_ALIGN_LEFT,
					TEXT_ALIGN_TOP
				)

				local a, b = surface.GetTextSize( "Bleeding!" )
				xi = xi +32 +2 +a +10
			end
			
			y = y +24 +2
		end

		y = y +21 +2
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawRect( x, y -1, wide -(x *2), 1 )
	end
end

function Panel:PerformLayout( intW, intH )
end
vgui.Register( "SRPComputer_AppWindow_MedDB_MedRecord", Panel, "EditablePanel" )

local function FindPlayerByName( strName )
	if strName == "" then return end
	for k, v in pairs( player.GetAll() ) do
		if v:Nick():lower():Trim():match( strName:lower():Trim() ) then
			return v
		end
	end
end

local function FindPlayerByLicenseID( strID )
	if strID == "" then return end
	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Player:GetSharedGameVar( v, "driver_license", "" ) == "" then continue end
		if GAMEMODE.Player:GetSharedGameVar( v, "driver_license", "" ):lower():Trim() == strID:lower():Trim() then
			return v
		end
	end
end

local Panel = {}
function Panel:Init()
	self.m_pnlNameLabel = vgui3D.Create( "DLabel", self )
	self.m_pnlNameLabel:SetTextColor( color_white )
	self.m_pnlNameLabel:SetFont( "Trebuchet18" )
	self.m_pnlNameLabel:SetText( "Search By Name" )

	self.m_pnlNameText = vgui3D.Create( "SRPPhone_TextEntry", self )
	self.m_pnlNameText:SetMultiline( false )
	self.m_pnlNameText:SetFont( "SRPTextMessageFontSmall" )
	self.m_pnlNameText.PerformLayout = DTextEntry.PerformLayout
	self.m_pnlNameText:SetRoot( self:GetParent():GetParent():GetDesktop() )

	self.m_pnlBtnSearchName = vgui3D.Create( "DButton", self )
	self.m_pnlBtnSearchName:SetText( "Search" )
	self.m_pnlBtnSearchName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnSearchName:SetFont( "Trebuchet18" )
	self.m_pnlBtnSearchName.DoClick = function()
		local pl = FindPlayerByName( self.m_pnlNameText:GetValue() or "" )
		if not IsValid( pl ) then return end
		GAMEMODE.Net:SendEMSRecordRequest( pl )
	end

	self.m_pnlIDLabel = vgui3D.Create( "DLabel", self )
	self.m_pnlIDLabel:SetTextColor( color_white )
	self.m_pnlIDLabel:SetFont( "Trebuchet18" )
	self.m_pnlIDLabel:SetText( "Search By License ID" )

	self.m_pnlIDText = vgui3D.Create( "SRPPhone_TextEntry", self )
	self.m_pnlIDText:SetMultiline( false )
	self.m_pnlIDText:SetFont( "SRPTextMessageFontSmall" )
	self.m_pnlIDText.PerformLayout = DTextEntry.PerformLayout
	self.m_pnlIDText:SetRoot( self:GetParent():GetParent():GetDesktop() )

	self.m_pnlBtnSearchID = vgui3D.Create( "DButton", self )
	self.m_pnlBtnSearchID:SetText( "Search" )
	self.m_pnlBtnSearchID:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnSearchID:SetFont( "Trebuchet18" )
	self.m_pnlBtnSearchID.DoClick = function()
		local pl = FindPlayerByLicenseID( self.m_pnlIDText:GetValue() or "" )
		if not IsValid( pl ) then return end
		GAMEMODE.Net:SendEMSRecordRequest( pl )
	end
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlNameLabel:SizeToContents()
	self.m_pnlIDLabel:SizeToContents()

	self.m_pnlNameText:SetSize( 350, 20 )
	self.m_pnlIDText:SetSize( 350, 20 )

	self.m_pnlBtnSearchName:SetSize( 45, 20 )
	self.m_pnlBtnSearchID:SetSize( 45, 20 )

	local yOffset = math.min( self.m_pnlNameLabel:GetTall() +self.m_pnlNameText:GetTall() +5 +2.5, intH /2 )

	local y = (intH /2) -yOffset
	self.m_pnlNameLabel:SetPos( (intW /2) -(self.m_pnlNameLabel:GetWide() /2), y )
	y = y +self.m_pnlNameLabel:GetTall() +5

	self.m_pnlNameText:SetPos( (intW /2) -((self.m_pnlNameText:GetWide() +self.m_pnlBtnSearchName:GetWide()) /2), y )
	y = y +self.m_pnlNameText:GetTall() +5

	local x, y2 = self.m_pnlNameText:GetPos()
	self.m_pnlBtnSearchName:SetPos( x +self.m_pnlNameText:GetWide(), y2 )

	self.m_pnlIDLabel:SetPos( (intW /2) -(self.m_pnlIDLabel:GetWide() /2), y )
	y = y +self.m_pnlIDLabel:GetTall() +5

	self.m_pnlIDText:SetPos( (intW /2) -((self.m_pnlIDText:GetWide() +self.m_pnlBtnSearchID:GetWide())/2), y )

	x, y2 = self.m_pnlIDText:GetPos()
	self.m_pnlBtnSearchID:SetPos( x +self.m_pnlIDText:GetWide(), y2 )
end
vgui.Register( "SRPComputer_AppWindow_MedDB_Search", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self:SetText( " " )
	self.m_pnlLabelName = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelName:SetText( "RecordName" )
	self.m_pnlLabelName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelName:SetFont( "Trebuchet18" )
end

function Panel:SetData( tblData )
	self.m_tblData = tblData
	self.m_pnlLabelName:SetText( ("Doctor: %s - %s"):format(
		tblData.doctor_name,
		os.date("%X - %m/%d/%Y", tblData.time)
	) )
end

function Panel:DoClick()
	self:GetParent():GetParent():GetParent():ShowRecord( self.m_tblData )
end

function Panel:Paint( intW, intH )
	if self.Hovered then
		surface.SetDrawColor( 50, 50, 50, 120 )
	else
		surface.SetDrawColor( 10, 10, 10, 120 )
	end	
	surface.DrawRect( 0, 0, intW, intH )
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlLabelName:SizeToContents()
	self.m_pnlLabelName:SetPos( 5, (intH /2) -(self.m_pnlLabelName:GetTall() /2) )
end
vgui.Register( "SRPComputer_AppWindow_MedDB_Card", Panel, "DLabel" )


local Panel = {}
function Panel:Init()
	self.m_pnlContainer = vgui3D.Create( "SRPComputer_ScrollPanel", self )

	self.m_pnlBtnBack = vgui3D.Create( "DButton", self.m_pnlContainer )
	self.m_pnlBtnBack:SetText( "Back" )
	self.m_pnlBtnBack:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnBack:SetFont( "Trebuchet18" )
	self.m_pnlBtnBack.DoClick = function()
		self:GetParent():ShowCards()
	end
	self.m_pnlContainer:AddItem( self.m_pnlBtnBack )

	self.m_pnlLabelName = vgui3D.Create( "DLabel", self.m_pnlContainer )
	self.m_pnlLabelName:SetText( "RecordName" )
	self.m_pnlLabelName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelName:SetFont( "Trebuchet18" )
	self.m_pnlContainer:AddItem( self.m_pnlLabelName )

	self.m_pnlLabelDate = vgui3D.Create( "DLabel", self.m_pnlContainer )
	self.m_pnlLabelDate:SetText( "RecordDate" )
	self.m_pnlLabelDate:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelDate:SetFont( "Trebuchet18" )
	self.m_pnlContainer:AddItem( self.m_pnlLabelDate )

	self.m_pnlLabelNotes = vgui3D.Create( "DLabel", self.m_pnlContainer )
	self.m_pnlLabelNotes:SetText( "RecordNotes" )
	self.m_pnlLabelNotes:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelNotes:SetFont( "Trebuchet18" )
	self.m_pnlLabelNotes:SetWrap( true )
	self.m_pnlContainer:AddItem( self.m_pnlLabelNotes )

	self.m_pnlLabelCost = vgui3D.Create( "DLabel", self.m_pnlContainer )
	self.m_pnlLabelCost:SetText( "RecordCost" )
	self.m_pnlLabelCost:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelCost:SetFont( "Trebuchet18" )
	self.m_pnlContainer:AddItem( self.m_pnlLabelCost )

	self.m_pnlMedView = vgui3D.Create( "SRPComputer_AppWindow_MedDB_MedRecord", self.m_pnlContainer )
	self.m_pnlContainer:AddItem( self.m_pnlMedView )
end

function Panel:SetData( tblData )
	self.m_tblData = tblData

	self.m_pnlLabelName:SetText( "Doctor: ".. tblData.doctor_name )
	self.m_pnlLabelDate:SetText( "Date: ".. os.date("%X - %m/%d/%Y", tblData.time) )

	self.m_pnlLabelNotes:SetText( "Notes:\n".. tblData.notes:Replace("\\n", "\n") )

	local suffix = (self.m_tblFullData and tblData.uid and self.m_tblFullData.bills[tblData.uid]) and "UNPAID" or "PAID"
	self.m_pnlLabelCost:SetText( "Cost: $".. string.Comma(tblData.charge).. "    ".. suffix )
	self.m_pnlMedView:SetData( tblData )
	self:InvalidateLayout()
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlContainer:SetPos( 0, 0 )
	self.m_pnlContainer:SetSize( intW, intH )
	
	self.m_pnlLabelName:SizeToContents()
	self.m_pnlLabelDate:SizeToContents()
	self.m_pnlLabelCost:SizeToContents()

	self.m_pnlBtnBack:SetSize( 45, 20 )
	self.m_pnlBtnBack:SetPos( intW -55, 5 )

	local y = 5
	self.m_pnlLabelName:SetPos( 5, y )
	y = y +self.m_pnlLabelName:GetTall() +5

	self.m_pnlLabelDate:SetPos( 5, y )
	y = y +self.m_pnlLabelDate:GetTall() +5

	self.m_pnlLabelCost:SetPos( 5, y )
	y = y +self.m_pnlLabelCost:GetTall()

	self.m_pnlMedView:SetSize( 230, 400 )
	self.m_pnlMedView:SetPos( 5, y )
	y = y +3
	
	self.m_pnlLabelNotes:SetPos( 10 +230, y )
	self.m_pnlLabelNotes:SetWide( intW -(240) )
	self.m_pnlLabelNotes:SizeToContentsY()
	y = y +self.m_pnlLabelNotes:GetTall() +5
end
vgui.Register( "SRPComputer_AppWindow_MedDB_ViewRecord", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self.m_pnlBtnBack = vgui3D.Create( "DButton", self )
	self.m_pnlBtnBack:SetText( "Back" )
	self.m_pnlBtnBack:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnBack:SetFont( "Trebuchet18" )
	self.m_pnlBtnBack.DoClick = function()
		self:GetParent():ShowSearch()
	end

	self.m_pnlAvatar = vgui3D.Create( "SRP_AvatarImg", self )
	self.m_pnlAvatar:SetSize( 32, 32 )
	
	self.m_pnlLabelName = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelName:SetText( "PlayerName" )
	self.m_pnlLabelName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelName:SetFont( "Trebuchet18" )

	self.m_pnlLabelUnpaid = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelUnpaid:SetText( "PlayerBillTotal" )
	self.m_pnlLabelUnpaid:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelUnpaid:SetFont( "Trebuchet18" )

	self.m_pnlCardContainer = vgui3D.Create( "SRPComputer_ScrollPanel", self )
	self.m_tblCards = {}

	self.m_pnlRecordContainer = vgui3D.Create( "SRPComputer_AppWindow_MedDB_ViewRecord", self )
	self.m_pnlRecordContainer:SetVisible( false )
end

function Panel:ShowCards()
	self.m_pnlCardContainer:SetVisible( true )
	self.m_pnlRecordContainer:SetVisible( false )
	self.m_pnlCardContainer:MoveToFront()
end

function Panel:ShowRecord( tblData )
	self.m_pnlRecordContainer:InvalidateLayout( true )
	self.m_pnlCardContainer:SetVisible( false )
	self.m_pnlRecordContainer:SetVisible( true )
	self.m_pnlRecordContainer:SetData( tblData )
	self.m_pnlRecordContainer:MoveToFront()
end

function Panel:Refresh( pPlayer, tblData )
	if not IsValid( pPlayer ) then return end
	for k, v in pairs( self.m_tblCards ) do
		if ValidPanel( v ) then v:Remove() end
	end

	self.m_tblData = tblData
	self.m_pnlRecordContainer.m_tblFullData = tblData

	self.m_tblCards = {}
	
	self.m_pnlAvatar:SetPlayer( pPlayer )
	self.m_pnlLabelName:SetText( ("%s - Medical Records"):format(pPlayer:Nick()) )
	self.m_pnlLabelUnpaid:SetText( ("Total Expenses Due: $%s"):format(string.Comma(tblData.totalUnpaid)) )

	for k, v in pairs( tblData.records ) do
		local card = vgui3D.Create( "SRPComputer_AppWindow_MedDB_Card", self.m_pnlCardContainer )
		card:SetData( v )
		self.m_pnlCardContainer:AddItem( card )
		table.insert( self.m_tblCards, card )
	end
end

function Panel:Paint( intW, intH )
	surface.SetDrawColor( 50, 50, 50, 150 )
	surface.DrawRect( 32 +5, 5 +16 -8, intW -10 -32 -5, 16 )

	surface.SetDrawColor( 0, 0, 0, 250 )
	surface.DrawRect( 5, 5, 32, 32 )
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlAvatar:SetPos( 5, 5 )
	self.m_pnlAvatar:SetSize( 32, 32 )

	self.m_pnlLabelName:SizeToContents()
	self.m_pnlLabelName:SetPos( 32 +10, 5 +16 -(self.m_pnlLabelName:GetTall() /2) )

	self.m_pnlBtnBack:SetSize( 45, 16 )
	self.m_pnlBtnBack:SetPos( intW -50, 5 +16 -(self.m_pnlBtnBack:GetTall() /2) )

	self.m_pnlLabelUnpaid:SizeToContents()
	self.m_pnlLabelUnpaid:SetPos( intW -self.m_pnlLabelUnpaid:GetWide() -10 -self.m_pnlBtnBack:GetWide(),  5 +16 -(self.m_pnlLabelUnpaid:GetTall() /2) )

	
	self.m_pnlCardContainer:SetPos( 5, 32 +10 )
	self.m_pnlCardContainer:SetSize( intW -10, intH -15 -32 )

	self.m_pnlRecordContainer:SetPos( 5, 32 +10 )
	self.m_pnlRecordContainer:SetSize( intW -10, intH -15 -32 )

	for k, v in pairs( self.m_tblCards ) do
		v:DockMargin( 0, 0, 0, 5 )
		v:SetTall( 24 )
		v:Dock( TOP )
	end
end
vgui.Register( "SRPComputer_AppWindow_MedDB_View", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self:GetParent():SetTitle( App.Name )
	self:GetParent():SetSize( 500, 425 )
	self:GetParent():SetPos( 100, 25 )
	self:GetParent():RequestFocus()
	self:GetParent():MoveToFront()

	self.m_pnlWindow = vgui3D.Create( "SRPComputer_AppWindow_MedDB_Search", self )
	self.m_pnlView = vgui3D.Create( "SRPComputer_AppWindow_MedDB_View", self )
	self:ShowSearch()

	hook.Add( "GamemodeOnGetEMSMedicalRecords", "EMSMedDBApp", function( pPlayer, tblData )
		if not self or not ValidPanel( self ) then return end
		self:ShowView( pPlayer, tblData )
	end )
end

function Panel:ShowSearch()
	self.m_pnlView:ShowCards()
	self.m_pnlWindow:SetVisible( true )
	self.m_pnlView:SetVisible( false )
	self.m_pnlWindow:MoveToFront()
end

function Panel:ShowView( pPlayer, tblData )
	self.m_pnlView:Refresh( pPlayer, tblData )
	self.m_pnlWindow:SetVisible( false )
	self.m_pnlView:SetVisible( true )
	self.m_pnlView:MoveToFront()
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlWindow:SetPos( 0, 0 )
	self.m_pnlWindow:SetSize( intW, intH )

	self.m_pnlView:SetPos( 0, 0 )
	self.m_pnlView:SetSize( intW, intH )
end
vgui.Register( "SRPComputer_AppWindow_MedDB", Panel, "EditablePanel" )