--[[
	Name: sh_cop_impound.lua
	For: SantosRP
	By: Ultra
]]--

local App = {}
App.Name = "Impound"
App.ID = "impound.exe"
App.Panel = "SRPComputer_AppWindow_Impound"
App.Icon = "santosrp/computer/srp_db_icon_new.png"
App.DekstopIcon = true
App.StartMenuIcon = true

GM.Apps:Register( App )

if SERVER then return end

local function FindPlayerByName( strName )
	if strName == "" then return end
	for k, v in pairs( player.GetAll() ) do
		if v:Nick():lower():Trim():match( strName:lower():Trim() ) then
			return v
		end
	end
end

local function FindPlayerByLicenseID( strID )
	if strID == "" then return end
	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Player:GetSharedGameVar( v, "driver_license", "" ) == "" then continue end
		if GAMEMODE.Player:GetSharedGameVar( v, "driver_license", "" ):lower():Trim() == strID:lower():Trim() then
			return v
		end
	end
end

local Panel = {}
function Panel:Init()
	self.m_pnlNameLabel = vgui3D.Create( "DLabel", self )
	self.m_pnlNameLabel:SetTextColor( color_white )
	self.m_pnlNameLabel:SetFont( "Trebuchet18" )
	self.m_pnlNameLabel:SetText( "Search By Name" )

	self.m_pnlNameText = vgui3D.Create( "SRPPhone_TextEntry", self )
	self.m_pnlNameText:SetMultiline( false )
	self.m_pnlNameText:SetFont( "SRPTextMessageFontSmall" )
	self.m_pnlNameText.PerformLayout = DTextEntry.PerformLayout
	self.m_pnlNameText:SetRoot( self:GetParent():GetParent():GetDesktop() )

	self.m_pnlBtnSearchName = vgui3D.Create( "DButton", self )
	self.m_pnlBtnSearchName:SetText( "Search" )
	self.m_pnlBtnSearchName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnSearchName:SetFont( "Trebuchet18" )
	self.m_pnlBtnSearchName.DoClick = function()
		local pl = FindPlayerByName( self.m_pnlNameText:GetValue() or "" )
		if not IsValid( pl ) then return end
		GAMEMODE.Net:SendCopImpoundRequest( pl )
	end

	self.m_pnlIDLabel = vgui3D.Create( "DLabel", self )
	self.m_pnlIDLabel:SetTextColor( color_white )
	self.m_pnlIDLabel:SetFont( "Trebuchet18" )
	self.m_pnlIDLabel:SetText( "Search By License ID" )

	self.m_pnlIDText = vgui3D.Create( "SRPPhone_TextEntry", self )
	self.m_pnlIDText:SetMultiline( false )
	self.m_pnlIDText:SetFont( "SRPTextMessageFontSmall" )
	self.m_pnlIDText.PerformLayout = DTextEntry.PerformLayout
	self.m_pnlIDText:SetRoot( self:GetParent():GetParent():GetDesktop() )

	self.m_pnlBtnSearchID = vgui3D.Create( "DButton", self )
	self.m_pnlBtnSearchID:SetText( "Search" )
	self.m_pnlBtnSearchID:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnSearchID:SetFont( "Trebuchet18" )
	self.m_pnlBtnSearchID.DoClick = function()
		local pl = FindPlayerByLicenseID( self.m_pnlIDText:GetValue() or "" )
		if not IsValid( pl ) then return end
		GAMEMODE.Net:SendCopImpoundRequest( pl )
	end
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlNameLabel:SizeToContents()
	self.m_pnlIDLabel:SizeToContents()

	self.m_pnlNameText:SetSize( 350, 20 )
	self.m_pnlIDText:SetSize( 350, 20 )

	self.m_pnlBtnSearchName:SetSize( 45, 20 )
	self.m_pnlBtnSearchID:SetSize( 45, 20 )

	local yOffset = math.min( self.m_pnlNameLabel:GetTall() +self.m_pnlNameText:GetTall() +5 +2.5, intH /2 )

	local y = (intH /2) -yOffset
	self.m_pnlNameLabel:SetPos( (intW /2) -(self.m_pnlNameLabel:GetWide() /2), y )
	y = y +self.m_pnlNameLabel:GetTall() +5

	self.m_pnlNameText:SetPos( (intW /2) -((self.m_pnlNameText:GetWide() +self.m_pnlBtnSearchName:GetWide()) /2), y )
	y = y +self.m_pnlNameText:GetTall() +5

	local x, y2 = self.m_pnlNameText:GetPos()
	self.m_pnlBtnSearchName:SetPos( x +self.m_pnlNameText:GetWide(), y2 )

	self.m_pnlIDLabel:SetPos( (intW /2) -(self.m_pnlIDLabel:GetWide() /2), y )
	y = y +self.m_pnlIDLabel:GetTall() +5

	self.m_pnlIDText:SetPos( (intW /2) -((self.m_pnlIDText:GetWide() +self.m_pnlBtnSearchID:GetWide())/2), y )

	x, y2 = self.m_pnlIDText:GetPos()
	self.m_pnlBtnSearchID:SetPos( x +self.m_pnlIDText:GetWide(), y2 )
end
vgui.Register( "SRPComputer_AppWindow_Impound_Search", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self.m_pnlLabelName = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelName:SetText( "RecordName" )
	self.m_pnlLabelName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelName:SetFont( "Trebuchet18" )

	self.m_pnlBtnFree = vgui3D.Create( "DButton", self )
	self.m_pnlBtnFree:SetText( "Release" )
	self.m_pnlBtnFree:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnFree:SetFont( "Trebuchet18" )
	self.m_pnlBtnFree.DoClick = function()
		if not IsValid( self.m_pPlayer ) then return end
		GAMEMODE.Net:SendCopImpoundRelRequest( self.m_pPlayer, self.m_strUID )
	end
end

function Panel:SetUID( pPlayer, strUID )
	self.m_pPlayer = pPlayer
	self.m_strUID = strUID
	self.m_tblData = GAMEMODE.Cars:GetCarByUID( strUID )
	if not self.m_tblData then return end
	self.m_pnlLabelName:SetText( ("%s %s"):format(self.m_tblData.Make, self.m_tblData.Name) )
	self:InvalidateLayout()
end

function Panel:Paint( intW, intH )
	if self.Hovered then
		surface.SetDrawColor( 50, 50, 50, 120 )
	else
		surface.SetDrawColor( 10, 10, 10, 120 )
	end	
	surface.DrawRect( 0, 0, intW, intH )
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlLabelName:SizeToContents()
	self.m_pnlLabelName:SetPos( 5, (intH /2) -(self.m_pnlLabelName:GetTall() /2) )

	self.m_pnlBtnFree:SetSize( 55, 20 )
	self.m_pnlBtnFree:SetPos( intW -self.m_pnlBtnFree:GetWide() -5, (intH /2) -(self.m_pnlBtnFree:GetTall() /2) )
end
vgui.Register( "SRPComputer_AppWindow_Impound_CarCard", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self.m_pnlBtnBack = vgui3D.Create( "DButton", self )
	self.m_pnlBtnBack:SetText( "Back" )
	self.m_pnlBtnBack:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlBtnBack:SetFont( "Trebuchet18" )
	self.m_pnlBtnBack.DoClick = function()
		self:GetParent():ShowSearch()
	end

	self.m_pnlAvatar = vgui3D.Create( "SRP_AvatarImg", self )
	self.m_pnlAvatar:SetSize( 32, 32 )
	
	self.m_pnlLabelName = vgui3D.Create( "DLabel", self )
	self.m_pnlLabelName:SetText( "PlayerName" )
	self.m_pnlLabelName:SetTextColor( Color(240, 240, 240, 255) )
	self.m_pnlLabelName:SetFont( "Trebuchet18" )

	self.m_pnlCardContainer = vgui3D.Create( "SRPComputer_ScrollPanel", self )
	self.m_tblCards = {}
end

function Panel:Refresh( pPlayer, tblData )
	if not IsValid( pPlayer ) then return end
	for k, v in pairs( self.m_tblCards ) do
		if ValidPanel( v ) then v:Remove() end
	end

	self.m_tblData = tblData
	self.m_tblCards = {}
	
	self.m_pnlAvatar:SetPlayer( pPlayer )
	self.m_pnlLabelName:SetText( ("%s - Impounded Vehicles"):format(pPlayer:Nick()) )

	for k, uid in pairs( tblData ) do
		local card = vgui3D.Create( "SRPComputer_AppWindow_Impound_CarCard", self.m_pnlCardContainer )
		card:SetUID( pPlayer, uid )
		self.m_pnlCardContainer:AddItem( card )
		table.insert( self.m_tblCards, card )
	end
end

function Panel:Paint( intW, intH )
	surface.SetDrawColor( 50, 50, 50, 150 )
	surface.DrawRect( 32 +5, 5 +16 -8, intW -10 -32 -5, 16 )

	surface.SetDrawColor( 0, 0, 0, 250 )
	surface.DrawRect( 5, 5, 32, 32 )
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlAvatar:SetPos( 5, 5 )
	self.m_pnlAvatar:SetSize( 32, 32 )

	self.m_pnlLabelName:SizeToContents()
	self.m_pnlLabelName:SetPos( 32 +10, 5 +16 -(self.m_pnlLabelName:GetTall() /2) )

	self.m_pnlBtnBack:SetSize( 45, 16 )
	self.m_pnlBtnBack:SetPos( intW -50, 5 +16 -(self.m_pnlBtnBack:GetTall() /2) )

	self.m_pnlCardContainer:SetPos( 5, 32 +10 )
	self.m_pnlCardContainer:SetSize( intW -10, intH -15 -32 )

	for k, v in pairs( self.m_tblCards ) do
		v:DockMargin( 0, 0, 0, 5 )
		v:SetTall( 24 )
		v:Dock( TOP )
	end
end
vgui.Register( "SRPComputer_AppWindow_Impound_View", Panel, "EditablePanel" )


local Panel = {}
function Panel:Init()
	self:GetParent():SetTitle( App.Name )
	self:GetParent():SetSize( 500, 425 )
	self:GetParent():SetPos( 100, 25 )
	self:GetParent():RequestFocus()
	self:GetParent():MoveToFront()

	self.m_pnlWindow = vgui3D.Create( "SRPComputer_AppWindow_Impound_Search", self )
	self.m_pnlView = vgui3D.Create( "SRPComputer_AppWindow_Impound_View", self )
	self:ShowSearch()

	hook.Add( "GamemodeOnGetCopImpoundRecords", "CopImpoundApp", function( pPlayer, tblData )
		if not self or not ValidPanel( self ) then return end
		self:ShowView( pPlayer, tblData )
	end )
end

function Panel:ShowSearch()
	self.m_pnlWindow:SetVisible( true )
	self.m_pnlView:SetVisible( false )
	self.m_pnlWindow:MoveToFront()
end

function Panel:ShowView( pPlayer, tblData )
	self.m_pnlView:Refresh( pPlayer, tblData )
	self.m_pnlWindow:SetVisible( false )
	self.m_pnlView:SetVisible( true )
	self.m_pnlView:MoveToFront()
end

function Panel:PerformLayout( intW, intH )
	self.m_pnlWindow:SetPos( 0, 0 )
	self.m_pnlWindow:SetSize( intW, intH )

	self.m_pnlView:SetPos( 0, 0 )
	self.m_pnlView:SetSize( intW, intH )
end
vgui.Register( "SRPComputer_AppWindow_Impound", Panel, "EditablePanel" )