--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--
GM.License = (GAMEMODE or GM).License or {}
GM.License.m_tblActiveCars = (GAMEMODE or GM).License.m_tblActiveCars or {}

function GM.License:NetworkEntityCreated(eEnt)
	if eEnt:IsVehicle() and eEnt:GetClass() == "prop_vehicle_jeep" then
		self:RegisterNewCar(eEnt)
	end
end

function GM.License:PostDrawTranslucentRenderables()
	self:DrawCarPlates()
end

function GM.License:PlayerHasLicense(pPlayer)
	return GAMEMODE.Player:GetSharedGameVar(pPlayer, "driver_license", "") ~= ""
end

function GM.License:GetPlayerPlateNumber(pPlayer)
	if not GAMEMODE.Cars:PlayerHasCar(pPlayer) then return "unknown" end

	return GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer):GetNWString("plate_serial")
end

function GM.License:GetPlayerFromPlateNumber(strPlateNumber)
	for k, v in pairs(player.GetAll()) do
		if not GAMEMODE.Player:PlayerHasCar(v) then continue end
		if GAMEMODE.Cars:GetCurrentPlayerCar(pPlayer):GetNWString("plate_serial"):lower() == strPlateNumber:lower() then return v end
	end
end

g_plates = {}

function RegisterPlatesForVeh(what, ...)
	if g_plates[what] then return print(what, "existing plates") end
	g_plates[what] = {...}
end

-- RegisterPlates("m4_sgm", {
-- 	pos = Vector(0, 114.6, 17.7),
-- 	ang = Angle(0, 180, 95),
-- 	scale = 0.025
-- }, {
-- 	pos = Vector(0, -107.4, 35),
-- 	ang = Angle(0, 0, 80),
-- 	scale = 0.030
-- })
local fmt

local function startFormat(data)
	fmt = [[
	RegisterPlates("%s", {
	pos = Vector(%d, %d, %d),
	ang = Angle(%d, %d, %d),
	scale = %f
	}
]]

	if data[2] then
		fmt = fmt .. [[, {
	pos = Vector(%d, %d, %d),
	ang = Angle(%d, %d, %d),
	scale = %f
	})
	]]
	else
		fmt = fmt .. [[)
	]]
	end

	return fmt
end

function PrintPlates()
	local str = ""

	for k, v in pairs(g_plates) do
		local fmt = startFormat(v)

		if v[2] then
			fmt = fmt:format(k, v[1].pos.x, v[1].pos.y, v[1].pos.z, v[1].ang.p, v[1].ang.y, v[1].ang.r, v[1].scale, v[2].pos.x, v[2].pos.y, v[2].pos.z, v[2].ang.p, v[2].ang.y, v[2].ang.r, v[2].scale)
		else
			fmt = fmt:format(k, v[1].pos.x, v[1].pos.y, v[1].pos.z, v[1].ang.p, v[1].ang.y, v[1].ang.r, v[1].scale)
		end

		str = str .. fmt .. "\n"
	end

	SetClipboardText(str)
	print("Copied " .. #str .. " characters")
end

function GetPlatesFor(eEnt)
	local script = eEnt:GetNWString("vehicle_script")
	local mdl = eEnt:GetModel()
	if g_plates[mdl] then return g_plates[mdl] end

	if g_plates[script] then
		return g_plates[script]
	else
		return {
			{
				pos = eEnt:WorldToLocal(eEnt:GetPos() + eEnt:GetForward() * eEnt:OBBMins().y),
				ang = Angle(0, 0, 0), -- not entirely sure what this shit was for (z was originally 90 not 190 ) Moved it into the ground because shits cring and im not gonna delete it cuz idk what it does ofc
				scale = 0.0001
			}
		}
	end
end

--[[ License plate addon integrated and rewritten ]]
--
function GM.License:RegisterNewCar(entCar)
	self.m_tblActiveCars[entCar] = true
end

function GM.License:DrawCarPlates()
	local pos = LocalPlayer():GetPos()
	local max = GAMEMODE.Config.RenderDist_Level3 ^ 2

	for car, _ in pairs(self.m_tblActiveCars) do
		if not IsValid(car) then
			self.m_tblActiveCars[car] = nil
			continue
		end

		if pos:DistToSqr(car:GetPos()) > max then continue end
		self:DrawLPlate(car)
	end
end

--Draw func is pretty much the same for legacy support
surface.CreateFont("PlateFontBig", {
	font = "Trebuchet",
	size = 128,
	antialias = true
})

GM.License.m_tblLPlateSize = {
	w = 512,
	h = 256
}

GM.License.m_matPlate = Material("gnet/lplate.png", "")
GM.License.m_bDrawPlateShadows = true
GM.License.m_colPlateShadow = Color(170, 170, 170, 255)
GM.License.m_colTextCol = Color(20, 20, 20, 255)

function GM.License:DrawLPlate(entCar)
	local data = GetPlatesFor(entCar)
	if not data then return end
	local serial = entCar:GetNWString("plate_serial", "")
	if not serial or serial == "" then return end

	for _, data in pairs(data) do
		cam.Start3D2D(entCar:LocalToWorld(data.pos), entCar:LocalToWorldAngles(data.ang), data.scale)
		surface.SetMaterial(self.m_matPlate)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(-self.m_tblLPlateSize.w / 2 - 6, -self.m_tblLPlateSize.h / 2 - 6, self.m_tblLPlateSize.w + 12, self.m_tblLPlateSize.h + 12)

		if self.m_bDrawPlateShadows then
			draw.SimpleText(serial, "PlateFontBig", -2, 2, self.m_colPlateShadow, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		draw.SimpleText(serial, "PlateFontBig", 0, 0, self.m_colTextCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		cam.End3D2D()
	end
end

--[[ Game Vars ]]
--
hook.Add("GamemodeDefineGameVars", "DefineLicenseVars", function(pPlayer)
	GAMEMODE.Player:DefineSharedGameVar("driver_license", "", "String", true)
end)

--[[ Plate Code ]]
--	
local RegisterPlates = RegisterPlatesForVeh
-- moved back to vehicle defaults in addon/lplates