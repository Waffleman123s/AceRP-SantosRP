--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345), QuackDuck (QuackDuck#6610)
	For: AceRP.gg 
]]--
--
surface.CreateFont("BuddyFont", {
	size = 128,
	weight = 500,
	font = "DermaLarge"
})

GM.Buddy = (GAMEMODE or GM).Buddy or {}
GM.Buddy.m_tblCurBuddies = (GAMEMODE or GM).Buddy.m_tblCurBuddies or {}
GM.Buddy.m_matBuddyIcon = Material("icon16/user.png", "noclamp smooth")

local function IsDisguised(pPlayer)
	return GAMEMODE.Player:GetSharedGameVar(pPlayer, "eq_slot_Face") ~= "" or GAMEMODE.Player:GetSharedGameVar(pPlayer, "eq_slot_Neck") ~= ""
end

function GM.Buddy:GetPlayerBuddyID(pPlayer)
	if not pPlayer:GetCharacterID() then return end
	local buddyID = pPlayer:GetCharacterID()

	return self.m_tblCurBuddies[buddyID] and buddyID or nil
end

function GM.Buddy:GetPlayerByBuddyID(intBuddyID)
	for k, v in pairs(player.GetAll()) do
		if v:GetCharacterID() == intBuddyID then return v end
	end
end

function GM.Buddy:GetBuddyData(intBuddyID)
	return self.m_tblCurBuddies[intBuddyID]
end

function GM.Buddy:IsBuddyWith(pPlayer)
	if not pPlayer:GetCharacterID() then return false end

	return self.m_tblCurBuddies[pPlayer:GetCharacterID()] or false
end

function GM.Buddy:SetBuddyTable(tblBuddies)
	self.m_tblCurBuddies = tblBuddies
end

function GM.Buddy:GetBuddyTable()
	return self.m_tblCurBuddies
end
local staffGroups = {
    ["trialmod"] = true,
    ["moderator"] = true,
    ["supervisor"] = true,
}
do
	local fnTrace = util.TraceLine
	local traceData = {}
	local pmeta = debug.getregistry().Player
	local fnGetShootPos = pmeta.GetShootPos
	local fnGetAimVec = pmeta.GetAimVector
	local fnNick = pmeta.Nick
	local emeta = debug.getregistry().Entity
	local fnIsPlayer = emeta.IsPlayer
	local fnStart3D = cam.Start3D2D
	local fnEnd3D = cam.End3D2D
	local fnNoDraw = emeta.GetNoDraw
	local fnCenter = emeta.OBBCenter
	local fnLocalWorld = emeta.LocalToWorld
	local offset, iconSize = Vector(0, 0, 50), 128
	local ent, pos, ang, id, tr, pl

	function GM.Buddy:PostDrawTranslucentRenderables()
		pl = LocalPlayer()
		ang = Angle(0, pl:EyeAngles().y - 90, 90)
		traceData.start = fnGetShootPos(pl)
		traceData.endpos = fnGetShootPos(pl) + fnGetAimVec(pl) * 350
		traceData.filter = pl
		tr = fnTrace(traceData)

		if tr.Hit and IsValid(tr.Entity) and not fnNoDraw(tr.Entity) and tr.Entity.Nick then
			ent = IsValid(tr.Entity:GetRagdoll()) and tr.Entity:GetRagdoll() or tr.Entity
			surface.SetFont("BuddyFont")
			if ent:GetMoveType() == MOVETYPE_NOCLIP then return end
			if ent:GetColor().a == 0 then return end

			if self:IsBuddyWith(tr.Entity) then
				pos = fnLocalWorld(ent, fnCenter(ent)) + offset
				fnStart3D(pos, ang, 0.035)
				tW, tH = surface.GetTextSize(fnNick(tr.Entity))
				surface.SetTextColor(255, 255, 255, 255)
				surface.SetTextPos(-(tW / 2), tH / 2)
				id = fnNick(tr.Entity)

				if IsDisguised(tr.Entity) then
					id = tr.Entity:SteamID64()
				end

				surface.DrawText(id)
				-- surface.SetMaterial( self.m_matBuddyIcon )
				-- surface.SetDrawColor( 255, 255, 255, 255 )
				-- surface.DrawTexturedRect( -(tW /2) -iconSize -24, (tH /2), iconSize, iconSize )
				fnEnd3D()
			else
				pos = fnLocalWorld(ent, fnCenter(ent)) + offset

				if PRIVATE_SERVER then
					id = "#" .. GAMEMODE.Player:GetSharedGameVar(tr.Entity, "forum_id", 0)
				else
					id = tr.Entity:SteamID64()
				end

				if IsDisguised(tr.Entity) then
					id = tr.Entity:SteamID64()
				end

				if staffGroups[LocalPlayer():GetUserGroup()] or LocalPlayer():IsAdmin() or GAMEMODE.Jobs:GetPlayerJob(tr.Entity).Receives911Messages or tr.Entity == LocalPlayer() then
					id = tr.Entity:Nick()
				end

				fnStart3D(pos, ang, 0.035)
				tW, tH = surface.GetTextSize(id)
				surface.SetTextColor(255, 255, 255, 255)
				surface.SetTextPos(-(tW / 2), tH / 2)
				surface.DrawText(id)
				fnEnd3D()
			end
		end
	end
end

hook.Add("GamemodeDefineGameVars", "DefineForumID", function()
	GAMEMODE.Player:DefineSharedGameVar("forum_id", 0, "UInt32", true)
end)