--[[
Original Creators: MazeRP Development Team
Modified and reworked by: GNetRP Development Team
Legal Information: Legal@gnetrp.com
Extra Information: www.gnetrp.com or www.gnetrp.gg | https://discord.gg/2Mnk937aMn | @Tylr#9999 STEAM_0:1:71010553 @Krusty STEAM_0:1:164681911 @Meaty STEAM_0:1:151895828 | https://github.com/TylrDevs | https://github.com/gnetrp |
]]--

GM.Net:AddProtocol( "fd", 55 )

local Job = {}
Job.ID = 4
Job.HasMasterKeys = true
Job.Receives911Messages = true
Job.Enum = "JOB_FIREFIGHTER"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Firefighter"
Job.PlayerModel = {
	Male_Fallback = "models/player/portal/male_07_fireman.mdl",
	Female_Fallback = "models/player/portal/male_07_fireman.mdl",
	
	Male = {
		["male_01"] = "models/player/portal/male_01_fireman.mdl",
		["male_02"] = "models/player/portal/male_02_fireman.mdl",
		["male_03"] = "models/player/portal/male_03_fireman.mdl",
		["male_04"] = "models/player/portal/male_04_fireman.mdl",
		["male_05"] = "models/player/portal/male_05_fireman.mdl",
		["male_06"] = "models/player/portal/male_06_fireman.mdl",
		["male_07"] = "models/player/portal/male_07_fireman.mdl",
		["male_08"] = "models/player/portal/male_08_fireman.mdl",
		["male_09"] = "models/player/portal/male_09_fireman.mdl",
	},
	Female = {
		["female_01"] = "models/player/portal/male_02_fireman.mdl",
		["female_02"] = "models/player/portal/male_02_fireman.mdl",
		["female_03"] = "models/player/portal/male_02_fireman.mdl",
		["female_04"] = "models/player/portal/male_04_fireman.mdl",
		["female_05"] = "models/player/portal/male_05_fireman.mdl",
		["female_06"] = "models/player/portal/male_06_fireman.mdl",
		["female_07"] = "models/player/portal/male_07_fireman.mdl",
		["female_08"] = "models/player/portal/male_08_fireman.mdl",
		["female_09"] = "models/player/portal/male_09_fireman.mdl",
	},
}
Job.PlayerCap = GM.Config.Job_Fire_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.ParkingGaragePos = GM.Config.FireParkingZone
Job.CarSpawns = GM.Config.FireCarSpawns
Job.FiretruckID = "fire_truck"
Job.FirstRespondID = "fire_first"

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Fire", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 3, "Fire", false )
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 4, "Fire Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 3
		Job.ChannelKeys = {
			[2] = true, --Police Encrypted
			[4] = true, --Fire Encrypted
			[6] = true, --EMS Encrypted
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	pPlayer.m_intSelectedJobModelSkin = nil
	pPlayer.m_tblSelectedJobModelBGroups = nil

	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_FIREFIGHTER then
		curCar:Remove()
	end
end

function Job:GetPlayerModel( pPlayer )
	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)
	
	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end

function GM.Net:RequestSpawnFDCar( strJobCarID, colColor, tblBodygroups )
	self:NewEvent( "fd", "sp_c" )
		net.WriteString( strJobCarID )
		net.WriteColor( colColor or Color(255, 255, 255, 255) )
		net.WriteTable( tblBodygroups or {} )
	self:FireEvent()
end

function GM.Net:RequestStowFDCar()
	self:NewEvent( "fd", "st" )
	self:FireEvent()
end

GM.Jobs:Register( Job )