--[[
	Name: sv_city_worker.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 974
Job.Enum = "JOB_LUMBERWORKER"
Job.TeamColor = Color( 146, 120, 160, 255 )
Job.Name = "Lumber Worker"
Job.PlayerCap = GM.Config.Job_LumberWorker_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarID = "gmc_lumber"
Job.ParkingLotPos = GM.Config.RoadParkingZone
Job.CarSpawns = GM.Config.RoadParkingSpawns
Job.Payouts = {
	['small_plank'] = 150,
	['quart_log'] = 85
}

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 35 },
		{ PlayTime = 4 *(60 *60), Pay = 40 },
		{ PlayTime = 12 *(60 *60), Pay = 45 },
		{ PlayTime = 24 *(60 *60), Pay = 50 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 90 },
	}
end


Job.m_tblEvents = JOB_LUMBERWORKER and GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblEvents or {}
Job.m_tblSpawned = JOB_LUMBERWORKER and GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblSpawned or {}
Job.DefaultTrunk = {
	["Lumber Axe"] = 1
}

function Job:OnPlayerJoinJob( pPlayer )
	self:SpawnNewEvent(pPlayer);
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_LUMBERWORKER then
		curCar:Remove()
	end

	for k, v in pairs( ents.GetAll() ) do
		if v.LumberWorkerEnt and v.SpawnedFor == pPlayer then
			v:Remove()
		elseif v.IsItem and v.ItemData.JobItem then
			if v.ItemData.JobItem == "JOB_LUMBERWORKER" and v.CreatedBy == pPlayer then
				v:Remove()
			end
	end
end

	GAMEMODE.Player:SetGameVar( pPlayer, "lwork_dest", "" )
	GAMEMODE.Player:SetGameVar( pPlayer, "lwork_type", "" )
	pPlayer.m_entCurFixEvent = nil
end

function Job:PlayerLoadout( pPlayer )
end

function Job:OnPlayerSpawnVan( pPlayer, entCar )
	for k, v in pairs(self.DefaultTrunk) do
		GAMEMODE.TrunkStorage:AddToTrunkForce(entCar:EntIndex(), k, v)
	end
	entCar.IsLumberTruck = true
	entCar:SetSkin( 14 )
	pPlayer:AddNote( "You spawned your lumber utility truck!" )
end

function Job:PlayerSpawnVan( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.CarID, self.CarSpawns, self.ParkingLotPos )
	if IsValid( car ) then
		self:OnPlayerSpawnVan( pPlayer, car )
		car.lumberjack_car = true;
		car:SetNWBool("lumberjack_car", true);
		car.lumberjack_carOwner = pPlayer;
		
		car.stock_quart = 0
		car.stock_log = 0
		car.stock_plank = 0
		car.stock_small_log = 0

		car.props_tbl = {}
		car.stock_quart_max = 18
		car.stock_log_max = 3
		car.stock_plank_max = 18
		car.stock_small_log_max = 6
	end
end

function Job:PlayerStowVan( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingLotPos )
end

function Job:RegisterEvent( strID, tbl )
	self.m_tblEvents[strID] = tbl
end

function Job:SpawnNewEvent( pPlayer )
	if pPlayer.m_entCurFixEvent then return end

	local eventNo = math.random( 1, table.Count(self.m_tblEvents) )
	local iter = 0
	for k, v in pairs( self.m_tblEvents ) do
		iter = iter +1
		if eventNo == iter then
			pPlayer.m_entCurFixEvent = v.spawn( pPlayer )
			if pPlayer.m_entCurFixEvent then
				pPlayer:AddNote( "You have a new activity to perform for the lumber mill!" )
				GAMEMODE.Player:SetGameVar( pPlayer, "lwork_type", k )
			end

			break
		end
	end
end

local playerChecks = {}
local lastCheck = CurTime() +1
hook.Add( "Think", "ThinkLumberDamage", function()
	if lastCheck > CurTime() then return end
	lastCheck = CurTime() +1

	if GAMEMODE.Jobs:GetNumPlayers( JOB_LUMBERWORKER ) <= 0 then return end

	for k, v in pairs( player.GetAll() ) do
		if GAMEMODE.Jobs:GetPlayerJobID( v ) ~= JOB_LUMBERWORKER then continue end
		if (playerChecks[v] or 0) > CurTime() then continue end
		playerChecks[v] = CurTime() +math.random( GAMEMODE.Config.MinDmgEventTime, GAMEMODE.Config.MaxDmgEventTime )

		Job:SpawnNewEvent( v )
	end

	for k, v in pairs( playerChecks ) do
		if not IsValid( k ) then playerChecks[k] = nil end
	end
end )

-- hook.Add( "PlayerUse", "UseCityTruck", function( pPlayer, eEnt )
-- 	if not GAMEMODE.Jobs:PlayerIsJob( pPlayer, JOB_LUMBERWORKER ) then return end
-- 	if not IsValid( eEnt ) or not eEnt:IsVehicle() or not eEnt.IsCityVan then return end

-- 	local dot = (pPlayer:GetEyeTrace().HitPos -eEnt:GetPos()):GetNormal():Dot( eEnt:GetForward() )
-- 	if dot < -0.9 and CurTime() >(pPlayer.m_intLastUsedCityTruck or 0) then
-- 		GAMEMODE.Net:ShowNWMenu( pPlayer, "city_worker_van" )
-- 		pPlayer.m_intLastUsedCityTruck = CurTime() +1
-- 		return false
-- 	end
-- end )
 
hook.Add( "GamemodeDefineGameVars", "DefineLumberWorkerVars", function( pPlayer )
	GAMEMODE.Player:DefineGameVar( pPlayer, "lwork_dest", "", "String", true )
	GAMEMODE.Player:DefineGameVar( pPlayer, "lwork_type", "", "String", true )
end )

-- Job:RegisterEvent( "dead_tree", {
-- 	spawn = function( pSpawnedFor )
-- 		--[[Job.m_tblSpawned["dead_tree"] = Job.m_tblSpawned["dead_tree"] or {}

-- 		local num, found, data, idx = 0, nil, nil, nil
-- 		while true do
-- 			data, idx = table.Random( GAMEMODE.Config.DeadTreePoints )
-- 			if not Job.m_tblSpawned["dead_tree"][idx] then
-- 				found = idx
-- 				break
-- 			end

-- 			num = num +1
-- 			if num >= 3 then break end
-- 		end
-- 		if not found then return end
-- 		Job.m_tblSpawned["dead_tree"][found] = true

-- 		local ent = ents.Create( "realistic_woodcutter_maintree" )
-- 		ent:SetPos( data.pos )
-- 		ent:SetAngles( data.ang +Angle( 0, math.random(-180, 180), 0) )
-- 		ent:Spawn()
-- 		ent:Activate()
-- 		--ent:SetModel("models/props/cs_assault/firehydrant.mdl")
-- 		ent:CallOnRemove( "updEvent", function()
-- 			--done
-- 			GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblSpawned["dead_tree"][found] = nil
-- 			GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblEvents["dead_tree"].finish( ent.m_entRemovedBy, pSpawnedFor )
-- 		end )

-- 		pSpawnedFor:DeleteOnRemove( ent )
-- 		ent.LumberWorkerEnt = true
-- 		ent.SpawnedFor = pSpawnedFor
-- 		GAMEMODE.Player:SetGameVar( pSpawnedFor, "lwork_dest", tostring(data.pos) )

-- 		return true]]
-- 		return false;
-- 	end,

-- 	finish = function( pRemover, pSpawnedFor )
-- 		--[[if not IsValid( pRemover ) then return end
-- 		if not IsValid( pSpawnedFor ) then return end
-- 		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_LUMBERWORKER ) then return end
		
-- 		pSpawnedFor.m_entCurFixEvent = nil

-- 		local pay = 150
-- 		pRemover:AddNote( "You earned $".. pay.. " for removing a dead tree!" )
-- 		pRemover:AddNote( "These funds have been sent to your bank account." )
-- 		pRemover:AddBankMoney( pay, "Lumber worker commission" )

-- 		GAMEMODE.Player:SetGameVar( pSpawnedFor, "lwork_dest", "" )
-- 		GAMEMODE.Player:SetGameVar( pSpawnedFor, "lwork_type", "" )]]
-- 	end,
-- } )

-------------------------------------------------------------------------
Job:RegisterEvent( "tree_event", {
	spawn = function( pSpawnedFor )
		Job.m_tblSpawned["tree_event"] = Job.m_tblSpawned["tree_event"] or {}

		local num, found, data, idx = 0, nil, nil, nil
		while true do
			data, idx = table.Random( GAMEMODE.Config.LumberTreesPoints )
			if not Job.m_tblSpawned["tree_event"][idx] then
				found = idx
				break
			end

			num = num +1
			if num >= 3 then break end
		end
		if not found then return end
		Job.m_tblSpawned["tree_event"][found] = true

		local ent = ents.Create( "realistic_woodcutter_stumps" )
		ent:SetPos( data.pos )
		ent:SetAngles( data.ang + Angle( 0, math.random(-180, 180), 0) )
		ent:Spawn()
		ent:Activate()
		ent:CallOnRemove( "updEvent", function()
			--done
			GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblSpawned["tree_event"][found] = nil
			GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblEvents["tree_event"].finish( ent.m_entRemovedBy, pSpawnedFor )
		end )
		ent:DropToFloor();
		ent:Grow();

		pSpawnedFor:DeleteOnRemove( ent )
		ent.CityWorkerEnt = true
		ent.SpawnedFor = pSpawnedFor
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "lwork_dest", tostring(data.pos) )

		return true
	end,

	finish = function( pRemover, pSpawnedFor )
		if not IsValid( pRemover ) then return end
		if not IsValid( pSpawnedFor ) then return end
		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_LUMBERWORKER ) then return end
		
		pSpawnedFor.m_entCurFixEvent = nil

		local pay = 850
		pRemover:AddNote( "You earned $".. pay.. " for fixing a leaking fire hydrant!" )
		pRemover:AddNote( "These funds have been sent to your bank account." )
		pRemover:AddBankMoney( pay, "City services commission" )

		GAMEMODE.Player:SetGameVar( pSpawnedFor, "lwork_dest", "" )
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "lwork_type", "" )
	end,
} )
--[[
Job:RegisterEvent( "mow_grass", {
	spawn = function( pSpawnedFor )
		Job.m_tblSpawned["mow_grass"] = Job.m_tblSpawned["mow_grass"] or {}

		local num, found, data, idx = 0, nil, nil, nil
		while true do
			data, idx = table.Random( GAMEMODE.Config.MowableGrassZones )
			if not Job.m_tblSpawned["mow_grass"][idx] then
				found = idx
				break
			end

			num = num +1
			if num >= 3 then break end
		end
		if not found then return end
		Job.m_tblSpawned["mow_grass"][found] = true

		local grassEnts = {}
		local numGrass = math.random( #data.Grass *0.6, #data.Grass )
		local i = 1
		for k, v in RandomPairs( data.Grass ) do
			local ent = ents.Create( "ent_mowable_grass" )
			ent:SetPos( data.Grass[i].pos )
			ent:SetAngles( data.Grass[i].ang )
			ent:Spawn()
			ent:Activate()
			ent:CallOnRemove( "updEvent", function()
				grassEnts[ent] = nil
				if table.Count( grassEnts ) <= 0 then
					--done
					GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblSpawned["mow_grass"][found] = nil
					GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblEvents["mow_grass"].finish( pSpawnedFor )
				end
			end )

			pSpawnedFor:DeleteOnRemove( ent )
			ent.CityWorkerEnt = true
			ent.SpawnedFor = pSpawnedFor
			pSpawnedFor.m_tblMowData = data
			grassEnts[ent] = true

			GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", data.Name )
			i = i+1
			if i >= numGrass then break end
		end

		return true
	end,

	finish = function( pSpawnedFor )
		if not IsValid( pSpawnedFor ) then return end
		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_LUMBERWORKER ) then return end

		pSpawnedFor.m_entCurFixEvent = nil

		if pSpawnedFor.m_tblMowData then
			pSpawnedFor:AddBankMoney( pSpawnedFor.m_tblMowData.Pay, "City services commission" )
			pSpawnedFor:AddNote( "You earned $".. string.Comma(pSpawnedFor.m_tblMowData.Pay).. " for mowing grass!" )
			pSpawnedFor:AddNote( "These funds have been sent to your bank account." )
		end

		pSpawnedFor.m_tblMowData = nil
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", "" )
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_type", "" )
	end,
} )

Job:RegisterEvent( "road_debris", {
	spawn = function( pSpawnedFor )
		Job.m_tblSpawned["road_debris"] = Job.m_tblSpawned["road_debris"] or {}

		local num, found, data, idx = 0, nil, nil, nil
		while true do
			data, idx = table.Random( GAMEMODE.Config.RoadDamageSpawns )
			if not Job.m_tblSpawned["road_debris"][idx] then
				found = idx
				break
			end

			num = num +1
			if num >= 3 then break end
		end
		if not found then return end
		Job.m_tblSpawned["road_debris"][found] = true

		local ent = ents.Create( "ent_road_debris" )
		ent:SetPos( data.pos )
		ent:SetAngles( data.ang )
		ent:Spawn()
		ent:Activate()
		ent:CallOnRemove( "updEvent", function()
			--done
			GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblSpawned["road_debris"][found] = nil
			GAMEMODE.Jobs:GetJobByID( JOB_LUMBERWORKER ).m_tblEvents["road_debris"].finish( ent.m_entRemovedBy, pSpawnedFor )
		end )

		pSpawnedFor:DeleteOnRemove( ent )
		ent.CityWorkerEnt = true
		ent.SpawnedFor = pSpawnedFor
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", tostring(data.pos) )

		return true
	end,

	finish = function( pRemover, pSpawnedFor )
		if not IsValid( pRemover ) then return end
		if not IsValid( pSpawnedFor ) then return end
		if not GAMEMODE.Jobs:PlayerIsJob( pSpawnedFor, JOB_LUMBERWORKER ) then return end
		
		pSpawnedFor.m_entCurFixEvent = nil

		local pay = 500
		pRemover:AddNote( "You earned $".. pay.. " for clearing debris off the road!" )
		pRemover:AddNote( "These funds have been sent to your bank account." )
		pRemover:AddBankMoney( pay, "City services commission" )

		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_dest", "" )
		GAMEMODE.Player:SetGameVar( pSpawnedFor, "cwork_type", "" )
	end,
} )
]]

local function updatePlayer( pPlayer )
	GAMEMODE.Net:NewEvent( "ent", "lwork_van_upd" )
	GAMEMODE.Net:FireEvent( pPlayer )
end
GM.Net:RegisterEventHandle( "ent", "lwork_van_take", function( intMsgLen, pPlayer )
	local van = net.ReadEntity()
	if not IsValid( van ) or not van.IsCityVan then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_LUMBERWORKER then return end
	if pPlayer:GetPos():Distance( van:GetPos() ) > 200 then return end

	local itemName = net.ReadString()
	if not Job.VanItems[itemName] then return end

	local itemNum = math.Clamp( net.ReadUInt(16), 0, Job.VanItems[itemName] -GAMEMODE.Inv:GetPlayerItemAmount(pPlayer, itemName) )
	if itemNum <= 0 then return end
	
	if not GAMEMODE.Inv:PlayerHasItemEquipped( pPlayer, itemName ) then
		if GAMEMODE.Inv:GivePlayerItem( pPlayer, itemName, itemNum ) then
			updatePlayer( pPlayer )
		end
	end
end )

GM.Net:RegisterEventHandle( "ent", "lwork_van_add", function( intMsgLen, pPlayer )
	local van = net.ReadEntity()
	if not IsValid( van ) or not van.IsCityVan then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_LUMBERWORKER then return end
	if van:GetPos():Distance( van:GetPos() ) > 200 then return end

	local itemName = net.ReadString()
	if not Job.VanItems[itemName] then return end

	local itemNum = math.Clamp( net.ReadUInt(16), 0, GAMEMODE.Inv:GetPlayerItemAmount(pPlayer, itemName) )
	if itemNum <= 0 then return end
	
	if GAMEMODE.Inv:TakePlayerItem( pPlayer, itemName, itemNum ) then
		updatePlayer( pPlayer )
	end
end )

GM.Jobs:Register( Job )