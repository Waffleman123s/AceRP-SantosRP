GM.Net:AddProtocol( "fd", 55 )

local Job = {}
Job.ID = 4
Job.HasMasterKeys = true
Job.Receives911Messages = true
Job.Enum = "JOB_FIREFIGHTER"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Firefighter"
Job.PlayerModel = {
	Male_Fallback = "models/player/portal/male_07_fireman.mdl",
	Female_Fallback = "models/player/portal/male_07_fireman.mdl",
	
	Male = {
		["male_01"] = "models/player/portal/male_01_fireman.mdl",
		["male_02"] = "models/player/portal/male_02_fireman.mdl",
		["male_03"] = "models/player/portal/male_03_fireman.mdl",
		["male_04"] = "models/player/portal/male_04_fireman.mdl",
		["male_05"] = "models/player/portal/male_05_fireman.mdl",
		["male_06"] = "models/player/portal/male_06_fireman.mdl",
		["male_07"] = "models/player/portal/male_07_fireman.mdl",
		["male_08"] = "models/player/portal/male_08_fireman.mdl",
		["male_09"] = "models/player/portal/male_09_fireman.mdl",
	},
	Female = {
		["female_01"] = "models/player/portal/male_02_fireman.mdl",
		["female_02"] = "models/player/portal/male_02_fireman.mdl",
		["female_03"] = "models/player/portal/male_02_fireman.mdl",
		["female_04"] = "models/player/portal/male_04_fireman.mdl",
		["female_05"] = "models/player/portal/male_05_fireman.mdl",
		["female_06"] = "models/player/portal/male_06_fireman.mdl",
		["female_07"] = "models/player/portal/male_07_fireman.mdl",
		["female_08"] = "models/player/portal/male_08_fireman.mdl",
		["female_09"] = "models/player/portal/male_09_fireman.mdl",
	},
}
Job.PlayerCap = GM.Config.Job_Fire_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.CarLimit = math.ceil( Job.PlayerCap.Max *0.66 )
Job.ParkingGaragePos = GM.Config.FireParkingZone
Job.CarSpawns = GM.Config.FireCarSpawns
Job.FiretruckID = "fire_truck"
Job.FirstRespondID = "fire_first"
Job.RescueTruckID = "rescue_truck"
Job.CrownVicID = "fd_cvfirstrespond"

if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 50 },
		{ PlayTime = 12 *(60 *60), Pay = 55 },
		{ PlayTime = 24 *(60 *60), Pay = 60 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 70 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 125 },
		{ PlayTime = (24 *(60 *60)) *14, Pay = 150 },
		{ PlayTime = (24 *(60 *60)) *30, Pay = 190 },
		{ PlayTime = (24 *(60 *60)) *365, Pay = 420 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 50 },
		{ PlayTime = 12 *(60 *60), Pay = 55 },
		{ PlayTime = 24 *(60 *60), Pay = 60 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 70 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 125 },
		{ PlayTime = (24 *(60 *60)) *14, Pay = 150 },
		{ PlayTime = (24 *(60 *60)) *30, Pay = 190 },
		{ PlayTime = (24 *(60 *60)) *365, Pay = 420 },
	}
end

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Fire", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 3, "Fire", false )
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 4, "Fire Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 3
		Job.ChannelKeys = {
			[2] = true, --Police Encrypted
			[4] = true, --Fire Encrypted
			[6] = true, --EMS Encrypted
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	pPlayer.m_intSelectedJobModelSkin = nil
	pPlayer.m_tblSelectedJobModelBGroups = nil

	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_FIREFIGHTER then
		curCar:Remove()
	end
end

function Job:GetPlayerModel( pPlayer )
	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( pPlayer, "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)
	
	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end

function Job:PlayerSetModel( pPlayer )
	pPlayer:SetModel( self:GetPlayerModel(pPlayer) )
	pPlayer:SetSkin( pPlayer.m_intSelectedJobModelSkin or 0 )

	if pPlayer.m_tblSelectedJobModelBGroups then
		for k, v in pairs( pPlayer:GetBodyGroups() ) do
			if pPlayer.m_tblSelectedJobModelBGroups[v.id] then
				if pPlayer.m_tblSelectedJobModelBGroups[v.id] > pPlayer:GetBodygroupCount( v.id ) -1 then continue end
				pPlayer:SetBodygroup( v.id, pPlayer.m_tblSelectedJobModelBGroups[v.id] )
			end
		end
	end
end

function Job:PlayerLoadout( pPlayer )
	if PRIVATE_SERVER then
		pPlayer:Give( "weapon_gspeak_radio_fire" )
	end
end

function Job:OnPlayerSpawnFiretruck( pPlayer, entCar )
	function entCar:GetHoseSlot( id )
		if id == 1 then
			local Pos = entCar:LocalToWorld( Vector(-5, -180.047256, 30) )
			local Ang = entCar:LocalToWorldAngles( Angle(90, -90, -34) )
			return Pos, Ang
		elseif id == 2 then
			local Pos = entCar:LocalToWorld( Vector(15, -180.047256, 30) )
			local Ang = entCar:LocalToWorldAngles( Angle(90, -90, 40) )
			return Pos, Ang			
		elseif id == 3 then
			local Pos = entCar:LocalToWorld( Vector(-53.2, 32, 67) )
			local Ang = entCar:LocalToWorldAngles( Angle(-90, 0, 0) )
			return Pos, Ang			
		end
	end

	local btn = ents.Create( "ent_button" )
	btn:SetModel( "models/maxofs2d/button_03.mdl" )
	btn:SetIsToggle( true )
	btn:SetPos( entCar:LocalToWorld(Vector('-46.812012 -33.949708 67.029053')) )
	btn:SetAngles( entCar:LocalToWorldAngles(Angle('90.000 90.000 0.000')) )
	btn:SetModelScale( 0.4 )
	btn:SetParent( entCar )
	btn:Spawn()
	entCar:DeleteOnRemove( btn )
	btn:SetLabel( "Start/Stop Hydrant Pump" )
	btn.BlockPhysGun = true
	btn:SetCanUseCallback( function( entBtn, pPlayer )
		if not IsValid( entCar.Hose3 ) or not entCar.Hose3:AttachedToHydrant() then
			return
		end

		return GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) == JOB_FIREFIGHTER
	end )
	btn:SetThinkFunction( function( entBtn )
		if not IsValid( entCar ) then return end
		if not IsValid( entCar.Hose3 ) or not entCar.Hose3:AttachedToHydrant() then
			if entBtn:GetOn() then entBtn:Toggle( false ) end
		end
	end )
	function btn:Toggle( bEnable, pPlayer )
		self:SetOn( not self:GetOn() )
		self:EmitSound( "buttons/lever7.wav", 60, 100, 0.6 )

		if self:GetOn() then
			self.m_sndLoopEffect = CreateSound( self:GetParent(), "vehicles/crane/crane_startengine1.wav" )
			self.m_sndLoopEffect:PlayEx( 0.8, 100 ) 
		else
			self.m_sndLoopEffect:Stop()
			self.m_sndLoopEffect = nil
			self:GetParent():EmitSound( "vehicles/v8/v8_stop1.wav", 60, 65, 0.8 )
		end
	end
	entCar.m_entPumpSwitch = btn

	entCar:CallOnRemove( "stoppumpsound", function()
		if entCar.m_entPumpSwitch and entCar.m_entPumpSwitch.m_sndLoopEffect then
			entCar.m_entPumpSwitch.m_sndLoopEffect:Stop()
			entCar.m_entPumpSwitch.m_sndLoopEffect = nil
		end
	end )

	local screenmdl = ents.Create( "prop_dynamic" )
	screenmdl:SetModel( "models/props_c17/consolebox01a.mdl" )
	screenmdl:SetPos( entCar:LocalToWorld(Vector("-26.944336 -0.5 76")) )
	screenmdl:SetAngles( entCar:LocalToWorldAngles(Angle("0.000 180.000 -0.000")) )
	screenmdl:SetModelScale( 0.6 )
	screenmdl:SetOwner( entCar )
	screenmdl:Spawn()
	screenmdl:Activate()
	screenmdl:SetParent( entCar )
	entCar:DeleteOnRemove( screenmdl )

	local Pos, Ang = entCar:GetHoseSlot( 3 )
	entCar.IsFiretruck = true
	entCar.Hose3 = ents.Create( "ent_firesupplyhose" )
	entCar.Hose3:SetSlotID( 3 )
	entCar.Hose3:SetPos( Pos )
	entCar.Hose3:SetAngles( Ang )
	entCar.Hose3:SetOwner( entCar )
	entCar.Hose3:SetAttPos( Vector(-41.25, -1, 52) )
	entCar.Hose3:SetAttAng( Vector(45, 180, 0) )
	entCar.Hose3:SetCurve1( Vector(0, 0, 0) )
	entCar.Hose3:SetCurve2( Vector(-16, 0, 0) )
	entCar.Hose3:SetScreenPos( Vector('-36.85 8 81.4') )
	entCar.Hose3:SetScreenAngle( Angle('0 -90 90') )
	entCar.Hose3:SetWaterLevel( 5000 )
	entCar.Hose3:Spawn()
	entCar.Hose3:Activate()
	entCar.Hose3:SetParent( entCar )

	local Pos, Ang = entCar:GetHoseSlot( 1 )
	entCar.IsFiretruck = true
	entCar.Hose1 = ents.Create( "ent_firehose" )
	entCar.Hose1:SetSlotID( 1 )
	entCar.Hose1:SetPos( Pos )
	entCar.Hose1:SetAngles( Ang )
	entCar.Hose1:SetOwner( entCar )
	entCar.Hose1:SetAttPos( Vector(5, -162, 90) )
	entCar.Hose1:SetAttAng( Vector(36, -90, 0) )
	entCar.Hose1:SetCurve1( Vector(0, 0, 0) )
	entCar.Hose1:SetCurve2( Vector(-16, 0, 0) )
	entCar.Hose1:SetSupplyHose( entCar.Hose3 )
	entCar.Hose1:Spawn()
	entCar.Hose1:Activate()
	entCar.Hose1:SetParent( entCar )

	local Pos, Ang = entCar:GetHoseSlot( 2 )
	entCar.IsFiretruck = true
	entCar.Hose2 = ents.Create( "ent_firehose" )
	entCar.Hose2:SetSlotID( 2 )
	entCar.Hose2:SetPos( Pos )
	entCar.Hose2:SetAngles( Ang )
	entCar.Hose2:SetOwner( entCar )
	entCar.Hose2:SetAttPos( Vector(5, -162, 90) )
	entCar.Hose2:SetAttAng( Vector(36, -90, 0) )
	entCar.Hose2:SetCurve1( Vector(0, 0, 0) )
	entCar.Hose2:SetCurve2( Vector(-16, 0, 0) )
	entCar.Hose2:SetSupplyHose( entCar.Hose3 )
	entCar.Hose2:Spawn()
	entCar.Hose2:Activate()
	entCar.Hose2:SetParent( entCar )

	entCar:SetSkin( 1 )
	pPlayer:AddNote( "You spawned your firetruck!" )
end

function Job:OnPlayerSpawnFDCar( pPlayer, entCar )
	if not entCar.UID then return end
	if entCar.UID == self.FiretruckID then
		self:OnPlayerSpawnFiretruck( pPlayer, entCar )
	elseif entCar.UID == self.FirstRespondID then
		self:OnPlayerSpawnFirstRespondCar( pPlayer, entCar )
	elseif entCar.UID == self.CrownVicID then
		self:OnPlayerSpawnFirstCV( pPlayer, entCar )
	else
		pPlayer:AddNote( "Your spawned your FD vehicle!" )
	end

	local color, groups = net.ReadColor(), net.ReadTable()
	entCar:SetColor( color )
	for k, v in pairs( groups ) do
		entCar:SetBodygroup( k, v )
	end	
end

GM.Net:RegisterEventHandle( "fd", "sp_c", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_FIREFIGHTER then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "fire_chief" then return end

	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, net.ReadString(), Job.CarSpawns, Job.ParkingGaragePos )
	if IsValid( car ) then
		Job:OnPlayerSpawnFDCar( pPlayer, car )
	end
end )

GM.Net:RegisterEventHandle( "fd", "st", function( intMsgLen, pPlayer )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_FIREFIGHTER then return end
	if not pPlayer:WithinTalkingRange() then return end
	if pPlayer:GetTalkingNPC().UID ~= "fire_chief" then return end

	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, Job.ParkingGaragePos )
end )

GM.Jobs:Register( Job )


--Player wants to spawn a first responder vehicle
--[[function Job:PlayerSpawnFirstRespondCar( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.FirstRespondID, self.CarSpawns, self.ParkingLotPos )
	if IsValid( car ) then
		self:OnPlayerSpawnFirstRespondCar( pPlayer, car )
	end
end

--Player wants to spawn a firetruck
function Job:PlayerSpawnFiretruck( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.FiretruckID, self.CarSpawns, self.ParkingGaragePos )
	if IsValid( car ) then
		self:OnPlayerSpawnFiretruck( pPlayer, car )
	end
end

--Player wants to spawn a rescue truck
function Job:PlayerSpawnRescueTruck( pPlayer )
	local car = GAMEMODE.Cars:PlayerSpawnJobCar( pPlayer, self.RescueTruckID, self.CarSpawns, self.ParkingGaragePos )
	if IsValid( car ) then
		self:OnPlayerSpawnRescueTruck( pPlayer, car )
	end
end

--Player wants to stow their firetruck
function Job:PlayerStowFiretruck( pPlayer )
	GAMEMODE.Cars:PlayerStowJobCar( pPlayer, self.ParkingGaragePos )
end]]--