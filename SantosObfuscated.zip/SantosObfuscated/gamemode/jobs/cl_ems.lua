--[[
	Name: ems.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "ems", 53 )

local Job = {}
Job.ID = 3
Job.HasMasterKeys = true
Job.Receives911Messages = true
Job.Enum = "JOB_EMS"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Paramedic"
Job.PlayerModel = {
	Male_Fallback = "models/player/portal/male_09_medic.mdl",
	Female_Fallback = "models/player/portal/male_09_medic.mdl",
	
	Male = {
		["male_01"] = "models/player/portal/male_01_medic.mdl",
		["male_02"] = "models/player/portal/male_02_medic.mdl",
		["male_03"] = "models/player/portal/male_03_medic.mdl",
		["male_04"] = "models/player/portal/male_04_medic.mdl",
		["male_05"] = "models/player/portal/male_05_medic.mdl",
		["male_06"] = "models/player/portal/male_06_medic.mdl",
		["male_07"] = "models/player/portal/male_07_medic.mdl",
		["male_08"] = "models/player/portal/male_08_medic.mdl",
		["male_09"] = "models/player/portal/male_09_medic.mdl",
	},
	Female = {
		["female_01"] = "models/player/portal/male_02_medic.mdl",
		["female_02"] = "models/player/portal/male_02_medic.mdl",
		["female_03"] = "models/player/portal/male_02_medic.mdl",
		["female_04"] = "models/player/portal/male_04_medic.mdl",
		["female_05"] = "models/player/portal/male_05_medic.mdl",
		["female_06"] = "models/player/portal/male_06_medic.mdl",
		["female_07"] = "models/player/portal/male_07_medic.mdl",
		["female_08"] = "models/player/portal/male_08_medic.mdl",
		["female_09"] = "models/player/portal/male_09_medic.mdl",
	},
}
Job.PlayerCap = GM.Config.Job_EMS_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.ParkingLotPos = GM.Config.EMSParkingZone
Job.CarSpawns = GM.Config.EMSCarSpawns
Job.FirstRespondID = "ems_firstrespond"
Job.AmbulanceID = "ems_ambulance"
Job.BedModel = "models/custommodels/stretcher.mdl" --"models/props_medicinalpractice/medic_stretcher_a.mdl"

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_EMS", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 5, "EMS", false )
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 6, "EMS Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 5
		Job.ChannelKeys = {
			[2] = true, --Police Encrypted
			[4] = true, --Fire Encrypted
			[6] = true, --EMS Encrypted
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_EMS then
		curCar:Remove()
	end
end

function Job:CalcHealPay( tblClipData )
	local total = 100--Max player health
	local cur = tblClipData.health
	for k, v in pairs( GAMEMODE.PlayerDamage:GetLimbs() ) do --Add up limb health, account for broken and bleeding limbs
		if not tblClipData.limbs[k] then continue end
		total = total +v.MaxHealth
		total = total +20 --10 for bleeding, 10 for broken

		cur = cur +tblClipData.limbs[k].Health
		cur = cur +(tblClipData.limbs[k].Bleeding and 0 or 10)
		cur = cur +(tblClipData.limbs[k].Broken and 0 or 10)
	end
	local scalar = math.Clamp( (total -cur) /total, 0, 1 ) --amount of damage, 0 - 1
	local pay = math.ceil( GAMEMODE.Config.EMSMaxHealPay *scalar )
	return pay
end

function GM.Net:RequestSpawnEMSCar( strJobCarID, colColor, tblBodygroups )
	self:NewEvent( "ems", "sp_c" )
		net.WriteString( strJobCarID )
		net.WriteColor( colColor or Color(255, 255, 255, 255) )
		net.WriteTable( tblBodygroups or {} )
	self:FireEvent()
end

function GM.Net:RequestStowEMSCar()
	self:NewEvent( "ems", "st" )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "ems", "clip", function( intMsgLen, pPlayer )
	local about = net.ReadEntity()
	local health = net.ReadUInt( 8 )

	local limbs = {}
	for k, v in pairs( GAMEMODE.PlayerDamage:GetLimbs() ) do
		limbs[net.ReadUInt( 8 )] = {
			Health = net.ReadUInt( 8 ),
			Bleeding = net.ReadBool(),
			Broken = net.ReadBool(),
		}
	end

	local wep = LocalPlayer():GetActiveWeapon()
	if IsValid( wep ) and wep:GetClass() == "weapon_ems_clipboard" then
		wep.m_tblHealthData	= {
			Limbs = limbs,
			Health = health,
			Target = about,
		}
	end

	g_LastEMSClipData = {
		player = about,
		health = health,
		limbs = limbs,
	}
	hook.Call( "GamemodeOnGetEMSClipboardData", GAMEMODE, g_LastEMSClipData )
end )

GM.Net:RegisterEventHandle( "ems", "clipr", function( intMsgLen, pPlayer )
	local wep = LocalPlayer():GetWeapon( "weapon_ems_clipboard" )
	if IsValid( wep ) then
		wep.m_tblHealthData	= {
			Limbs = {},
			Health = 0,
			Target = NULL,
		}
	end

	g_LastEMSClipData = nil
	hook.Call( "GamemodeOnGetEMSClipboardData", GAMEMODE, g_LastEMSClipData )
end )

function GM.Net:SendEMSBillRequest( strNotes )
	self:NewEvent( "ems", "billp" )
		net.WriteString( strNotes )
	self:FireEvent()
end

function GM.Net:SendEMSRecordRequest( pPlayer )
	self:NewEvent( "ems", "rdbd" )
		net.WriteEntity( pPlayer )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "ems", "sdbd", function( intMsgLen, pPlayer )
	local target = net.ReadEntity()
	local len = net.ReadUInt( 32 )
	local data = util.JSONToTable( util.Decompress(net.ReadData(len)) )
	if not data then return end

	local ret = {
		records = data,
		totalUnpaid = net.ReadUInt( 32 ),
		bills = {},
	}

	local numBills = net.ReadUInt( 16 )
	if numBills > 0 then
		for i = 1, numBills do
			ret.bills[net.ReadString()] = true
		end
	end
	
	hook.Call( "GamemodeOnGetEMSMedicalRecords", GAMEMODE, target, ret )
end )

GM.Jobs:Register( Job )



local RagCache = {}
hook.Add( "NetworkEntityCreated", "EMSCache", function( eEnt )
	if eEnt:GetClass() == "prop_ragdoll" then
		RagCache[eEnt] = true
	end
end )

hook.Add( "EntityRemoved", "EMSCache", function( eEnt )
	RagCache[eEnt] = nil
end )

local MAT_HEALTH_ICON = Material( "icon16/heart.png" )
hook.Add( "HUDPaint", "EMS_DrawDeadPlayers", function()
	if GAMEMODE.Jobs:GetPlayerJobID( LocalPlayer() ) ~= JOB_EMS then return end
	
	for k, v in pairs( player.GetAll() ) do
		if not (v:IsUncon() or not v:Alive()) or not IsValid( v:GetRagdoll() ) then continue end
		RagCache[v:GetRagdoll()] = v
	end

	for k, v in pairs( RagCache ) do
		if not IsValid( k ) then RagCache[k] = nil continue end
		
		local pos = k:GetPos():ToScreen()
		if type( v ) == "Player" then 
			local timeelapsed = CurTime() -(not v:Alive() and v:GetNWFloat("DeathStart") or v:GetNWFloat("StartDie"))
			draw.SimpleText(
				string.ToMinutesSeconds( (v:Alive() and 600 or 180) -timeelapsed ),
				"Trebuchet24",
				pos.x,
				pos.y,
				color_white,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_TOP
			)
			local num, unit = GAMEMODE.Util:ConvertUnitsToM( v:GetPos():Distance(LocalPlayer():GetPos()) )
			draw.SimpleText(
				num.. unit,
				"Trebuchet24",
				pos.x,
				pos.y +18,
				color_white,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_TOP
			)
		else
			local num, unit = GAMEMODE.Util:ConvertUnitsToM( k:GetPos():Distance(LocalPlayer():GetPos()) )
			draw.SimpleText(
				num.. unit,
				"Trebuchet24",
				pos.x,
				pos.y +18,
				color_white,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_TOP
			)
		end
		
		local iconSize = 16
		surface.SetMaterial( MAT_HEALTH_ICON )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect( pos.x -(iconSize /2), pos.y -iconSize, iconSize, iconSize )
	end
end )