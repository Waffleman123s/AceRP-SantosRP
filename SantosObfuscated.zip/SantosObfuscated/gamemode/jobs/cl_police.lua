--[[
	Name: police.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "police", 51 )

local Job = {}
Job.ID = 2
Job.Enum = "JOB_POLICE"
Job.Receives911Messages = true
Job.TeamColor = Color( 255, 0, 0, 255 )
Job.Name = "Police"
Job.WhitelistName = "police"
Job.PlayerModel = {
	Male_Fallback = "models/roro/police_male_2.mdl",
	Female_Fallback = "models/portal/player/female_police02.mdl",

	Male = {
		["male_01"] = "models/roro/police_male_1.mdl",
		["male_02"] = "models/roro/police_male_2.mdl",
		["male_03"] = "models/roro/police_male_3.mdl",
		["male_04"] = "models/roro/police_male_4.mdl",
		["male_05"] = "models/roro/police_male_5.mdl",
		["male_06"] = "models/roro/police_male_6.mdl",
		["male_07"] = "models/roro/police_male_7.mdl",
		["male_08"] = "models/roro/police_male_8.mdl",
		["male_09"] = "models/roro/police_male_9.mdl",
	},
	Female = {	
		["female_01"] = "models/portal/player/female_police02.mdl",
	},
}
-- Job.ClothingLockerExtraModels = {
-- 	["pmc_swat"] = {
-- 		Male_Fallback = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl", --"models/player/pmc_4/pmc__11.mdl",
-- 		Female_Fallback = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl", --"models/player/pmc_4/pmc__11.mdl",

-- 		Male = {
-- 		["male_01"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
-- 		},
-- 		Female = {
-- 		["female_01"] = "models/omgwtfbbq/Quantum_Break/Characters/Operators/MonarchOperator01PlayerModel.mdl",
-- 		},
-- 	},
-- }
Job.CanWearCivClothing = true
Job.PlayerCap = GM.Config.Job_Police_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.PoliceGaragePos = GM.Config.CopParkingZone
Job.CarSpawns = GM.Config.CopCarSpawns

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Police", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 1, "Police", false )
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 2, "Police Encrypted", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 1
		Job.ChannelKeys = {
			[2] = true, --Police Encrypted
			[4] = true, --Fire Encrypted
			[6] = true, --EMS Encrypted
		}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

function Job:GetPlayerModel( pPlayer, bUnModified )
	if pPlayer.m_bJobCivModelOverload and not bUnModified then
		return GAMEMODE.Jobs:GetJobByID( JOB_CIVILIAN ):GetPlayerModel( pPlayer )
	end

	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)

	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end

function GM.Net:RequestSpawnCopCar( strJobCarID, colColor, intSkin, tblBodygroups )
	self:NewEvent( "police", "sp_c" )
		net.WriteString( strJobCarID )
		net.WriteColor( colColor or Color(255, 255, 255, 255) )
		net.WriteUInt( intSkin or 0, 8 )
		net.WriteTable( tblBodygroups or {} )
	self:FireEvent()
end

function GM.Net:RequestStowCopCar()
	self:NewEvent( "police", "st" )
	self:FireEvent()
end

function GM.Net:SendCopImpoundRequest( pPlayer )
	self:NewEvent( "police", "gid" )
		net.WriteEntity( pPlayer )
	self:FireEvent()
end

function GM.Net:SendCopImpoundRelRequest( pPlayer, strCarUID )
	self:NewEvent( "police", "rid" )
		net.WriteEntity( pPlayer )
		net.WriteString( strCarUID )
	self:FireEvent()
end

GM.Net:RegisterEventHandle( "police", "sid", function( intMsgLen, pPlayer )
	local target = net.ReadEntity()
	local len = net.ReadUInt( 16 )
	local lst = {}
	if len > 0 then
		for i = 1, len do
			lst[#lst+1] = net.ReadString()
		end
	end
	hook.Call( "GamemodeOnGetCopImpoundRecords", GAMEMODE, target, lst )
end )

GM.Jobs:Register( Job )