--[[
	Name: mayor.lua
	For: SantosRP
	By: Ultra
]]--

GM.Net:AddProtocol( "mayor", 54 )

local Job = {}
Job.ID = 12
Job.Enum = "JOB_MAYOR"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Mayor"
Job.WhitelistName = "mayor"
Job.PlayerCap = { Min = 1, MinStart = 1, Max = 1, MaxEnd = 1 }
Job.PlayerModel = {
	Male_Fallback = "models/player/breen.mdl",
	Female_Fallback = "models/player/breen.mdl",

	Male = {
		["male_01"] = "models/player/breen.mdl",
		["male_02"] = "models/player/breen.mdl",
		["male_03"] = "models/player/breen.mdl",
		["male_04"] = "models/player/breen.mdl",
		["male_05"] = "models/player/breen.mdl",
		["male_06"] = "models/player/breen.mdl",
		["male_07"] = "models/player/breen.mdl",
		["male_08"] = "models/player/breen.mdl",
		["male_09"] = "models/player/breen.mdl",
	},
	Female = {
		["female_01"] = "models/player/breen.mdl",
	},
}
if PUBLIC_SERVER then
	Job.Pay = {
		{ PlayTime = 0, Pay = 6000 },
		{ PlayTime = 12 *(60 *60), Pay = 8500 },
		{ PlayTime = 24 *(60 *60), Pay = 9000 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 10000 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 16500 },
	}
else
	Job.Pay = {
		{ PlayTime = 0, Pay = 6000 },
		{ PlayTime = 12 *(60 *60), Pay = 8500 },
		{ PlayTime = 24 *(60 *60), Pay = 9000 },
		{ PlayTime = (24 *(60 *60)) *2, Pay = 10000 },
		{ PlayTime = (24 *(60 *60)) *7, Pay = 16500 },
	}
end

function Job:PlayerLoadout( pPlayer )
	pPlayer:Give( "dsr_megaphone" )
end

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Mayor", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 8, "Secret Service", true )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 8
		Job.ChannelKeys = {
			[8] = true,
		}
	end )
end

function Job:GetPlayerModel( pPlayer, bUnModified )
	if pPlayer.m_bJobCivModelOverload and not bUnModified then
		return GAMEMODE.Jobs:GetJobByID( JOB_CIVILIAN ):GetPlayerModel( pPlayer )
	end

	if pPlayer.m_strSelectedJobModelOverload and not bUnModified then
		return pPlayer.m_strSelectedJobModelOverload
	end

	local valid, mdl = GAMEMODE.Util:FaceMatchPlayerModel(
		GAMEMODE.Player:GetGameVar( pPlayer, "char_model_base", "" ),
		GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE,
		self.PlayerModel
	)

	if valid then
		return mdl
	else
		if GAMEMODE.Player:GetSharedGameVar( pPlayer, "char_sex", GAMEMODE.Char.SEX_MALE ) == GAMEMODE.Char.SEX_MALE then
			return self.PlayerModel.Male_Fallback
		else
			return self.PlayerModel.Female_Fallback
		end
	end
end

function Job:PlayerSetModel( pPlayer )
	pPlayer:SetModel( self:GetPlayerModel(pPlayer) )

	local selcSkin = pPlayer.m_bJobCivModelOverload and GAMEMODE.Player:GetGameVar( pPlayer, "char_skin", 0 ) or nil
	if not selcSkin then selcSkin = pPlayer.m_intSelectedJobModelSkin end
	pPlayer:SetSkin( selcSkin and selcSkin or 0 )

	if pPlayer.m_tblSelectedJobModelBGroups then
		for k, v in pairs( pPlayer:GetBodyGroups() ) do
			if pPlayer.m_tblSelectedJobModelBGroups[v.id] then
				if pPlayer.m_tblSelectedJobModelBGroups[v.id] > pPlayer:GetBodygroupCount( v.id ) -1 then continue end
				pPlayer:SetBodygroup( v.id, pPlayer.m_tblSelectedJobModelBGroups[v.id] )
			end
		end
	end
end


function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
	local curCar = GAMEMODE.Cars:GetCurrentPlayerCar( pPlayer )
	if curCar and curCar.Job and curCar.Job == JOB_SSERVICE then
		curCar:Remove()
	end
end

function Job:PlayerLoadout( pPlayer )
	if PRIVATE_SERVER then
		pPlayer:Give( "weapon_gspeak_radio_ss" )
	end
end

hook.Add( "GamemodeCanPlayerSetJob", "PermaMayor", function( pPlayer, intJobID )
	if intJobID ~= JOB_MAYOR and GAMEMODE.Jobs:IsPlayerWhitelisted( pPlayer, JOB_MAYOR ) then
		if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR then
			GAMEMODE.Jobs:SetPlayerJob( pPlayer, JOB_MAYOR )
		else
			pPlayer:AddNote( "You may not have another job as mayor!" )
		end
		
		return false
	end
end )

hook.Add( "GamemodeBuildPlayerComputerApps", "AutoInstallMayorApps", function( pPlayer, entComputer, tblApps )
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR then return end
	tblApps["turbotax97.exe"] = GAMEMODE.Apps:GetComputerApp( "turbotax97.exe" )
	tblApps["nsa.exe"] = GAMEMODE.Apps:GetComputerApp( "nsa.exe" )
end )

GM.Net:RegisterEventHandle( "mayor", "updt", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["turbotax97.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end
	if pPlayer.m_intLastTaxUpdated or 0 > CurTime() then return end
	pPlayer.m_intLastTaxUpdated = CurTime() +2

	local id, val = net.ReadString(), math.Round( net.ReadFloat(), 2 )
	if GAMEMODE.Econ:SetTaxRate( id, val ) then
		GAMEMODE.Econ:CommitTaxData()
	end
end )

GM.Net:RegisterEventHandle( "mayor", "updtb", function( intMsgLen, pPlayer )
	if not pPlayer:IsUsingComputer() then return end
	if not pPlayer:GetActiveComputer():GetInstalledApps()["turbotax97.exe"] then return end
	if GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_MAYOR and GAMEMODE.Jobs:GetPlayerJobID( pPlayer ) ~= JOB_DEPUTY_MAYOR then return end
	pPlayer.m_intLastTaxUpdated = CurTime() +2

	local num = net.ReadUInt( 8 )
	if num <= 0 then return end
	local ids = {}

	for i = 1, num do
		local id, val = net.ReadString(), math.Round( net.ReadFloat(), 2 )

		if GAMEMODE.Econ:SetTaxRate( id, val, true ) then
			ids[id] = true
		end
	end

	GAMEMODE.Net:SendTaxUpdateBatch( nil, ids )
	GAMEMODE.Econ:CommitTaxData()
end )

GM.Jobs:Register( Job )