--[[
	Name: josh.lua
	For: SantosRP
	By: Turtle
]]--

local Job = {}
Job.ID = 89
Job.Enum = "JOB_JOSH"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Reporter"
Job.WhitelistName = "josh"
Job.PlayerCap = GM.Config.Job_Lawyer_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

GM.Jobs:Register( Job )