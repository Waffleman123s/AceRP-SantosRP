--[[
	Name: towtruck.lua
	For: SantosRP
	By: Ultra
]]--

local Job = {}
Job.ID = 6
Job.Enum = "JOB_TOW"
Job.TeamColor = Color( 255, 100, 160, 255 )
Job.Name = "Tow Truck Driver"
Job.PlayerCap = GM.Config.Job_Tow_PlayerCap or { Min = 2, MinStart = 8, Max = 6, MaxEnd = 60 }
Job.ParkingLotPos = GM.Config.TowParkingZone
Job.TruckSpawns = GM.Config.TowCarSpawns
Job.TruckID = "tow_truck"
Job.FlatbedID = "tow_flatbed"

if not PRIVATE_SERVER then
	hook.Add( "Initialize", "GamemodeInitJob_Tow", function()
		GAMEMODE.Module:GetModule( "Chat Radios" ):RegisterChannel( 7, "Tow Services", false )
		Job.HasChatRadio = true
		Job.DefaultChatRadioChannel = 7
		Job.ChannelKeys = {}
	end )
end

function Job:OnPlayerJoinJob( pPlayer )
end

function Job:OnPlayerQuitJob( pPlayer )
end

do
	local function carThread( tblPlayers )
		local ret = {}
		for k, v in pairs( tblPlayers ) do
			if IsValid( v ) then
				local car = GAMEMODE.Cars:GetCurrentPlayerCar( v )
				if IsValid( car ) and car:GetNWBool( "impound" ) then
					ret[car] = true
				end
			end
			coroutine.yield()
		end
		return ret
	end

	local thread, vehCache = nil, {}
	local function updateCars()
		local new
		if not thread then
			thread = coroutine.create( carThread )
			new = true
		end

		local status = coroutine.status( thread )
		if status == "dead" then
			thread = nil
		else
			b, ret = coroutine.resume( thread, new and player.GetAll() or nil )
			if not b and ret then
				thread = nil
			else
				if ret and istable( ret ) then
					vehCache = ret
				end
			end
		end
	end

	hook.Add( "Tick", "Tow_UpdateCars", function()
		if not IsValid( LocalPlayer() ) or not LocalPlayer().Team then return end
		if GAMEMODE.Jobs:GetPlayerJobID( LocalPlayer() ) ~= JOB_TOW then return end
		updateCars()
	end )
	
	hook.Add( "HUDPaint", "Tow_DrawImpoundCar", function()
		if not IsValid( LocalPlayer() ) or not LocalPlayer().Team then return end
		if GAMEMODE.Jobs:GetPlayerJobID( LocalPlayer() ) ~= JOB_TOW then return end
		
		for k, v in pairs( vehCache ) do
			if not IsValid( k ) or not k:GetNWBool( "impound" ) then continue end
			if k:GetPos():Distance( LocalPlayer():GetPos() ) > 200 then continue end
			
			local pos = k:LocalToWorld(k:OBBCenter()):ToScreen()
			draw.SimpleText(
				"VEHICLE WANTED FOR IMPOUND",
				"DermaDefault",
				pos.x,
				pos.y,
				color_white,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_CENTER
			)
		end
	end )
end

GM.Jobs:Register( Job )