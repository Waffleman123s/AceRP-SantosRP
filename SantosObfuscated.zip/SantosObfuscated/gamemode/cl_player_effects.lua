--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--

GM.PlayerEffects = {}
GM.PlayerEffects.m_tblRegister = {}
GM.PlayerEffects.m_tblCurEffects = {}

function GM.PlayerEffects:Load()
	GM:PrintDebug( 0, "->LOADING PLAYER EFFECTS" )

	local foundFiles, foundFolders = file.Find( GM.Config.GAMEMODE_PATH.. "effects/*.lua", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )
		include( GM.Config.GAMEMODE_PATH.. "effects/".. v )
	end

	GM:PrintDebug( 0, "->PLAYER EFFECTS LOADED" )
end

function GM.PlayerEffects:Register( tblEffect )
	self.m_tblRegister[tblEffect.ID] = tblEffect
	if tblEffect.Setup then
		tblEffect:Setup()
	end
end

function GM.PlayerEffects:GetEffect( strEffectID )
	return self.m_tblRegister[strEffectID]
end

function GM.PlayerEffects:GetPlayerEffects()
	return self.m_tblCurEffects
end

function GM.PlayerEffects:GamemodeEditInventorySize( tblData )
	for k, v in pairs( self.m_tblCurEffects ) do
		if self.m_tblRegister[k].GamemodeEditInventorySize then
			self.m_tblRegister[k]:GamemodeEditInventorySize( tblData )
		end
	end
end

function GM.PlayerEffects:RenderScreenspaceEffects()
	for k, v in pairs( self.m_tblCurEffects ) do
		if self.m_tblRegister[k].RenderScreenspaceEffects then
			self.m_tblRegister[k]:RenderScreenspaceEffects()
		end
	end
end

function GM.PlayerEffects:SetupMove( ... )
	for k, v in pairs( self.m_tblCurEffects ) do
		if self.m_tblRegister[k].SetupMove then
			self.m_tblRegister[k]:SetupMove( ... )
		end
	end
end

function GM.PlayerEffects:CreateMove( ... )
	for k, v in pairs( self.m_tblCurEffects ) do
		if self.m_tblRegister[k].CreateMove then
			self.m_tblRegister[k]:CreateMove( ... )
		end
	end
end

function GM.PlayerEffects:Tick()
	for k, v in pairs( self.m_tblCurEffects ) do
		if self.m_tblRegister[k].Tick then
			self.m_tblRegister[k]:Tick()
		end
	end
end

function GM.PlayerEffects:GetMotionBlurValues( intW, intH, intForward, intRot )
	local changed, a, b, c, d
	for k, v in pairs( self:GetPlayerEffects() ) do
		if self.m_tblRegister[k].GetMotionBlurValues then
			a, b, c, d = self.m_tblRegister[k]:GetMotionBlurValues( intW, intH, intForward, intRot )
			intW = intW +a
			intH = intH +b
			intForward = intForward +c
			intRot = intRot +d
			changed = true
		end
	end

	if not changed then return end
	return intW, intH, math.min( intForward, 0.5 ), math.Clamp( intRot, -90, 90 )
end

function GM.PlayerEffects:AddEffect( strEffectID, intTime, intDur, bIgnoreOnStart )
	self.m_tblCurEffects[strEffectID] = { intTime, intDur }

	--Call OnStart()
	if not bIgnoreOnStart then
		self:GetEffect( strEffectID ):OnStart( LocalPlayer() )
	end

	hook.Call( "GamemodeOnNewActiveEffect", GAMEMODE, strEffectID, intTime, intDur, bIgnoreOnStart )
end

function GM.PlayerEffects:UpdateEffectDuration( strEffectID, intTime, intDur )
	if not self.m_tblCurEffects[strEffectID] then return end

	self.m_tblCurEffects[strEffectID] = { intTime, intDur }

	--Remove it, duration zero
	if self.m_tblCurEffects[strEffectID][2] <= 0 then
		self:ClearEffect( strEffectID )
		return
	end

	hook.Call( "GamemodeOnActiveEffectUpdate", GAMEMODE, strEffectID, intTime, intDur )
end

function GM.PlayerEffects:GetEffectDuration( strEffectID )
	local delta = CurTime() -self.m_tblCurEffects[strEffectID][1]
	return math.max( self.m_tblCurEffects[strEffectID][2] -delta, 0 )
end

function GM.PlayerEffects:ClearEffect( strEffectID, bIgnoreOnStop )
	if not self.m_tblCurEffects[strEffectID] then return end

	--Remove effect from tracking
	self.m_tblCurEffects[strEffectID] = nil

	--Call OnStop()
	if not bIgnoreOnStop then
		self:GetEffect( strEffectID ):OnStop( LocalPlayer() )
	end

	hook.Call( "GamemodeOnActiveEffectRemoved", GAMEMODE, strEffectID )
end

function GM.PlayerEffects:ClearAll()
	if table.Count( self.m_tblCurEffects ) <= 0 then return end
	
	--Call OnStop()
	for k, v in pairs( self.m_tblCurEffects ) do
		self:GetEffect( k ):OnStop( LocalPlayer() )
	end

	--Remove all effects
	table.Empty( self.m_tblCurEffects )

	hook.Call( "GamemodeOnAllActiveEffectsRemoved", GAMEMODE )
end

function GM.PlayerEffects:GetDuration( pPlayer, strEffectID )
	return self.m_tblCurEffects[strEffectID] and (self.m_tblCurEffects[strEffectID][2] or 0) or 0
end

function GM.PlayerEffects:HasEffect( pPlayer, strEffectID )
	return self.m_tblCurEffects[strEffectID] and true
end