--[[
	Name: sh_eating_drain.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Draining Hunger"
Effect.Icon48 = "santosrp/ae_icons/Starvation 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Starvation 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {},
	Drains = {
		["Hunger"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_Hunger_Drain = CurTime()
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		self:LazyTick( pPlayer ) --Force 1 last tick
		pPlayer.m_intLastFX_Hunger_Drain = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if not pPlayer.m_intLastFX_Hunger_Drain then return end
		if CurTime() > pPlayer.m_intLastFX_Hunger_Drain +1 then
			local delta = CurTime() -pPlayer.m_intLastFX_Hunger_Drain
			local frac, numSecs = delta %1, math.floor( delta )
			pPlayer.m_intLastFX_Hunger_Drain = CurTime() -frac
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Hunger", 8 *numSecs )
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )