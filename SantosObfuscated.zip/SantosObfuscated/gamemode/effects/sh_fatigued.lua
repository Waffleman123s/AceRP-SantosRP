--[[
	Name: sh_fatigued.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Fatigued"
Effect.Icon48 = "santosrp/ae_icons/Fatigued 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Fatigued 18x18.png"
Effect.ExhaustedVal = 45
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Fatigued", -15, -25 )
		pPlayer.m_intLastFX_FatigStart = CurTime() +self.ExhaustedVal
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Fatigued" )
		pPlayer.m_intLastFX_FatigStart = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_FatigStart or 0) +self.ExhaustedVal then
			pPlayer.m_intLastFX_FatigStart = CurTime()
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Exhausted", 60 )
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )