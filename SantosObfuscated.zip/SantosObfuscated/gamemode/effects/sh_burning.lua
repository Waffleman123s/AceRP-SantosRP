--[[
	Name: sh_burning.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Burning"
Effect.Icon48 = "santosrp/ae_icons/Burning 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Burning 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
		["Stamina"] = 3,
		["Health"] = 3,
	}
}

function Effect:Setup()
	if CLIENT then return end
	hook.Add( "GamemodeOnEntityIgnite", "IgniteEffect", function( eEnt, intLen )
		if not IsValid( eEnt ) then return end
		if not eEnt:IsPlayer() or not intLen then return end
		GAMEMODE.PlayerEffects:ClearEffect( eEnt, "Burning" )
		GAMEMODE.PlayerEffects:AddEffect( eEnt, "Burning", intLen, nil, nil, true )
	end )

	hook.Add( "GamemodeOnEntityExtinguish", "IgniteEffect", function( eEnt )
		if not IsValid( eEnt ) or not eEnt:IsPlayer() then return end
		GAMEMODE.PlayerEffects:ClearEffect( eEnt, "Burning" )
	end )
end

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Burning", -100, -100 )
	end
end

function Effect:OnStop( pPlayer )
	pPlayer.m_intLastFX_Burning = nil
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Burning" )
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, strNeedID, 2 )
		end
	end

	function Effect:LazyTick( pPlayer )
		if pPlayer:IsUncon() then return end
		if CurTime() > (pPlayer.m_intLastFX_Burning or 0) then
			pPlayer.m_intLastFX_Burning = CurTime() +math.random( 4, 6 )
			GAMEMODE.Util:PlayerEmitSound( pPlayer, "Pain" )
		end
	end
elseif CLIENT then
	function Effect:Tick()
		if CurTime() > (LocalPlayer().m_intLastFX_Burning or 0) then
			LocalPlayer().m_intLastFX_Burning = CurTime() +math.random( 4, 6 )
			RunConsoleCommand( "act", "zombie" )
		end
	end
end

GM.PlayerEffects:Register( Effect )