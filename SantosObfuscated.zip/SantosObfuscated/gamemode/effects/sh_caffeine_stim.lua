--[[
	Name: sh_caffeine_stim.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Caffeine Stimulation"
Effect.Icon48 = "santosrp/ae_icons/Caffeine Stimulation 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Caffeine Stimulation 18x18.png"
Effect.MaxDuration = 60 *3
Effect.Effects = {
	Gains = {
		["Stamina"] = 1,
		["Move Speed"] = 1,
	},
	Drains = {}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_GenCaffeineStim = CurTime()
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:CaffeineStim", 20, 40 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		self:LazyTick( pPlayer ) --Force 1 last tick
		pPlayer.m_intLastFX_GenCaffeineStim = nil
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:CaffeineStim" )
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if not pPlayer.m_intLastFX_GenCaffeineStim then return end
		if CurTime() > (pPlayer.m_intLastFX_GenCaffeineStim or 0) +2 then
			pPlayer.m_intLastFX_GenCaffeineStim = CurTime()
			GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Stamina", 1 )
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )