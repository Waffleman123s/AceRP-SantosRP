--[[
	Name: sh_drinking_drain.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Draining Thirst"
Effect.Icon48 = "santosrp/ae_icons/Thirst 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Thirst 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {},
	Drains = {
		["Thirst"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_Drinking_Drain = CurTime()
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		self:LazyTick( pPlayer ) --Force 1 last tick
		pPlayer.m_intLastFX_Drinking_Drain = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if not pPlayer.m_intLastFX_Drinking_Drain then return end
		if CurTime() > pPlayer.m_intLastFX_Drinking_Drain +1 then
			--Compute the delta time since we last ran
			local delta = CurTime() -pPlayer.m_intLastFX_Drinking_Drain
			--Get the full number of seconds in our delta, and split out the fraction component
			local frac, numSecs = delta %1, math.floor( delta )

			--Set our last time to the current time minus our fraction of the next second
			--We effectively compute the delta for an exact amount of seconds,
			--even if we don't run in perfect 1 second intervals (We 'lie' about when the calculation happens)
			pPlayer.m_intLastFX_Drinking_Drain = CurTime() -frac
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Thirst", 8 *numSecs )
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )