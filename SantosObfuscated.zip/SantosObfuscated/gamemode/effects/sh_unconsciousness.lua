--[[
	Name: sh_unconsciousness.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Unconsciousness"
Effect.Icon48 = "santosrp/ae_icons/unconciousness 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/unconciousness 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )

end

function Effect:OnStop( pPlayer )

end

if SERVER then
	function Effect:GamemodeOnPlayerClearUncon( pPlayer )
		GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )