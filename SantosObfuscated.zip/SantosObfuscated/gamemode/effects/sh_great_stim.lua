--[[
	Name: sh_great_stim.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Great Amphetamine Stimulation"
Effect.Icon48 = "santosrp/ae_icons/Great Amphetamine Stimulation 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Great Amphetamine Stimulation 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {
		["Stamina"] = 3,
		["Move Speed"] = 3,
		["Carry Weight"] = 2,
		["Carry Volume"] = 2,
		["Taser Immunity"] = 1,
	},
	Drains = {
		["Thirst"] = 3,
		["Hunger"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		self:Cough( pPlayer )

		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] ~= self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, self.PacOutfit )
		end

		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:GreatStim", 45, 70 )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] == self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, "" )
		end

		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:GreatStim" )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

if SERVER then
	function Effect:Cough( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		pPlayer:EmitSound( "ambient/voices/cough".. math.random(1, 4)..".wav", 75, 95 )
		pPlayer:ViewPunch( Angle(math.random(6, 12), 0, 0) )
	end

	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID ~= "Stamina" then return end
		tblVal[1] = tblVal[1] +15
	end

	function Effect:GamemodeEditNeedDecay( pPlayer, strNeedID, tblVal )
		if strNeedID == "Thirst" then
			tblVal[1] = tblVal[1] +25
		elseif strNeedID == "Hunger" then
			tblVal[1] = tblVal[1] +15
		end
	end

	function Effect:GamemodeEditInventorySize( pPlayer, tblData )
		tblData[1] = tblData[1] +150
		tblData[2] = tblData[2] +150
	end

	function Effect:GamemodeCanTasePlayer( pPlayer )
		return false
	end
elseif CLIENT then

	function Effect:GamemodeEditInventorySize( tblData )
		tblData[1] = tblData[1] +150
		tblData[2] = tblData[2] +150
	end

	function Effect:RenderScreenspaceEffects()
		local speed = 5

		DrawBloom(
			0.45 +math.cos(RealTime() *speed +0.1) *0.1,  --dark
			1,    --mul
			0.2,  --x
			0.2,  --y
			2,    --pass
			2,  --col mul
			1,  --r
			1,  --g
			1   --b
		)

		DrawSharpen( (math.sin(RealTime() *speed) *4) +4, 0.15 )
	end

	--[[function Effect:GetMotionBlurValues( intW, intH, intForward, intRot )
		return intW, intH, intForward +((math.sin( CurTime() ) *0.25) +0.25), intRot
	end]]--
end

Effect.PacOutfit = "drug_meth"
Effect.PacOutfitSlot = {
	Name = "int_drug_meth",
	Data = {
		Type = "GAMEMODE_INTERNAL_PAC_ONLY",
		Internal = true,
		KeepOnDeath = false,
		PacEnabled = true,
	},
}

GM.PlayerEffects:Register( Effect )