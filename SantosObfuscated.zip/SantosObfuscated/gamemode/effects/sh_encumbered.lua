--[[
	Name: sh_encumbered.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Over Encumbered"
Effect.Icon48 = "santosrp/ae_icons/Over Encumbered 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Over Encumbered 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Encumbered", -1e9, -1e9 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Encumbered" )
	end
end

if SERVER then

elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )