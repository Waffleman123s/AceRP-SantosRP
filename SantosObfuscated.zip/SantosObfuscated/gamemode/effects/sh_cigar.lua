--[[
	Name: sh_cigar.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Cigar Smoking"
Effect.Icon48 = "santosrp/ae_icons/Hunter Wrynn Disease 48x48.png"
Effect.Icon18 = "santosrp/ae_icons/Hunter Wrynn Disease 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {
		["Cool Factor"] = 1,
	},
	Drains = {
		["Smoker's Cough"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] ~= self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, self.PacOutfit )
		end
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] == self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, "" )
		end

		pPlayer.m_intLastFX_CigarCough = nil
	end
end

if SERVER then
	function Effect:Cough( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		pPlayer:EmitSound( "ambient/voices/cough".. math.random(1, 4)..".wav", 75, 95 )
		pPlayer:ViewPunch( Angle(math.random(6, 12), 0, 0) )
	end

	function Effect:LazyTick( pPlayer )
		if CurTime() > (pPlayer.m_intLastFX_CigarCough or 0) then
			if math.random( 1, 3 ) == 1 then
				self:Cough( pPlayer )
			end

			pPlayer.m_intLastFX_CigarCough = CurTime() +math.random( 60, 120 )
		end
	end
end

Effect.PacOutfit = "drug_cigar"
Effect.PacOutfitSlot = {
	Name = "int_drug_cigar",
	Data = {
		Type = "GAMEMODE_INTERNAL_PAC_ONLY",
		Internal = true,
		KeepOnDeath = false,
		PacEnabled = true,
	},
}
GM.Inv:RegisterEquipSlot( Effect.PacOutfitSlot.Name, Effect.PacOutfitSlot.Data )

GM.PacModels:Register( Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 6,
					["UniqueID"] = "419367293",
					["StickToSurface"] = false,
					["EndSize"] = 35,
					["Material"] = "particle/particle_smokegrenade1",
					["AirResistance"] = 30,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(1.4326171875, -7.712890625, 0.03564453125),
					["Sliding"] = false,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["DieTime"] = 8,
					["ClassName"] = "particles",
					["OwnerVelocityMultiplier"] = 0.01,
					["FireDelay"] = 25,
					["Gravity"] = Vector(0, 0, 2),
					["Angles"] = Angle(-3.7012421671534e-005, -66.997940063477, -2.2321513824863e-005),
					["StartSize"] = 1,
					["RollDelta"] = -0.1,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "145926232",
							["Name"] = "band",
							["Scale"] = Vector(1, 1, 0.40000000596046),
							["Material"] = "models/props_c17/furniturefabric001a",
							["Size"] = 0.228,
							["Position"] = Vector(0, -0.0020000000949949, -1),
							["Angles"] = Angle(-4.2688685653047e-007, 12.39999961853, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "4096653763",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2835220303",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["Model"] = "models/props_docks/dock01_pole01a_128.mdl",
							["ClassName"] = "model",
							["Size"] = 0.05,
							["EditorExpand"] = true,
							["Position"] = Vector(0.00030517578125, -0.00390625, 2.434326171875),
							["Material"] = "models/props_canal/rock_riverbed01a",
							["Brightness"] = 0.8,
							["Angles"] = Angle(-4.2688685653047e-007, -9.6049541298271e-007, 0),
						},
					},
				},
				["self"] = {
					["UniqueID"] = "4272946858",
					["Name"] = "stogie",
					["Scale"] = Vector(1, 1, 0.69999998807907),
					["EditorExpand"] = true,
					["Size"] = 0.05,
					["ClassName"] = "model",
					["Angles"] = Angle(-4.2688685653047e-007, -9.6049541298271e-007, 108.96017456055),
					["Position"] = Vector(0.6483154296875, -7.52734375, -1.169921875),
					["Model"] = "models/props_docks/dock01_pole01a_128.mdl",
					["Material"] = "models/props_pipes/GutterMetal01a",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1237277158",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )

GM.PacModels:Register( "female_".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 6,
					["UniqueID"] = "419367293",
					["StickToSurface"] = false,
					["EndSize"] = 35,
					["Material"] = "particle/particle_smokegrenade1",
					["AirResistance"] = 30,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(1.4326171875, -7.712890625, 0.03564453125),
					["Sliding"] = false,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["DieTime"] = 8,
					["ClassName"] = "particles",
					["OwnerVelocityMultiplier"] = 0.01,
					["FireDelay"] = 25,
					["Gravity"] = Vector(0, 0, 2),
					["Angles"] = Angle(-3.7012421671534e-005, -66.997940063477, -2.2321513824863e-005),
					["StartSize"] = 1,
					["RollDelta"] = -0.1,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "145926232",
							["Name"] = "band",
							["Scale"] = Vector(1, 1, 0.40000000596046),
							["Material"] = "models/props_c17/furniturefabric001a",
							["Size"] = 0.19,
							["Position"] = Vector(0, -0.0020000000949949, -1),
							["Angles"] = Angle(-4.2688685653047e-007, 12.39999961853, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "4096653763",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2835220303",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["Model"] = "models/props_docks/dock01_pole01a_128.mdl",
							["ClassName"] = "model",
							["Size"] = 0.04,
							["EditorExpand"] = true,
							["Position"] = Vector(-0.001953125, -0.001953125, 1.951416015625),
							["Material"] = "models/props_canal/rock_riverbed01a",
							["Brightness"] = 0.8,
							["Angles"] = Angle(-4.2688685653047e-007, -9.6049541298271e-007, 0),
						},
					},
				},
				["self"] = {
					["UniqueID"] = "4272946858",
					["Name"] = "stogie",
					["Scale"] = Vector(1, 1, 0.69999998807907),
					["EditorExpand"] = true,
					["Size"] = 0.04,
					["ClassName"] = "model",
					["Angles"] = Angle(-0, 5.069281314718e-007, 110.72737121582),
					["Position"] = Vector(0.09130859375, -7.23193359375, -1.07421875),
					["Model"] = "models/props_docks/dock01_pole01a_128.mdl",
					["Material"] = "models/props_pipes/GutterMetal01a",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1237277158",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitModelOverload( Effect.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Effect.PacOutfit )

GM.PacModels:Register( "m04".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "4096653763",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2835220303",
							["Name"] = "ash",
							["Scale"] = Vector(1, 1, 0.10000000149012),
							["Model"] = "models/props_docks/dock01_pole01a_128.mdl",
							["ClassName"] = "model",
							["Size"] = 0.05,
							["EditorExpand"] = true,
							["Position"] = Vector(0.00030517578125, -0.00390625, 2.434326171875),
							["Material"] = "models/props_canal/rock_riverbed01a",
							["Brightness"] = 0.8,
							["Angles"] = Angle(-4.2688685653047e-007, -9.6049541298271e-007, 0),
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["UniqueID"] = "145926232",
							["Name"] = "band",
							["Scale"] = Vector(1, 1, 0.40000000596046),
							["Material"] = "models/props_c17/furniturefabric001a",
							["Size"] = 0.228,
							["Position"] = Vector(0, -0.0020000000949949, -1),
							["Angles"] = Angle(-4.2688685653047e-007, 12.39999961853, 0),
							["Model"] = "models/props_junk/PopCan01a.mdl",
							["ClassName"] = "model",
						},
					},
				},
				["self"] = {
					["UniqueID"] = "4272946858",
					["Name"] = "stogie",
					["Scale"] = Vector(1, 1, 0.69999998807907),
					["EditorExpand"] = true,
					["Size"] = 0.05,
					["ClassName"] = "model",
					["Angles"] = Angle(-0, 5.069281314718e-007, 110.72737121582),
					["Position"] = Vector(1.2124633789063, -7.20068359375, -1.06591796875),
					["Model"] = "models/props_docks/dock01_pole01a_128.mdl",
					["Material"] = "models/props_pipes/GutterMetal01a",
				},
			},
			[2] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 6,
					["UniqueID"] = "419367293",
					["StickToSurface"] = false,
					["EndSize"] = 35,
					["Material"] = "particle/particle_smokegrenade1",
					["AirResistance"] = 30,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(1.4326171875, -7.712890625, 0.03564453125),
					["Sliding"] = false,
					["Lighting"] = false,
					["AlignToSurface"] = false,
					["DieTime"] = 8,
					["ClassName"] = "particles",
					["OwnerVelocityMultiplier"] = 0.01,
					["FireDelay"] = 25,
					["Gravity"] = Vector(0, 0, 2),
					["Angles"] = Angle(-3.7012421671534e-005, -66.997940063477, -2.2321513824863e-005),
					["StartSize"] = 1,
					["RollDelta"] = -0.1,
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1237277158",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitFaceIDOverload( Effect.PacOutfit, "male_04", "m04".. Effect.PacOutfit )

GM.PlayerEffects:Register( Effect )