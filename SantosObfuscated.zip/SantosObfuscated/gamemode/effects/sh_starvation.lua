--[[
	Name: sh_starvation.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Starvation"
Effect.Icon48 = "santosrp/ae_icons/Starvation 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Starvation 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 2,
		["Stamina"] = 3,
		["Health"] = 3,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Starvation", -20, -40 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Starvation" )
		pPlayer.m_intLastFX_StarvationHealthDecay = nil
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID == "Stamina" then
			tblVal[1] = tblVal[1] -1e9
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, strNeedID, 2 )
		end
	end

	function Effect:LazyTick( pPlayer )
		if GAMEMODE.Jail:IsPlayerInJail( pPlayer ) or pPlayer:IsUncon() then return end
		if CurTime() > (pPlayer.m_intLastFX_StarvationHealthDecay or 0) then
			pPlayer:SetHealth( math.max(pPlayer:Health() -3, 0) )
			pPlayer.m_intLastFX_StarvationHealthDecay = CurTime() +1

			if pPlayer:Health() <= 0 then
				pPlayer:GoUncon()
			end
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )