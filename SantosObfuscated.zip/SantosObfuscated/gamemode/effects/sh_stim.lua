--[[
	Name: sh_stim.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Mild Amphetamine Stimulation"
Effect.Icon48 = "santosrp/ae_icons/Mild Amphetamine Stimulation 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Mild Amphetamine Stimulation 18x18.png"
Effect.MaxDuration = 60 *10
Effect.EfForwardScale = 0.33
Effect.Effects = {
	Gains = {
		["Stamina"] = 2,
		["Move Speed"] = 2,
		["Carry Weight"] = 1,
		["Carry Volume"] = 1,
	},
	Drains = {
		["Thirst"] = 2,
		["Hunger"] = 1,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )["Great Amphetamine Stimulation"]
	if data or intDuration > self.MaxDuration then
		if GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID] then
			GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
		end

		if not bNoAutoForward then
			if GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Great Amphetamine Stimulation", intDuration *self.EfForwardScale ) then
				return false, true
			end
		else
			return false, GAMEMODE.PlayerEffects:GetEffect( "Great Amphetamine Stimulation" ):CanGive( pPlayer, intDuration *self.EfForwardScale )
		end

		return false
	end

	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		if not bNoAutoForward then
			if GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Great Amphetamine Stimulation", ((data[2] -(CurTime() -data[1])) +intDuration) *self.EfForwardScale ) then
				GAMEMODE.PlayerEffects:ClearEffect( pPlayer, self.ID )
				return false, true
			end
		else
			return false, GAMEMODE.PlayerEffects:GetEffect( "Great Amphetamine Stimulation" ):CanGive( pPlayer, ((data[2] -(CurTime() -data[1])) +intDuration) *self.EfForwardScale )
		end

		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		self:Cough( pPlayer )

		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] ~= self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, self.PacOutfit )
		end

		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Stim", 30, 50 )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		if pPlayer:GetEquipment()[self.PacOutfitSlot.Name] == self.PacOutfit then
			GAMEMODE.Inv:SetPlayerEquipSlotValue( pPlayer, self.PacOutfitSlot.Name, "" )
		end

		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Stim" )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

if SERVER then
	function Effect:Cough( pPlayer )
		if not pPlayer:Alive() or pPlayer:IsRagdolled() then return end
		
		pPlayer:EmitSound( "ambient/voices/cough".. math.random(1, 4)..".wav", 75, 95 )
		pPlayer:ViewPunch( Angle(math.random(6, 12), 0, 0) )
	end

	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID ~= "Stamina" then return end
		tblVal[1] = tblVal[1] +8
	end

	function Effect:GamemodeEditNeedDecay( pPlayer, strNeedID, tblVal )
		if strNeedID == "Thirst" then
			tblVal[1] = tblVal[1] +15
		elseif strNeedID == "Hunger" then
			tblVal[1] = tblVal[1] +5
		end
	end

	function Effect:GamemodeEditInventorySize( pPlayer, tblData )
		tblData[1] = tblData[1] +50
		tblData[2] = tblData[2] +50
	end

elseif CLIENT then

	function Effect:GamemodeEditInventorySize( tblData )
		tblData[1] = tblData[1] +50
		tblData[2] = tblData[2] +50
	end

	function Effect:RenderScreenspaceEffects()
		local speed = 4

		DrawBloom(
			0.5 +math.cos(RealTime() *speed +0.1) *0.1,  --dark
			1,    --mul
			0.2,  --x
			0.2,  --y
			2,    --pass
			2,  --col mul
			1,  --r
			1,  --g
			1   --b
		)

		DrawSharpen( (math.sin(RealTime() *speed) *3) +3, 0.15 )
	end

	--[[function Effect:GetMotionBlurValues( intW, intH, intForward, intRot )
		return intW, intH, intForward +((math.sin( CurTime() ) *0.15) +0.15), intRot
	end]]--
end

Effect.PacOutfit = "drug_meth"
Effect.PacOutfitSlot = {
	Name = "int_drug_meth",
	Data = {
		Type = "GAMEMODE_INTERNAL_PAC_ONLY",
		Internal = true,
		KeepOnDeath = false,
		PacEnabled = true,
	},
}
GM.Inv:RegisterEquipSlot( Effect.PacOutfitSlot.Name, Effect.PacOutfitSlot.Data )

GM.PacModels:Register( Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 2,
					["UniqueID"] = "3860556725",
					["EndSize"] = 30,
					["Material"] = "particle/particle_smokegrenade",
					["NumberParticles"] = 2,
					["AirResistance"] = 10,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.81370544433594, -6.7429809570313, 0.00140380859375),
					["Sliding"] = false,
					["Lighting"] = false,
					["FireDelay"] = 22,
					["DieTime"] = 10,
					["ClassName"] = "particles",
					["Bounce"] = 0,
					["Spread"] = 0.4,
					["Gravity"] = Vector(0, 0, 1),
					["Angles"] = Angle(7.8120283433236e-005, -87.789237976074, -2.5506487872917e-005),
					["StartSize"] = 0,
					["RollDelta"] = -0.2,
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-90, 0, 0),
							["ClassName"] = "clip",
							["UniqueID"] = "2985885681",
							["Position"] = Vector(-0.0020904541015625, 0.00567626953125, -2.2859497070313),
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(0, 180, 0),
									["ClassName"] = "clip",
									["UniqueID"] = "2566512536",
									["Position"] = Vector(1.5040740966797, -0.004364013671875, -0.00775146484375),
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["UniqueID"] = "3890718453",
									["TintColor"] = Vector(255, 255, 255),
									["Model"] = "models/props_mining/caverocks_cluster01.mdl",
									["Name"] = "meth",
									["Scale"] = Vector(0.69999998807907, 0.69999998807907, 0.30000001192093),
									["Size"] = 0.01,
									["ClassName"] = "model",
									["DoubleFace"] = true,
									["EditorExpand"] = true,
									["Position"] = Vector(-0.34999999403954, 0, 0),
									["Angles"] = Angle(-90, 0, 0),
									["Brightness"] = 1.1,
									["Material"] = "models/props/cs_office/snowmana",
								},
							},
							[3] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(90, 0, 0),
									["ClassName"] = "clip",
									["UniqueID"] = "1306617473",
									["Position"] = Vector(0, 0, 1.4800000190735),
								},
							},
							[4] = {
								["children"] = {
								},
								["self"] = {
									["Position"] = Vector(0.42996215820313, 0.0185546875, -0.0185546875),
									["ClassName"] = "effect",
									["UniqueID"] = "3877593657",
									["Effect"] = "barrel_smoke_trailb",
								},
							},
						},
						["self"] = {
							["Position"] = Vector(-0.0006103515625, 0.00299072265625, -1.7405395507813),
							["Name"] = "bowl",
							["Alpha"] = 0.65,
							["ClassName"] = "model",
							["DoubleFace"] = true,
							["UniqueID"] = "1682371200",
							["Size"] = 0.037,
							["Material"] = "models/debug/debugwhite",
							["Model"] = "models/XQM/Rails/gumball_1.mdl",
							["EditorExpand"] = true,
						},
					},
				},
				["self"] = {
					["UniqueID"] = "1447719391",
					["Model"] = "models/props_junk/PopCan01a.mdl",
					["Size"] = 0.15,
					["Name"] = "pipe",
					["Scale"] = Vector(1, 1, 3.0999999046326),
					["Alpha"] = 0.85,
					["ClassName"] = "model",
					["DoubleFace"] = true,
					["EditorExpand"] = true,
					["Position"] = Vector(0.86341094970703, -7.2188720703125, -0.11407470703125),
					["Angles"] = Angle(0, 0, -90),
					["Brightness"] = 10.7,
					["Material"] = "models/props_combine/health_charger_glass",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "2340012506",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )

GM.PacModels:Register( "female_".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["UniqueID"] = "3890718453",
									["TintColor"] = Vector(255, 255, 255),
									["Model"] = "models/props_mining/caverocks_cluster01.mdl",
									["Name"] = "meth",
									["Scale"] = Vector(0.69999998807907, 0.69999998807907, 0.30000001192093),
									["Size"] = 0.01,
									["ClassName"] = "model",
									["DoubleFace"] = true,
									["EditorExpand"] = true,
									["Position"] = Vector(-0.34999999403954, 0, 0),
									["Angles"] = Angle(-90, 0, 0),
									["Brightness"] = 1.1,
									["Material"] = "models/props/cs_office/snowmana",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(0, 180, 0),
									["ClassName"] = "clip",
									["UniqueID"] = "2566512536",
									["Position"] = Vector(1.5040740966797, -0.004364013671875, -0.00775146484375),
								},
							},
							[3] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(90, 0, 0),
									["ClassName"] = "clip",
									["UniqueID"] = "1306617473",
									["Position"] = Vector(0, 0, 1.4800000190735),
								},
							},
							[4] = {
								["children"] = {
								},
								["self"] = {
									["Effect"] = "barrel_smoke_trailb",
									["ClassName"] = "effect",
									["UniqueID"] = "4083499796",
									["Angles"] = Angle(2.2598509788513, 9.3988192020333e-006, 1.7088761524064e-005),
								},
							},
						},
						["self"] = {
							["Position"] = Vector(-0.0006103515625, 0.00299072265625, -1.7405395507813),
							["Name"] = "bowl",
							["Alpha"] = 0.65,
							["ClassName"] = "model",
							["DoubleFace"] = true,
							["UniqueID"] = "1682371200",
							["Size"] = 0.037,
							["Material"] = "models/debug/debugwhite",
							["Model"] = "models/XQM/Rails/gumball_1.mdl",
							["EditorExpand"] = true,
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-90, 0, 0),
							["ClassName"] = "clip",
							["UniqueID"] = "2985885681",
							["Position"] = Vector(-0.0020904541015625, 0.00567626953125, -2.2859497070313),
						},
					},
				},
				["self"] = {
					["UniqueID"] = "1447719391",
					["Model"] = "models/props_junk/PopCan01a.mdl",
					["Size"] = 0.15,
					["Name"] = "pipe",
					["Scale"] = Vector(1, 1, 3.0999999046326),
					["Alpha"] = 0.85,
					["ClassName"] = "model",
					["DoubleFace"] = true,
					["EditorExpand"] = true,
					["Position"] = Vector(0.00897216796875, -6.914306640625, 0.0350341796875),
					["Angles"] = Angle(0, 0, -90),
					["Brightness"] = 10.7,
					["Material"] = "models/props_combine/health_charger_glass",
				},
			},
			[2] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 2,
					["UniqueID"] = "3860556725",
					["EndSize"] = 30,
					["Material"] = "particle/particle_smokegrenade",
					["NumberParticles"] = 2,
					["AirResistance"] = 10,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.027557373046875, -6.77294921875, 0.00140380859375),
					["Sliding"] = false,
					["Lighting"] = false,
					["FireDelay"] = 22,
					["DieTime"] = 10,
					["ClassName"] = "particles",
					["Bounce"] = 0,
					["Spread"] = 0.4,
					["Gravity"] = Vector(0, 0, 1),
					["Angles"] = Angle(7.8120283433236e-005, -87.789237976074, -2.5506487872917e-005),
					["StartSize"] = 0,
					["RollDelta"] = -0.2,
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "2340012506",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitModelOverload( Effect.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Effect.PacOutfit )

GM.PacModels:Register( "m04".. Effect.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["UniqueID"] = "3890718453",
									["TintColor"] = Vector(255, 255, 255),
									["Model"] = "models/props_mining/caverocks_cluster01.mdl",
									["Name"] = "meth",
									["Scale"] = Vector(0.69999998807907, 0.69999998807907, 0.30000001192093),
									["Size"] = 0.01,
									["ClassName"] = "model",
									["DoubleFace"] = true,
									["EditorExpand"] = true,
									["Position"] = Vector(-0.34999999403954, 0, 0),
									["Angles"] = Angle(-90, 0, 0),
									["Brightness"] = 1.1,
									["Material"] = "models/props/cs_office/snowmana",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(0, 180, 0),
									["ClassName"] = "clip",
									["UniqueID"] = "2566512536",
									["Position"] = Vector(1.5040740966797, -0.004364013671875, -0.00775146484375),
								},
							},
							[3] = {
								["children"] = {
								},
								["self"] = {
									["Angles"] = Angle(90, 0, 0),
									["ClassName"] = "clip",
									["UniqueID"] = "1306617473",
									["Position"] = Vector(0, 0, 1.4800000190735),
								},
							},
							[4] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "effect",
									["UniqueID"] = "2129041181",
									["Position"] = Vector(0.42864990234375, 0.00341796875, -0.003387451171875),
									["Effect"] = "barrel_smoke_trailb",
									["Angles"] = Angle(12.683970451355, 2.6253908799845e-005, 1.7502605260233e-005),
								},
							},
						},
						["self"] = {
							["Position"] = Vector(-0.0006103515625, 0.00299072265625, -1.7405395507813),
							["Name"] = "bowl",
							["Alpha"] = 0.65,
							["ClassName"] = "model",
							["DoubleFace"] = true,
							["UniqueID"] = "1682371200",
							["Size"] = 0.037,
							["Material"] = "models/debug/debugwhite",
							["Model"] = "models/XQM/Rails/gumball_1.mdl",
							["EditorExpand"] = true,
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-90, 0, 0),
							["ClassName"] = "clip",
							["UniqueID"] = "2985885681",
							["Position"] = Vector(-0.0020904541015625, 0.00567626953125, -2.2859497070313),
						},
					},
				},
				["self"] = {
					["UniqueID"] = "1447719391",
					["Model"] = "models/props_junk/PopCan01a.mdl",
					["Size"] = 0.15,
					["Name"] = "pipe",
					["Scale"] = Vector(1, 1, 3.0999999046326),
					["Alpha"] = 0.85,
					["ClassName"] = "model",
					["DoubleFace"] = true,
					["EditorExpand"] = true,
					["Position"] = Vector(1.1987915039063, -7.0154418945313, 0.018218994140625),
					["Angles"] = Angle(0, 0, -90),
					["Brightness"] = 10.7,
					["Material"] = "models/props_combine/health_charger_glass",
				},
			},
			[2] = {
				["children"] = {
				},
				["self"] = {
					["Velocity"] = 2,
					["UniqueID"] = "3860556725",
					["EndSize"] = 30,
					["Material"] = "particle/particle_smokegrenade",
					["NumberParticles"] = 2,
					["AirResistance"] = 10,
					["RandomColour"] = false,
					["Collide"] = false,
					["Position"] = Vector(0.81370544433594, -6.7429809570313, 0.00140380859375),
					["Sliding"] = false,
					["Lighting"] = false,
					["FireDelay"] = 22,
					["DieTime"] = 10,
					["ClassName"] = "particles",
					["Bounce"] = 0,
					["Spread"] = 0.4,
					["Gravity"] = Vector(0, 0, 1),
					["Angles"] = Angle(7.8120283433236e-005, -87.789237976074, -2.5506487872917e-005),
					["StartSize"] = 0,
					["RollDelta"] = -0.2,
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "2340012506",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitFaceIDOverload( Effect.PacOutfit, "male_04", "m04".. Effect.PacOutfit )

GM.PlayerEffects:Register( Effect )