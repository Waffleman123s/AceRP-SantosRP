--[[
	Name: sh_lsd.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Psychedelic Trip"
Effect.Icon48 = "santosrp/ae_icons/tripping balls 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/tripping balls 18x18.png"
Effect.MaxDuration = 60 * 3
Effect.Effects = {
	Gains = {
		["Stamina"] = 2,
		["Move Speed"] = 1,
		["Carry Weight"] = 2,
		["Carry Volume"] = 2,
	},
	Drains = {
		["Hunger"] = 1,
		["Thirst"] = 1
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	local data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:LSD", 10, 25 )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:LSD" )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

if SERVER then
	function Effect:GamemodeEditNeedRegen( pPlayer, strNeedID, tblVal )
		if strNeedID ~= "Stamina" then return end
		tblVal[1] = tblVal[1] +8
	end

	function Effect:GamemodeEditNeedDecay( pPlayer, strNeedID, tblVal )
		if strNeedID == "Thirst" then
			tblVal[1] = tblVal[1] +5
		end
	end

	function Effect:GamemodeEditInventorySize( pPlayer, tblData )
		tblData[1] = tblData[1] +150
		tblData[2] = tblData[2] +150
	end

elseif CLIENT then

	function Effect:GamemodeEditInventorySize( tblData )
		tblData[1] = tblData[1] +150
		tblData[2] = tblData[2] +150
	end

	function Effect:RenderScreenspaceEffects()
		DrawTexturize(0.1, Material("pp/texturize/rainbow.png"))
	end
end
GM.PlayerEffects:Register( Effect )