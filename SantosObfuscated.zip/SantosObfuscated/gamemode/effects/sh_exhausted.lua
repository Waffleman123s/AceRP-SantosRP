--[[
	Name: sh_exhausted.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Exhausted"
Effect.Icon48 = "santosrp/ae_icons/Exhausted 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Exhausted 18x18.png"
Effect.MaxDuration = 60 *2
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:Exhausted", -1e9, -1e9 )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:Exhausted" )
	end
end

if SERVER then

elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )