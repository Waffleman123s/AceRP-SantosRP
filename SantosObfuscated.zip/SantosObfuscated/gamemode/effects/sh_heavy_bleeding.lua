--[[
	Name: sh_heavy_bleeding.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Heavy Bleeding"
Effect.Icon48 = "santosrp/ae_icons/Heavy Bleeding 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Heavy Bleeding 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Health"] = 2,
		["Bullet Accuracy"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		pPlayer:AddNote( "You have severe bleeding!" )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_HeavyBleeding = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if pPlayer:IsUncon() or not pPlayer:Alive() then return end
		if CurTime() > (pPlayer.m_intLastFX_HeavyBleeding or 0) then
			pPlayer:SetHealth( math.max(pPlayer:Health() -2, 0) )
			pPlayer.m_intLastFX_HeavyBleeding = CurTime() +6

			if pPlayer:Health() <= 0 then
				pPlayer:GoUncon()
			end
		end
	end

	function Effect:EntityFireBullets( pPlayer, tblBullet )
		--tblBullet.Dir = tblBullet.Dir +Vector( math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1) ) *0.075
		tblBullet.Spread = tblBullet.Spread +VectorRand() *0.25

		return true
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )