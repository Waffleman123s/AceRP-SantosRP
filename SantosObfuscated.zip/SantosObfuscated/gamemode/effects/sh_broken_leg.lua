--[[
	Name: sh_broken_leg.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Broken Leg"
Effect.Icon48 = "santosrp/ae_icons/Broken Leg(s) 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Broken Leg(s) 18x18.png"
Effect.Effects = {
	Gains = {},
	Drains = {
		["Move Speed"] = 3,
		["Carry Weight"] = 2,
		["Carry Volume"] = 2,
	}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	return not data
end

function Effect:OnStart( pPlayer )
	if SERVER then
		GAMEMODE.Player:ModifyMoveSpeed( pPlayer, "Effect:BrokenLeg", -100, -100 )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		GAMEMODE.Player:RemoveMoveSpeedModifier( pPlayer, "Effect:BrokenLeg" )
		GAMEMODE.Inv:InvalidateInventorySize( pPlayer )
	end
end

if SERVER then
	function Effect:GamemodeEditInventorySize( pPlayer, tblData )
		tblData[1] = tblData[1] -150
		tblData[2] = tblData[2] -150
	end
elseif CLIENT then
	function Effect:GamemodeEditInventorySize( tblData )
		tblData[1] = tblData[1] -150
		tblData[2] = tblData[2] -150
	end
end

GM.PlayerEffects:Register( Effect )