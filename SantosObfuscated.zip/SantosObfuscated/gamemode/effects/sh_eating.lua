--[[
	Name: sh_eating.lua
	For: SantosRP
	By: Ultra
]]--

local Effect = {}
Effect.ID = "Restoring Hunger"
Effect.Icon48 = "santosrp/ae_icons/Restoring Hunger 48x48.png"
Effect.Icon16 = "santosrp/ae_icons/Restoring Hunger 18x18.png"
Effect.MaxDuration = 60 *10
Effect.Effects = {
	Gains = {
		["Hunger"] = 1,
	},
	Drains = {}
}

function Effect:CanGive( pPlayer, intDuration, bNoAutoForward )
	if GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Hunger" ) >= GAMEMODE.Needs:GetNeedData( "Hunger" ).Max then
		return false
	end

	data = GAMEMODE.PlayerEffects:GetPlayerEffects( pPlayer )[self.ID]
	if not data then return true end

	if (data[2] -(CurTime() -data[1])) +intDuration > self.MaxDuration then
		return false
	end

	return true
end

function Effect:OnStart( pPlayer )
	if SERVER then
		pPlayer.m_intLastFX_Hunger = CurTime()
	end
end

function Effect:OnStop( pPlayer )
	if SERVER then
		self:LazyTick( pPlayer ) --Force 1 last tick
		pPlayer.m_intLastFX_Hunger = nil
	end
end

if SERVER then
	function Effect:LazyTick( pPlayer )
		if not pPlayer.m_intLastFX_Hunger then return end
		if CurTime() > pPlayer.m_intLastFX_Hunger +1 then
			local delta = CurTime() -pPlayer.m_intLastFX_Hunger
			local frac, numSecs = delta %1, math.floor( delta )
			pPlayer.m_intLastFX_Hunger = CurTime() -frac
			GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Hunger", 8 *numSecs )
		end
	end
elseif CLIENT then

end

GM.PlayerEffects:Register( Effect )