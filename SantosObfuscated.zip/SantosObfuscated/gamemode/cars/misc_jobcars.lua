--[[
	Name: misc_jobcars.lua
	For: SantosRP
	By: Ultra
]]--
local Car = {}
Car.Make = "Dodge"
Car.Name = "Flatbed Tow Truck"
Car.UID = "tow_flatbed"
Car.Job = "JOB_TOW"
Car.Desc = "A tow truck."
Car.Model = "models/sentry/flatbed.mdl"
Car.Script = "scripts/vehicles/sentry/flatbed.txt"
Car.FuellTank = 65
Car.FuelConsumption = 28
Car.LPlates = {
	{
		pos = Vector( 0, 184.5, 24.60 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.025
	},
	{
		pos = Vector( 0, -187.5, 29 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.021
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Chevy"
Car.Name = "Chevy Impala Taxi"
Car.UID = "taxi_cab"
Car.Job = "JOB_TAXI"
Car.Desc = "A taxi cab."
Car.Model = "models/lonewolfie/chev_impala_09_taxi.mdl"
Car.Script = "scripts/vehicles/lwcars/chev_impala_09.txt"
Car.FuellTank = 100
Car.FuelConsumption = 20
Car.LPlates = {
	{
		pos = Vector( 0, -105, 37.5 ),
		ang = Angle( 0, 0, 85 ),
		scale = 0.030
	}
}
GM.Cars:RegisterJobCar( Car )



local Car = {}
Car.Make = "Dodge"
Car.Name = "Ram 3500 Laramie Tow Truck"
Car.UID = "tow_truck"
Car.Job = "JOB_TOW"
Car.Desc = "A tow truck."
Car.Model = "models/statetrooper/ram_tow.mdl"
Car.Script = "scripts/vehicles/tdmcars/scaniafire.txt"
Car.FuellTank = 65
Car.FuelConsumption = 28
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = 300,
        ["maxSpeed"] = 700,
        ["horsepower"] = 250,
    }
}
Car.LPlates = {
    {
        pos = Vector( 0, 139.5, 27.5 ),
        ang = Angle( 0, 180, 100 ),
        scale = 0.031
    },
    {
        pos = Vector( 0, -149.5, 32.8 ),
        ang = Angle( 0, 0, 90 ),
        scale = 0.030
    }
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Mercedes"
Car.Name = "UPS Van"
Car.UID = "mail_truck"
Car.Job = "JOB_MAIL"
Car.Desc = "A mail truck."
Car.Model = "models/tdmcars/courier_truck.mdl"
Car.Script = "scripts/vehicles/tdmcars/courier_truck.txt"
Car.FuellTank = 200
Car.FuelConsumption = 20
Car.LPlates = {
	{
		pos = Vector( 0, 140.5, 28 ), 
		ang = Angle( 0, 180, 90 ),
		scale = 0.025
	},
	{
		pos = Vector( 0, -158, 27 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.020
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Mercedes"
Car.Name = "Courier Truck"
Car.UID = "sales_truck"
Car.Job = "JOB_SALES_TRUCK"
Car.Desc = "A mail truck."
Car.Model = "models/LoneWolfie/merc_sprinter_swb.mdl"
Car.Script = "scripts/vehicles/LWCars/merc_sprinter_swb.txt"
Car.FuellTank = 200
Car.FuelConsumption = 20
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = 200,
        ["maxSpeed"] = 700,
        ["horsepower"] = 200,
    }
}
Car.LPlates = {
	{
		pos = Vector( -17.725189, -113, 23.596401 ), 
		ang = Angle( 0, 0, 90 ),
		scale = 0.025
	},
	{
		pos = Vector( -0.083337, 133.555435, 23.920391 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.020
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "MTL"
Car.Name = "Bus"
Car.UID = "mtl_bus"
Car.Job = "JOB_BUS_DRIVER"
Car.Desc = "A city bus."
Car.Model = "models/tdmcars/bus.mdl"
Car.Script = "scripts/vehicles/tdmcars/bus.txt"
Car.FuellTank = 200
Car.FuelConsumption = 20
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = 400,
        ["maxSpeed"] = 700,
        ["horsepower"] = 250,
    }
}
Car.LPlates = {
	{
		pos = Vector( 0, 269.5, 44 ),
		ang = Angle( 0, 183, 90 ),
		scale = 0.035
	},
	{
		pos = Vector( 26, -268, 63 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.035
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Ford"
Car.Name = "F350 Utillity Truck"
Car.UID = "city_van"
Car.Job = "JOB_CITYWORKER"
Car.Desc = ""
Car.Model = "models/tdmcars/gtav/utillitruck.mdl"
Car.Script = "scripts/vehicles/TDMCars/gtav/utillitruck.txt"
Car.FuellTank = 200
Car.FuelConsumption = 3.5
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = 200,
        ["maxSpeed"] = 700,
        ["horsepower"] = 200,
    }
}
Car.LPlates = {
	{
		pos = Vector( 0, 170.5, 27 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.026
	},
	{
		pos = Vector( 0, -155.5, 34.8 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.029
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "MTL"
Car.Name = "Garbage Truck"
Car.UID = "garbage_truck"
Car.Job = "JOB_GARBWORKER"
Car.Desc = "A garbage truck."
Car.Model = "models/sligwolf/garbagetruck/sw_truck.mdl"
Car.Script = "scripts/vehicles/sligwolf/sw_truck.txt"
Car.VehicleTable = "sw_garbagetruck"
Car.FuellTank = 200
Car.FuelConsumption = 20
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = 400,
        ["maxSpeed"] = 700,
        ["horsepower"] = 250,
    }
}
Car.LPlates = {
	{
		pos = Vector( 30, 179, 14.5 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.032
	},
	{
		pos = Vector( 0, -156.5, 34.4 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.038
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Peterbilt"
Car.Name = "Truck"
Car.UID = "peterbilt_379"
Car.Job = "JOB_TRUCKDRIVER"
Car.Desc = "A Peterbilt Truck."
Car.Model = "models/sentry/p379.mdl"
Car.Script = "scripts/vehicles/sentry/p379_tow.txt"
Car.FuelTank = 200
Car.FuelConsumption = 16
Car.VehicleParams = {
    ["engine"] = {
        ["shiftUpRPM"] = -300,
        ["maxSpeed"] = -300,
        ["horsepower"] = -300,
    }
}
GM.Cars:RegisterJobCar( Car )