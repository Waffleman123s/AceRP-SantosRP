--[[
Property of acerp.gg ©2022
By: Tylr (tylrdevs@gmail.com, Tylr#6345)
For: AceRP.gg 
]]--
local Car = {}
Car.VIP = true
Car.Make = "BMW"
Car.Name = "2015 BMW i8"
Car.UID = "crsk_bmw_i8"
Car.Desc = "BMW"
Car.Model = "models/crsk_autos/bmw/i8_2015.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_bmw_i8.txt"
Car.Price = 130000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

-- local Car = {}
-- Car.Make = "BMW"
-- Car.Name = "2002 BMW M3 GTR"
-- Car.UID = "bmw_m3_gtr"
-- Car.Desc = "BMW"
-- Car.Model = "models/mlautomotive/bmw_m3_gtr.mdl"
-- Car.Script = "scripts/vehicles/mlautomotive/bmw_m3_gtr.txt"
-- Car.Price = 13000
-- Car.FuellTank = 65
-- Car.FuelConsumption = 1
-- Car.LPlates = {
--     pos = Vector(0, 109, 20.4),
--     ang = Angle(0, 180, 90),
--     scale = 0.027
--     },
--     {
--     pos = Vector(0, -127, 25),
--     ang = Angle(0, 0, 69),
--     scale = 0.029
-- }
-- GM.Cars:Register( Car )