local Car = {}
Car.Make = "Government"
Car.Name = "2020 Ford Police Interceptor Utility"
Car.UID = "20explorer"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/sentry/20explorer.mdl"
Car.Script = "scripts/vehicles/sentry/20explorer.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1
Car.LPlates = {
	{
		pos = Vector( 0, -123.3, 26 ),
		ang = Angle( 0, 0, 86.5 ),
		scale = 0.026
	}
}
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "2015 Police Dodge Charger RT"
Car.UID = "dodge_charger_2015_police"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/lonewolfie/dodge_charger_2015_police.mdl"
Car.Script = "scripts/vehicles/lwcars/dodge_charger_2015_police.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "Chevrolet Suburban Police Cruiser"
Car.UID = "chev_suburban_pol"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/LoneWolfie/chev_suburban_pol.mdl"
Car.Script = "scripts/vehicles/LWCars/chev_suburban.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "2010 Ford Taurus SHO"
Car.UID = "chev_suburban_pol"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/sentry/taurussho.mdl"
Car.Script = "scripts/vehicles/sentry/taurus.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "Police Motorcycle"
Car.UID = "policeb"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/tdmcars/gtav/policeb.mdl"
Car.Script = "scripts/vehicles/TDMCars/gtav/policeb.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "2010 Ford CVPI"
Car.UID = "cvpi_fh3"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/sentry/cvpi_fh3.mdl"
Car.Script = "scripts/vehicles/sentry/cvpi_fh3.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "1998 Ford Crown Victoria P71"
Car.UID = "cvpi_new"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/sentry/cvpi_new.mdl"
Car.Script = "scripts/vehicles/sentry/cvpi_new.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )
local Car = {}
Car.Make = "Government"
Car.Name = "2017 Ford Raptor"
Car.UID = "17raptor_cop_sgm"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/sentry/17raptor_cop.mdl"
Car.Script = "scripts/vehicles/sentry/17raptor.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )

local Car = {}
Car.Make = "Government"
Car.Name = "SWAT Lenco BearCat G3"
Car.UID = "perryn_bearcat_g3"
Car.Job = "JOB_POLICE"
Car.Desc = ""
Car.Model = "models/perrynsvehicles/bearcat_g3/bearcat_g3.mdl"
Car.Script = "scripts/vehicles/perryn/bearcat_g3.txt"
Car.PreviewSkin = 1
Car.FuellTank = 65
Car.FuelConsumption = 1 
-- Car.LPlates = {
-- 	{
-- 		pos = Vector( 0, -123.3, 26 ),
-- 		ang = Angle( 0, 0, 86.5 ),
-- 		scale = 0.026
-- 	}
-- }
-- lplates not done
GM.Cars:RegisterJobCar( Car )