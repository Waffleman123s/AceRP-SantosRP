local Car = {}
Car.Make = "Honda"
Car.Name = "1980 Honda Prelude SN"
Car.UID = "crsk_honda_prelude_1980"
Car.Desc = "Honda"
Car.Model = "models/crsk_autos/honda/prelude_1980.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_honda_prelude_1980.txt"
Car.Price = 12000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Honda"
Car.Name = "1998 Honda Integra DC2 Type R"
Car.UID = "crsk_honda_integra_dc2_typer_1998"
Car.Desc = "Honda"
Car.Model = "models/crsk_autos/honda/integra_dc2_typer_1998.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_honda_integra_dc2_typer_1998.txt"
Car.Price = 16000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Honda"
Car.Name = "2017 Honda NSX"
Car.UID = "crsk_honda_nsx_2017"
Car.Desc = "Honda"
Car.Model = "models/crsk_autos/honda/nsx_2017.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_honda_nsx_2017.txt"
Car.Price = 157500
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )