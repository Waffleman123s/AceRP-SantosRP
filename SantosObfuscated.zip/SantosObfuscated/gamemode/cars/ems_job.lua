--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--
local Car = {}
Car.Make = "Ford"
Car.Name = "F350 Ambulance"
Car.UID = "ems_ambulance"
Car.Job = "JOB_EMS"
Car.Desc = "An ambulance."
Car.Model = "models/lonewolfie/ford_f350_ambu.mdl"
Car.Script = "scripts/vehicles/lwcars/ford_f350_ambu.txt"
Car.PreviewSkin = 7
Car.FuellTank = 65
Car.FuelConsumption = 20
Car.LPlates = {
	{
		pos = Vector( 0, 160, 33.5 ),
		ang = Angle( 0, 180, 90 ),
		scale = 0.020
	},
	{
		pos = Vector( 0, -170.8, 35.5 ),
		ang = Angle( 0, 0, 90 ),
		scale = 0.0310
	}
}
Car.Trunk = {
	pos = Vector( -59.510120, -143.510666, 55.690380 ),
	dot = -0.869551,
	dist = 59.463867,
	weight = 850,
	volume = 850,
}
GM.Cars:RegisterJobCar( Car )