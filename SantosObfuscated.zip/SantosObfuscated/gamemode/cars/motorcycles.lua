local Car = {}
Car.VIP = true
Car.Make = "Motorcycles"
Car.Name = "2017 KTM 690 SMC R"
Car.UID = "azok30_ktm_690_smc_r"
Car.Desc = "Motorcycles"
Car.Model = "models/azok30/ktm_690_smc_r.mdl"
Car.Script = "scripts/vehicles/azok30/ktm_690_smc_r.txt"
Car.Price = 10000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Motorcycles"
Car.Name = "2019 KTM 690 SMC R"
Car.UID = "azok30_ktm_690_smc_r_2019"
Car.Desc = "Motorcycles"
Car.Model = "models/azok30/ktm_690_smc_r_2019.mdl"
Car.Script = "scripts/vehicles/azok30/ktm_690_smc_r.txt"
Car.Price = 11699
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Motorcycles"
Car.Name = "1978 Jawa 634"
Car.UID = "crsk_jawa_350_634"
Car.Desc = "Motorcycles"
Car.Model = "models/crsk_autos/jawa/350_634.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_jawa_350_634.txt"
Car.Price = 20000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Motorcycles"
Car.Name = "2018 YAMAHA TMAX 530"
Car.UID = "azok30_tmax_530"
Car.Desc = "Motorcycles"
Car.Model = "models/azok30/tmax_530.mdl"
Car.Script = "scripts/vehicles/azok30/tmax_530.txt"
Car.Price = 15000
Car.FuellTank = 100
Car.FuelConsumption = 100
GM.Cars:Register( Car )