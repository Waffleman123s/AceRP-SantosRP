--[[
Property of acerp.gg ©2022
By: Tylr (tylrdevs@gmail.com, Tylr#6345)
For: AceRP.gg 
]]--
-- jack moss
local Car = {}
Car.JACK = true
Car.Make = "Custom"
Car.Name = "Jack's BMW M3 E46 GTR"
Car.UID = "bmw_m3_gtr"
Car.Desc = "Custom"
Car.Model = "models/whitetiger/bmwm3gtr46.mdl"
Car.Script = "scripts/vehicles/whitetiger/bmwm3gtr46.txt"
Car.Price = 1
Car.FuellTank = 65
Car.FuelConsumption = 1
Car.SteamID = {
    ["STEAM_0:1:157472089"] = true,
}
Car.VehicleParams = {
    ["engine"] = {
        ["Horsepower"] = 420,
        ["ShiftUpRPM"] = 800,
        ["MaxSpeed"] = 400,
        ["BoostMaxSpeed"] = 320,
        ["gearCount"] = 6,
        ["MaxRPM"] = 1200,
 }
}
GM.Cars:Register( Car )

local Car = {}
Car.JACK = true
Car.Make = "Custom"
Car.Name = "Jack's 2002 Skyline R34"
Car.UID = "minesr34"
Car.Desc = "Custom"
Car.Model = "models/sentry/minesr34.mdl"
Car.Script = "scripts/vehicles/sentry/minesr34.txt"
Car.Price = 1
Car.FuellTank = 65
Car.SteamID = {
    ["STEAM_0:1:157472089"] = true,
}
Car.FuelConsumption = 1
Car.VehicleParams = {
    ["engine"] = {
        ["horsepower"] = 500,
        ["shiftUpRPM"] = 8500,
        ["maxSpeed"] = 600,
        ["boostMaxSpeed"] = 370,
        ["gearCount"] = 8,
        ["MaxRPM"] = 8800,
 }
}
GM.Cars:Register( Car )