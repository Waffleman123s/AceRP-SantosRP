local Car = {}
Car.VIP = true
Car.Make = "Mercedes-Benz"
Car.Name = "1994 Mercedes-Benz E500"
Car.UID = "crsk_mercedes_e500_w124_1994"
Car.Desc = "Mercedes-Benz"
Car.Model = "models/crsk_autos/mercedes-benz/e500_w124_1994.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_mercedes_e500_w124_1994.txt"
Car.Price = 15000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Mercedes-Benz"
Car.Name = "2019 Mercedes-Benz AMG G63"
Car.UID = "crsk_mercedes_g63_amg_2019"
Car.Desc = "Mercedes-Benz"
Car.Model = "models/crsk_autos/mercedes-benz/g63_amg_2019.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_mercedes_g63_amg_2019.txt"
Car.Price = 146495
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Mercedes-Benz"
Car.Name = "2015 Mercedes-Benz AMG GT"
Car.UID = "amggt_sgm"
Car.Desc = "Mercedes-Benz"
Car.Model = "models/sentry/amggt.mdl"
Car.Script = "scripts/vehicles/sentry/amggt.txt"
Car.Price = 120000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )