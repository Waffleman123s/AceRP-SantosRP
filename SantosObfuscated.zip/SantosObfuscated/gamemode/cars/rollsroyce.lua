local Car = {}
Car.VIP = true
Car.Make = "Rolls Royce"
Car.Name = "2016 Rolls-Royce Dawn"
Car.UID = "crsk_rolls-royce_dawn"
Car.Desc = "Rolls Royce"
Car.Model = "models/crsk_autos/rolls-royce/dawn_2016.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_rolls-royce_dawn.txt"
Car.Price = 350000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.Make = "Rolls Royce"
Car.Name = "1963 Rolls-Royce Silver Cloud III"
Car.UID = "crsk_rolls-royce_silvercloud3"
Car.Desc = "Rolls Royce"
Car.Model = "models/crsk_autos/rolls-royce/silvercloud3.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_rolls-royce_silvercloud3.txt"
Car.Price = 80000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )

local Car = {}
Car.VIP = true
Car.Make = "Rolls Royce"
Car.Name = "1993 Rolls-Royce Silver Spirit Mk III"
Car.UID = "crsk_rolls-royce_silverspiritmk3"
Car.Desc = "Rolls Royce"
Car.Model = "models/crsk_autos/rolls-royce/silverspiritmk3.mdl"
Car.Script = "scripts/vehicles/crsk_autos/crsk_rolls-royce_silverspiritmk3.txt"
Car.Price = 21000
Car.FuellTank = 65
Car.FuelConsumption = 1
GM.Cars:Register( Car )