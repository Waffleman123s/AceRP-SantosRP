--[[
	Name: drugs_cocaine.lua
	For: SantosRP
	By: Ultra
]]--

local function CocainePlayerCanUse( tblItem, pPlayer )
	local random = math.random( tblItem.IntoxMin, tblItem.IntoxMax )
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect( "Cocaine Rush" ):CanGive( pPlayer, random, true )
	return b or bHandedOff, (b or bHandedOff) and { random } 
end

local function CocainePlayerUse( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Cocaine Rush", intDuration )
	end
end

local function CrackCocainePlayerCanUse( tblItem, pPlayer )
	local random = math.random( tblItem.IntoxMin, tblItem.IntoxMax )
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect( "Crack Cocaine Rush" ):CanGive( pPlayer, random, true )
	return b or bHandedOff, (b or bHandedOff) and { random } 
end

local function CrackCocainePlayerUse( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Crack Cocaine Rush", intDuration )
	end
end

local cocaineGrowModels = {
	[1] = {
		{
			mdl = "models/freeman/coca_plant.mdl",
			pos = Vector(0, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		}
	},

	[2] = {
		{
			mdl = "models/freeman/coca_plant.mdl",
			pos = Vector(0, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 2, },
		}
	},

	[3] = {
		{
			mdl = "models/freeman/coca_plant.mdl",
			pos = Vector(0, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 3, },
		}
	},

	[4] = {
		{
			mdl = "models/freeman/coca_plant.mdl",
			pos = Vector(0, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 4, },
		}
	},

	[5] = {
		{
			mdl = "models/freeman/coca_plant.mdl",
			pos = Vector(0, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 5, },
		}
	},
}

-- ----------------------------------------------------------------
--
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Coca Seeds (Low Quality)"
Item.Desc = "A box of low quality coca seeds."
Item.Type = "type_drugs"
Item.Model = "models/freeman/coca_seedbox.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "coca seeds"

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = cocaineGrowModels, --Models for each growth stage
	GrowStageTime = 210, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Coca Leaves (Low Quality)",
	GiveItemAmount = 2,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 4, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )


local Item = {}
Item.Name = "Coca Seeds (Medium Quality)"
Item.Desc = "A box of medium quality coca seeds."
Item.Type = "type_drugs"
Item.Model = "models/freeman/coca_seedbox.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "coca seeds"

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = cocaineGrowModels, --Models for each growth stage
	GrowStageTime = 210, --Time between growth stages
	PlantHealth = 75,

	GiveItem = "Coca Leaves (Medium Quality)",
	GiveItemAmount = 2,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.33, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.33, --Min % of total possible light this plant needs to grow

	NutrientDecay = 4, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.33, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Coca Seeds (High Quality)"
Item.Desc = "A box of high quality coca seeds."
Item.Type = "type_drugs"
Item.Model = "models/freeman/coca_seedbox.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "coca seeds"

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = cocaineGrowModels, --Models for each growth stage
	GrowStageTime = 210, --Time between growth stages
	PlantHealth = 50,

	GiveItem = "Coca Leaves (High Quality)",
	GiveItemAmount = 2,

	WaterDecay = 6, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.525, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.525, --Min % of total possible light this plant needs to grow

	NutrientDecay = 5, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.525, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local data = {
	["Low"] = { BlendAmount = 1 },
	["Medium"] = { BlendAmount = 3 },
	["High"] = { BlendAmount = 5 },
}
for k, v in pairs( data ) do
	local Item = {}
	Item.Name = ("Coca Leaves (%s Quality)"):format( k )
	Item.Desc = ("%s grade coca leaves, fresh from the plant."):format( k )
	Item.Type = "type_drugs"
	Item.Model = "models/freeman/coca_leafbale.mdl"
	Item.Weight = 15
	Item.Volume = 15
	Item.CanDrop = true
	Item.Illegal = true
	Item.LimitID = "coca leaves"

	Item.DrugLab_BlenderVars = {
		BlendProgress = 5,
		BlendAmountPerTick = 0.1,
		GiveItem = "Mulched Coca Leaves",
		GiveAmount = data[k].BlendAmount,
	}

	Item.SetupEntity = function( _, eEnt )
		eEnt.CanPlayerPickup = Item.CanPlayerPickup
		eEnt.CanPlayerUse = Item.CanPlayerUse
	end
	Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
		return true --Anyone can take drugs!
	end
	Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
		return true --Anyone can take drugs!
	end
	GM.Inv:RegisterItem( Item )
	GM.Inv:RegisterItemLimit( Item.LimitID, 8 )
end


local Item = {}
Item.Name = "Mulched Coca Leaves"
Item.Desc = "Mulched coca leaves, ready for processing."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_bag001a.mdl"
Item.Weight = 8
Item.Volume = 12
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "mulched coca leaves"
Item.DropClass = "ent_fluid_coca_leaves"

Item.ReactionChamberVars = {
	Mats = { --Items needed to make a single MakeAmount of the output fluid
		["Ammonia"] = 1,
		["Mulched Coca Leaves"] = 1,
	},
	Interval = 1, --Interval
	MakeAmount = 5, --Amount of fluid to make per interval
	MinGiveAmount = 650, --Amount of the output fluid needed to give a player an item
	GiveItem = "Cocaine Paste",
	GiveAmount = 1,
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )


local Item = {}
Item.Name = "Cocaine Paste"
Item.Desc = "Cocaine paste, ready for drying."
Item.Type = "type_drugs"
Item.Model = "models/freeman/cocaine_bakingtray.mdl"
Item.Weight = 8
Item.Volume = 12
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "cocaine paste"

Item.DryingRackTime = 30
Item.DryingRackGiveItem = "Cocaine"
Item.DryingRackOffset = Vector( 0, 0, -3 )
Item.DryingRackAngOffset = Angle( 0, 90, 0 )

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )


local Item = {}
Item.Name = "Cocaine"
Item.Desc = "Cocaine"
Item.Type = "type_drugs"
Item.Model = "models/freeman/cocaine_powder.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.CanCook = true
Item.LimitID = "cocaine"
Item.IntoxMin = 60
Item.IntoxMax = 120
Item.PlayerCanUse = CocainePlayerCanUse
Item.OnUse = CocainePlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )


local Item = {}
Item.Name = "Crack Cocaine"
Item.Desc = "Crack cocaine"
Item.Type = "type_drugs"
Item.Model = "models/freeman/cocaine_crack.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "crack cocaine"
Item.IntoxMin = 30
Item.IntoxMax = 60
Item.PlayerCanUse = CrackCocainePlayerCanUse
Item.OnUse = CrackCocainePlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end

Item.CookingPotVars = {
	Skill = "Chemistry",
	SkillWeight = 0.5, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You burned your cocaine!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 60,
	MaxTime = 180,
	TimeWeight = -0.4, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.725, --% from min to max time to consider ideal

	Items = {
		["Cocaine"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
		["Baking Soda"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Water"] = { IdealAmount = 150, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Crack Cocaine", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Crack Cocaine", GiveAmount = 2 },
		{ MinQuality = 0.825, GiveItem = "Crack Cocaine", GiveAmount = 3 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )