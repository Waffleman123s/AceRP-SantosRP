--This would be a lot faster and less painful if CW2.0 used values as keys...
local updatePlayerAttachments, queueAttachmentUpdate
if SERVER then
	local StandardAtts = {
		"bg_foldsight",
		"bg_nostock",
		"bg_glock17black",
		"bg_tritiumG17",
		"cam_flechetterounds",
		"cam_magnum",
		"cam_matchgrade",
		"cam_slugrounds",
		"cbg_aug_rail",
		"cbg_aug_small_barrel",
		"cbg_longris",
		"cbg_m249_bipod",
		"cbg_mpl_stock",
		"cmd_aimpoint",
		"cmd_anpeq15",
		"cmd_bfreflex",
		"cmd_csgo_acog",
		"cmd_csgo_scope_ssg",
		"cmd_csgo_silencer_rifle",
		"cmd_deltasight",
		"cmd_docter",
		"cmd_foregrip",
		"cmd_kobra",
		"cmd_lasersight",
		"cmd_microt1",
		"cmd_rinic_extended_mag",
		"cmd_saker",
		"cmd_tundra9mm",
		"cpk_light",
		"cpk_sleightofhand",
	}

	updatePlayerAttachments = function( pPlayer )
		local lst, lstk = {}, {}
		local data
		for itemID, num in pairs( pPlayer:GetInventory() ) do
			if num <= 0 then continue end
			data = GAMEMODE.Inv:GetItem( itemID )
			
			if data and data.IsCWAttachment then
				if isstring( data.CWAttID ) then
					if lstk[data.CWAttID] then continue end
					lst[#lst +1] = data.CWAttID
					lstk[data.CWAttID] = true
				elseif istable( data.CWAttID ) then
					for _, id in pairs( data.CWAttID ) do
						if lstk[data.CWAttID] then continue end
						lst[#lst +1] = id
						lstk[id] = true
					end
				end
			end
		end

		for _, id in pairs( StandardAtts ) do
			lst[#lst +1] = id
			lstk[id] = true	
		end

		pPlayer.CWAttachments = lstk
		CustomizableWeaponry.giveAttachments( pPlayer, lst, true, true )

		--Go through active weapons and look for attachments we must remove
		for _, wep in pairs( pPlayer:GetWeapons() ) do --one loop
			if not wep.CW20Weapon or not wep.ActiveAttachments then continue end

			--Loop active attachments and remove
			for att, b in pairs( wep.ActiveAttachments ) do --two loops
				if not b then continue end

				if not lstk[att] then
					for k, v in pairs( wep.Attachments ) do --three loops
						if table.HasValue( v.atts, att ) then --four! NASTY
							wep:detach( k )
							break
						end
					end
				end
			end
		end
	end

	queueAttachmentUpdate = function( tblItem, pPlayer )
		if pPlayer.m_bWaitingAttUpdate then return end
		pPlayer.m_bWaitingAttUpdate = true
		timer.Simple( 1, function()
			if not IsValid( pPlayer ) then return end
			pPlayer.m_bWaitingAttUpdate = false
			updatePlayerAttachments( pPlayer )
		end )
	end
	g_CW2UpdateGamemodeAtts = queueAttachmentUpdate

	hook.Add( "PlayerSpawn", "ApplyCWAttachments", function( pPlayer )
		if not pPlayer:GetCharacterID() then return end
		updatePlayerAttachments( pPlayer )
	end )

	hook.Add( "Initialize", "CWAttachmentsNoAutoGive", function()
		RunConsoleCommand( "cw_keep_attachments_post_death", "1" )
		CustomizableWeaponry.buildAttachmentString = function()
			return ""
		end
	end )

	hook.Add( "GamemodeOnPlayerRagdolled", "CWAtts", function( pPlayer )
		local data = {}
		for _, wep in pairs( pPlayer:GetWeapons() ) do
			if not wep.CW20Weapon or not wep.ActiveAttachments then continue end
			local t = {}

			for att, b in pairs( wep.ActiveAttachments ) do
				t[att] = b
			end

			data[wep:GetClass()] = t
		end
		pPlayer.m_tblSavedCWAtts = data
	end )

	hook.Add( "GamemodeOnPlayerUnRagdolled", "CWAtts", function( pPlayer, bNoSpawn )
		if not pPlayer.m_tblSavedCWAtts then return end
		if bNoSpawn then return end

		local sendTbl = {}
		for className, atts in pairs( pPlayer.m_tblSavedCWAtts ) do
			local wep = pPlayer:GetWeapon( className )
			if not IsValid( wep ) then continue end

			for att, b in pairs( atts ) do
				if not b then continue end
				
				--Make sure they still have the attachment item
				local has, dat
				for name, amt in pairs( pPlayer:GetInventory() ) do
					if amt <= 0 then continue end
					dat = GAMEMODE.Inv:GetItem( name )
					if isstring( dat.CWAttID ) and dat.CWAttID == att then has = true break end
					if istable( dat.CWAttID ) and table.HasValue( dat.CWAttID, att ) then has = true break end
				end
				if not has then continue end

				for cat, lst in pairs( wep.Attachments ) do
					local found
					for i = 1, #lst.atts do
						if lst.atts[i] == att then
							wep:_attach( cat, i, CustomizableWeaponry.registeredAttachmentsSKey[lst.atts[i]])
							found = true

							sendTbl[className] = sendTbl[className] or {}
							sendTbl[className][att] = { cat, i }
							break
						end
					end

					if found then break end
				end
			end
		end
		pPlayer.m_tblSavedCWAtts = nil

		GAMEMODE.Net:NewEvent( "game", "cwa" )
			net.WriteUInt( table.Count(sendTbl), 8 )

			for className, atts in pairs( sendTbl ) do
				net.WriteString( className )
				net.WriteUInt( table.Count(atts), 8 )

				for att, data in pairs( atts ) do
					net.WriteString( att )
					net.WriteUInt( data[1], 8 )
					net.WriteUInt( data[2], 8 )
				end
			end
		GAMEMODE.Net:FireEvent( pPlayer )
	end )
elseif CLIENT then
	--We must call attach() ourselves clientside on weapon switch or the client will desync from the server... ugh
	GM.Net:RegisterEventHandle( "game", "cwa", function( intMsgLen )
		local tbl = {}

		local numWeps = net.ReadUInt( 8 )
		for wepI = 1, numWeps do
			local className = net.ReadString()
			local numAtts = net.ReadUInt( 8 )
			tbl[className] = {}

			for i = 1, numAtts do
				tbl[className][net.ReadString()] = {
					cat = net.ReadUInt( 8 ),
					idx = net.ReadUInt( 8 )
				}
			end
		end

		g_PendingClientAttUpdates = tbl
	end )

	hook.Add( "PlayerSwitchWeapon", "CWAttUpd", function( pPlayer, entOld, entNew )
		if not g_PendingClientAttUpdates or not g_PendingClientAttUpdates[entNew:GetClass()] then return end
		for att, data in pairs( g_PendingClientAttUpdates[entNew:GetClass()] ) do
			entNew:_attach( data.cat, data.idx, CustomizableWeaponry.registeredAttachmentsSKey[att] )
		end
		g_PendingClientAttUpdates[entNew:GetClass()] = nil
	end )
end

local baseItem = {}
baseItem.Type = "type_atts"
baseItem.Model = "models/Items/BoxSRounds.mdl"
baseItem.Weight = 5
baseItem.Volume = 5
baseItem.CanDrop = true
baseItem.Illegal = true
baseItem.IsCWAttachment = true
baseItem.DropClass = "prop_physics_multiplayer"
baseItem.Type = "type_atts"
baseItem.TypeName = "Attachments"

baseItem.CraftingEntClass = "ent_gunsmithing_table"
baseItem.CraftSkill = "Gun Smithing"
baseItem.CraftSkillLevel = 5
baseItem.CraftSkillXP = 5

baseItem.OnGive = queueAttachmentUpdate
baseItem.OnTake = queueAttachmentUpdate

local function newItem( tblMerge )
	local t = table.Copy( baseItem )
	table.Merge( t, tblMerge )
	return t
end


-- Attachments
-- ----------------------------------------------------------------
-- Generic
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "Bipod",
	Desc = "Decreases recoil by 70%. Greatly increases hip fire accuracy.",
	CWAttID = "bg_bipod",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Bar"] = 6,
		["Metal Bracket"] = 8,
		["Metal Plate"] = 8,
		["Chunk of Plastic"] = 8,
		["Pliers"] = 2,
	},
} )
--[[GM.Inv:RegisterItem( newItem{
	Name = "Folding sights",
	Desc = "Folding sights.",
	CWAttID = "bg_foldsight",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Bar"] = 3,
		["Metal Bracket"] = 2,
		["Metal Plate"] = 2,
		
	},
} )]]--
GM.Inv:RegisterItem( newItem{
	Name = "Long barrel",
	Desc = "Long barrel.",
	CWAttID = "bg_longbarrel",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
		["Metal Bar"] = 8,
		["Metal Bracket"] = 9,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Long barrel RIS",
	Desc = "A rail interface for long barrels - Allows additional attachments.",
	CWAttID = "bg_longris",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
		["Metal Bar"] = 8,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Magpul handguard",
	Desc = "A comfortable, lightweight handguard.",
	CWAttID = "bg_magpulhandguard",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Metal Pipe"] = 2,
		["Metal Plate"] = 15,
		["Metal Bar"] = 8,
	},
} )
--[[GM.Inv:RegisterItem( newItem{
	Name = "No stock",
	Desc = "Removes stock.",
	CWAttID = "bg_nostock",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Bracket"] = 3,
		["Wood Plank"] = 3,
		["Metal Bar"] = 8,
		["Metal Plate"] = 2,
		
	},
} )]]--
GM.Inv:RegisterItem( newItem{
	Name = "Regular barrel",
	Desc = "Regular barrel.",
	CWAttID = "bg_regularbarrel",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Bar"] = 3,
		["Metal Bracket"] = 2,
		["Metal Plate"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Retractable stock",
	Desc = "Retractable stock.",
	CWAttID = "bg_retractablestock",
	CraftSkillLevel = 13,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Bracket"] = 2,
		["Metal Plate"] = 5,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "RIS",
	Desc = "Allows additional attachments.",
	CWAttID = "bg_ris",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Trijicon ACOG",
	Desc = "Provides 4x magnification.",
	CWAttID = "md_acog",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,

	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Aimpoint",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_aimpoint",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Plate"] = 10,
		["Chunk of Plastic"] = 10,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "AN/PEQ-15",
	Desc = "AN/PEQ-15 reticule.",
	CWAttID = "md_anpeq15",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Cobra M2",
	Desc = "Decreases firing noise.",
	CWAttID = "md_cobram2",
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Chunk of Plastic"] = 20,
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "EoTech 552",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_eotech",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Plate"] = 10,
		["Chunk of Plastic"] = 10,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Foregrip",
	Desc = "Foregrip.",
	CWAttID = "md_foregrip",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Chunk of Plastic"] = 35,
		["Metal Bracket"] = 8,
		["Metal Bar"] = 7,
		["Metal Plate"] = 3,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Insight X2 LAM",
	Desc = "Insight X2 LAM reticule.",
	CWAttID = "md_insight_x2",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Kobra",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_kobra",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Plate"] = 10,
		["Chunk of Plastic"] = 10,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Micro T1",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_microt1",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Plate"] = 10,
		["Chunk of Plastic"] = 10,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Nightforce NXS",
	Desc = "Provides 8x magnification.",
	CWAttID = "md_nightforce_nxs",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "PBS-1",
	Desc = "Decreases firing noise.",
	CWAttID = "md_pbs1",
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Chunk of Plastic"] = 20,
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
		["Metal Bar"] = 10,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "PSO-1",
	Desc = "Provides 4x magnification.",
	CWAttID = "md_pso1",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Trijicon RMR",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_rmr",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Plate"] = 6,
		["Chunk of Plastic"] = 10,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "SAKER",
	Desc = "Decreases firing noise.",
	CWAttID = "md_saker",
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Chunk of Plastic"] = 20,
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
		["Metal Bar"] = 10,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Schmidt&Bender Short dot",
	Desc = "Provides 2.5x magnification.",
	CWAttID = "md_schmidt_shortdot",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Plate"] = 10,
		["Chunk of Plastic"] = 10,
		["Metal Bracket"] = 2,
		["Metal Bar"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "Tundra 9MM",
	Desc = "Decreases firing noise.",
	CWAttID = "md_tundra9mm",
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Chunk of Plastic"] = 20,
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
	},
} )


-- MP5
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "HK MP5: K variant",
	Desc = "K variant barrel.",
	CWAttID = "bg_mp5_kbarrel",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Chunk of Plastic"] = 25,
		["Metal Bracket"] = 6,
		["Metal Pipe"] = 3,
		["Metal Plate"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "HK MP5: SD variant",
	Desc = "SD variant barrel.",
	CWAttID = "bg_mp5_sdbarrel",
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Chunk of Plastic"] = 20,
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "HK MP5: 30 round magazine",
	Desc = "Increases mag size to 30 rounds.",
	CWAttID = "bg_mp530rndmag",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Chunk of Plastic"] = 25,
		["Metal Bracket"] = 6,
		["Metal Pipe"] = 3,
		["Metal Plate"] = 2,
	},
} )


-- MR96
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "MR96: Long barrel",
	Desc = "Long barrel.",
	CWAttID = "bg_longbarrelmr96",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Pliers"] = 4,
		["Metal Bracket"] = 4,
		["Metal Bar"] = 5,
		["Metal Plate"] = 3,
	},
} )


-- IMI Desert Eagle
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "IMI Desert Eagle: Compensator",
	Desc = "Compensator.",
	CWAttID = "bg_deagle_compensator",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Pliers"] = 4,
		["Metal Bracket"] = 4,
		["Metal Bar"] = 5,
		["Metal Plate"] = 3,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "IMI Desert Eagle: Extended barrel",
	Desc = "Extended barrel.",
	CWAttID = "bg_deagle_extendedbarrel",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Pliers"] = 4,
		["Metal Bracket"] = 4,
		["Metal Bar"] = 5,
		["Metal Plate"] = 3,
	},
} )


-- AK-74
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "AK-74: RPK variant",
	Desc = "Allows the use of a bipod.",
	CWAttID = { "bg_ak74_rpkbarrel", "bg_ak74heavystock", "bg_ak74rpkmag" },
	CraftSkillLevel = 21,
	CraftRecipe = {
		["Wood Plank"] = 10,
		["Pliers"] = 8,
		["Metal Bracket"] = 7,
		["Metal Bar"] = 10,
		["Metal Plate"] = 3,
		["Metal Pipe"] = 4,
		
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "AK-74: Shortened barrel",
	Desc = "Shortened barrel.",
	CWAttID = { "bg_ak74_ubarrel", "bg_ak74foldablestock" },
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Metal Bar"] = 3,
		["Wood Plank"] = 2,
		["Metal Bracket"] = 4,
		["Metal Plate"] = 4,
		["Metal Pipe"] = 2,
	},
} )


-- AR15
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "AR-15: Heavy stock",
	Desc = "Heavy stock.",
	CWAttID = "bg_ar15heavystock",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Wood Plank"] = 2,
		["Metal Bar"] = 3,
		["Metal Plate"] = 3,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "AR-15: Sturdy stock",
	Desc = "Sturdy stock.",
	CWAttID = "bg_ar15sturdystock",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Wood Plank"] = 2,
		["Metal Bar"] = 3,
		["Metal Plate"] = 3,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "AR-15: Quad-stack mag",
	Desc = "Increases mag size to 60 rounds.",
	CWAttID = "bg_ar1560rndmag",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Metal Bracket"] = 3,
		["Metal Bar"] = 3,
		["Metal Plate"] = 3,
	},
} )


-- SG1
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "SG1: Scope",
	Desc = "Provides 6x magnification.",
	CWAttID = "bg_sg1scope",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
	},
} )


-- Glock 17 mod
-- ----------------------------------------------------------------
--[[GM.Inv:RegisterItem( newItem{
	Name = "Glock 17: Black Matte",
	Desc = "A clean, rather recent black matte look for your gun.",
	CWAttID = "bg_glock17black",
	CraftSkillLevel = 5,
	CraftRecipe = {
		["Metal Bar"] = 2,
	},
} )]]--
GM.Inv:RegisterItem( newItem{
	Name = "Glock 17: Internal Laser",
	Desc = "Adds a laser to your gun.",
	CWAttID = "md_g17laser",
	CraftSkillLevel = 20,
	CraftRecipe = {
		["Metal Pipe"] = 10,
		["Metal Plate"] = 15,
	},
} )
--[[GM.Inv:RegisterItem( newItem{
	Name = "Glock 17: Tritium sights",
	Desc = "Adds tritium sights to your gun.",
	CWAttID = "bg_tritiumG17",
	CraftSkillLevel = 5,
	CraftRecipe = {
		["Metal Bar"] = 2,
	},
} )]]--


-- Extra CW mod
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "MAC-11: Extended barrel",
	Desc = "An extended barrel.",
	CWAttID = "bg_mac11_extended_barrel",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Metal Bar"] = 4,
		["Metal Plate"] = 4,
		["Metal Pipe"] = 4,
		["Metal Bracket"] = 4,
		
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "MAC-11: Unfolded stock",
	Desc = "Unfolded stock.",
	CWAttID = "bg_mac11_unfolded_stock",
	CraftSkillLevel = 15,
	CraftRecipe = {
		["Wood Plank"] = 2,
		["Metal Bar"] = 3,
		["Metal Plate"] = 3,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "PM Makarov: Extended magazine",
	Desc = "Increases mag size to 12 rounds.",
	CWAttID = "bg_makarov_extmag",
	CraftSkillLevel = 10,
	CraftRecipe = {
		["Metal Bar"] = 2,
		["Metal Bracket"] = 2,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "PM Makarov: PB variant",
	Desc = "The PB/6P9 variant of the Makarov pistol.",
	CWAttID = { "bg_makarov_pb6p9", "bg_makarov_pb_suppressor" },
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
	},
} )
GM.Inv:RegisterItem( newItem{
	Name = "PM Makarov: PM Suppressor",
	Desc = "Decreases firing noise.",
	CWAttID = "bg_makarov_pm_suppressor",
	CraftSkillLevel = 25,
	CraftRecipe = {
		["Chunk of Plastic"] = 20,
		["Metal Bracket"] = 10,
		["Metal Pipe"] = 15,
		["Metal Plate"] = 4,
	},
} )