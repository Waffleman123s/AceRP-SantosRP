--[[
	Name: food_cookable.lua
	For: SantosRP
	By: Ultra
]]--

local function PlayerCanEatItem( tblItem, pPlayer )
	if GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Hunger" ) >= GAMEMODE.Needs:GetNeedData( "Hunger" ).Max then
		return false
	end

	if tblItem.HungerFillLen then
		--We are adding hunger
		local bHunger, _ = GAMEMODE.PlayerEffects:GetEffect( "Restoring Hunger" ):CanGive( pPlayer, tblItem.HungerFillLen )
		if bHunger then return true end
	else
		--We are removing hunger
		local bHunger, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Hunger" ):CanGive( pPlayer, tblItem.HungerDrainLen )
		if bHunger then return true end
	end
end

local function PlayerEatItem( tblItem, pPlayer )
	if tblItem.HungerFillLen then
		--We are adding hunger
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Restoring Hunger", tblItem.HungerFillLen )
	else
		--We are removing hunger
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Hunger", tblItem.HungerDrainLen )
	end

	--Check if eating this item will change our thirst
	if tblItem.ThirstFillLen then
		--We are adding thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Quenching Thirst" ):CanGive( pPlayer, tblItem.ThirstFillLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Quenching Thirst", tblItem.ThirstFillLen )
		end
	elseif tblItem.ThirstDrainLen then
		--We are removing thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Thirst" ):CanGive( pPlayer, tblItem.ThirstDrainLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Thirst", tblItem.ThirstDrainLen )
		end
	end

	--Check if eating this item will change our stamina
	if tblItem.StaminaFillLen then
		--We are adding thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Restoring Stamina" ):CanGive( pPlayer, tblItem.StaminaFillLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Restoring Stamina", tblItem.StaminaFillLen )
		end
	elseif tblItem.StaminaDrainLen then
		--We are removing thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Stamina" ):CanGive( pPlayer, tblItem.StaminaDrainLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Stamina", tblItem.StaminaDrainLen )
		end
	end

	pPlayer:EmitSound( "santosrp/eating.mp3" )
end

--[[local function PlayerEatItem( tblItem, pPlayer )
	if tblItem.GiveHunger >= 0 then
		GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Hunger", tblItem.GiveHunger )
	else
		GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Hunger", math.abs(tblItem.GiveHunger) )
	end

	if tblItem.GiveStamina then
		if tblItem.GiveStamina >= 0 then
			GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Stamina", tblItem.GiveStamina )
		else
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Stamina", math.abs(tblItem.GiveStamina) )
		end
	end
	
	pPlayer:EmitSound( "santosrp/eating.mp3" )
end

local function PlayerDrinkItem( tblItem, pPlayer )
	if tblItem.GiveThirst >= 0 then
		GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Thirst", tblItem.GiveThirst )
	else
		GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Thirst", math.abs(tblItem.GiveThirst) )
	end

	if tblItem.GiveStamina then
		if tblItem.GiveStamina >= 0 then
			GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Stamina", tblItem.GiveStamina )
		else
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Stamina", math.abs(tblItem.GiveStamina) )
		end
	end
	
	pPlayer:EmitSound( "npc/barnacle/barnacle_gulp".. math.random(1, 2).. ".wav", 60, math.random(70, 130) )
	pPlayer:ViewPunch( Angle(-math.random(6, 12), 0, 0) )
end

local function PlayerCanEatItem( tblItem, pPlayer )
	return GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Hunger" ) < GAMEMODE.Needs:GetNeedData( "Hunger" ).Max
end

local function PlayerCanDrinkItem( tblItem, pPlayer )
	return GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Thirst" ) < GAMEMODE.Needs:GetNeedData( "Thirst" ).Max
end]]--

local qualityLevels = { "Disgusting", "Average", "Delicious" }
local function DeclareCookableFood( tblFoodProto, tblCookingPotVars )
	for i = 1, 3 do
		local Item = {}
		Item.Name = tblFoodProto.Name.. (" (%s Quality)"):format( qualityLevels[i] )
		Item.Desc = tblFoodProto.Desc
		Item.Type = tblFoodProto.Type
		Item.Model = tblFoodProto.Model
		Item.Weight = tblFoodProto.Weight
		Item.Volume = tblFoodProto.Volume
		Item.CanDrop = tblFoodProto.CanDrop
		Item.CanUse = tblFoodProto.CanUse
		Item.CanCook = tblFoodProto.CanCook
		Item.DropClass = tblFoodProto.DropClass
		Item.HungerFillLen = tblFoodProto.GiveHunger[i]
		Item.OnUse = PlayerEatItem
		Item.PlayerCanUse = PlayerCanEatItem
		Item.FishingData = tblFoodProto.FishingData
		
		if i == 1 then
			Item.CookingPotVars = tblCookingPotVars
		end

		if tblFoodProto.GiveStamina then
			Item.StaminaFillLen = tblFoodProto.GiveStamina[i]
		end

		GM.Inv:RegisterItem( Item )
	end
end


--[[ Fish ]]--

local Item = {}
Item.Name = "Piña Colada"
Item.Desc = "A freshly made cocktail."
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/coconut_drink.mdl"
Item.Weight = 3
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = false
Item.DropClass = "prop_physics"
Item.GiveThirst = 100
Item.OnUse = function( tblItem, pPlayer )
	PlayerDrinkItem( tblItem, pPlayer )
	GAMEMODE.Drugs:PlayerApplyEffect( pPlayer, "drunk", 3.5 *60, 1 )
end

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 4
Item.CraftSkillXP = 2
Item.CraftRecipe = {
	["Moonshine"] = 1,
	["Pineapple"] = 1,
	["Coconut"] = 1,
}
GM.Inv:RegisterItem( Item )

DeclareCookableFood( {
	Name = "Cooked Lobster",
	Desc = "A serving of cooked lobster.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/lobster.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 31, 56 },
	GiveStamina = { 1, 2, 6 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.5, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your lobster!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 120,
	MaxTime = 220,
	TimeWeight = -0.85, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.6895, --% from min to max time to consider ideal

	Items = {
		["Uncooked Lobster"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 50, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 350, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Lobster (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Lobster (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Lobster (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Bass",
	Desc = "A serving of cooked bass.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishbass.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 25, 44 },
	GiveStamina = { 1, 2, 5 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.275, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your bass!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 50,
	MaxTime = 200,
	TimeWeight = -0.4, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.45, --% from min to max time to consider ideal

	Items = {
		["Uncooked Bass"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 50, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 350, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Bass (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Bass (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Bass (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Catfish",
	Desc = "A serving of cooked catfish.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishcatfish.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 25, 44 },
	GiveStamina = { 1, 2, 5 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.275, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your catfish!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 60,
	MaxTime = 180,
	TimeWeight = -0.4, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.75, --% from min to max time to consider ideal

	Items = {
		["Uncooked Catfish"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 75, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 350, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Catfish (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Catfish (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Catfish (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Rainbow Trout",
	Desc = "A serving of cooked rainbow trout.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishrainbow.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12.5, 25, 44 },
	GiveStamina = { 1, 2, 4 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.33, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your trout!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 80,
	MaxTime = 220,
	TimeWeight = -0.45, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.77, --% from min to max time to consider ideal

	Items = {
		["Uncooked Rainbow Trout"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 350, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Rainbow Trout (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Rainbow Trout (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Rainbow Trout (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Golden Trout",
	Desc = "A serving of cooked golden trout.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishgolden.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 25, 44 },
	GiveStamina = { 1, 2, 4 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.33, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your trout!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 80,
	MaxTime = 220,
	TimeWeight = -0.45, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.25, --% from min to max time to consider ideal

	Items = {
		["Uncooked Golden Trout"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 50, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 300, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Golden Trout (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Golden Trout (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Golden Trout (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Sunfish",
	Desc = "A serving of cooked sunfish.",
	Type = "type_food",
	Model = "models/props/cs_militia/fishriver01.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 6, 12, 25 },
	GiveStamina = { 1, 2, 3 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.275, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your sunfish!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 60,
	MaxTime = 180,
	TimeWeight = -0.45, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.2, --% from min to max time to consider ideal

	Items = {
		["Uncooked Sunfish"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 150, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Sunfish (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Sunfish (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Sunfish (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 2 },
		{ MinQuality = 0.61, GiveAmount = 3 },
		{ MinQuality = 0.825, GiveAmount = 5 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Gold Fish",
	Desc = "A serving of cooked gold fish. If you can call that a serving.",
	Type = "type_food",
	Model = "models/props/de_inferno/goldfish.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 1, 2, 3 },
	GiveStamina = { 1, 1, 2 },
},
{
	Skill = "Cooking",
	SkillWeight = 0.25, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your sunfish!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 60,
	MaxTime = 180,
	TimeWeight = -0.45, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.33, --% from min to max time to consider ideal

	Items = {
		["Uncooked Gold Fish"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
		["Water"] = { IdealAmount = 125, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Gold Fish (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Gold Fish (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Gold Fish (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 2 },
		{ MinQuality = 0.61, GiveAmount = 3 },
		{ MinQuality = 0.825, GiveAmount = 5 },
	}
} )


--[[ Meats ]]--
DeclareCookableFood( {
	Name = "Cooked Bacon",
	Desc = "A serving of cooked bacon.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/baconcooked.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	CanCook = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 9, 12, 19 },
	GiveStamina = { 1, 2, 5 },

	FishingData = {
		IsBait = true,
	}
},
{
	Skill = "Cooking",
	SkillWeight = 0.25, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You burnt your bacon to a crisp!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = true, --Start a fire if the item goes over max time

	MinTime = 30,
	MaxTime = 90,
	TimeWeight = -0.33, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.66, --% from min to max time to consider ideal

	Items = {
		["Uncooked Bacon"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Cooking Oil"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Bacon (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Bacon (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Bacon (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Cooked Steak",
	Desc = "A serving of cooked steak.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/steak2.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	CanCook = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 15, 31, 56 },
	GiveStamina = { 1, 2, 6 },

	FishingData = {
		IsBait = true,
	}
},
{
	Skill = "Cooking",
	SkillWeight = 0.5, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You burnt your steak to a crisp!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = true, --Start a fire if the item goes over max time

	MinTime = 120,
	MaxTime = 220,
	TimeWeight = -0.85, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.7125, --% from min to max time to consider ideal

	Items = {
		["Uncooked Steak"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
	},
	Fluids = {
		["Cooking Oil"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
		["Salt"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cooked Steak (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cooked Steak (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cooked Steak (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )


--[[ Meals ]]--
DeclareCookableFood( {
	Name = "Cheese Burger",
	Desc = "A simple cheese burger.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/burgersims2.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 25, 44 },
	GiveStamina = { 1, 2, 5 },

	FishingData = {
		IsBait = true,
	}
},
{
	Skill = "Cooking",
	SkillWeight = 0.25, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your burger!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = true, --Start a fire if the item goes over max time

	MinTime = 30,
	MaxTime = 120,
	TimeWeight = -0.25, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.35, --% from min to max time to consider ideal

	Items = {
		["Uncooked Beef"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
		["Cheese"] = { IdealAmount = 1, MaxAmount = 1, MinAmount = 1 },
		["Wheat Bread"] = { IdealAmount = 2, MaxAmount = 2, MinAmount = 1 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 25, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Cheese Burger (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cheese Burger (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cheese Burger (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "Double Cheese Burger",
	Desc = "A double cheese burger.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/mcdburger.mdl",
	Weight = 2,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 34, 50 },
	GiveStamina = { 1, 2, 5 },

	FishingData = {
		IsBait = true,
	}
},
{
	Skill = "Cooking",
	SkillWeight = 0.33, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your burger!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = true, --Start a fire if the item goes over max time

	MinTime = 30,
	MaxTime = 120,
	TimeWeight = -0.275, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.35, --% from min to max time to consider ideal

	Items = {
		["Uncooked Beef"] = { IdealAmount = 2, MaxAmount = 2, MinAmount = 2 },
		["Cheese"] = { IdealAmount = 2, MaxAmount = 2, MinAmount = 2 },
		["Wheat Bread"] = { IdealAmount = 3, MaxAmount = 3, MinAmount = 2 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 50, MaxAmount = 750, MinAmount = 25 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Double Cheese Burger (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Double Cheese Burger (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Double Cheese Burger (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )

DeclareCookableFood( {
	Name = "French Fries",
	Desc = "A serving of fries.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/mcdfrenchfries.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 9, 19, 25 },
	GiveStamina = { 1, 2, 3 },

	FishingData = {
		IsBait = true,
	}
},
{
	Skill = "Cooking",
	SkillWeight = 0.25, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked your fries!",
	OverTimeExplode = false, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = true, --Start a fire if the item goes over max time

	MinTime = 30,
	MaxTime = 120,
	TimeWeight = -0.25, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.35, --% from min to max time to consider ideal

	Items = {
		["Potato"] = { IdealAmount = 2, MaxAmount = 2, MinAmount = 2 },
	},
	Fluids = {
		["Salt"] = { IdealAmount = 100, MaxAmount = 750, MinAmount = 25 },
		["Cooking Oil"] = { IdealAmount = 350, MaxAmount = 750, MinAmount = 100 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "French Fries (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "French Fries (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "French Fries (Delicious Quality)", GiveAmount = 1 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
} )