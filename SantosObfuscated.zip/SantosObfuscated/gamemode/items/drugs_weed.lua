--[[
	Name: drugs_weed.lua
	For: SantosRP
	By: Ultra
]]--

local function WeedPlayerCanUse( tblItem, pPlayer )
	local random = math.random( tblItem.IntoxMin, tblItem.IntoxMax )
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect( "High" ):CanGive( pPlayer, random, true )
	return b or bHandedOff, (b or bHandedOff) and { random } 
end

local function WeedPlayerUse( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "High", intDuration )
	end
end
-- 	GAMEMODE.Drugs:ClearPlayerDrugEffects(ply)
local function DrugClearAll( pPlayer )
	GAMEMODE.Drugs:ClearPlayerDrugEffects( pPlayer )
end
local weedGrowModels = {
	[1] = {
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 0, },
		},
	},

	[2] = {
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			bgroups = { [1] = 1, },
		},
	},

	[3] = {
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 2,
			bgroups = { [1] = 2, },
		},
	},

	[4] = {
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 2.5,
			bgroups = { [1] = 3, },
		},
	},

	[5] = {
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(8.5, 0, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, 8.5, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(0, -8.5, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
		{
			mdl = "models/gonzo/weed/weed.mdl",
			pos = Vector(-8.5, 0, 7),
			ang = "random_yaw",
			scale = 3,
			bgroups = { [1] = 4, },
		},
	},
}


--[[ Misc Items ]]--
local Item = {}
Item.Name = "Drying Rack"
Item.Desc = "A drying rack for various goods."
Item.Type = "type_drugs"
Item.Model = "models/props_wasteland/kitchen_shelf001a.mdl"
Item.Weight = 15
Item.Volume = 50
Item.HealthOverride = 2500
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_drying_rack"
Item.LimitID = "drying rack"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Machines"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Box Fan"] = 2,
	["Metal Bracket"] = 12,
	["Metal Plate"] = 6,
	["Metal Pipe"] = 2,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1} )

local Item = {}
Item.Name = "Trimming Machine"
Item.Desc = "An automatic trimming machine for dry cannabis."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/MetalBucket02a.mdl"
Item.Weight = 12
Item.Volume = 15
Item.HealthOverride = 1000
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_weed_trimmer"
Item.LimitID = "trimming machine"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Machines"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Metal Bucket"] = 1,
	["Wrench"] = 1,
	["Pliers"] = 1,
	["Circular Saw"] = 1,
	["Metal Plate"] = 4,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1} )

-- ----------------------------------------------------------------
-- Low Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Cannabis Seeds (Low Quality)"
Item.Desc = "A box of low quality marijuana seeds."
Item.Type = "type_drugs"
Item.Model = "models/freeman/seedbox.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "cannabis seeds"

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = weedGrowModels, --Models for each growth stage
	GrowStageTime = 210, --Time between growth stages
	PlantHealth = 100,

	GiveItem = "Fresh Cannabis (Low Quality)",
	GiveItemAmount = 2,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.25, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.25, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.25, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4 )

local Item = {}
Item.Name = "Fresh Cannabis (Low Quality)"
Item.Desc = "Low grade marijuana, ready to dry."
Item.Type = "type_drugs"
Item.Model = "models/freeman/drugbale_large.mdl"
Item.Weight = 15
Item.Volume = 15
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "fresh cannabis"

Item.DryingRackTime = 30
Item.DryingRackGiveItem = "Dry Cannabis (Low Quality)"

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

local Item = {}
Item.Name = "Dry Cannabis (Low Quality)"
Item.Desc = "Low grade marijuana, ready to trim."
Item.Type = "type_drugs"
Item.Model = "models/freeman/drugbale_large.mdl"
Item.Weight = 8
Item.Volume = 12
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "dry cannabis"

Item.TrimmerGiveItem = "Cannabis (Low Quality)"
Item.TrimmerGiveAmount = 4

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

local Item = {}
Item.Name = "Cannabis (Low Quality)"
Item.Desc = "Low grade marijuana"
Item.Type = "type_drugs"
Item.Model = "models/freeman/smalldrugbag.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "cannabis"
Item.IntoxMin = 120
Item.IntoxMax = 180
Item.PlayerCanUse = WeedPlayerCanUse
Item.OnUse = WeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

-- ----------------------------------------------------------------
-- Medium Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Cannabis Seeds (Medium Quality)"
Item.Desc = "A box of medium quality marijuana seeds."
Item.Type = "type_drugs"
Item.Model = "models/freeman/seedbox.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "cannabis seeds"

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = weedGrowModels, --Models for each growth stage
	GrowStageTime = 210, --Time between growth stages
	PlantHealth = 75,

	GiveItem = "Fresh Cannabis (Medium Quality)",
	GiveItemAmount = 2,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.33, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.33, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.33, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Fresh Cannabis (Medium Quality)"
Item.Desc = "Medium grade marijuana, ready to dry."
Item.Type = "type_drugs"
Item.Model = "models/freeman/drugbale_large.mdl"
Item.Weight = 15
Item.Volume = 15
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "fresh cannabis"

Item.DryingRackTime = 30
Item.DryingRackGiveItem = "Dry Cannabis (Medium Quality)"

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Dry Cannabis (Medium Quality)"
Item.Desc = "Medium grade marijuana, ready to trim."
Item.Type = "type_drugs"
Item.Model = "models/freeman/drugbale_large.mdl"
Item.Weight = 8
Item.Volume = 12
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "dry cannabis"

Item.TrimmerGiveItem = "Cannabis (Medium Quality)"
Item.TrimmerGiveAmount = 4

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Cannabis (Medium Quality)"
Item.Desc = "Medium grade marijuana"
Item.Type = "type_drugs"
Item.Model = "models/freeman/smalldrugbag.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "cannabis"
Item.IntoxMin = 200
Item.IntoxMax = 400
Item.PlayerCanUse = WeedPlayerCanUse
Item.OnUse = WeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


-- ----------------------------------------------------------------
-- High Quality Weed
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Cannabis Seeds (High Quality)"
Item.Desc = "A box of high quality marijuana seeds."
Item.Type = "type_drugs"
Item.Model = "models/freeman/seedbox.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "cannabis seeds"

--Vars used by the plant pot entity to configure growth params
Item.CanPlant = true
Item.DrugGrowthVars = {
	GrowModels = weedGrowModels, --Models for each growth stage
	GrowStageTime = 210, --Time between growth stages
	PlantHealth = 50,

	GiveItem = "Fresh Cannabis (High Quality)",
	GiveItemAmount = 2,

	WaterDecay = 5, --Amout of water to consume per water decay tick
	WaterDecayTime = 15, --Time in seconds before WaterDecay water is taken from the plant
	WaterDamageAmount = 1, --Amount of damage to deal to the plant when out of water
	WaterDamageInterval = 2, --Time in seconds per damage event from lack of water
	WaterRequirement = 0.525, --Min % of total possible water this plant needs to grow

	LightDecay = 10, --Amount of light to consume per light decay tick
	LightDecayTime = 4, --Time in seconds before LightDecay light is taken from the plant
	LightDamageAmount = 1, --Amount of damage to deal to the plant when out of light
	LightDamageInterval = 2, --Time in seconds per damage event from lack of light
	LightRequirement = 0.525, --Min % of total possible light this plant needs to grow

	NutrientDecay = 3, --Amount of nutrients to consume per nutrient decay tick
	NutrientDecayTime = 35, --Time in seconds before NutrientDecay nutrients are taken from the plant
	NutrientDamageAmount = 1, --Amount of damage to deal to the plant when out of nutrients
	NutrientDamageInterval = 2, --Time in seconds per damage event from lack of nutrients
	NutrientRequirement = 0.525, --Min % of total possible nutrients this plant needs to grow
}

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Fresh Cannabis (High Quality)"
Item.Desc = "High grade marijuana, ready to dry."
Item.Type = "type_drugs"
Item.Model = "models/freeman/drugbale_large.mdl"
Item.Weight = 15
Item.Volume = 15
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "fresh cannabis"

Item.DryingRackTime = 30
Item.DryingRackGiveItem = "Dry Cannabis (High Quality)"

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Dry Cannabis (High Quality)"
Item.Desc = "High grade marijuana, ready to trim."
Item.Type = "type_drugs"
Item.Model = "models/freeman/drugbale_large.mdl"
Item.Weight = 8
Item.Volume = 12
Item.CanDrop = true
Item.Illegal = true
Item.LimitID = "dry cannabis"

Item.TrimmerGiveItem = "Cannabis (High Quality)"
Item.TrimmerGiveAmount = 4

Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Cannabis (High Quality)"
Item.Desc = "High grade marijuana"
Item.Type = "type_drugs"
Item.Model = "models/freeman/smalldrugbag.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "cannabis"
Item.IntoxMin = 450
Item.IntoxMax = 550
Item.PlayerCanUse = WeedPlayerCanUse
Item.OnUse = WeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Detox Pills"
Item.Desc = "Clears all active effects."
Item.Type = "type_drugs"
Item.Model = "models/fless/pill01.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = false
Item.LimitID = "pill"
Item.PlayerCanUse = true
Item.OnUse = DrugClearAll
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )