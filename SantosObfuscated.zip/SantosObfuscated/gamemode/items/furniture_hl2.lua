--[[
	Name: furniture_hl2.lua
	For: SantosRP
	By: Ultra
]]--

local Item = {}
Item.Name = "Round Table"
Item.Desc = "A round table."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureTable001a.mdl"
Item.Weight = 40
Item.Volume = 50
Item.HealthOverride = 1500
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Table"
Item.Desc = "A table."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureTable002a.mdl"
Item.Weight = 55
Item.Volume = 65
Item.HealthOverride = 3000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Coffee Table"
Item.Desc = "A coffee table."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureTable003a.mdl"
Item.Weight = 30
Item.Volume = 45
Item.HealthOverride = 1500
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Shelf Unit 1"
Item.Desc = "A shelf unit."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/shelfunit01a.mdl"
Item.Weight = 80
Item.Volume = 100
Item.HealthOverride = 3000
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Shelf Unit 2"
Item.Desc = "A shelf unit."
Item.Type = "type_furniture"
Item.Model = "models/props_interiors/Furniture_shelf01a.mdl"
Item.Weight = 60
Item.Volume = 70
Item.HealthOverride = 2250
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Metal Shelf"
Item.Desc = "A metal shelf for displaying items."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_office/shelves_metal.mdl"
Item.Weight = 45
Item.Volume = 50
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Large Wooden Bar"
Item.Desc = "A big old pub style bar."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_militia/bar01.mdl"
Item.Weight = 175
Item.Volume = 150
Item.HealthOverride = 3000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Patio Table with Umbrella"
Item.Desc = "A metal patio table covered by an umbrella."
Item.Type = "type_furniture"
Item.Model = "models/props/de_tides/patio_table2.mdl"
Item.Weight = 50
Item.Volume = 70
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Sturdy Wooden Table"
Item.Desc = "An old but sturdy wooden table."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_italy/it_mkt_table2.mdl"
Item.Weight = 45
Item.Volume = 50
Item.CanDrop = true
Item.CanSitOn = true
Item.HealthOverride = 1500
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Wooden Display Table"
Item.Desc = "A tilted wooden display table."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_italy/it_mkt_table1.mdl"
Item.Weight = 30
Item.Volume = 40
Item.CanDrop = true
Item.CanSitOn = true
Item.HealthOverride = 1500
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Metal Office Desk"
Item.Desc = "A nice metal office desk."
Item.Type = "type_furniture"
Item.Model = "models/props_office/desk_01.mdl"
Item.Weight = 70
Item.Volume = 80
Item.CanDrop = true
Item.CanSitOn = true
Item.HealthOverride = 1500
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Elegant Dining Table"
Item.Desc = "A very elegant wooden dining table."
Item.Type = "type_furniture"
Item.Model = "models/env/furniture/din_table/din_table_four.mdl"
Item.Weight = 75
Item.Volume = 90
Item.CanDrop = true
Item.CanSitOn = true
Item.HealthOverride = 1500
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Fancy End Table"
Item.Desc = "A well made wooden end table."
Item.Type = "type_furniture"
Item.Model = "models/env/furniture/deco_table/deco_table.mdl"
Item.Weight = 40
Item.Volume = 35
Item.CanDrop = true
Item.CanSitOn = true
Item.HealthOverride = 1500
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )


--Seating Props
local Item = {}
Item.Name = "Elegant Dining Chair"
Item.Desc = "A high-back elegant dining chair."
Item.Type = "type_furniture"
Item.Model = "models/env/furniture/din_chair/din_chair.mdl"
Item.Weight = 25
Item.Volume = 20
Item.HealthOverride = 1000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Fancy Modern Chair"
Item.Desc = "A modern seat."
Item.Type = "type_furniture"
Item.Model = "models/env/furniture/decosofa_wood/decosofa_wood_sin.mdl"
Item.Weight = 50
Item.Volume = 35
Item.HealthOverride = 1000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Leather Couch"
Item.Desc = "Medium quality leather couch."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_office/sofa.mdl"
Item.Weight = 75
Item.Volume = 100
Item.HealthOverride = 1500
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "Leather Chair"
-- Item.Desc = "Medium quality leather chair."
-- Item.Type = "type_furniture"
-- Item.Model = "models/props/cs_office/sofa_chair.mdl"
-- Item.Weight = 25
-- Item.Volume = 40
-- Item.HealthOverride = 1500
-- Item.CanDrop = true
-- Item.CanSitOn = true
-- Item.DropClass = "prop_physics_multiplayer"
-- GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "Leather Office Chair"
-- Item.Desc = "Standard cheap leather office chair."
-- Item.Type = "type_furniture"
-- Item.Model = "models/props/cs_office/chair_office.mdl"
-- Item.Weight = 15
-- Item.Volume = 25
-- Item.HealthOverride = 1500
-- Item.CanDrop = true
-- Item.CanSitOn = true
-- Item.DropClass = "prop_physics_multiplayer"
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Derelict Couch"
Item.Desc = "An old couch like found on the side of a road."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_militia/couch.mdl"
Item.Weight = 50
Item.Volume = 80
Item.HealthOverride = 1500
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Wooden Bar Stool"
Item.Desc = "An old bar stool."
Item.Type = "type_furniture"
Item.Model = "models/props/cs_militia/barstool01.mdl"
Item.Weight = 12
Item.Volume = 14
Item.HealthOverride = 1500
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "Metal Patio Chair"
-- Item.Desc = "A metal patio chair."
-- Item.Type = "type_furniture"
-- Item.Model = "models/props/de_tides/patio_chair2.mdl"
-- Item.Weight = 20
-- Item.Volume = 15
-- Item.HealthOverride = 1000
-- Item.CanDrop = true
-- Item.CanSitOn = true
-- Item.DropClass = "prop_physics_multiplayer"
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Sofa 1"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureCouch001a.mdl"
Item.Weight = 60
Item.Volume = 50
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Sofa 2"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureCouch002a.mdl"
Item.Weight = 60
Item.Volume = 50
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Sofa 3"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_interiors/Furniture_Couch01a.mdl"
Item.Weight = 50
Item.Volume = 50
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Chair 1"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_interiors/Furniture_Couch02a.mdl"
Item.Weight = 25
Item.Volume = 30
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Chair 2"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureChair001a.mdl"
Item.Weight = 10
Item.Volume = 15
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Chair 3"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/chair02a.mdl"
Item.Weight = 12
Item.Volume = 15
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Chair 4"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_interiors/Furniture_chair01a.mdl"
Item.Weight = 10
Item.Volume = 15
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Chair 5"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_interiors/Furniture_chair03a.mdl"
Item.Weight = 8
Item.Volume = 12
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Desk Chair 1"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_combine/breenchair.mdl"
Item.Weight = 45
Item.Volume = 50
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Desk Chair 2"
Item.Desc = "Looks comfy."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/chair_office01a.mdl"
Item.Weight = 30
Item.Volume = 50
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

--Decorative

local Item = {}
Item.Name = "Wall Clock"
Item.Desc = "A wall clock."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/clock01.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Flower Planter"
Item.Desc = "Some flowers in a planter."
Item.Type = "type_furniture"
Item.Model = "models/props/de_tides/planter.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Small Potted Plant"
Item.Desc = "A small pot with a tropical plant."
Item.Type = "type_furniture"
Item.Model = "models/env/decor/cheese_plant/cheese_plant.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Large Potted Plant"
Item.Desc = "A large pot with a tropical plant."
Item.Type = "type_furniture"
Item.Model = "models/highrise/potted_plant_04.mdl"
Item.Weight = 5
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Wild Monkey Flowers"
Item.Desc = "Wild monkey flowers"
Item.Type = "type_furniture"
Item.Model = "models/plantlife/monkeyflower/jn_monkeyflower_group.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

--Storage containers

local Item = {}
Item.Name = "Storage Chest"
Item.Desc = "A large chest for storing items temporarily."
Item.Model = "models/Items/ammocrate_smg1.mdl"
Item.Weight = 50
Item.Volume = 100
Item.HealthOverride = 10000
Item.CanDrop = true
Item.LimitID = "storage chest"
Item.DropClass = "ent_storage_chest"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1 } )

local Item = {}
Item.Name = "Dresser"
Item.Desc = "A dresser."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureDrawer001a.mdl"
Item.Weight = 80
Item.Volume = 100
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "dresser"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 300, 2 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "Cupboard"
Item.Desc = "A cupboard."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureCupboard001a.mdl"
Item.Weight = 65
Item.Volume = 50
Item.HealthOverride = 1500
Item.CanDrop = true
Item.LimitID = "cupboard"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 75, 2 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "Drawer Set 1"
Item.Desc = "An end table with drawers."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureDrawer002a.mdl"
Item.Weight = 25
Item.Volume = 50
Item.HealthOverride = 750
Item.CanDrop = true
Item.LimitID = "drawer set"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 50, 2 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "Drawer Set 2"
Item.Desc = "A cupboard."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureDrawer003a.mdl"
Item.Weight = 25
Item.Volume = 50
Item.HealthOverride = 1500
Item.CanDrop = true
Item.LimitID = "drawer set"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 50, 2 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "Desk"
Item.Desc = "A desk."
Item.Type = "type_furniture"
Item.Model = "models/props_interiors/Furniture_Desk01a.mdl"
Item.Weight = 40
Item.Volume = 50
Item.HealthOverride = 2000
Item.CanDrop = true
Item.CanSitOn = true
Item.LimitID = "desk"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 100, 2 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "Fancy Desk"
Item.Desc = "A fancy desk."
Item.Type = "type_furniture"
Item.Model = "models/props_combine/breendesk.mdl"
Item.Weight = 125
Item.Volume = 75
Item.HealthOverride = 3000
Item.CanDrop = true
Item.CanSitOn = true
Item.LimitID = "desk"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 125, 2 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "File Cabinet"
Item.Desc = "A file cabinet."
Item.Type = "type_furniture"
Item.Model = "models/props_lab/filecabinet02.mdl"
Item.Weight = 35
Item.Volume = 15
Item.HealthOverride = 750
Item.CanDrop = true
Item.LimitID = "file cabinet"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 50 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )

local Item = {}
Item.Name = "Large File Cabinet"
Item.Desc = "A large file cabinet."
Item.Type = "type_furniture"
Item.Model = "models/props_wasteland/controlroom_filecabinet002a.mdl"
Item.Weight = 55
Item.Volume = 40
Item.HealthOverride = 1000
Item.CanDrop = true
Item.LimitID = "file cabinet"
Item.DropClass = "ent_storage_chest"
Item.SetupEntity = function( tblItem, eEnt )
	eEnt:Setup( tblItem.Model, 100 )
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 1, ["vip_t2"] = 1, ["vip_t3"] = 1, ["vip_t4"] = 1 } )