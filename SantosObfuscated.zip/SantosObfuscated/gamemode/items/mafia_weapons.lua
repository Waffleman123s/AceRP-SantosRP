--[[
	Name: cartel_weapons.lua
	For: TalosLife
	By: TalosLife
]]--

if SERVER then
	resource.AddWorkshop( "717188718" )
	resource.AddWorkshop( "358608166" )
	resource.AddWorkshop( "349050451" )
end

hook.Add( "InitPostEntity", "PatchCWMouse", function()
	local base = weapons.GetStored( "cw_base" )
	if not base then return end

	base.AdjustMouseSensitivity = function()
		return 1 --go eway
	end

	for k, v in pairs( GAMEMODE.Inv:GetItems() ) do
		if not v.IsCW then continue end
		local wep = weapons.GetStored( v.EquipGiveClass )
		if wep then
			wep.Primary.DefaultClip = 0
		end
	end
end )

if SERVER and CustomizableWeaponry then
	CustomizableWeaponry.canDropWeapon = false -- set this to false to disable cw_dropweapon concommand
	CustomizableWeaponry.enableWeaponDrops = false -- set this to false to disable weapon dropping in general (no idea why you would want to do that though)
end

if CLIENT then
	RunConsoleCommand( "cw_customhud_ammo", "1" )
end

--[[local Item = {}
Item.Name = "Civ Radio"
Item.Desc = "Civ Radio"
Item.Type = "type_weapon"
Item.Model = "models/gspeak/funktronics.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "swep_radio"
Item.DropClass = "swep_radio"
GM.Inv:RegisterItem( Item )]]

local Item = {}
Item.Name = "El Cartel Charmer"
Item.Desc = "A weapon El Cartel are known for using."
Item.Type = "type_weapon"
Item.Model = "models/cw2/weapons/w_vectorsmg.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.CanRobStore = true
Item.NoDefaultClip = true
Item.IsCW = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_vector_k10"
Item.DropClass = "cw_vector_k10"
Item.PacOutfit = "crate_m4"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Mafia Thompson"
Item.Desc = "A weapon the mafia are known for using."
Item.Type = "type_weapon"
Item.Model = "models/cw2/weapons/w_tac_thompson.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.CanRobStore = true
Item.CanEquip = true
Item.Illegal = true
Item.NoDefaultClip = true
Item.IsCW = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_tactical_thompson"
Item.DropClass = "cw_tactical_thompson"
Item.PacOutfit = "m4_back"
Item.PacOutfit = "crate_m4"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )