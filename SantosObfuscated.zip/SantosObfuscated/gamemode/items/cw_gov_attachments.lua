local baseItem = {}
baseItem.Type = "type_atts"
baseItem.Model = "models/Items/BoxSRounds.mdl"
baseItem.Weight = 5
baseItem.Volume = 5
baseItem.CanDrop = false
baseItem.IsCWAttachment = true
baseItem.JobItem = "JOB_SSERVICE"
baseItem.Type = "type_atts"
baseItem.TypeName = "Attachments"

baseItem.OnGive = function(...) g_CW2UpdateGamemodeAtts(...) end
baseItem.OnTake = function(...) g_CW2UpdateGamemodeAtts(...) end

local function newItem( tblMerge )
	local t = table.Copy( baseItem )
	table.Merge( t, tblMerge )
	return t
end


-- Glock17
-- ----------------------------------------------------------------
GM.Inv:RegisterItem( newItem{
	Name = "Government Issue Insight X2 LAM",
	Desc = "Insight X2 LAM reticule.",
	CWAttID = "md_insight_x2"
} )
GM.Inv:RegisterItem( newItem{
	Name = "Government Issue Glock 17: Internal Laser",
	Desc = "Adds a laser to your gun.",
	CWAttID = "md_g17laser"
} )
GM.Inv:RegisterItem( newItem{
	Name = "Government Issue Tundra 9MM",
	Desc = "Decreases firing noise.",
	CWAttID = "md_tundra9mm"
} )
GM.Inv:RegisterItem( newItem{
	Name = "Government Issue Cobra M2",
	Desc = "Decreases firing noise.",
	CWAttID = "md_cobram2"
} )
GM.Inv:RegisterItem( newItem{
	Name = "Government Issue Micro T1",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_microt1"
} )
GM.Inv:RegisterItem( newItem{
	Name = "Government Issue Trijicon RMR",
	Desc = "Provides a bright reticle to ease aiming.",
	CWAttID = "md_rmr"
} )