--[[
	Name: cw_ammo.lua
	For: SantosRP
	By: Ultra
]]--


-- PreReq
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Smokeless Gunpowder"
Item.Desc = "Smokeless gunpowder used for loading bullets."
Item.Model = "models/props_junk/cardboard_box004a.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Nitrocellulose"] = 1,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Nitrocellulose"
Item.Desc = "Also known as 'Gun Cotton', used to make smokeless powder."
Item.Model = "models/props_lab/box01a.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Bucket of Fertilizer"] = 1,
	["Cloth"] = 1,
}
GM.Inv:RegisterItem( Item )


-- Handguns
-- ----------------------------------------------------------------
local Item = {}
Item.Name = ".50 AE 5 Rounds"
Item.Desc = "5 rounds of .50 AE ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 5, ".50 AE" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".50 AE" ) > 20 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = ".44 Magnum 10 Rounds"
Item.Desc = "10 rounds of .44 Magnum ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, ".44 Magnum" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".44 Magnum" ) > 20 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "9x19MM 10 Rounds"
Item.Desc = "10 rounds of 9x19MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "9x19MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "9x19MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "5.7x28MM 10 Rounds"
Item.Desc = "10 rounds of 5.7x28MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "5.7x28MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "5.7x28MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = ".45 ACP 10 Rounds"
Item.Desc = "10 rounds of .45 ACP ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, ".45 ACP" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".45 ACP" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = ".45 Auto ACP 10 Rounds"
Item.Desc = "10 rounds of .45 Auto ACP ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, ".45 Auto ACP" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".45 ACP" ) > 120 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "9x18MM 10 Rounds"
Item.Desc = "10 rounds of 9x18MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "9x18MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "9x18MM" ) > 40 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


-- SMGs & Rifles
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "7.62x51MM 10 Rounds"
Item.Desc = "10 rounds of 7.62x51MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "7.62x51MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "7.62x51MM" ) > 80 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "HK 4.6x30MM 10 Rounds"
Item.Desc = "10 rounds of HK 4.6x30MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "HK 4.6x30MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "HK 4.6x30MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end

GM.Inv:RegisterItem( Item )
local Item = {}
Item.Name = ".300 AC 10 Rounds"
Item.Desc = "10 rounds of .300 AAC ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, ".300 AAC Blackout" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".300 AAC Blackout" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end

GM.Inv:RegisterItem( Item )
local Item = {}
Item.Name = "9x17MM 10 Rounds"
Item.Desc = "10 rounds of 9x17MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "9x17MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "9x17MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "5.56x45MM 10 Rounds"
Item.Desc = "10 rounds of 5.56x45MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "5.56x45MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "5.56x45MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "5.45x39MM 10 Rounds"
Item.Desc = "10 rounds of 5.45x39MM ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 10, "5.45x39MM" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "5.45x39MM" ) > 50 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Cigars"
Item.Desc = ""
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/props_c17/TrapPropeller_Lever.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = false
Item.CanUse = true
Item.Illegal = false
Item.DropClass = "prop_physics_multiplayer"

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 100, "12 Gauge" )
	pPlayer:GiveAmmo( 100, ".338 Lapua" )
	pPlayer:GiveAmmo( 100, "5.45x39MM" )
	pPlayer:GiveAmmo( 100, "5.56x45MM" )
	pPlayer:GiveAmmo( 100, "9x17MM" )
	pPlayer:GiveAmmo( 100, "7.62x51MM" )
	pPlayer:GiveAmmo( 100, "9x18MM" )
	pPlayer:GiveAmmo( 100, "9x19MM" )
	pPlayer:GiveAmmo( 100, ".45 ACP" )
	pPlayer:GiveAmmo( 100, "5.7x28MM" )
	pPlayer:GiveAmmo( 100, ".44 Magnum" )
	pPlayer:GiveAmmo( 100, ".50 AE" )
	pPlayer:GiveAmmo( 100, "HK 4.6x30MM" )
	pPlayer:GiveAmmo( 100, ".300 AAC Blackout" )
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = ".338 Lapua 5 Rounds"
Item.Desc = "5 rounds of .338 Lapua ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 5, ".338 Lapua" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( ".338 Lapua" ) > 20 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )


-- Shotguns
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "12 Gauge 5 Rounds"
Item.Desc = "5 rounds of 12 Gauge ammunition."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 25
Item.Volume = 15
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.CraftingEntClass = "ent_gunsmithing_table"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Smokeless Gunpowder"] = 1,
	["Metal Bar"] = 2,
}

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 5, "12 Gauge" )
end
Item.PlayerCanUse = function( _, pPlayer )
	if pPlayer:GetAmmoCount( "12 Gauge" ) > 15 then
		pPlayer:AddNote( "You can't equip that much ammo!" )
		return false
	end

	return true
end
GM.Inv:RegisterItem( Item )

-- Shotguns
-- ----------------------------------------------------------------
local Item = {}
Item.Name = "Crate Ammo"
Item.Desc = "Works on all weapons."
Item.Type = "type_ammo"
Item.TypeName = "Ammo"
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.DropClass = "prop_physics_multiplayer"

Item.OnUse = function( itm, pPlayer )
	pPlayer:GiveAmmo( 100, "12 Gauge" )
	pPlayer:GiveAmmo( 100, ".338 Lapua" )
	pPlayer:GiveAmmo( 100, "5.45x39MM" )
	pPlayer:GiveAmmo( 100, "5.56x45MM" )
	pPlayer:GiveAmmo( 100, "9x17MM" )
	pPlayer:GiveAmmo( 100, "7.62x51MM" )
	pPlayer:GiveAmmo( 100, "9x18MM" )
	pPlayer:GiveAmmo( 100, "9x19MM" )
	pPlayer:GiveAmmo( 100, ".45 ACP" )
	pPlayer:GiveAmmo( 100, "5.7x28MM" )
	pPlayer:GiveAmmo( 100, ".44 Magnum" )
	pPlayer:GiveAmmo( 100, ".50 AE" )
	pPlayer:GiveAmmo( 100, "HK 4.6x30MM" )
	pPlayer:GiveAmmo( 100, ".300 AAC Blackout" )
end
GM.Inv:RegisterItem( Item )