--[[
	Name: drugs_alcohol.lua
	For: SantosRP
	By: Ultra
]]--

--[[local function PlayerDrinkItem( tblItem, pPlayer )
	if tblItem.GiveThirst >= 0 then
		GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Thirst", tblItem.GiveThirst )
	else
		GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Thirst", math.abs(tblItem.GiveThirst) )
	end
	pPlayer:EmitSound( "npc/barnacle/barnacle_gulp".. math.random(1, 2).. ".wav", 60, math.random(70, 130) )
	pPlayer:ViewPunch( Angle(-math.random(6, 12), 0, 0) )
end

local function PlayerCanDrinkItem( tblItem, pPlayer )
	return GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Thirst" ) < GAMEMODE.Needs:GetNeedData( "Thirst" ).Max
end]]--

-- Drinking
-- --------------------------------------------------------------------------------------------------------------------------------
local function PlayerCanDrinkItem( tblItem, pPlayer )
	if GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Thirst" ) >= GAMEMODE.Needs:GetNeedData( "Thirst" ).Max then
		return
	end

	if tblItem.ThirstFillLen then
		--We are adding thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Quenching Thirst" ):CanGive( pPlayer, tblItem.ThirstFillLen )
		return bThirst
	else
		--We are removing thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Thirst" ):CanGive( pPlayer, tblItem.ThirstDrainLen )
		return bThirst
	end
end

local function PlayerDrinkItem( tblItem, pPlayer )
	if tblItem.ThirstFillLen then
		--We are adding thirst
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Quenching Thirst", tblItem.ThirstFillLen )
	else
		--We are removing thirst
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Thirst", tblItem.ThirstDrainLen )
	end

	pPlayer:EmitSound( "npc/barnacle/barnacle_gulp".. math.random(1, 2).. ".wav", 60, math.random(70, 130) )
	pPlayer:ViewPunch( Angle(-math.random(6, 12), 0, 0) )
end

local function AlcPlayerCanUse( tblItem, pPlayer )
	if not PlayerCanDrinkItem( tblItem, pPlayer ) then return false end

	local random = math.random( tblItem.IntoxMin, tblItem.IntoxMax )
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect( "Intoxication" ):CanGive( pPlayer, random, true )
	return b or bHandedOff, (b or bHandedOff) and { random } 
end

local function AlcPlayerUse( tblItem, pPlayer, intDuration )
	PlayerDrinkItem( tblItem, pPlayer )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Intoxication", intDuration )
	end
end


-- Items
-- --------------------------------------------------------------------------------------------------------------------------------
local Item = {}
Item.Name = "Beer"
Item.Desc = "A bottle of beer."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_glassbottle001a.mdl"
Item.Weight = 2
Item.Volume = 1
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_beer"
--Item.GiveThirst = 10
Item.ThirstFillLen = 4
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )


local Item = {}
Item.Name = "Red Wine"
Item.Desc = "A bottle of red wine."
Item.Type = "type_drugs"
Item.Model = "models/foodnhouseholditems/wine_red1.mdl"
Item.Weight = 3
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_redwine"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_redwine"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "White Wine"
Item.Desc = "A bottle of white wine."
Item.Type = "type_drugs"
Item.Model = "models/foodnhouseholditems/wine_white3.mdl"
Item.Weight = 3
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_whitewine"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_whitewine"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Champagne"
Item.Desc = "A bottle of champagne."
Item.Type = "type_drugs"
Item.Model = "models/foodnhouseholditems/champagne.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_champagne"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_champagne"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Moonshine"
Item.Desc = "A bottle of moonshine."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_glassbottle002a.mdl"
Item.Weight = 2
Item.Volume = 1
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_moonshine"
--Item.GiveThirst = 10
Item.ThirstFillLen = 4
Item.IntoxMin = 400
Item.IntoxMax = 600
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 5, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Methanol", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Whiskey"
Item.Desc = "A bottle of whiskey."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_glassbottle003a.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_whiskey"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_whiskey"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Vodka"
Item.Desc = "A bottle of vodka."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/glassjug01.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_vodka"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Bourbon"
Item.Desc = "A bottle of bourbon."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_glassbottle003a.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_bourbon"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_bourbon"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Brandy"
Item.Desc = "A bottle of brandy."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_glassbottle003a.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_brandy"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_brandy"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Scotch"
Item.Desc = "A bottle of scotch."
Item.Type = "type_drugs"
Item.Model = "models/props_junk/garbage_glassbottle003a.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "alcohol"
Item.DropClass = "ent_fluid_scotch"
--Item.GiveThirst = 25
Item.ThirstFillLen = 6
Item.IntoxMin = 140
Item.IntoxMax = 300
Item.PlayerCanUse = AlcPlayerCanUse
Item.OnUse = AlcPlayerUse

Item.StillVars = {
	FluidAmountPerItem = 500, --amount of processed fluid needed to give the player an item
	FluidStillRate = 3, --amount of fluid to process each interval
	FluidStillInterval = 0.5, --Time until the next fluid processing

	GiveItem = "Moonshine", --item to give when fluidamount is reached
	GiveAmount = 1, --amount of the item to give each time
}

Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_item_scotch"
GM.Inv:RegisterItem( Item )