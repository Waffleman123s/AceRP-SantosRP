--[[
	Name: job_items_gov.lua
	For: SantosRP
	By: Ultra
]]--


local Item = {}
Item.Name = "Government Issue Spare Tire Kit"
Item.Desc = "A replacement set of tires for any vehicle."
Item.Model = "models/props_vehicles/carparts_wheel01a.mdl"
Item.Weight = 30
Item.Volume = 40
Item.CanDrop = true
Item.JobItem = "JOB_SSERVICE" --This item can only be possessed by by players with this job
Item.LimitID = "car repair kit"
Item.DropClass = "ent_carfix_wheels"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )


local Item = {}
Item.Name = "Government Issue Engine Overhaul"
Item.Desc = "A complete engine overhaul kit. Used on vehicles that have 0 health."
Item.Model = "models/props_c17/TrapPropeller_Engine.mdl"
Item.Weight = 60
Item.Volume = 50
Item.CanDrop = true
Item.JobItem = "JOB_SSERVICE" --This item can only be possessed by by players with this job
Item.LimitID = "car repair kit"
Item.DropClass = "ent_carfix_high"
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )


local Item = {}
Item.Name = "Government Issue Traffic Barrel"
Item.Desc = "A traffic trailer barrel."
Item.Model = "models/noble/trafficbarrel/traffic_barrel.mdl"
Item.Weight = 2
Item.Volume = 8
Item.CanDrop = true
Item.CanSitOn = true
Item.RemoveDropOnDeath = true
Item.HealthOverride = 3000
Item.JobItem = "JOB_SSERVICE" --This item can only be possessed by by players with this job
Item.LimitID = "traffic barrel"
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
		return eEnt:GetPlayerOwner() == pPlayer
	end
end
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 10 )
Item.CollidesWithCars = true


local Item = {}
Item.Name = "Government Issue Barrier"
Item.Desc = "A government barrier"
Item.Model = "models/props_fortifications/police_barrier001_128_reference.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanSitOn = true
Item.RemoveDropOnDeath = true
Item.HealthOverride = 3000
Item.JobItem = "JOB_SSERVICE" --This item can only be possessed by by players with this job
Item.LimitID = "barrier"
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
		return eEnt:GetPlayerOwner() == pPlayer
	end
end
Item.CanGive = function( self, pPlayer, intAmount )
	local itemNum = GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, self.Name ) +intAmount
	return itemNum <= GAMEMODE.Config.JobLockerItems[_G[self.JobItem]][self.Name]
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 6 )
Item.CollidesWithCars = true


-- local Item = {}
--     Item.Name = "Judge Cape"
--     Item.Desc = "A Judge cape. Made by Sour."
--     Item.Type = "type_clothing"
--     Item.Model = "models/weapons/w_defuser.mdl"
--     Item.Weight = 1
--     Item.Volume = 1
--     Item.CanDrop = false
--     Item.CanEquip = true
--     Item.Illegal = false
--     Item.EquipSlot = "Back"
--     Item.PacOutfit = "judgecape"
--     Item.Stats = [[
--     +4500 Inventory Weight
--     +4500 Inventory Volume]]
 
--     Item.EquipBoostCarryWeight = 500
--     Item.EquipBoostCarryVolume = 500
 
 
--         GM.PacModels:Register( Item.PacOutfit, {
--   [1] = {
-- 	["children"] = {
-- 		[1] = {
-- 			["children"] = {
-- 			},
-- 			["self"] = {
-- 				["UniqueID"] = "3310762629",
-- 				["Position"] = Vector(2.7160000801086, 4.0609998703003, 3.9349999427795),
-- 				["Scale"] = Vector(1.2000000476837, 1.1000000238419, 0.80000001192093),
-- 				["Alpha"] = 0.975,
-- 				["Angles"] = Angle(19.260000228882, 115.63400268555, -106.80599975586),
-- 				["Size"] = 0.015,
-- 				["EditorExpand"] = true,
-- 				["ClassName"] = "model",
-- 				["Bone"] = "spine 4",
-- 				["Model"] = "models/hunter/plates/plate1x1.mdl",
-- 				["Material"] = "https://s-media-cache-ak0.pinimg.com/originals/24/13/97/2413978937f2d93382bcf46d80960793.png",
-- 			},
-- 		},
-- 		[2] = {
-- 			["children"] = {
-- 				[1] = {
-- 					["children"] = {
-- 					},
-- 					["self"] = {
-- 						["Angles"] = Angle(4.7600517272949, 0.00014542967255693, 8.3531040218077e-06),
-- 						["ClassName"] = "model",
-- 						["UniqueID"] = "1620269459",
-- 						["EditorExpand"] = true,
-- 						["Color"] = Vector(67, 67, 67),
-- 						["Position"] = Vector(-4.8157958984375, 0.000579833984375, 18.3330078125),
-- 						["Model"] = "models/pac/jiggle/clothing/base_cape_2.mdl",
-- 						["Material"] = "models/props_lab/door_klab01",
-- 					},
-- 				},
-- 			},
-- 			["self"] = {
-- 				["UniqueID"] = "2430657235",
-- 				["Position"] = Vector(-15.6552734375, -17.3046875, -0.15760803222656),
-- 				["EditorExpand"] = true,
-- 				["Material"] = "models/props_vents/borealis_vent001c",
-- 				["Angles"] = Angle(-0.00012977360165678, -47.177303314209, -90.000030517578),
-- 				["Color"] = Vector(96, 96, 96),
-- 				["Bone"] = "neck",
-- 				["Model"] = "models/sal/acc/fix/scarf01.mdl",
-- 				["ClassName"] = "model",
-- 			},
-- 		},
-- 		[3] = {
-- 			["children"] = {
-- 			},
-- 			["self"] = {
-- 				["UniqueID"] = "1206748179",
-- 				["Position"] = Vector(1.37399995327, 5.6950001716614, 3.8159999847412),
-- 				["Scale"] = Vector(1, 1, 0.10000000149012),
-- 				["Alpha"] = 0.95,
-- 				["Angles"] = Angle(4.4619998931885, 136.60899353027, -101.94100189209),
-- 				["Size"] = 0.025,
-- 				["EditorExpand"] = true,
-- 				["ClassName"] = "model",
-- 				["Bone"] = "spine 4",
-- 				["Model"] = "models/hunter/plates/plate1x1.mdl",
-- 				["Material"] = "https://upload.wikimedia.org/wikipedia/commons/5/54/Seal_of_the_United_States_Department_of_Justice.svg",
-- 			},
-- 		},
-- 	},
-- 	["self"] = {
-- 		["EditorExpand"] = true,
-- 		["UniqueID"] = "84323560",
-- 		["ClassName"] = "group",
-- 		["Name"] = "my outfit",
-- 		["Description"] = "add parts to me!",
-- 	},
-- },
--     } )
-- GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
-- GM.Inv:RegisterItem( Item )
    
local Item = {}
Item.Name = "Government Issue Radio"
Item.Desc = "Government Radio."
Item.Type = "type_weapon"
Item.Model = "models/realistic_police/radio/w_radio.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = SRPGG.Config.Job.Radio
Item.Illegal = false -- Just so cops can pat this item down
Item.EquipSlot = "PocketWeapon"
Item.EquipGiveClass = "weapon_rdo_radio"
Item.DropClass = "weapon_rdo_radio"
Item.PacOutfit = "pdradio"
GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(13.2109375, 3.4433288574219, 13.95458984375),
				["Angles"] = Angle(38.337619781494, 176.63598632813, 74.092636108398),
				["UniqueID"] = "526401356",
				["Size"] = 0.775,
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/realistic_police/radio/c_radio.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},	
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "331751174",
		["ClassName"] = "group",
		["Name"] = "pdradio",
		["Description"] = "add parts to me!",
	},
},
} )
GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
GM.Inv:RegisterItem( Item )