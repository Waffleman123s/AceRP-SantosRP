--[[
	Name: job_weapons_lumber_jack.lua
	For: SantosRP
	By: Ultra
]]--

local Item = {}
Item.Name = "Lumber Axe"
Item.Desc = "A Lumber Axe! Cut down trees with this tool"
Item.Type = "type_weapon"
Item.Model = "models/weapons/tfa_nmrih/w_me_hatchet.mdl"
Item.Weight = 12
Item.Volume = 8
Item.CanDrop = false
Item.CanEquip = true
Item.JobItem = "JOB_LUMBERWORKER"
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "weapon_fireaxe"
GM.Inv:RegisterItem( Item )