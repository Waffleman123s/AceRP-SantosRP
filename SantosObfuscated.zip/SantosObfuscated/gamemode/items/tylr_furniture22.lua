--[[
local Item = {}
Item.Name = "Round Table"
Item.Desc = "A round table."
Item.Type = "type_furniture"
Item.Model = "models/props_c17/FurnitureTable001a.mdl"
Item.Weight = 40
Item.Volume = 50
Item.HealthOverride = 1500
Item.CanDrop = true
Item.CanSitOn = true
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Cash Register"
Item.Desc = "A cash register that allows the user to manage a store. Caution: Walking away from the register is a bad idea."
Item.Model = "models/props_c17/cashregister01a.mdl"
Item.Type = "type_electronics"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "cash register"
Item.DropClass = "ent_cashregister"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t2"] = 1 } )

Model
























]]--

local Item = {}
Item.Name = "Blue Chair" -- noprice
Item.Desc = "A Blue Chair."
Item.Model = "models/props_c17/chair02a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair1"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

local Item = {}
Item.Name = "Wood Chair" -- noprice
Item.Desc = "A Wood Chair."
Item.Model = "models/props_c17/FurnitureChair001a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair2"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

 -- office 
local Item = {}
Item.Name = "Office Chair" -- noprice
Item.Desc = "An office chair."
Item.Model = "models/props_combine/breenchair.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair3"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

local Item = {}
Item.Name = "Metal Chair" -- noprice
Item.Desc = "An metal chair."
Item.Model = "models/props_wasteland/controlroom_chair001a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair6"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- old office 
local Item = {}
Item.Name = "Old Office Chair" -- noprice
Item.Desc = "An old office chair."
Item.Model = "models/nova/chair_office01.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair9"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- plastic shitter
local Item = {}
Item.Name = "Plastic Chair" -- noprice
Item.Desc = "A plastic chair."
Item.Model = "models/chairs_mod/chair10/chair10.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair18"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- hill billy chair 
local Item = {}
Item.Name = "Hill Billy Chair" -- noprice
Item.Desc = "A shitty hill billy chair."
Item.Model = "models/chairs_mod/chair9/chair9.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair17"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

local Item = {}
Item.Name = "Sunbathing Chair" -- noprice
Item.Desc = "A sunbathing chair."
Item.Model = "models/chairs_mod/sunbathing_chair/sunbathing_chair.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_sunbathing"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

local Item = {}
Item.Name = "Stool" -- noprice
Item.Desc = "A stool."
Item.Model = "models/props_c17/chair_stool01a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair20"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )


local Item = {}
Item.Name = "School Desk" -- noprice
Item.Desc = "A School Desk."
Item.Model = "models/chairs_mod/chair11/chair11.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair16"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- wood 
local Item = {}
Item.Name = "Wood Bench" -- noprice
Item.Desc = "A wood bench."
Item.Model = "models/props_c17/bench01a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_bench1"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- red 
local Item = {}
Item.Name = "Red Sofa" -- noprice
Item.Desc = "A Sofa."
Item.Model = "models/props_c17/FurnitureCouch001a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_sofa1"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

--dass_chair_sofa4 -- yellow
--models/props_interiors/Furniture_Couch02a.mdl
local Item = {}
Item.Name = "Yellow Sofa" -- noprice
Item.Desc = "A Sofa."
Item.Model = "models/props_interiors/Furniture_Couch02a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_sofa4"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

--dass_chair_sofa7 -- swag
--models/chairs_mod/sofa3/sofa3.mdl
local Item = {}
Item.Name = "Fancy Sofa" -- noprice
Item.Desc = "A Sofa."
Item.Model = "models/chairs_mod/sofa3/sofa3.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_sofa7"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- dass_chair_sofa6 -- king 
-- models/chairs_mod/sofa2/sofa2.mdl
local Item = {}
Item.Name = "Kings Sofa" -- noprice
Item.Desc = "A king Sofa."
Item.Model = "models/chairs_mod/sofa2/sofa2.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_sofa7"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )

-- dass_chair_bed3 bedd
-- models/chairs_mod/bed1/bed1.mdl
local Item = {}
Item.Name = "Bed" -- noprice
Item.Desc = "For sleepy people."
Item.Model = "models/chairs_mod/bed1/bed1.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_bed3"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1 } )

-- dass_chair_bathtub2
-- models/props_interiors/BathTub01a.mdl
local Item = {}
Item.Name = "Bathtub" -- noprice
Item.Desc = "For sleepy people."
Item.Model = "models/props_interiors/BathTub01a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_bathtub2"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1 } )

-- dass_chair_toilet
-- models/props_c17/FurnitureToilet001a.mdl

local Item = {}
Item.Name = "Toilet" -- noprice
Item.Desc = "A toilet."
Item.Model = "models/props_c17/FurnitureToilet001a.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_toilet"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1 } )

--dass_chair_armchair -- arty chair
--models/chairs/armchair.mdl
-- local Item = {}
-- Item.Name = "Arm Chair" -- noprice
-- Item.Desc = "An Arm Chair."
-- Item.Model = "models/chairs/armchair.mdl"
-- Item.Type = "type_furniture"
-- Item.Weight = 15
-- Item.Volume = 20
-- Item.HealthOverride = 3000
-- Item.CanDrop = true
-- Item.LimitID = "chair"
-- Item.DropClass = "dass_chair_armchair"
-- GM.Inv:RegisterItem( Item )
-- GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1 } )

local Item = {}
Item.Name = "Arm Chair" -- noprice
Item.Desc = "An Arm Chair."
Item.Model = "models/chairs/armchair.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_armchair"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1 } )

--dass_chair_chair12 -- Gaming 
--models/chairs_mod/chair3/chair3.mdl
local Item = {}
Item.Name = "Gaming Chair" -- noprice
Item.Desc = "A Gaming Chair."
Item.Model = "models/chairs_mod/chair3/chair3.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair12"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1 } )

-- dass_chair_chair15 -- red stool 
-- models/chairs_mod/chair7/chair7.mdl
local Item = {}
Item.Name = "Red Stool" -- noprice
Item.Desc = "A Red Stool."
Item.Model = "models/chairs_mod/chair7/chair7.mdl"
Item.Type = "type_furniture"
Item.Weight = 15
Item.Volume = 20
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "chair"
Item.DropClass = "dass_chair_chair15"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 6 } )