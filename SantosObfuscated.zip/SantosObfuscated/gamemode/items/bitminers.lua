-- local Item = {}
-- Item.Name = "Bitminer S1"
-- Item.Desc = "An prototype of the first bitminer."
-- Item.Model = "models/bitminers2/bitminer_1.mdl"
-- Item.Weight = 125
-- Item.Volume = 150
-- Item.CanDrop = true
-- Item.LimitID = "bitminer s1"
-- Item.DropClass = "bm2_bitminer_1"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 1
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 3,
-- 	["Pliers"] = 1,
-- 	["Metal Plate"] = 2,
-- 	["Metal Bar"] = 4,
-- 	["Metal Bracket"] = 2
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit(Item.LimitID, 1, {
-- 	["vip_t1"] = 2
-- })

-- local Item = {}
-- Item.Name = "Bitminer S2"
-- Item.Desc = "A prototype of the second bitminer."
-- Item.Model = "models/bitminers2/bitminer_3.mdl"
-- Item.Weight = 185
-- Item.Volume = 200
-- Item.CanDrop = true
-- Item.LimitID = "bitminer s2"
-- Item.DropClass = "bm2_bitminer_2"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 5
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 8,
-- 	["Pliers"] = 3,
-- 	["Metal Plate"] = 6,
-- 	["Metal Bar"] = 9,
-- 	["Metal Bracket"] = 6
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit(Item.LimitID, 1, {
-- 	["vip_t1"] = 2
-- })

-- local Item = {}
-- Item.Name = "Bitminer Power Lead"
-- Item.Desc = "A Bitminer power lead."
-- Item.Model = "models/bitminers2/bitminer_plug_2.mdl"
-- Item.Weight = 35
-- Item.Volume = 22
-- Item.CanDrop = true
-- Item.LimitID = "bitminer power lead"
-- Item.DropClass = "bm2_power_lead"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 1
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 12,
-- 	["Pliers"] = 2,
-- 	["Metal Plate"] = 8,
-- 	["Metal Bar"] = 10,
-- 	["Metal Bracket"] = 5
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit(Item.LimitID, 2, {
-- 	["vip_t1"] = 4
-- })

-- local Item = {}
-- Item.Name = "Bitminer Power Strip"
-- Item.Desc = "A Bitminer power strip."
-- Item.Model = "models/bitminers2/bitminer_plug_3.mdl"
-- Item.Weight = 45
-- Item.Volume = 32
-- Item.CanDrop = true
-- Item.LimitID = "bitminer power strip"
-- Item.DropClass = "bm2_extention_lead"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 1
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 15,
-- 	["Pliers"] = 3,
-- 	["Metal Plate"] = 12,
-- 	["Metal Bar"] = 15,
-- 	["Metal Bracket"] = 10
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit(Item.LimitID, 2, {
-- 	["vip_t1"] = 2
-- })

-- local Item = {}
-- Item.Name = "Bitminer Server"
-- Item.Desc = "A Bitminer server (requires a rack)."
-- Item.Model = "models/bitminers2/bitminer_2.mdl"
-- Item.Weight = 122
-- Item.Volume = 110
-- Item.CanDrop = true
-- Item.LimitID = "bitminer server box"
-- Item.DropClass = "bm2_bitminer_server"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 8
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 20,
-- 	["Pliers"] = 2,
-- 	["Metal Plate"] = 17,
-- 	["Metal Bar"] = 19,
-- 	["Metal Bracket"] = 15
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit( Item.LimitID, 4, { ["vip_t1"] = 8, ["vip_t2"] = 12 } )


-- local Item = {}
-- Item.Name = "Bitminer Server Rack"
-- Item.Desc = "A Bitminer server rack."
-- Item.Model = "models/bitminers2/bitminer_rack.mdl"
-- Item.Weight = 50
-- Item.Volume = 70
-- Item.CanDrop = true
-- Item.LimitID = "bitminer server rack"
-- Item.DropClass = "bm2_bitminer_rack"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 8
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 25,
-- 	["Pliers"] = 1,
-- 	["Metal Plate"] = 14,
-- 	["Metal Bar"] = 5,
-- 	["Metal Bracket"] = 2
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 1, ["vip_t2"] = 2 } )


-- local Item = {}
-- Item.Name = "Bitminer Generator"
-- Item.Desc = "A Bitminer generator."
-- Item.Model = "models/bitminers2/generator.mdl"
-- Item.Weight = 200
-- Item.Volume = 250
-- Item.CanDrop = true
-- Item.LimitID = "bitminer generator"
-- Item.DropClass = "bm2_generator"
-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Bitminers"
-- Item.CraftSkill = "Assembly"
-- Item.CraftSkillLevel = 1
-- Item.CraftSkillXP = 10

-- Item.CraftRecipe = {
-- 	["Chunk of Plastic"] = 45,
-- 	["Pliers"] = 3,
-- 	["Metal Plate"] = 25,
-- 	["Metal Bar"] = 15,
-- 	["Metal Bracket"] = 25
-- }

-- GM.Inv:RegisterItem(Item)

-- GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 2, ["vip_t2"] = 3 } )