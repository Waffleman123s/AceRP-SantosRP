--[[
	Name: cw_guns.lua
	For: SantosRP
	By: Ultra
]]--

if SERVER then
	resource.AddWorkshop( "717188718" )
	resource.AddWorkshop( "358608166" )
	resource.AddWorkshop( "349050451" )
end

hook.Add( "InitPostEntity", "PatchCWMouse", function()
	local base = weapons.GetStored( "cw_base" )
	if not base then return end

	base.AdjustMouseSensitivity = function()
		return 1 --go eway
	end

	for k, v in pairs( GAMEMODE.Inv:GetItems() ) do
		if not v.IsCW then continue end
		local wep = weapons.GetStored( v.EquipGiveClass )
		if wep then
			wep.Primary.DefaultClip = 0
		end
	end
end )

if SERVER and CustomizableWeaponry then
	CustomizableWeaponry.canDropWeapon = false -- set this to false to disable cw_dropweapon concommand
	CustomizableWeaponry.enableWeaponDrops = false -- set this to false to disable weapon dropping in general (no idea why you would want to do that though)
end

if CLIENT then
	RunConsoleCommand( "cw_customhud_ammo", "1" )
end

local Item = {}
Item.Name = "Makarov"
Item.Desc = "A makarov pistol."
Item.Type = "type_weapon"
Item.Model = "models/cw2/pistols/w_makarov.mdl"
Item.Weight = 6
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "cw_makarov"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_makarov"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 6
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 1,
    ["Handle Grip"] = 1,
    ["Trigger"] = 1,
    ["Slide"] = 1,
    ["Bolt"] = 1,
    ["Firing Pin"] = 1,
    ["Lower Receiver"] = 1,
    ["Short Barrel"] = 1,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "M1911"
Item.Desc = "An M1911 pistol."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_1911.mdl"
Item.Weight = 6
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "cw_m1911"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_m1911"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 9
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 1,
    ["Handle Grip"] = 1,
    ["Trigger"] = 2,
    ["Slide"] = 1,
    ["Bolt"] = 1,
    ["Firing Pin"] = 1,
    ["Lower Receiver"] = 1,
    ["Short Barrel"] = 1,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "P99"
Item.Desc = "A P99 pistol."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_pist_p228.mdl"
Item.Weight = 6
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "cw_p99"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_p99"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 11
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 2,
    ["Handle Grip"] = 1,
    ["Trigger"] = 2,
    ["Slide"] = 1,
    ["Bolt"] = 1,
    ["Firing Pin"] = 1,
    ["Lower Receiver"] = 1,
    ["Short Barrel"] = 1,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Five Seven"
Item.Desc = "A Five Seven pistol."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_pist_fiveseven.mdl"
Item.Weight = 6
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "cw_fiveseven"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_fiveseven"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 13
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 2,
    ["Handle Grip"] = 2,
    ["Trigger"] = 2,
    ["Slide"] = 1,
    ["Bolt"] = 1,
    ["Firing Pin"] = 1,
    ["Lower Receiver"] = 1,
    ["Short Barrel"] = 1,
}
GM.Inv:RegisterItem( Item )




local Item = {}
Item.Name = "M11A1"
Item.Desc = "A M11A1 machine pistol."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cst_mac11.mdl"
Item.Weight = 8
Item.Volume = 6
Item.CanDrop = true
Item.DropClass = "cw_mac11"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_mac11"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "SMGs"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 15
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 2,
    ["Handle Grip"] = 3,
    ["Trigger"] = 4,
    ["Slide"] = 2,
    ["Bolt"] = 2,
    ["Firing Pin"] = 3,
    ["Lower Receiver"] = 2,
    ["Short Barrel"] = 4,  
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Glock-17"
Item.Desc = "A Glock-17 pistol."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_pist_glock18.mdl"
Item.Weight = 6
Item.Volume = 4
Item.CanDrop = true
Item.DropClass = "cw_nen_glock17"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_nen_glock17"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 15
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 2,
    ["Handle Grip"] = 1,
    ["Trigger"] = 2,
    ["Slide"] = 1,
    ["Bolt"] = 1,
    ["Firing Pin"] = 1,
    ["Lower Receiver"] = 2,
    ["Short Barrel"] = 1,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "M3 Super 90"
Item.Desc = "An M3 Super 90 shotgun."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cstm_m3super90.mdl"
Item.Weight = 18
Item.Volume = 11
Item.CanDrop = true
Item.DropClass = "cw_m3super90"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_m3super90"
Item.PacOutfit = "m3_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Shotguns"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 16
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 2,
    ["Handle Grip"] = 5,
    ["Trigger"] = 4,
    ["Slide"] = 4,
    ["Bolt"] = 4,
    ["Firing Pin"] = 4,
    ["Lower Receiver"] = 2,
    ["Short Barrel"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3060188880",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_m3super90",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-7.1727294921875, -5.107421875, 1.20458984375),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_cstm_m3super90.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Thompson" --p90
Item.Desc = "A thompson rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_thompsont.mdl"
Item.Weight = 14
Item.Volume = 11
Item.CanDrop = true
Item.DropClass = "cw_thompsona1_s"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_thompsona1_s"
Item.PacOutfit = "cw_thompsona1_s"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 17
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 4,
    ["Handle Grip"] = 3,
    ["Long Barrel"] = 1,
    ["Trigger"] = 4,
	["Stock"] = 1,
    ["Bolt"] = 3,
    ["Lower Receiver"] = 4,
    ["Short Barrel"] = 2, 
    ["Cylinder"] = 3,
    ["Firing Pin"] = 2,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3060188880",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_thompsona1_s",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-4, -3.2, -0.260),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_thompsont.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "MP5A5" --mp5a3
Item.Desc = "An MP5A5 sub-machine gun."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_smg_mp5.mdl"
Item.Weight = 10
Item.Volume = 8
Item.CanDrop = true
Item.DropClass = "cw_mp5"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_mp5"
Item.PacOutfit = "mp5_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "SMGs"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 18
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 1,
    ["Bolt"] = 3,
	["Stock"] = 2,
    ["Upper Receiver"] = 3,
    ["Handle Grip"] = 4,
    ["Trigger"] = 4,
    ["Lower Receiver"] = 3,
    ["Firing Pin"] = 2,
    ["Short Barrel"] = 2,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3827241767",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_mp5",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(-3.2440683841705, -178.67698669434, -22.848773956299),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(2.2931747436523, -1.4446411132813, -8.773193359375),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_smg_mp5.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "UMP-45" -- mp7a1
Item.Desc = "A UMP45 SMG."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_smg_ump45.mdl"
Item.Weight = 12
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "cw_ump45"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_ump45"
Item.PacOutfit = "ump45"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "SMGs"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 18
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Bolt"] = 3,
	["Stock"] = 2,
    ["Upper Receiver"] = 3,
    ["Handle Grip"] = 4,
    ["Trigger"] = 4,
    ["Lower Receiver"] = 3,
    ["Firing Pin"] = 2,
    ["Short Barrel"] = 2,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "2696076219",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_ump45",
						},
					},
				},
				["self"] = {
					["Position"] = Vector(-13.74267578125, 0.849365234375, -0.64501953125),
					["Angles"] = Angle(3.4856202602386, -0.33305096626282, 12.302300453186),
					["UniqueID"] = "1484483537",
					["Size"] = 0.925,
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_smg_ump45.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "AAC Honey Badger"
-- Item.Desc = "A Honey Badger SMG."
-- Item.Type = "type_weapon"
-- Item.Model = "models/cw2/gsm/w_gsm_aac.mdl"
-- Item.Weight = 14
-- Item.Volume = 11
-- Item.CanDrop = true
-- Item.DropClass = "cw_aacgsm"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "cw_aacgsm"
-- Item.PacOutfit = "cw_aacgsm"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "SMGs"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 19
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 4,
--     ["Bolt"] = 5,
--     ["Trigger"] = 5,
--     ["Stock"] = 4,
--     ["Handle Grip"] = 4,
--     ["Long Barrel"] = 5,
--     ["Upper Receiver"] = 6,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "3060188880",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "cw_aacgsm",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3.2, -0.260),
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/cw2/gsm/w_gsm_aac.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )

-- local Item = {}
--     Item.Name = "AUG A3"
-- Item.Desc = "An aug a3 rifle."
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/therambotnic09/w_cw2_auga3.mdl"
-- Item.Weight = 14
-- Item.Volume = 11
-- Item.CanDrop = true
-- Item.DropClass = "cw_tr09_auga3"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "cw_tr09_auga3"
-- Item.PacOutfit = "cw_tr09_auga3"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Rifles"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 20
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 3,
--     ["Bolt"] = 4,
--     ["Trigger"] = 2,
--     ["Stock"] = 3,
--     ["Handle Grip"] = 4,
--     ["Long Barrel"] = 3,
--     ["Upper Receiver"] = 4,
-- 	["Metal Plate"] = 40,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "3060188880",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "cw_tr09_auga3",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3.2, -0.260),
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/weapons/therambotnic09/w_cw2_auga3.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "AK-47"
Item.Desc = "An AK-47 rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_rif_ak47.mdl"
Item.Weight = 12
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "cw_ak74"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_ak74"
Item.PacOutfit = "ak47_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 21
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 5,
    ["Bolt"] = 5,
    ["Upper Receiver"] = 5,
    ["Handle Grip"] = 5,
    ["Trigger"] = 5,
	["Stock"] = 5,
    ["Lower Receiver"] = 5,
    ["Firing Pin"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "2859473494",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_ak74",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(3, -3.2, -5),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_rif_ak47.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "KSG"
-- Item.Desc = "A KSG shotgun."
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/therambotnic09/w_rafael_ksg.mdl"
-- Item.Weight = 14
-- Item.Volume = 11
-- Item.CanDrop = true
-- Item.DropClass = "cw_tr09_ksg12"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "cw_tr09_ksg12"
-- Item.PacOutfit = "ksg_back"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Shotguns"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 22
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 3,
--     ["Bolt"] = 4,
--     ["Trigger"] = 5,
--     ["Stock"] = 4,
--     ["Handle Grip"] = 3,
--     ["Long Barrel"] = 5,
--     ["Upper Receiver"] = 4,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "3060188880",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "cw_tr09_ksg12",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3.2, -0.260),
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/weapons/therambotnic09/w_rafael_ksg.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "IMI Desert Eagle"
Item.Desc = "A Desert Eagle pistol."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_pist_deagle.mdl"
Item.Weight = 9
Item.Volume = 6
Item.CanDrop = true
Item.DropClass = "cw_deagle"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_deagle"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 23
Item.CraftSkillXP = 5
Item.CraftRecipe = {
    ["Upper Receiver"] = 2,
    ["Handle Grip"] = 4,
    ["Trigger"] = 4,
    ["Slide"] = 4,
    ["Bolt"] = 4,
    ["Firing Pin"] = 4,
    ["Lower Receiver"] = 4,
    ["Short Barrel"] = 4,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "M14" -- ssg crafting
Item.Desc = "An M14 rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cstm_m14.mdl"
Item.Weight = 12
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "cw_m14"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_m14"
Item.PacOutfit = "m14_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 24
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Stock"] = 4,
    ["Upper Receiver"] = 4,
    ["Handle Grip"] = 4,
    ["Trigger"] = 5,
    ["Long Barrel"] = 8,
    ["Bolt"] = 4,
    ["Firing Pin"] = 4,
    ["Lower Receiver"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "965353309",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_m14",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-4, -3.2, -0.260),
					["Size"] = 1.025,
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_cstm_m14.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "G3A3"
Item.Desc = "A G3A3 rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_snip_g3sg1.mdl"
Item.Weight = 12
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "cw_g3a3"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_g3a3"
Item.PacOutfit = "cw_g3a3"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 25
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Stock"] = 5,
    ["Upper Receiver"] = 4,
    ["Handle Grip"] = 4,
    ["Trigger"] = 5,
    ["Long Barrel"] = 8,
    ["Bolt"] = 4,
    ["Firing Pin"] = 4,
    ["Lower Receiver"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3060188880",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_g3a3",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(-3.2440683841705, -178.67698669434, -22.848773956299),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-3.8226852416992, -1.2533569335938, -9.2270812988281),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_snip_g3sg1.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "G36C"
Item.Desc = "A G36C rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/cw20_g36c.mdl"
Item.Weight = 12
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "cw_g36c"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_g36c"
Item.PacOutfit = "g36_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 26
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Stock"] = 5,
    ["Upper Receiver"] = 5,
    ["Handle Grip"] = 4,
    ["Trigger"] = 5,
    ["Long Barrel"] = 8,
    ["Bolt"] = 4,
    ["Firing Pin"] = 4,
    ["Lower Receiver"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3661784215",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_g36c",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-4, -3.2, -0.260),
					["Size"] = 1.025,
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/cw20_g36c.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "L115" -- awp
Item.Desc = "An L115 bolt action rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cstm_l96.mdl"
Item.Weight = 12
Item.Volume = 12
Item.CanDrop = true
Item.DropClass = "cw_l115"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_l115"
Item.PacOutfit = "m24_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Sniper Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 27
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 8,
    ["Bolt"] = 5,
    ["Upper Receiver"] = 5,
    ["Handle Grip"] = 5,
    ["Trigger"] = 5,
	["Stock"] = 5,
    ["Lower Receiver"] = 5,
    ["Firing Pin"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "1972331155",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_l115",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-4 -2.9111938476563, -5.2907600402832),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_cstm_l96.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )


-- local Item = {}
-- Item.Name = "LR300"
-- Item.Desc = "A LR300 rifle."
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/therambotnic09/w_cw2_lr300.mdl"
-- Item.Weight = 12
-- Item.Volume = 10
-- Item.CanDrop = true
-- Item.DropClass = "cw_tr09_lr300"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "cw_tr09_lr300"
-- Item.PacOutfit = "cw_tr09_lr300"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Rifles"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 28
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 4,
--     ["Bolt"] = 5,
--     ["Trigger"] = 4,
--     ["Stock"] = 5,
--     ["Handle Grip"] = 3,
--     ["Long Barrel"] = 5,
--     ["Lower Receiver"] = 6,
--     ["Upper Receiver"] = 7,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "3060188880",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "cw_tr09_lr300",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3, -0.260),
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/weapons/therambotnic09/w_cw2_lr300.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Mosin Nagant" -- awp editted
Item.Desc = "A Mosin nagant rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/ws mosin/w_ws_mosin.mdl"
Item.Weight = 14
Item.Volume = 11
Item.CanDrop = true
Item.DropClass = "cw_ws_mosin"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_ws_mosin"
Item.PacOutfit = "mosin_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 29
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 8,
    ["Bolt"] = 6,
    ["Upper Receiver"] = 5,
    ["Handle Grip"] = 5,
    ["Trigger"] = 6,
	["Stock"] = 6,
    ["Lower Receiver"] = 5,
    ["Firing Pin"] = 5,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3060188880",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_ws_mosin",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-4, -3.2, -0.260),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/ws mosin/w_ws_mosin.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "QBZ 97"
-- Item.Desc = "A qbz 97 rifle."
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/therambotnic09/w_cw2_qbz97.mdl"
-- Item.Weight = 14
-- Item.Volume = 11
-- Item.CanDrop = true
-- Item.DropClass = "cw_tr09_qbz97"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "cw_tr09_qbz97"
-- Item.PacOutfit = "cw_tr09_qbz97"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Rifles"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 30
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 4,
--     ["Bolt"] = 6,
--     ["Trigger"] = 5,
--     ["Stock"] = 7,
--     ["Handle Grip"] = 4,
--     ["Long Barrel"] = 8,
--     ["Upper Receiver"] = 3,
-- 	["Metal Plate"] = 40,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "3060188880",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "cw_tr09_qbz97",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3.2, -0.260),
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/weapons/therambotnic09/w_cw2_qbz97.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Raging Bull"
Item.Desc = "A Raging Bull revolver."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_357.mdl"
Item.Weight = 9
Item.Volume = 6
Item.CanDrop = true
Item.DropClass = "cw_mr96"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "SecondaryWeapon"
Item.EquipGiveClass = "cw_mr96"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Pistols"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 31
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 6,
    ["Bolt"] = 6,
    ["Upper Receiver"] = 6,
    ["Handle Grip"] = 7,
    ["Trigger"] = 7,
	["Stock"] = 6,
    ["Lower Receiver"] = 6,
    ["Firing Pin"] = 6,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "ScarH"
Item.Desc = "A ScarH rifle."
Item.Type = "type_weapon"
Item.Model = "models/cw2/rifles/w_scarh.mdl"
Item.Weight = 12
Item.Volume = 10
Item.CanDrop = true
Item.DropClass = "cw_scarh"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_scarh"
Item.PacOutfit = "scar_back"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 31
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 8,
    ["Bolt"] = 8,
    ["Upper Receiver"] = 8,
    ["Handle Grip"] = 8,
    ["Trigger"] = 8,
	["Stock"] = 8,
    ["Lower Receiver"] = 8,
    ["Firing Pin"] = 8,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3060188880",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_scarh",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(-4, -3.2, -0.260),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/cw2/rifles/w_scarh.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )


-- local Item = {}
-- Item.Name = "ImI Tar 21"
-- Item.Desc = "A tar 21 rifle."
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/therambotnic09/w_cw2_tar21.mdl"
-- Item.Weight = 14
-- Item.Volume = 11
-- Item.CanDrop = true
-- Item.DropClass = "cw_tr09_tar21"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "cw_tr09_tar21"
-- Item.PacOutfit = "cw_tr09_tar21"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Rifles"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 32
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 4,
--     ["Bolt"] = 6,
--     ["Trigger"] = 8,
--     ["Stock"] = 7,
--     ["Handle Grip"] = 5,
--     ["Long Barrel"] = 3,
--     ["Upper Receiver"] = 5,
-- 	["Metal Plate"] = 40,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "3060188880",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "cw_tr09_tar21",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3.2, -0.260),
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/weapons/therambotnic09/w_cw2_tar21.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "AR-15"
Item.Desc = "A school rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_rif_m4a1.mdl"
Item.Weight = 14
Item.Volume = 11
Item.CanDrop = true
Item.DropClass = "cw_ar15"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_ar15"
Item.PacOutfit = "cw_ar15"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 21
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 6,
    ["Bolt"] = 6,
    ["Upper Receiver"] = 6,
    ["Handle Grip"] = 6,
    ["Trigger"] = 6,
	["Stock"] = 6,
    ["Lower Receiver"] = 6,
    ["Firing Pin"] = 6,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "3060188880",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_ar15",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
					["UniqueID"] = "1484483537",
					["Position"] = Vector(2, -3.2, -6),
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/w_rif_m4a1.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

-- local Item = {}
-- Item.Name = "M4A1"
-- Item.Desc = "An M4A1 rifle."
-- Item.Type = "type_weapon"
-- Item.Model = "models/weapons/w_her_m27ia.mdl"
-- Item.Weight = 12
-- Item.Volume = 10
-- Item.CanDrop = true
-- Item.DropClass = "heretic_cw2_m27"
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "heretic_cw2_m27"
-- Item.PacOutfit = "m4_back"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Rifles"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 36
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
--     ["Firing Pin"] = 5,
--     ["Bolt"] = 7,
--     ["Trigger"] = 8,
--     ["Stock"] = 9,
--     ["Handle Grip"] = 5,
--     ["Long Barrel"] = 6,
--     ["Lower Receiver"] = 4,
--     ["Upper Receiver"] = 4,
-- }
-- GM.PacModels:Register( Item.PacOutfit, {
-- 	[1] = {
-- 		["children"] = {
-- 			[1] = {
-- 				["children"] = {
-- 					[1] = {
-- 						["children"] = {
-- 						},
-- 						["self"] = {
-- 							["Event"] = "weapon_class",
-- 							["UniqueID"] = "1107791906",
-- 							["Operator"] = "equal",
-- 							["ClassName"] = "event",
-- 							["Arguments"] = "heretic_cw2_m27",
-- 						},
-- 					},
-- 				},
-- 				["self"] = {
-- 					["Angles"] = Angle(24.521390914917, 2.9193983078003, -0.26048710942268),
-- 					["UniqueID"] = "1484483537",
-- 					["Position"] = Vector(-4, -3.2, -0.260),
-- 					["Size"] = 1.025,
-- 					["EditorExpand"] = true,
-- 					["Bone"] = "spine 2",
-- 					["Model"] = "models/weapons/w_her_m27ia.mdl",
-- 					["ClassName"] = "model",
-- 				},
-- 			},
-- 		},
-- 		["self"] = {
-- 			["EditorExpand"] = true,
-- 			["UniqueID"] = "239303487",
-- 			["ClassName"] = "group",
-- 			["Name"] = "my outfit",
-- 			["Description"] = "add parts to me!",
-- 		},
-- 	},
-- } )
-- GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "M249" -- scar ++
Item.Desc = "An M249 lmg."
Item.Type = "type_weapon"
Item.Model = "models/weapons/cw2_0_mach_para.mdl"
Item.Weight = 120
Item.Volume = 50
Item.CanDrop = true
Item.DropClass = "cw_m249_official"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_m249_official"
Item.PacOutfit = "cw_m249_official"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Heavy Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 37
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 8,
    ["Bolt"] = 8,
    ["Upper Receiver"] = 9,
    ["Handle Grip"] = 8,
    ["Trigger"] = 8,
	["Stock"] = 8,
    ["Lower Receiver"] = 9,
    ["Firing Pin"] = 8,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "965353309",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_m249_official",
						},
					},
				},
				["self"] = {
					["Position"] = Vector(-4.3627014160156, -2.2530517578125, -8.9742736816406),
					["Angles"] = Angle(-2.9162585735321, -177.65454101563, -12.110625267029),
					["UniqueID"] = "1484483537",
					["Size"] = 1.025,
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/weapons/cw2_0_mach_para.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "VSS Vintorez"
Item.Desc = "An VSS rifle."
Item.Type = "type_weapon"
Item.Model = "models/cw2/rifles/w_vss.mdl"
Item.Weight = 18
Item.Volume = 15
Item.CanDrop = true
Item.DropClass = "cw_vss"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_vss"
Item.PacOutfit = "cw_vss"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Sniper Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 40
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 8,
    ["Bolt"] = 8,
    ["Upper Receiver"] = 10,
    ["Handle Grip"] = 8,
    ["Trigger"] = 8,
	["Stock"] = 8,
    ["Lower Receiver"] = 9,
    ["Firing Pin"] = 8,
}
GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "weapon_class",
							["UniqueID"] = "1137486923",
							["Operator"] = "equal",
							["ClassName"] = "event",
							["Arguments"] = "cw_vss",
						},
					},
				},
				["self"] = {
					["Position"] = Vector(-3.5045623779297, -2.8840942382813, 1.4510498046875),
					["Angles"] = Angle(-28.385202407837, 179.85206604004, 1.4463603496552),
					["UniqueID"] = "1484483537",
					["Size"] = 1.025,
					["EditorExpand"] = true,
					["Bone"] = "spine 2",
					["Model"] = "models/cw2/rifles/w_vss.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "239303487",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.Inv:RegisterItem( Item )
local Item = {}
Item.Name = "HK416"
Item.Desc = "An HK416 rifle."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_cwkk_hk416.mdl"
Item.Weight = 18
Item.Volume = 15
Item.CanDrop = true
Item.DropClass = "cw_kk_hk416"
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "cw_kk_hk416"
Item.PacOutfit = "w cwkk hk"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Rifles"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 40
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Long Barrel"] = 8,
    ["Bolt"] = 8,
    ["Upper Receiver"] = 10,
    ["Handle Grip"] = 8,
    ["Trigger"] = 8,
	["Stock"] = 8,
    ["Lower Receiver"] = 9,
    ["Firing Pin"] = 8,
}
GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Arguments"] = "cw_kk_hk416",
						["UniqueID"] = "1137486923",
						["Event"] = "weapon_class",
						["Operator"] = "equal",
						["Name"] = "weapon class equal\"cw_kk_hk416\"",
						["ClassName"] = "event",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.9097290039063, -4.6875, -8.3095703125),
				["Angles"] = Angle(3.3602318763733, 2.2610514861299e-05, -0.00069575849920511),
				["UniqueID"] = "1484483537",
				["Size"] = 1.025,
				["EditorExpand"] = true,
				["Bone"] = "spine 2",
				["Model"] = "models/weapons/w_cwkk_hk416.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "239303487",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
} )
GM.Inv:RegisterItem( Item )

-- ------------------------------------fASSSSSSSSSSSSSSS FAS FAS FAS----------------