-- --TODO: WORK IN PROGRESS

-- --Watch

-- local Item = {}
-- Item.Name = "Sterling Watch"
-- Item.Desc = "Valuable watch (Jewelry)"
-- Item.Model = "models/sterling/ajr_stand_watch.mdl"
-- Item.Weight = 100
-- Item.Volume = 8
-- Item.CanDrop = true
-- Item.Illegal = true
-- Item.BankBanned = true
-- GM.Inv:RegisterItem( Item )

-- --Necklace
-- local Item = {}
-- Item.Name = "Valuable Necklace"
-- Item.Desc = "Valuable necklace (Jewelry)"
-- Item.Model = "models/sterling/ajr_stand_necklace.mdl"
-- Item.Weight = 100
-- Item.Volume = 8
-- Item.CanDrop = true
-- Item.Illegal = true
-- Item.BankBanned = true
-- GM.Inv:RegisterItem( Item )

-- --Box of Rings

-- local Item = {}
-- Item.Name = "Box of Rings"
-- Item.Desc = "Box of rings (Jewelry)"
-- Item.Model = "models/sterling/ajr_ringbox.mdl"
-- Item.Weight = 100
-- Item.Volume = 8
-- Item.CanDrop = true
-- Item.Illegal = true
-- Item.BankBanned = true
-- GM.Inv:RegisterItem( Item )

-- --Hammer

-- local Item = {}
-- Item.Name = "Glass Smasher"
-- Item.Desc = "Glass Smasher (Jewelry)"
-- Item.Type = "type_weapon"
-- Item.Model = "models/sterling/ajr_hammer_w.mdl"
-- Item.Weight = 2
-- Item.Volume = 4
-- Item.CanDrop = true
-- Item.CanEquip = true
-- Item.Illegal = true
-- Item.EquipSlot = "AltWeapon"
-- Item.EquipGiveClass = "jewelry_robbery_hammer"
-- Item.DropClass = "jewelry_robbery_hammer"

-- Item.CraftingEntClass = "ent_assembly_table"
-- Item.CraftingTab = "Weapons"
-- Item.CraftSkill = "Gun Smithing"
-- Item.CraftSkillLevel = 15
-- Item.CraftSkillXP = 5
-- Item.CraftRecipe = {
-- 	["Cut Diamond"] = 1,
-- 	["Metal Bar"] = 4,
-- 	["Handle Grip"] = 1,
-- }
-- GM.Inv:RegisterItem( Item )