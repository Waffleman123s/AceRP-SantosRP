--[[
	Name: drugs_lsd.lua
	For: SantosRP
	By: Asriel
]]
--
local function LSDPlayerCanUse(tblItem, pPlayer)
	local random = math.random(tblItem.IntoxMin, tblItem.IntoxMax)
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect("Psychedelic Trip"):CanGive(pPlayer, random, true)

	return b or bHandedOff, (b or bHandedOff) and {random}
end

local function LSDPlayerUse(tblItem, pPlayer, intDuration)
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect(pPlayer, "Psychedelic Trip", intDuration)
	end
end

local Item = {}
Item.Name = "Drain Cleaner"
Item.Desc = "A jar of full of drain cleaner."
Item.Model = "models/foodnhouseholditems/soapfud.mdl"
Item.Weight = 2
Item.Volume = 6
Item.CanDrop = true
Item.LimitID = "drain cleaner"

Item.DrugLab_BlenderVars = {
	BlendProgress = 10,
	BlendAmountPerTick = 0.1,
	GiveItem = "Potassium Hydroxide",
	GiveAmount = 2
}

GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 2)
local Item = {}
Item.Name = "Potassium Hydroxide"
Item.Desc = "A bag full of powdered Potassium Hydroxide. (KOH)"
Item.Model = "models/props_junk/garbage_bag001a.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.LimitID = "potassium hydroxide"
Item.DropClass = "ent_fluid_koh"
GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 2)
local Item = {}
Item.Name = "Ergot Alkaloids"
Item.Desc = "A small box full of dry Ergot Alkaloids"
Item.Model = "models/props_lab/box01a.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanCook = true
Item.Illegal = true
Item.DropClass = "prop_physics"
Item.LimitID = "Ergot Alkaloids"
GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 2)
local Item = {}
Item.Name = "Methanolic KOH"
Item.Desc = "A bottle full of Methanolic KOH"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 5
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_mkoh"
Item.LimitID = "methanolic KOH"

Item.ReactionChamberVars = {
	Mats = {
		["Methanol"] = 1,
		["Potassium Hydroxide"] = 1
	},
	Interval = 0.75,
	MakeAmount = 2,
	MinGiveAmount = 500,
	GiveItem = "Methanolic KOH",
	GiveAmount = 1
}

GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 2)
local Item = {}
Item.Name = "HNO3"
Item.Desc = "A bottle full of HNO3"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_HNO3"
Item.LimitID = "HNO3"
GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 2)
local Item = {}
Item.Name = "LSA"
Item.Desc = "A bottle full of LSA, to be processed further"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.DropClass = "ent_fluid_lsa"
Item.Illegal = true
Item.LimitID = "LSA"

Item.CookingPotVars = {
	Skill = "Chemistry",
	SkillWeight = 0.10,
	OverCookMsg = "You overcooked it, you ruined the batch!",
	OverTimeExplode = true,
	OverTimeStartFire = true,
	MinTime = 200,
	MaxTime = 300,
	TimeWeight = -0.85,
	IdealTimePercent = 0.50,
	Items = {
		["Ergot Alkaloids"] = {
			IdealAmount = 2,
			MaxAmount = 3,
			MinAmount = 1
		}
	},
	Fluids = {
		["Methanolic KOH"] = {
			IdealAmount = 500,
			MaxAmount = 600,
			MinAmount = 100
		},
		["Water"] = {
			IdealAmount = 100,
			MaxAmount = 250,
			MinAmount = 25
		}
	},
	GiveItems = {
		{
			MinQuality = 0,
			GiveItem = "LSA",
			GiveAmount = 1
		},
		{
			MinQuality = 0.61,
			GiveItem = "LSA",
			GiveAmount = 1
		},
		{
			MinQuality = 0.825,
			GiveItem = "LSA",
			GiveAmount = 1
		}
	},
	GiveXP = {
		{
			MinQuality = 0,
			GiveAmount = 10
		},
		{
			MinQuality = 0.61,
			GiveAmount = 40
		},
		{
			MinQuality = 0.825,
			GiveAmount = 80
		}
	}
}

GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 8)
local Item = {}
Item.Name = "iso LSD"
Item.Desc = "A bottle iso LSD"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 5
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_iso"
Item.LimitID = "iso LSD"

Item.ReactionChamberVars = {
	Mats = {
		["LSA"] = 2,
		["Methanolic KOH"] = 1,
		["HNO3"] = 1
	},
	Interval = 0.75,
	MakeAmount = 1,
	MinGiveAmount = 1000,
	GiveItem = "iso LSD",
	GiveAmount = 1
}

GM.Inv:RegisterItem(Item)
GM.Inv:RegisterItemLimit(Item.LimitID, 2)

local Item = {}
Item.Name = "LSD"
Item.Desc = "Container of a psychedelic substance."
Item.Type = "type_drugs"
Item.Model = "models/labware/bottle2.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "lsd"
Item.IntoxMin = 300
Item.IntoxMax = 600
Item.PlayerCanUse = LSDPlayerCanUse
Item.OnUse = LSDPlayerUse

Item.SetupEntity = function(_, eEnt)
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end

Item.CanPlayerPickup = function() return true end
Item.CanPlayerUse = function() return true end


Item.CookingPotVars = {
	Skill = "Chemistry",
	SkillWeight = 0.39, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked it! This batch is ruined!",
	OverTimeExplode = true, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 10,
	MaxTime = 90,
	TimeWeight = -0.85, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.66, --% from min to max time to consider ideal

	Items = {},
	Fluids = {
		["Methanolic KOH"] = { IdealAmount = 350, MaxAmount = 425, MinAmount = 200 },
		["iso LSD"] = { IdealAmount = 400, MaxAmount = 500, MinAmount = 325 },
		["Moonshine"] = { IdealAmount = 100, MaxAmount = 250, MinAmount = 25 }
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "LSD", GiveAmount = 4 },
		{ MinQuality = 0.61, GiveItem = "LSD", GiveAmount = 6 },
		{ MinQuality = 0.825, GiveItem = "LSD", GiveAmount = 8 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
}

GM.Inv:RegisterItem(Item)

GM.Inv:RegisterItemLimit(Item.LimitID, 8)