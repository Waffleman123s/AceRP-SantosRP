local Item = {}
Item.Name = "Tech Trash"
Item.Desc = "Miscellaneous tech parts and scrap."
Item.Model = "models/props_lab/reciever01b.mdl"
Item.Weight = 1
Item.Volume = 2
Item.HealthOverride = 25
Item.CanDrop = true
Item.CollidesWithCars = false
Item.CanSitOn = false
Item.DropClass = "prop_physics_multiplayer"
Item.CraftingEntClass = "ent_crafting_table"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Broken Electronics"] = 4,
	["Chunk of Plastic"] = 2,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Makeshift Camera"
Item.Desc = "Miscellaneous tech parts and scrap."
Item.Model = "models/props_lab/reciever01b.mdl"
Item.Weight = 1
Item.Volume = 2
Item.HealthOverride = 25
Item.CanDrop = true
Item.CollidesWithCars = false
Item.CanSitOn = false
Item.DropClass = "prop_physics_multiplayer"
Item.CraftingEntClass = "ent_crafting_table"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Tech Trash"] = 10,
	["Chunk of Plastic"] = 1,
	["Pliers"] = 1,
	["Metal Plate"] = 3,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Broken Electronics"
Item.Desc = "Broken pieces of electronics."
Item.Model = "models/props_lab/reciever01c.mdl"
Item.Weight = 1
Item.Volume = 2
Item.HealthOverride = 25
Item.CanDrop = true
Item.CollidesWithCars = false
Item.CanSitOn = false
Item.DropClass = "prop_physics_multiplayer"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Makeshift Drone"
Item.Desc = ""
Item.Model = "models/dronesrewrite/cameradr/cameradr.mdl"
Item.Type = "type_electronics"
Item.Weight = 5
Item.Volume = 7
Item.CanDrop = true
Item.LimitID = "drone"
Item.DropClass = "dronesrewrite_racerdr"
Item.CraftingEntClass = "ent_crafting_table"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Tech Trash"] = 6,
	["Car Battery"] = 1,
	["Box Fan"] = 4,
	["Metal Bar"] = 8,
	["Chunk of Plastic"] = 3,
	["Makeshift Camera"] = 1,
}

GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t2"] = 1 } )

local Item = {}
Item.Name = "Police AR Drone"
Item.Desc = ""
Item.Model = "models/dronesrewrite/ardrone2/ardrone.mdl"
Item.Type = "type_electronics"
Item.Weight = 5
Item.Volume = 7
Item.CanDrop = true
Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
Item.LimitID = "drone"
Item.DropClass = "dronesrewrite_ardrone2"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t2"] = 1 } )