local Item = {}
Item.Name = "CCTV Camera"
Item.Desc = "A CCTV Camera which requires a monitor to view."
Item.Model = "models/tobadforyou/surveillance_camera.mdl"
Item.Type = "type_electronics"
Item.Weight = 15
Item.Volume = 20
Item.SetupEntity = function( _, entItem )
	entItem:Setup()
end
Item.CanDrop = true
Item.LimitID = "cctv camera"
Item.DropClass = "ent_cam"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 6, { ["vip_t1"] = 12 } )

local Item = {}
Item.Name = "CCTV Monitor"
Item.Desc = "A CCTV Monitor which allows you to view your cameras."
Item.Model = "models/unconid/pc_models/monitors/lcd_ultrawide_curved.mdl"
Item.Type = "type_electronics"
Item.Weight = 15
Item.Volume = 20
Item.CanDrop = true
Item.LimitID = "cctv monitor"
Item.DropClass = "ent_cam_monitor"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2, { ["vip_t1"] = 4 } )