--[[
	Name: misc_weapons.lua
	For: SantosRP
	By: Ultra
]]--


local Item = {}
Item.Name = "First Aid Kit"
Item.Desc = "A first aid kit, consumes Medical Supplies from your inventory."
Item.Type = "type_weapon"
Item.Model = "models/Items/HealthKit.mdl"
Item.Weight = 7
Item.Volume = 10
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_srp_medkit"

Item.CanPlayerEquip = function( tblItem, pPlayer )
	if GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, "FD Issue Medical Supplies" ) > 0 then return true end
	if GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, "Government Issue Medical Supplies" ) > 0 then return true end
	return GAMEMODE.Inv:GetPlayerItemAmount( pPlayer, "Medical Supplies" ) > 0
end
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Thermite"
Item.Desc = "A pipe filled with thermite, use to melt through strong metal."
Item.Type = "type_weapon"
Item.Model = "models/props_junk/flare.mdl"
Item.Weight = 9
Item.Volume = 5
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_item_thermite"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Weapons"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 14
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Aluminum Powder"] = 6,
	["Metal Bar"] = 12,
	["Wrench"] = 1,
	["Metal Pipe"] = 1,
}
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Cellular Phone"
Item.Desc = "A smart phone - push walk (default: Left Alt) to use the mouse when equipped."
Item.Type = "type_weapon"
Item.Model = "models/lt_c/tech/cellphone.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "PocketWeapon"
Item.EquipGiveClass = "aphone"
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Molotov Cocktail"
Item.Desc = "A molotov cocktail."
Item.Type = "type_weapon"
Item.Model = "models/props_junk/garbage_glassbottle003a.mdl"
Item.Weight = 3
Item.Volume = 3
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_molotov"
Item.DropClass = "weapon_molotov"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Weapons"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 20
Item.CraftSkillXP = 2
Item.CraftRecipe = {
	["Moonshine"] = 20,
	["Cloth"] = 10,
	["Metal Bracket"] = 10,
	["Metal Plate"] = 10,
}
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Flash Grenade"
Item.Desc = "A flash bang."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_eq_flashbang.mdl"
Item.Weight = 3
Item.Volume = 3
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "cw_flash_grenade"
Item.DropClass = "cw_flash_grenade"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Weapons"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 20
Item.CraftSkillXP = 2
Item.CraftRecipe = {
	["Metal Bracket"] = 10,
	["Metal Plate"] = 10,
	["Smokeless Gunpowder"] = 15,
}
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Lockpick"
Item.Desc = "A lockpick. Can unlock doors and free handcuffed players."
Item.Type = "type_weapon"
Item.Model = "models/weapons/w_crowbar.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_lockpick"
Item.DropClass = "weapon_lockpick"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Weapons"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 2
Item.CraftRecipe = {
	["Metal Bracket"] = 1,
	["Metal Plate"] = 2,
	["Crowbar"] = 1,
}
GM.Inv:RegisterItem( Item )


local Item = {}
Item.Name = "Zip Tie"
Item.Desc = "A zip tie. Can restrain other players."
Item.Type = "type_weapon"
Item.Model = "models/katharsmodels/handcuffs/handcuffs-1.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanEquip = true
Item.Illegal = true
Item.EquipSlot = "AltWeapon"
Item.EquipGiveClass = "weapon_ziptie"
Item.DropClass = "weapon_ziptie"

Item.CraftingEntClass = "ent_assembly_table"
Item.CraftingTab = "Weapons"
Item.CraftSkill = "Gun Smithing"
Item.CraftSkillLevel = 3
Item.CraftSkillXP = 2
Item.CraftRecipe = {
	["Chunk of Plastic"] = 8,
	["Metal Bracket"] = 2,
	["Pliers"] = 3,
}
GM.Inv:RegisterItem( Item )


-- local Item = {}
-- Item.Name = "Fishing Rod"
-- Item.Desc = "A fishing rod. Touch the hook against another item to try and bait it."
-- Item.Type = "type_weapon"
-- Item.Model = "models/props_c17/signpole001.mdl"
-- Item.Weight = 10
-- Item.Volume = 50
-- Item.CanDrop = true
-- Item.CanEquip = true
-- Item.EquipSlot = "PrimaryWeapon"
-- Item.EquipGiveClass = "weapon_item_fishing_rod"
-- Item.DropClass = "weapon_item_fishing_rod"

-- Item.CraftingEntClass = "ent_crafting_table"
-- Item.CraftingTab = "Weapons"
-- Item.CraftSkill = "Crafting"
-- Item.CraftSkillLevel = 7
-- Item.CraftSkillXP = 2
-- Item.CraftRecipe = {
-- 	["Wood Plank"] = 2,
-- 	["Metal Bracket"] = 4,
-- 	["Cloth"] = 2,
-- }
-- GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Smoker"
Item.Desc = "A Smoker. A device used in beekeeping to calm honey bees."
Item.Type = "type_weapon"
Item.Model = "models/sterling/bks_w_beesmoker.mdl"
Item.Weight = 10
Item.Volume = 50
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "beekeeping_smoker_swep"
Item.DropClass = "beekeeping_smoker_swep"
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Vacuum"
Item.Desc = "A Vacuum. A device used in beekeeping to collect honey bees."
Item.Type = "type_weapon"
Item.Model = "models/sterling/bks_w_beesmoker.mdl"
Item.Weight = 10
Item.Volume = 50
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "PrimaryWeapon"
Item.EquipGiveClass = "beekeeping_vacuum_swep"
Item.DropClass = "beekeeping_vacuum_swep"
GM.Inv:RegisterItem( Item )










--Shit Test

local Item = {}
Item.Name = "Revenge Hood - Seasonal Item"
Item.Desc = "A blessing left behind by the founder."
Item.Type = "type_clothing"
Item.Model = "models/cw2/cases/mr96_small_case.mdl"
Item.Weight = 1
Item.Volume = 1
Item.HealthOverride = 15000
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "Face"
Item.PacOutfit = "Revengehoodie"
GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "2352568410",
								["Scale"] = Vector(0.5, 0.69999998807907, 0.60000002384186),
								["ClassName"] = "model",
								["Size"] = 0.6,
								["Model"] = "models/pac/default.mdl",
								["Color"] = Vector(0, 0, 0),
								["Position"] = Vector(4.102294921875, -0.29425048828125, 66.4453125),
								["Brightness"] = -30.7,
								["Material"] = "models/debug/debugwhite",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "3174799106",
						["Scale"] = Vector(1.2000000476837, 1, 1),
						["EditorExpand"] = true,
						["Material"] = "https://i.pinimg.com/originals/25/f2/28/25f228ffb761c775a3ad61a9a7fa6621.jpg",
						["Angles"] = Angle(72.685317993164, -0.0028256447985768, -0.00043603862286545),
						["Color"] = Vector(255, 0, 0),
						["Position"] = Vector(-60.4794921875, 0, -11.6083984375),
						["Model"] = "models/sal/hanker.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3641075233",
				["Scale"] = Vector(1, 1, 1.5),
				["Material"] = "http://dwebhost.co/s/sour/26241-Pointed.png",
				["EditorExpand"] = true,
				["Size"] = 1.15,
				["Angles"] = Angle(-0.16081018745899, -4.724057674408, -91.943984985352),
				["Color"] = Vector(38, 38, 38),
				["Position"] = Vector(0.404296875, -6.54150390625, 0.06268310546875),
				["Model"] = "models/sal/hat04.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 0, 0),
						["UniqueID"] = "3241499695",
						["Length"] = 96,
						["ClassName"] = "trail",
						["EndColor"] = Vector(255, 0, 0),
						["EndAlpha"] = 0,
						["Position"] = Vector(-1.2188415527344, 1.1156921386719, 0.0517578125),
						["Bone"] = "rwing 2",
						["StartSize"] = 1.5,
						["TrailPath"] = "trails/smoke",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 0, 0),
						["UniqueID"] = "2582305311",
						["Length"] = 96,
						["EndColor"] = Vector(255, 0, 0),
						["ClassName"] = "trail",
						["EndAlpha"] = 0,
						["Angles"] = Angle(0.00019096514733974, -0.88881951570511, -0.00021451062639244),
						["Position"] = Vector(-1.8420944213867, -0.08905029296875, 0.3984375),
						["Bone"] = "lwing 2",
						["StartSize"] = 1.5,
						["TrailPath"] = "trails/smoke",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 0, 0),
						["UniqueID"] = "717511992",
						["Length"] = 96,
						["ClassName"] = "trail",
						["EndColor"] = Vector(255, 0, 0),
						["EndAlpha"] = 0,
						["Position"] = Vector(3.0484161376953, 0.408203125, -4.1416015625),
						["Bone"] = "rwing 1",
						["StartSize"] = 1.5,
						["TrailPath"] = "trails/smoke",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 0, 0),
						["UniqueID"] = "2756883021",
						["Length"] = 96,
						["ClassName"] = "trail",
						["EndColor"] = Vector(255, 0, 0),
						["EndAlpha"] = 0,
						["Position"] = Vector(-0.40882873535156, -0.1400146484375, -0.4541015625),
						["Bone"] = "lwing 1",
						["StartSize"] = 1.5,
						["TrailPath"] = "trails/smoke",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-56.5771484375, 3.96435546875, -0.0018768310546875),
				["ClassName"] = "model",
				["UniqueID"] = "3590294893",
				["EditorExpand"] = true,
				["Color"] = Vector(52, 52, 52),
				["Bone"] = "spine 4",
				["Model"] = "models/grinchfox/body_wear/angel_wings.mdl",
				["Angles"] = Angle(4.2688690882642e-05, 90, 90.000022888184),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "43150856",
		["EditorExpand"] = true,
	},
},
} )
GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
GM.Inv:RegisterItem( Item )








local Item = {}
Item.Name = "Lama Pet - Exclusive Item"
Item.Desc = "Floating Lama that follows you around"
Item.Type = "type_clothing"
Item.Model = "models/cw2/cases/mr96_small_case.mdl"
Item.Weight = 1
Item.Volume = 1
Item.HealthOverride = 15000
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "Eyes"
Item.PacOutfit = "lamabpet"

GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["Angles"] = Angle(6.6594344389159e-05, -135, 2.305188900209e-05),
												["ClassName"] = "clip",
												["UniqueID"] = "3665853758",
												["Position"] = Vector(1.444000005722, 0.44999998807907, 0),
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["Angles"] = Angle(6.6594344389159e-05, 45, 2.305188900209e-05),
												["ClassName"] = "clip",
												["UniqueID"] = "1638377013",
												["Position"] = Vector(-1.444000005722, -0.44999998807907, 0),
											},
										},
										[3] = {
											["children"] = {
											},
											["self"] = {
												["Angles"] = Angle(6.6594344389159e-05, 135, 2.305188900209e-05),
												["ClassName"] = "clip",
												["UniqueID"] = "2614187089",
												["Position"] = Vector(1.444000005722, -0.44999998807907, 0),
											},
										},
										[4] = {
											["children"] = {
											},
											["self"] = {
												["Angles"] = Angle(6.6594344389159e-05, -45, 2.305188900209e-05),
												["UniqueID"] = "3000625246",
												["PositionOffset"] = Vector(0, -0.5, 0),
												["Position"] = Vector(-1.444000005722, 0.44999998807907, -0.30000001192093),
												["ClassName"] = "clip",
											},
										},
										[5] = {
											["children"] = {
											},
											["self"] = {
												["Angles"] = Angle(6.6594344389159e-05, 0, 2.305188900209e-05),
												["ClassName"] = "clip",
												["UniqueID"] = "1375577112",
												["Position"] = Vector(-1.444000005722, 0, 0),
											},
										},
										[6] = {
											["children"] = {
											},
											["self"] = {
												["Angles"] = Angle(6.6594344389159e-05, 180, 2.305188900209e-05),
												["ClassName"] = "clip",
												["UniqueID"] = "3068825500",
												["Position"] = Vector(1.444000005722, 0, 0),
											},
										},
									},
									["self"] = {
										["DrawOrder"] = -1,
										["Position"] = Vector(-1.52587890625e-05, -0.000732421875, 4.70703125),
										["Model"] = "https://dl.dropboxusercontent.com/s/x6ieklc9tweqeu5/Ghost%20Eye.obj?dl=0",
										["Size"] = 0.375,
										["Material"] = "https://dl.dropboxusercontent.com/s/eheafzsm9eoz1e3/Spectre_Illum%201024.jpg?dl=0",
										["DoubleFace"] = true,
										["EditorExpand"] = true,
										["ClassName"] = "model",
										["Brightness"] = 20,
										["Translucent"] = true,
										["UniqueID"] = "162283847",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["Max"] = 0.30000001192093,
										["ClassName"] = "proxy",
										["UniqueID"] = "2124829213",
										["Axis"] = "y",
										["InputMultiplier"] = 2.0999999046326,
										["Min"] = -0.30000001192093,
										["VariableName"] = "PositionOffset",
									},
								},
								[3] = {
									["children"] = {
									},
									["self"] = {
										["Max"] = 0.10000000149012,
										["ClassName"] = "proxy",
										["UniqueID"] = "463554784",
										["Axis"] = "z",
										["InputMultiplier"] = 4.8000001907349,
										["Min"] = -0.10000000149012,
										["VariableName"] = "PositionOffset",
									},
								},
								[4] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
													},
													["self"] = {
														["Max"] = -1.6000000238419,
														["Pow"] = 100,
														["UniqueID"] = "1779302111",
														["Axis"] = "y",
														["Input"] = "timeex",
														["VariableName"] = "Position",
														["Offset"] = 2.2000000476837,
														["InputMultiplier"] = 2.5,
														["ClassName"] = "proxy",
													},
												},
											},
											["self"] = {
												["Angles"] = Angle(0, 90.199996948242, 0),
												["UniqueID"] = "2192877148",
												["EditorExpand"] = true,
												["Position"] = Vector(0, -1.4408159255981, 0),
												["ClassName"] = "clip",
											},
										},
									},
									["self"] = {
										["Model"] = "models/pac/default.mdl",
										["ClassName"] = "model",
										["UniqueID"] = "3560341922",
										["Size"] = 0.125,
										["Color"] = Vector(170, 148, 148),
										["Position"] = Vector(-2.6702880859375e-05, -0.0018310546875, 7.1435546875),
										["Translucent"] = true,
										["Material"] = "models/props_combine/metal_combinebridge001",
									},
								},
								[5] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "sprite",
												["Position"] = Vector(0, 0, -1.2999999523163),
												["SpritePath"] = "sprites/light_ignorez",
												["Color"] = Vector(127, 0, 255),
												["Size"] = 8.3500003814697,
												["SizeX"] = 3.5,
												["UniqueID"] = "1977254548",
											},
										},
									},
									["self"] = {
										["Position"] = Vector(-3.0517578125e-05, -0.0003662109375, 7.2080078125),
										["Name"] = "ghost%eye 1",
										["Model"] = "https://dl.dropboxusercontent.com/s/x6ieklc9tweqeu5/Ghost%20Eye.obj?dl=0",
										["EditorExpand"] = true,
										["DoubleFace"] = true,
										["Size"] = 0.375,
										["UniqueID"] = "1562157376",
										["Material"] = "https://dl.dropboxusercontent.com/s/2fwztfd4bsyd525/Spectre%201024.jpg?dl=0",
										["Translucent"] = true,
										["ClassName"] = "model",
									},
								},
								[6] = {
									["children"] = {
									},
									["self"] = {
										["Max"] = 0.10000000149012,
										["ClassName"] = "proxy",
										["UniqueID"] = "15831273",
										["InputMultiplier"] = 4.8000001907349,
										["Min"] = -0.10000000149012,
										["VariableName"] = "PositionOffset",
									},
								},
								[7] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "light",
												["Size"] = 100,
												["Color"] = Vector(127, 0, 255),
												["Position"] = Vector(-6.103515625e-05, -0.0001068115234375, -23.30029296875),
												["Brightness"] = 0.15000000596046,
												["UniqueID"] = "3082785085",
											},
										},
									},
									["self"] = {
										["UniqueID"] = "647930842",
										["Name"] = "Flashlight",
										["Scale"] = Vector(0.30000001192093, 0.30000001192093, 0.30000001192093),
										["Model"] = "models/effects/vol_light128x384.mdl",
										["Angles"] = Angle(-0.23649092018604, 12.462675094604, -88.930061340332),
										["Size"] = 0.10000000149012,
										["EditorExpand"] = true,
										["Color"] = Vector(237, 147, 255),
										["Position"] = Vector(-1.2596588134766, 5.7496337890625, 7.7802734375),
										["Translucent"] = true,
										["ClassName"] = "model",
									},
								},
							},
							["self"] = {
								["UniqueID"] = "1819670032",
								["Model"] = "models/sterling/llama.mdl",
								["EyeAngles"] = true,
								["Size"] = 0.15000000596046,
								["EditorExpand"] = true,
								["Position"] = Vector(-2.6591796875, -5.329345703125, -4.976375579834),
								["AngleOffset"] = Angle(90, 0, -90),
								["ClassName"] = "model",
								["DoubleFace"] = true,
								["PositionOffset"] = Vector(-0.045818611979485, -0.29998105764389, -0.045818611979485),
								["Color"] = Vector(177, 255, 255),
								["TextureFilter"] = 2,
								["Translucent"] = true,
								["Angles"] = Angle(0, 0, 90),
							},
						},
					},
					["self"] = {
						["ClassName"] = "jiggle",
						["Position"] = Vector(10.166000366211, 1.5210000276566, -11.623000144958),
						["Speed"] = 3,
						["EditorExpand"] = true,
						["UniqueID"] = "4257471642",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["UniqueID"] = "2252609760",
				["Model"] = "models/pac/default.mdl",
				["EditorExpand"] = true,
				["Bone"] = "spine 4",
				["Name"] = "Ghost Follow",
				["Translucent"] = true,
			},
		},
	},
	["self"] = {
		["Name"] = "Ghost",
		["ClassName"] = "group",
		["UniqueID"] = "1899629946",
		["EditorExpand"] = true,
	},
},

} )
GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
GM.Inv:RegisterItem( Item )



local Item = {}
Item.Name = "Astrohelmet - Rare Item"
Item.Desc = "Astrohelm."
Item.Type = "type_clothing"
Item.Model = "models/cw2/cases/mr96_small_case.mdl"
Item.Weight = 1
Item.Volume = 1
Item.HealthOverride = 15000
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "Head"
Item.PacOutfit = "strihekn"

GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "79737121",
				["Size"] = 0.25,
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.00026194844394922, -89.301666259766, -90.000030517578),
				["Position"] = Vector(-2.2685546875, -1.0237731933594, -0.0003662109375),
				["ClassName"] = "model",
				["Size"] = 0.76999998092651,
				["EditorExpand"] = true,
				["Model"] = "models/astronauthelmet/astronauthelmet.mdl",
				["UniqueID"] = "1896892414",
			},
		},
	},
	["self"] = {
		["Name"] = "my outfit",
		["ClassName"] = "group",
		["UniqueID"] = "3310835031",
		["EditorExpand"] = true,
	},
},

} )
GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
GM.Inv:RegisterItem( Item )



local Item = {}
	Item.Name = "The Irish Vest"
	Item.Desc = ""
	Item.Type = "type_clothing"
	Item.Model = "models/weapons/w_defuser.mdl"
	Item.Weight = 1
	Item.Volume = 1
	Item.HealthOverride = 15000
	Item.CanDrop = false
	Item.CanEquip = true
	Item.EquipSlot = "Neck"
	Item.JobItem = "JOB_KINGCOMMAND"
	Item.PacOutfit = "theirsh"
	Item.Stats = [[ Non-Buyable 
	+250 Inventory Weight
    +220 Inventory Volume]]
 
	Item.EquipBoostCarryWeight = 750
	Item.EquipBoostCarryVolume = 720 



		GM.PacModels:Register( Item.PacOutfit, {
    [1] = {
      ["children"] = {
        [1] = {
          ["children"] = {
            [1] = {
              ["children"] = {
              },
              ["self"] = {
                ["Angles"] = Angle(-0.23446387052536, 89.948524475098, 159.06571960449),
                ["UniqueID"] = "2140186653",
                ["Font"] = "DermaDefault",
                ["ClassName"] = "text",
                ["Size"] = 0.065,
                ["Position"] = Vector(-6.0986328125, 0.041259765625, -6.2257080078125),
                ["Text"] = "The Irish",
              },
            },
            [2] = {
              ["children"] = {
              },
              ["self"] = {
                ["ClassName"] = "model",
                ["Material"] = "https://dwebhost.co/s/sour/001211-Juvenile.png",
                ["UniqueID"] = "3213684313",
                ["Size"] = 0.08,
                ["Angles"] = Angle(-87.987899780273, 177.96572875977, -177.8656463623),
                ["Position"] = Vector(-7.3369140625, 0.079605102539063, 7.269775390625),
                ["Model"] = "models/XQM/panel360.mdl",
                ["Scale"] = Vector(22.5, 1, 1),
              },
            },
            [3] = {
              ["children"] = {
              },
              ["self"] = {
                ["ClassName"] = "model",
                ["Material"] = "https://dwebhost.co/s/sour/001211-Juvenile.png",
                ["UniqueID"] = "1257627658",
                ["Size"] = 0.08,
                ["Angles"] = Angle(-78.300926208496, 165.00514221191, -166.68635559082),
                ["Position"] = Vector(-10.109375, -1.5730743408203, -7.6102294921875),
                ["Model"] = "models/XQM/panel360.mdl",
                ["Scale"] = Vector(22.5, 1, 1),
              },
            },
            [4] = {
              ["children"] = {
              },
              ["self"] = {
                ["Angles"] = Angle(0.00021130897221155, 113.08547210693, -0.00020533257338684),
                ["ClassName"] = "clip",
                ["UniqueID"] = "3253947845",
                ["Position"] = Vector(-2.9287109375, -7.0064697265625, -0.010986328125),
              },
            },
            [5] = {
              ["children"] = {
              },
              ["self"] = {
                ["Angles"] = Angle(-0.00025346403708681, -100.26837158203, 0.00018441511201672),
                ["ClassName"] = "clip",
                ["UniqueID"] = "2996704764",
                ["Position"] = Vector(-0.3134765625, 6.4207153320313, 0.0177001953125),
              },
            },
          },
          ["self"] = {
            ["ClassName"] = "model",
            ["Skin"] = 1,
            ["UniqueID"] = "3633668065",
            ["EditorExpand"] = true,
            ["Position"] = Vector(-50.0546875, 2.3746948242188, -0.00408935546875),
            ["Bone"] = "spine 2",
            ["Model"] = "models/bloocobalt/resident evil/re6_bsaa_gear_vest.mdl",
            ["Angles"] = Angle(0, 90, 90),
          },
        },
        [2] = {
          ["children"] = {
            [1] = {
              ["children"] = {
                [1] = {
                  ["children"] = {
                  },
                  ["self"] = {
                    ["ClassName"] = "sprite",
                    ["Position"] = Vector(7.2080078125, 7.8361206054688, 5.2035522460938),
                    ["SpritePath"] = "sprites/glow04_noz",
                    ["Bone"] = "spine 2",
                    ["Size"] = 3.95,
                    ["UniqueID"] = "184426779",
                  },
                },
              },
              ["self"] = {
                ["ClassName"] = "event",
                ["UniqueID"] = "2712248729",
                ["Event"] = "is_flashlight_on",
                ["EditorExpand"] = true,
                ["Name"] = "Flashlight",
                ["Invert"] = true,
              },
            },
          },
          ["self"] = {
            ["ClassName"] = "group",
            ["UniqueID"] = "2449217635",
            ["EditorExpand"] = true,
          },
        },
      },
      ["self"] = {
        ["EditorExpand"] = true,
        ["UniqueID"] = "3067321557",
        ["ClassName"] = "group",
        ["Name"] = "my outfit",
        ["Description"] = "add parts to me!",
      },
    },
	} )
	GM.PacModels:Register( "female_".. Item.PacOutfit, {
    [1] = {
      ["children"] = {
        [1] = {
          ["children"] = {
            [1] = {
              ["children"] = {
              },
              ["self"] = {
                ["ClassName"] = "model",
                ["Material"] = "https://dwebhost.co/s/sour/001211-Juvenile.png",
                ["UniqueID"] = "3213684313",
                ["Size"] = 0.08,
                ["Angles"] = Angle(-87.987899780273, 177.96572875977, -177.8656463623),
                ["Position"] = Vector(-7.3369140625, 0.079605102539063, 7.269775390625),
                ["Model"] = "models/XQM/panel360.mdl",
                ["Scale"] = Vector(22.5, 1, 1),
              },
            },
            [2] = {
              ["children"] = {
              },
              ["self"] = {
                ["Angles"] = Angle(-0.00025346403708681, -100.26837158203, 0.00018441511201672),
                ["ClassName"] = "clip",
                ["UniqueID"] = "2996704764",
                ["Position"] = Vector(-0.3134765625, 6.4207153320313, 0.0177001953125),
              },
            },
            [3] = {
              ["children"] = {
              },
              ["self"] = {
                ["Angles"] = Angle(-0.23446387052536, 89.948524475098, 159.06571960449),
                ["UniqueID"] = "2140186653",
                ["Font"] = "DermaDefault",
                ["ClassName"] = "text",
                ["Size"] = 0.05,
                ["Position"] = Vector(-6.0986328125, 0.041259765625, -6.2257080078125),
                ["Text"] = "The Irish",
              },
            },
            [4] = {
              ["children"] = {
              },
              ["self"] = {
                ["Angles"] = Angle(0.00021130897221155, 113.08547210693, -0.00020533257338684),
                ["ClassName"] = "clip",
                ["UniqueID"] = "3253947845",
                ["Position"] = Vector(-2.9287109375, -7.0064697265625, -0.010986328125),
              },
            },
            [5] = {
              ["children"] = {
              },
              ["self"] = {
                ["ClassName"] = "model",
                ["Material"] = "https://dwebhost.co/s/sour/001211-Juvenile.png",
                ["UniqueID"] = "1257627658",
                ["Size"] = 0.08,
                ["Angles"] = Angle(-78.300926208496, 165.00514221191, -166.68635559082),
                ["Position"] = Vector(-10.109375, -1.5730743408203, -7.6102294921875),
                ["Model"] = "models/XQM/panel360.mdl",
                ["Scale"] = Vector(22.5, 1, 1),
              },
            },
          },
          ["self"] = {
            ["ClassName"] = "model",
            ["Skin"] = 1,
            ["UniqueID"] = "3633668065",
            ["EditorExpand"] = true,
            ["Position"] = Vector(-53.2080078125, 1.127685546875, -0.0063323974609375),
            ["Bone"] = "spine 2",
            ["Model"] = "models/bloocobalt/resident evil/re6_bsaa_gear_vest.mdl",
            ["Angles"] = Angle(0, 90, 90),
          },
        },
        [2] = {
          ["children"] = {
            [1] = {
              ["children"] = {
                [1] = {
                  ["children"] = {
                  },
                  ["self"] = {
                    ["ClassName"] = "sprite",
                    ["Position"] = Vector(4.033203125, 6.8248596191406, 5.1223602294922),
                    ["SpritePath"] = "sprites/glow04_noz",
                    ["Bone"] = "spine 2",
                    ["Size"] = 3.95,
                    ["UniqueID"] = "184426779",
                  },
                },
              },
              ["self"] = {
                ["ClassName"] = "event",
                ["UniqueID"] = "2712248729",
                ["Event"] = "is_flashlight_on",
                ["EditorExpand"] = true,
                ["Name"] = "Flashlight",
                ["Invert"] = true,
              },
            },
          },
          ["self"] = {
            ["ClassName"] = "group",
            ["UniqueID"] = "2449217635",
            ["EditorExpand"] = true,
          },
        },
      },
      ["self"] = {
        ["EditorExpand"] = true,
        ["UniqueID"] = "3067321557",
        ["ClassName"] = "group",
        ["Name"] = "my outfit",
        ["Description"] = "add parts to me!",
      },
    },
	} )
	GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
	GM.Inv:RegisterItem( Item )
	
	
	
	
	local Item = {}
    Item.Name = "L.S.S.O Duty Vest"
    Item.Desc = "Los Santos Sheriff's Office Duty Vest Attachments. Made by Sour."
    Item.Type = "type_clothing"
    Item.Model = "models/weapons/w_defuser.mdl"
    Item.Weight = 1
    Item.Volume = 1
    Item.CanDrop = false
    Item.CanEquip = true
    Item.Illegal = false
	Item.JobItem = "JOB_POLICE" --This item can only be possessed by by players with this job
    Item.EquipSlot = "Back"
    Item.PacOutfit = "lssodutyvestatt"
    Item.Stats = [[
    +150 Inventory Weight
    +150 Inventory Volume]]
 
    Item.EquipBoostCarryWeight = 150
    Item.EquipBoostCarryVolume = 150

    GM.PacModels:Register( Item.PacOutfit, {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.0078125, -3.7529296875, -0.000396728515625),
				["Angles"] = Angle(0, 90, 90),
				["UniqueID"] = "2467567647",
				["Size"] = 0.75,
				["ClassName"] = "model",
				["Bone"] = "spine 1",
				["Model"] = "models/weapons/w_defuser.mdl",
				["Scale"] = Vector(0.80000001192093, 1, 0.89999997615814),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2416272245",
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Size"] = 0.075000002980232,
				["Angles"] = Angle(39.436218261719, 7.6789019658463e-06, 3.3356023777742e-05),
				["Color"] = Vector(0, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/hunter/blocks/cube025x025x025.mdl",
				["Position"] = Vector(5.15771484375, 2.5283660888672, 2.7646484375),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.0245284101984e-05, 3.4150946248701e-06, -90.91487121582),
						["ClassName"] = "model",
						["UniqueID"] = "2275782392",
						["Size"] = 0.050000000745058,
						["Color"] = Vector(87, 87, 87),
						["Position"] = Vector(-0.8096923828125, -1.2314453125, 0.037109375),
						["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
						["Material"] = "models/props_debris/metalwall001a",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.0625, 8.5516357421875, -4.346076965332),
				["Angles"] = Angle(8.2268657684326, 98.27067565918, -147.45971679688),
				["UniqueID"] = "2993139656",
				["Size"] = 0.64999997615814,
				["EditorExpand"] = true,
				["Bone"] = "spine 1",
				["Model"] = "models/tobadforyou/handcuffs.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00018142691988032, -58.857456207275, 0.00033126422204077),
								["Bone"] = "left finger 11",
								["UniqueID"] = "1292550878",
								["ClassName"] = "bone",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(5.2933678627014, -72.439323425293, 0.63728100061417),
								["Bone"] = "left finger 2",
								["UniqueID"] = "571232605",
								["ClassName"] = "bone",
							},
						},
						[3] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00018142691988032, -58.857456207275, 0.00033126422204077),
								["Bone"] = "left finger 4",
								["UniqueID"] = "464837048",
								["ClassName"] = "bone",
							},
						},
						[4] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(1.1198099851608, -50.772785186768, -16.922004699707),
								["Bone"] = "left finger 41",
								["UniqueID"] = "284373363",
								["ClassName"] = "bone",
							},
						},
						[5] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-19.924324035645, -15.673861503601, -24.525581359863),
								["Bone"] = "left finger 0",
								["UniqueID"] = "4081284951",
								["ClassName"] = "bone",
							},
						},
						[6] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(21.043100357056, -7.5627346038818, 7.5575876235962),
								["UniqueID"] = "1886445265",
								["ClassName"] = "bone",
							},
						},
						[7] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(36.525035858154, -5.4263968467712, -12.06618976593),
								["Bone"] = "left finger 4",
								["UniqueID"] = "3134305086",
								["ClassName"] = "bone",
							},
						},
						[8] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-8.5232534408569, 0.00020287744700909, -0.00027107878122479),
								["Bone"] = "left forearm",
								["UniqueID"] = "3680423260",
								["ClassName"] = "bone",
							},
						},
						[9] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-14.154232978821, -32.858840942383, -1.4088077477936e-05),
								["Bone"] = "left finger 1",
								["UniqueID"] = "2879637461",
								["ClassName"] = "bone",
							},
						},
						[10] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-4.3542455387069e-05, -143.81764221191, -8.7084925326053e-05),
								["Bone"] = "left forearm",
								["UniqueID"] = "2446224380",
								["ClassName"] = "bone",
							},
						},
						[11] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00015965568309184, -32.858646392822, 7.0009446062613e-05),
								["Bone"] = "left finger 1",
								["UniqueID"] = "1789457327",
								["ClassName"] = "bone",
							},
						},
						[12] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-22.895551681519, -20.557104110718, 6.9579391479492),
								["Bone"] = "left upperarm",
								["UniqueID"] = "2891960637",
								["ClassName"] = "bone",
							},
						},
						[13] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00018142691988032, -58.857456207275, 0.00033126422204077),
								["Bone"] = "left finger 3",
								["UniqueID"] = "2681491572",
								["ClassName"] = "bone",
							},
						},
						[14] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00030735851032659, -58.857543945313, 18.240846633911),
								["Bone"] = "left finger 31",
								["UniqueID"] = "2543372601",
								["ClassName"] = "bone",
							},
						},
						[15] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(25.351282119751, -0.00058834539959207, -0.0006669961148873),
								["Bone"] = "left hand",
								["UniqueID"] = "3015554550",
								["ClassName"] = "bone",
							},
						},
					},
					["self"] = {
						["AffectChildrenOnly"] = true,
						["ClassName"] = "event",
						["Invert"] = true,
						["Event"] = "button",
						["Arguments"] = "b",
						["UniqueID"] = "350388899",
						["Name"] = "button",
						["EditorExpand"] = true,
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["StartColor"] = Vector(69, 69, 69),
								["UniqueID"] = "3925297840",
								["Bend"] = 9.5,
								["WidthBendSize"] = 2.2000000476837,
								["ClassName"] = "beam",
								["Width"] = 0.30000001192093,
								["EndPointUID"] = "2416272245",
								["EndColor"] = Vector(67, 67, 67),
								["Material"] = "models/shiny",
								["Angles"] = Angle(57.730892181396, 68.208801269531, 81.565940856934),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["UniqueID"] = "3123463247",
						["EditorExpand"] = true,
						["Color"] = Vector(0, 0, 0),
						["Size"] = 0.025000000372529,
						["Model"] = "models/hunter/blocks/cube025x025x025.mdl",
						["Position"] = Vector(-0.00146484375, -0.00341796875, 0.47200000286102),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1994836639",
				["Position"] = Vector(2.38427734375, 0.45703125, 5.4628601074219),
				["TextureFilter"] = 2.6,
				["Scale"] = Vector(0.89999997615814, 1.5, 1.6000000238419),
				["EditorExpand"] = true,
				["Angles"] = Angle(-38.075866699219, 96.128974914551, 179.49406433105),
				["Size"] = 0.1,
				["ClassName"] = "model",
				["Color"] = Vector(148, 148, 148),
				["Bone"] = "left clavicle",
				["Model"] = "models/props_lab/eyescanner.mdl",
				["AngleOffset"] = Angle(0, 0, -0.10000000149012),
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1798990497",
						["Scale"] = Vector(0.69999998807907, 0.89999997615814, 2.7000000476837),
						["Position"] = Vector(0.081000000238419, 0.00079345703125, -0.23899999260902),
						["Material"] = "models/props_building_details/courtyard_template001c_bars",
						["Size"] = 0.05,
						["Angles"] = Angle(0.16699999570847, 180.61700439453, 180),
						["Color"] = Vector(131, 131, 131),
						["Bone"] = "right clavicle",
						["Model"] = "models/hunter/plates/plate1x1.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "595781976",
				["Model"] = "models/hunter/plates/plate1x1.mdl",
				["EditorExpand"] = true,
				["Scale"] = Vector(0.89999997615814, 0.80000001192093, 0.10000000149012),
				["Alpha"] = 0.925,
				["Angles"] = Angle(39.701843261719, -64.431869506836, -164.38990783691),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "http://dwebhost.co/s/sour/american-flag-patch-gold.png",
				["Bone"] = "right clavicle",
				["Translucent"] = true,
				["Position"] = Vector(2.494140625, 0.97299998998642, -5.3860001564026),
			},
		},
	},
	["self"] = {
		["Name"] = "my outfit",
		["ClassName"] = "group",
		["UniqueID"] = "1143192131",
		["EditorExpand"] = true,
	},
},


})
    GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
    GM.Inv:RegisterItem( Item )