--[[
	Name: neck_items.lua
	For: TalosLife
	By: TalosLife
]]--

local Item = {}
Item.Name = "Bandana"
Item.Desc = "A bandana."
Item.Type = "type_clothing"
Item.Model = "models/modified/bandana.mdl"
Item.Weight = 1
Item.Volume = 1
Item.CanDrop = true
Item.CanEquip = true
Item.EquipSlot = "Neck"
Item.PacOutfit = "bandana"

Item.ClothingMenuCat = "Neckwear"
Item.ClothingMenuItemName = "Bandana"
Item.ClothingMenuPrice = 20

GM.PacModels:Register( Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {},
				["self"] = {
					["Angles"] = Angle(-1.1042726039886, -87.110969543457, -89.747604370117),
					["Position"] = Vector(-0.38726806640625, -0.10284423828125, -0.045135498046875),
					["ClassName"] = "model",
					["UniqueID"] = "209812177",
					["Model"] = "models/modified/bandana.mdl",
					["Scale"] = Vector(1.1499999761581, 0.98000001907349, 1),
				},
			},
		},
		["self"] = {
			["ClassName"] = "group",
			["OwnerName"] = "self",
			["UniqueID"] = "186508818",
			["EditorExpand"] = true,
		},
	},
} )
GM.PacModels:Register( "female_".. Item.PacOutfit, {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Angles"] = Angle(-1.1042726039886, -87.110969543457, -89.747604370117),
					["Position"] = Vector(-1.5002212524414, -0.01043701171875, -0.058563232421875),
					["ClassName"] = "model",
					["UniqueID"] = "209812177",
					["Model"] = "models/modified/bandana.mdl",
					["Scale"] = Vector(1.0499999523163, 0.98000001907349, 1),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "367889536",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
} )
GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
GM.Inv:RegisterItem( Item )

local function AddBandana(name, url, price, rand)
	local Item = {}

	Item.Name = name
	Item.Desc = "A ".. name.. "."
	Item.Type = "type_clothing"
	Item.Model = "models/modified/bandana.mdl"
	Item.Weight = 1
	Item.Volume = 1
	Item.CanDrop = true
	Item.CanEquip = true
	Item.EquipSlot = "Neck"
	Item.PacOutfit = name

	Item.ClothingMenuCat = "Neckwear"
	Item.ClothingMenuItemName = "Bandana"
	Item.ClothingMenuPrice = price

	GM.PacModels:Register( Item.PacOutfit, {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {},
					["self"] = {
						["Material"] = url,
						["Angles"] = Angle(-1.1042726039886, -87.110969543457, -89.747604370117),
						["Position"] = Vector(-0.38726806640625, -0.10284423828125, -0.045135498046875),
						["ClassName"] = "model",
						["UniqueID"] = rand[1],
						["Model"] = "models/modified/bandana.mdl",
						["Scale"] = Vector(1.1499999761581, 0.98000001907349, 1),
					},
				},
			},
			["self"] = {
				["ClassName"] = "group",
				["OwnerName"] = "self",
				["UniqueID"] = rand[2],
				["EditorExpand"] = true,
			},
		},
	} )
	GM.PacModels:Register( "female_".. Item.PacOutfit, {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = url,
						["Angles"] = Angle(-1.1042726039886, -87.110969543457, -89.747604370117),
						["Position"] = Vector(-1.5002212524414, -0.01043701171875, -0.058563232421875),
						["ClassName"] = "model",
						["UniqueID"] = rand[3],
						["Model"] = "models/modified/bandana.mdl",
						["BaseTexture"] = url,
						["Scale"] = Vector(1.0499999523163, 0.98000001907349, 1),
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = rand[4],
				["ClassName"] = "group",
				["Name"] = "my outfit",
				["Description"] = "add parts to me!",
			},
		},
	} )

	GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
	GM.Inv:RegisterItem( Item )
end



-- AddBandana("American Bandana", "https://i.imgur.com/W7JeULD.jpg", 810, {"172829400", "594033931", "643328999", "750939631"})
-- AddBandana("Marijuana Bandana", "https://i.imgur.com/6hmCqhK.jpg", 810, {"338951633", "344998548", "89592726", "278197290"})
-- AddBandana("Gucci Bandana", "https://i.imgur.com/kuWhrDh.png", 810, {"270777253", "506358799", "904254016", "123007145"})
--AddBandana("Fozie Bandana", "https://i.imgur.com/Bjnto88.png", 810, {"697205248", "998550214", "15378311", "222100768"})