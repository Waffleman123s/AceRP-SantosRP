--[[
	Name: drugs_tobacco.lua
	For: SantosRP
	By: Ultra
]]--

local Item = {}
Item.Name = "Cigarettes"
Item.Desc = "A pack of 20 cigarettes"
Item.Type = "type_drugs"
Item.Model = "models/boxopencigshib.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "cigarettes"

Item.OnUse = function( tblItem, pPlayer, intDuration )
	if not GAMEMODE.Inv:GivePlayerItem( pPlayer, "Cigarette", 20 ) then
		GAMEMODE.Inv:GivePlayerItem( pPlayer, tblItem.Name, 1 )
	end
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Cigarette"
Item.Desc = "A single cigarette"
Item.Type = "type_drugs"
Item.Model = "models/pissedmeoff.mdl"
Item.Weight = 0.1
Item.Volume = 0.1
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "cigarettes"

Item.SetupEntity = function( tblItem, eEnt )
	local v1 = Vector( 1, 1, 1 )
	eEnt:PhysicsInitBox( v1 *-1, v1 )
end
Item.PlayerCanUse = function( tblItem, pPlayer )
	local random = math.random( 180, 400 )
	local b, _ = GAMEMODE.PlayerEffects:GetEffect( "Cigarette Smoking" ):CanGive( pPlayer, random )
	return b, b and { random }
end
Item.OnUse = function( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Cigarette Smoking", intDuration )
	end
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Cigar Box"
Item.Desc = "A box of 10 cigars"
Item.Type = "type_drugs"
Item.Model = "models/gibs/furniture_gibs/furniture_vanity01a_gib01.mdl"
Item.Weight = 2
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "cigarettes"

Item.OnUse = function( tblItem, pPlayer, intDuration )
	if not GAMEMODE.Inv:GivePlayerItem( pPlayer, "Cigar", 10 ) then
		GAMEMODE.Inv:GivePlayerItem( pPlayer, tblItem.Name, 1 )
	end
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Cigar"
Item.Desc = "A single cigar"
Item.Type = "type_drugs"
Item.Model = "models/props_c17/TrapPropeller_Lever.mdl"
Item.Weight = 0.2
Item.Volume = 0.2
Item.CanDrop = true
Item.CanUse = true
Item.LimitID = "cigarettes"

Item.PlayerCanUse = function( tblItem, pPlayer )
	local random = math.random( 240, 500 )
	local b, _ = GAMEMODE.PlayerEffects:GetEffect( "Cigar Smoking" ):CanGive( pPlayer, random )
	return b, b and { random }
end
Item.OnUse = function( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Cigar Smoking", intDuration )
	end
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )