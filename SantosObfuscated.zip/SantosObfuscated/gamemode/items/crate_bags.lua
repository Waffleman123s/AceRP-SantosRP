--[[
	Name: crate_bags.lua
	For: ProjectSteele.Com
	By: Christopher Steele
]]--

for i = 1, 1 do
	local Item = {}
	Item.Name = "Jetpack Backpack (Skin ".. i.. ")"
	Item.Desc = "A backpack."
	Item.Type = "type_clothing"
	Item.Model = "models/gmod_tower/jetpack.mdl"
	Item.Skin = i -1
	Item.Weight = 1
	Item.Volume = 1
	Item.CanDrop = true
	Item.CanEquip = true

	Item.EquipSlot = "Back"
	Item.PacOutfit = "jetpackbackpack_".. (i -1)
	Item.Stats = [[+100 Inventory Weight
+150 Inventory Volume]]

	Item.EquipBoostCarryWeight = 100
	Item.EquipBoostCarryVolume = 150
	
	GM.PacModels:Register( Item.PacOutfit, {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {},
					["self"] = {
						["Angles"] = Angle(-2.2549149990082, 103.04399108887, 89.099395751953),
						["UniqueID"] = "1484483537",
						["Position"] = Vector(3.8101043701172, 2.7722778320313, -0.1195068359375),
						["Bone"] = "spine 1",
						["Model"] = "models/gmod_tower/jetpack.mdl",
						["ClassName"] = "model",
						["Skin"] = (i -1),
					},
				},
			},
			["self"] = {
				["ClassName"] = "group",
				["OwnerName"] = "self",
				["UniqueID"] = "706998888",
				["EditorExpand"] = true,
			},
		},
	} )
	GM.PacModels:Register( "female_".. Item.PacOutfit, {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.58343929052353, 95.733207702637, 89.392776489258),
						["UniqueID"] = "1484483537",
						["Position"] = Vector(-1.6768951416016, 1.4813537597656, -0.069732666015625),
						["ClassName"] = "model",
						["Bone"] = "spine 2",
						["Model"] = "models/gmod_tower/jetpack.mdl",
						["Scale"] = Vector(0.89999997615814, 1, 1),
						["Skin"] = (i -1),
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "672398888",
				["ClassName"] = "group",
				["Name"] = "my outfit",
				["Description"] = "add parts to me!",
			},
		},
	} )
	GM.PacModels:RegisterOutfitModelOverload( Item.PacOutfit, GM.Config.PlayerModels.Female, "female_".. Item.PacOutfit )
	GM.Inv:RegisterItem( Item )
end

-- ----------------------------------------------------------------