--[[
	Name: food_bakeable.lua
	For: SantosRP
	By: Ultra
]]--
local function EdibleWeedPlayerCanUse( tblItem, pPlayer )
	local random = math.random( tblItem.IntoxMin, tblItem.IntoxMax )
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect( "EdibleHigh" ):CanGive( pPlayer, random, true )
	return b or bHandedOff, (b or bHandedOff) and { random } 
end

local function EdibleWeedPlayerUse( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "EdibleHigh", intDuration )
	end
end
local function PlayerCanEatItem( tblItem, pPlayer )
	if GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Hunger" ) >= GAMEMODE.Needs:GetNeedData( "Hunger" ).Max then
		return false
	end

	if tblItem.HungerFillLen then
		--We are adding hunger
		local bHunger, _ = GAMEMODE.PlayerEffects:GetEffect( "Restoring Hunger" ):CanGive( pPlayer, tblItem.HungerFillLen )
		if bHunger then return true end
	else
		--We are removing hunger
		local bHunger, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Hunger" ):CanGive( pPlayer, tblItem.HungerDrainLen )
		if bHunger then return true end
	end
end

local function PlayerEatItem( tblItem, pPlayer )
	if tblItem.HungerFillLen then
		--We are adding hunger
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Restoring Hunger", tblItem.HungerFillLen )
	else
		--We are removing hunger
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Hunger", tblItem.HungerDrainLen )
	end

	--Check if eating this item will change our thirst
	if tblItem.ThirstFillLen then
		--We are adding thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Quenching Thirst" ):CanGive( pPlayer, tblItem.ThirstFillLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Quenching Thirst", tblItem.ThirstFillLen )
		end
	elseif tblItem.ThirstDrainLen then
		--We are removing thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Thirst" ):CanGive( pPlayer, tblItem.ThirstDrainLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Thirst", tblItem.ThirstDrainLen )
		end
	end

	--Check if eating this item will change our stamina
	if tblItem.StaminaFillLen then
		--We are adding thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Restoring Stamina" ):CanGive( pPlayer, tblItem.StaminaFillLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Restoring Stamina", tblItem.StaminaFillLen )
		end
	elseif tblItem.StaminaDrainLen then
		--We are removing thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Stamina" ):CanGive( pPlayer, tblItem.StaminaDrainLen )
		if bThirst then
			GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Stamina", tblItem.StaminaDrainLen )
		end
	end

	pPlayer:EmitSound( "santosrp/eating.mp3" )
end

--[[local function PlayerEatItem( tblItem, pPlayer )
	if tblItem.GiveHunger >= 0 then
		GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Hunger", tblItem.GiveHunger )
	else
		GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Hunger", math.abs(tblItem.GiveHunger) )
	end

	if tblItem.GiveStamina then
		if tblItem.GiveStamina >= 0 then
			GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Stamina", tblItem.GiveStamina )
		else
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Stamina", math.abs(tblItem.GiveStamina) )
		end
	end
	
	pPlayer:EmitSound( "santosrp/eating.mp3" )
end

local function PlayerDrinkItem( tblItem, pPlayer )
	if tblItem.GiveThirst >= 0 then
		GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Thirst", tblItem.GiveThirst )
	else
		GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Thirst", math.abs(tblItem.GiveThirst) )
	end

	if tblItem.GiveStamina then
		if tblItem.GiveStamina >= 0 then
			GAMEMODE.Needs:AddPlayerNeed( pPlayer, "Stamina", tblItem.GiveStamina )
		else
			GAMEMODE.Needs:TakePlayerNeed( pPlayer, "Stamina", math.abs(tblItem.GiveStamina) )
		end
	end
	
	pPlayer:EmitSound( "npc/barnacle/barnacle_gulp".. math.random(1, 2).. ".wav", 60, math.random(70, 130) )
	pPlayer:ViewPunch( Angle(-math.random(6, 12), 0, 0) )
end]]--

--local function PlayerCanEatItem( tblItem, pPlayer )
--	return GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Hunger" ) < GAMEMODE.Needs:GetNeedData( "Hunger" ).Max
--end
--
--local function PlayerCanDrinkItem( tblItem, pPlayer )
--	return GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Thirst" ) < GAMEMODE.Needs:GetNeedData( "Thirst" ).Max
--end

local qualityLevels = { "Disgusting", "Average", "Delicious" }
local function DeclareBakedFood( tblFoodProto )
	for i = 1, 3 do
		local Item = {}
		Item.Name = tblFoodProto.Name.. (" (%s Quality)"):format( qualityLevels[i] )
		Item.Desc = tblFoodProto.Desc
		Item.Type = tblFoodProto.Type
		Item.Model = tblFoodProto.Model
		Item.Weight = tblFoodProto.Weight
		Item.Volume = tblFoodProto.Volume
		Item.CanDrop = tblFoodProto.CanDrop
		Item.CanUse = tblFoodProto.CanUse
		Item.DropClass = tblFoodProto.DropClass
		Item.HungerFillLen = tblFoodProto.GiveHunger[i]
		Item.OnUse = PlayerEatItem
		Item.PlayerCanUse = PlayerCanEatItem
		Item.FishingData = tblFoodProto.FishingData

		if tblFoodProto.GiveStamina then
			Item.StaminaFillLen = tblFoodProto.GiveStamina[i]
		end

		GM.Inv:RegisterItem( Item )
	end
end


DeclareBakedFood{
	Name = "Toast",
	Desc = "A serving of toasted bread.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/toast.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 1, 6, 8 },
	GiveStamina = { 1, 1, 1 },

	FishingData = {
		IsBait = true,
	}
}
local Item = {}
Item.Name = "Wheat Bread"
Item.Desc = "A serving of wheat bread."
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/toast.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.175, --max % to remove from the score in the worst case

	OvenProgress = 7,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Toast",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Toast (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Toast (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Toast (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	},
}
Item.HungerFillLen = 1
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.FishingData = {
	IsBait = true,
}
GM.Inv:RegisterItem( Item )

DeclareBakedFood{
	Name = "Cake",
	Desc = "A freshly baked cake.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/cake.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 6, 25, 44 },
	GiveStamina = { 1, 2, 4 },

	FishingData = {
		IsBait = true,
	}
}
local Item = {}
Item.Name = "Cake Batter"
Item.Desc = "A tray of cake batter, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 6
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 3
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Box of Flour"] = 1,
	["Egg"] = 2,
	["Milk"] = 1,
	["Salt"] = 1,
	["Filtered Water"] = 1,
	["Sugar"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.4, --max % to remove from the score in the worst case

	OvenProgress = 10,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Cake",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Cake (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Cake (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Cake (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	},
}
Item.FishingData = {
	IsBait = true,
}
GM.Inv:RegisterItem( Item )


DeclareBakedFood{
	Name = "Pizza",
	Desc = "A freshly baked pizza.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/pizzab.mdl",
	Weight = 4,
	Volume = 4,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 8, 43, 50 },
	GiveStamina = { 1, 2, 5 },

	FishingData = {
		IsBait = true,
	}
}
local Item = {}
Item.Name = "Uncooked Pizza"
Item.Desc = "A freshly made pizza, ready to bake."
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/pizza.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 6
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 8
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Box of Flour"] = 2,
	["Salt"] = 1,
	["Filtered Water"] = 1,
	["Cheese"] = 2,
	["Tomato"] = 2,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.7, --max % to remove from the score in the worst case

	OvenProgress = 8,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 45, --Max time after being done before starting a fire
	GiveItem = "Pizza",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Pizza (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Pizza (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Pizza (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	},
}
GM.Inv:RegisterItem( Item )


--[[ Fish ]]--
DeclareBakedFood{
	Name = "Baked Sunfish",
	Desc = "A freshly baked sunfish meal.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 4, 7, 24 },
	GiveStamina = { 1, 2, 5 },
}
local Item = {}
Item.Name = "Unbaked Sunfish Meal"
Item.Desc = "A freshly made sunfish meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 3
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 2
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Sunfish"] = 1,
	["Salt"] = 1,
	["Cooking Oil"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.375, --max % to remove from the score in the worst case

	OvenProgress = 12,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Baked Sunfish",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Sunfish (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Sunfish (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Sunfish (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )


DeclareBakedFood{
	Name = "Baked Gold Fish",
	Desc = "A freshly baked gold fish meal. Not much of a meal, is it?",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 1, 2, 4 },
	GiveStamina = { 1, 1, 2 },
}
local Item = {}
Item.Name = "Unbaked Gold Fish Meal"
Item.Desc = "A freshly made gold fish meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 1
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Gold Fish"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.33, --max % to remove from the score in the worst case

	OvenProgress = 6,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 30, --Max time after being done before starting a fire
	GiveItem = "Baked Gold Fish",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Gold Fish (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Gold Fish (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Gold Fish (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )

DeclareBakedFood{
	Name = "Baked Golden Trout",
	Desc = "A freshly baked golden trout meal.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 10, 22, 36 },
	GiveStamina = { 1, 2, 5 },
}
local Item = {}
Item.Name = "Unbaked Golden Trout Meal"
Item.Desc = "A freshly made golden trout meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 3
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Golden Trout"] = 1,
	["Salt"] = 1,
	["Cooking Oil"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.4, --max % to remove from the score in the worst case

	OvenProgress = 13,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Baked Golden Trout",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Golden Trout (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Golden Trout (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Golden Trout (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )


DeclareBakedFood{
	Name = "Baked Bass",
	Desc = "A freshly baked bass meal.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 11, 24, 40 },
	GiveStamina = { 1, 2, 5 },
}
local Item = {}
Item.Name = "Unbaked Bass Meal"
Item.Desc = "A freshly made bass meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 3
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 7
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Bass"] = 1,
	["Salt"] = 1,
	["Cooking Oil"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.5, --max % to remove from the score in the worst case

	OvenProgress = 10,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Baked Bass",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Bass (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Bass (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Bass (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )


DeclareBakedFood{
	Name = "Baked Catfish",
	Desc = "A freshly baked catfish meal.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 11, 24, 44 },
	GiveStamina = { 1, 2, 5 },
}
local Item = {}
Item.Name = "Unbaked Catfish Meal"
Item.Desc = "A freshly made catfish meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 3
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 7
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Catfish"] = 1,
	["Salt"] = 1,
	["Cooking Oil"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.55, --max % to remove from the score in the worst case

	OvenProgress = 8,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 45, --Max time after being done before starting a fire
	GiveItem = "Baked Catfish",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Catfish (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Catfish (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Catfish (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )


DeclareBakedFood{
	Name = "Baked Rainbow Trout",
	Desc = "A freshly baked rainbow trout meal.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 11, 24, 44 },
	GiveStamina = { 1, 2, 5 },
}
local Item = {}
Item.Name = "Unbaked Rainbow Trout Meal"
Item.Desc = "A freshly made rainbow trout meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 3
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 7
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Rainbow Trout"] = 1,
	["Salt"] = 1,
	["Cooking Oil"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.6, --max % to remove from the score in the worst case

	OvenProgress = 9,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 50, --Max time after being done before starting a fire
	GiveItem = "Baked Rainbow Trout",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Rainbow Trout (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Rainbow Trout (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Rainbow Trout (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )


DeclareBakedFood{
	Name = "Baked Lobster",
	Desc = "A freshly baked lobster meal.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/fishsteak.mdl",
	Weight = 1,
	Volume = 1,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics_multiplayer",
	GiveHunger = { 12, 31, 53 },
	GiveStamina = { 1, 2, 5 },
}
local Item = {}
Item.Name = "Unbaked Lobster Meal"
Item.Desc = "A freshly made lobster meal, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics_multiplayer"
Item.HungerFillLen = 3
Item.StaminaFillLen = 1
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 10
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Uncooked Lobster"] = 1,
	["Salt"] = 1,
	["Cooking Oil"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.8, --max % to remove from the score in the worst case

	OvenProgress = 13,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 20, --Max time after being done before starting a fire
	GiveItem = "Baked Lobster",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Baked Lobster (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Baked Lobster (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Baked Lobster (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 3 },
		{ MinQuality = 0.61, GiveAmount = 5 },
		{ MinQuality = 0.825, GiveAmount = 7 },
	},
}
GM.Inv:RegisterItem( Item )

--ggsx

DeclareBakedFood{
    Name = "Special Brownies",
    Desc = "Gordaemert's Special Recipe",
    Type = "type_food",
    Model = "models/foodnhouseholditems/meat9b.mdl",
    Weight = 1,
    Volume = 2,
    CanDrop = true,
    CanUse = true,
    Illegal = true,
    DropClass = "prop_physics",
    GiveHunger = { 30, 120, 200 },
    GiveStamina = { 3, 20, 35 },

}
local Item = {}
Item.Name = "Special Brownies (Disgusting Quality)"
Item.Desc = "Gordaemert's Special Recipe"
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/meat9b.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.IntoxMin = 120
Item.IntoxMax = 180
Item.LimitID = "edibles"
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.PlayerCanUse = EdibleWeedPlayerCanUse
Item.OnUse = EdibleWeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

local Item = {}
Item.Name = "Special Brownies (Average Quality)"
Item.Desc = "Gordaemert's Special Recipe"
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/meat9.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.IntoxMin = 200
Item.IntoxMax = 400
Item.LimitID = "edibles"
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.PlayerCanUse = EdibleWeedPlayerCanUse
Item.OnUse = EdibleWeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

local Item = {}
Item.Name = "Special Brownies (Delicious Quality)"
Item.Desc = "Gordaemert's Special Recipe"
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/meat9.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.IntoxMin = 450
Item.IntoxMax = 550
Item.LimitID = "edibles"
Item.DropClass = "prop_physics"
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.PlayerCanUse = EdibleWeedPlayerCanUse
Item.OnUse = EdibleWeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

local Item = {}
Item.Name = "Special Batter"
Item.Desc = "A tray of Brownie batter, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.PlayerCanUse = EdibleWeedPlayerCanUse
Item.OnUse = EdibleWeedPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 5
Item.CraftSkillXP = 4
Item.NoCraftSounds = true
Item.CraftRecipe = {
    ["Box of Flour"] = 1,
    ["Egg"] = 1,
    ["Toblerone"] = 2,
    ["Salt"] = 1,
    ["Filtered Water"] = 1,
    ["Sugar"] = 1,
    ["Cannabis (High Quality)"] = 1,
}
Item.Cooking_OvenVars = {
    Skill = "Cooking",
    SkillWeight = 0.4, --max % to remove from the score in the worst case

    OvenProgress = 10,
    OvenAmountPerTick = 0.1,
    OvenMaxOverTime = 60, --Max time after being done before starting a fire
    GiveItem = "Special Brownies",
    GiveItems = {
        { MinQuality = 0, GiveItem = "Special Brownies (Disgusting Quality)", GiveAmount = 4 },
        { MinQuality = 0.61, GiveItem = "Special Brownies (Average Quality)", GiveAmount = 4 },
        { MinQuality = 0.825, GiveItem = "Special Brownies (Delicious Quality)", GiveAmount = 4 },
    },

    GiveXP = { --In order from 0 score up
        { MinQuality = 0, GiveAmount = 5 },
        { MinQuality = 0.61, GiveAmount = 7 },
        { MinQuality = 0.825, GiveAmount = 9 },
    },
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

DeclareBakedFood{
	Name = "Pumpkin Pie",
	Desc = "A freshly baked pie.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/pie.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics",
	GiveHunger = { 80, 250, 400 },
	GiveStamina = { 3, 20, 35 },
}
local Item = {}
Item.Name = "Uncooked Pumpkin Pie"
Item.Desc = "A freshly prepared pie ready to be baked."
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/pie.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 4
Item.CraftSkillXP = 7
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Box of Flour"] = 1,
	["Egg"] = 2,
	["Milk"] = 1,
	["Pumpkin"] = 1,
	["Sugar"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.4, --max % to remove from the score in the worst case

	OvenProgress = 10,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Pumpkin Pie",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Pumpkin Pie (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Pumpkin Pie (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Pumpkin Pie (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 15 },
		{ MinQuality = 0.61, GiveAmount = 17 },
		{ MinQuality = 0.825, GiveAmount = 19 },
	},
}
GM.Inv:RegisterItem( Item )

DeclareBakedFood{
	Name = "Roast Chicken",
	Desc = "A whole roast chicken.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/turkey2.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics",
	GiveHunger = { 150, 200, 250 },
	GiveStamina = { 25, 50, 75 },
}
local Item = {}
Item.Name = "Uncooked Chicken"
Item.Desc = "An uncooked serving of chicken."
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/meat3.mdl"
Item.Weight = 1
Item.Volume = 2
Item.CanDrop = true
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.175, --max % to remove from the score in the worst case

	OvenProgress = 7,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Roast Chicken",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Roast Chicken (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Roast Chicken (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Roast Chicken (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	},
}
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem
GM.Inv:RegisterItem( Item )

DeclareBakedFood{
	Name = "Pizza",
	Desc = "A delicious looking pizza.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/pizzab.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics",
	GiveHunger = { 50, 200, 350 },
	GiveStamina = { 3, 20, 35 },
}
local Item = {}
Item.Name = "Uncooked Pizza"
Item.Desc = "A pizza, ready to be baked."
Item.Type = "type_food"
Item.Model = "models/foodnhouseholditems/pizza.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.GiveHunger = 50
Item.GiveStamina = 3
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 7
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Box of Flour"] = 1,
	["Filtered Water"] = 1,
	["Salt"] = 1,
	["Tomato Paste"] = 1,
	["Uncooked Bacon"] = 1,
	["Cheese"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.4, --max % to remove from the score in the worst case

	OvenProgress = 10,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Pizza",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Pizza (Disgusting Quality)", GiveAmount = 1 },
		{ MinQuality = 0.61, GiveItem = "Pizza (Average Quality)", GiveAmount = 1 },
		{ MinQuality = 0.825, GiveItem = "Pizza (Delicious Quality)", GiveAmount = 1 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 25 },
		{ MinQuality = 0.61, GiveAmount = 37 },
		{ MinQuality = 0.825, GiveAmount = 49 },
	},
}
GM.Inv:RegisterItem( Item )


----Project Steele

DeclareBakedFood{
	Name = "Doughnut",
	Desc = "A freshly doughnut.",
	Type = "type_food",
	Model = "models/foodnhouseholditems/donut.mdl",
	Weight = 1,
	Volume = 2,
	CanDrop = true,
	CanUse = true,
	DropClass = "prop_physics",
	GiveHunger = { 50, 200, 350 },
	GiveStamina = { 3, 20, 35 },
}
local Item = {}
Item.Name = "Doughnut Batter"
Item.Desc = "A tray of doughnut batter, ready to bake."
Item.Type = "type_food"
Item.Model = "models/props_c17/metalPot002a.mdl"
Item.Weight = 4
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.CanCook = true
Item.DropClass = "prop_physics"
Item.GiveHunger = 25
Item.GiveStamina = 3
Item.OnUse = PlayerEatItem
Item.PlayerCanUse = PlayerCanEatItem

Item.CraftingEntClass = "ent_foodprep_table"
Item.CraftSkill = "Cooking"
Item.CraftSkillLevel = 3
Item.CraftSkillXP = 2
Item.NoCraftSounds = true
Item.CraftRecipe = {
	["Box of Flour"] = 1,
	["Egg"] = 2,
	["Milk"] = 1,
	["Salt"] = 1,
	["Filtered Water"] = 1,
	["Baking Soda"] = 1,
}
Item.Cooking_OvenVars = {
	Skill = "Cooking",
	SkillWeight = 0.4, --max % to remove from the score in the worst case

	OvenProgress = 10,
	OvenAmountPerTick = 0.1,
	OvenMaxOverTime = 60, --Max time after being done before starting a fire
	GiveItem = "Doughnut",
	GiveItems = {
		{ MinQuality = 0, GiveItem = "Doughnut (Disgusting Quality)", GiveAmount = 8 },
		{ MinQuality = 0.61, GiveItem = "Doughnut (Average Quality)", GiveAmount = 8 },
		{ MinQuality = 0.825, GiveItem = "Doughnut (Delicious Quality)", GiveAmount = 8 },
	},

	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	},
}
GM.Inv:RegisterItem( Item )