--[[
	Name: drugs_meth.lua
	For: SantosRP
	By: Ultra
]]--

local function PlayerCanDrinkItem( tblItem, pPlayer )
	if GAMEMODE.Needs:GetPlayerNeed( pPlayer, "Thirst" ) >= GAMEMODE.Needs:GetNeedData( "Thirst" ).Max then
		return
	end

	if tblItem.ThirstFillLen then
		--We are adding thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Quenching Thirst" ):CanGive( pPlayer, tblItem.ThirstFillLen )
		return bThirst
	else
		--We are removing thirst
		local bThirst, _ = GAMEMODE.PlayerEffects:GetEffect( "Draining Thirst" ):CanGive( pPlayer, tblItem.ThirstDrainLen )
		return bThirst
	end
end

local function PlayerDrinkItem( tblItem, pPlayer )
	if tblItem.ThirstFillLen then
		--We are adding thirst
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Quenching Thirst", tblItem.ThirstFillLen )
	elseif tblItem.ThirstDrainLen then
		--We are removing thirst
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Draining Thirst", tblItem.ThirstDrainLen )
	end

	if tblItem.IsPosion then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Fatal Poisoning", -1 )
	end

	pPlayer:EmitSound( "npc/barnacle/barnacle_gulp".. math.random(1, 2).. ".wav", 60, math.random(70, 130) )
	pPlayer:ViewPunch( Angle(-math.random(6, 12), 0, 0) )
end

local function MethPlayerCanUse( tblItem, pPlayer )
	local random = math.random( tblItem.IntoxMin, tblItem.IntoxMax )
	local b, bHandedOff = GAMEMODE.PlayerEffects:GetEffect( "Mild Amphetamine Stimulation" ):CanGive( pPlayer, random, true )
	return b or bHandedOff, (b or bHandedOff) and { random } 
end

local function MethPlayerUse( tblItem, pPlayer, intDuration )
	if intDuration then
		GAMEMODE.PlayerEffects:AddEffect( pPlayer, "Mild Amphetamine Stimulation", intDuration )
	end
end

local Item = {}
Item.Name = "Drug Lab"
Item.Desc = "A lab for processing chemicals and heating compounds."
Item.Type = "type_drugs"
Item.Model = "models/props/CS_militia/table_shed.mdl"
Item.Weight = 65
Item.Volume = 60
Item.HealthOverride = 2500
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_drug_lab"
Item.LimitID = "drug lab"

Item.CraftingEntClass = "ent_crafting_table"
Item.CraftingTab = "Machines"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Wood Plank"] = 10,
	["Metal Bracket"] = 8,
	["Metal Plate"] = 6,
	["Metal Pipe"] = 3,
	["Chunk of Plastic"] = 5,
	["Car Battery"] = 1,
	["Circular Saw"] = 1,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 2, ["vip_t2"] = 2 } )

local Item = {}
Item.Name = "Still"
Item.Desc = "A large still used to separate and condense chemicals."
Item.Type = "type_drugs"
Item.Model = "models/props_pipes/valve002.mdl"
Item.Weight = 65
Item.Volume = 60
Item.HealthOverride = 1500
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_still"
Item.LimitID = "still"

Item.CraftingEntClass = "ent_crafting_table"
Item.CraftingTab = "Machines"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Metal Bracket"] = 15,
	["Metal Plate"] = 10,
	["Metal Pipe"] = 15,
	["Chunk of Plastic"] = 4,
	["Car Battery"] = 1,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 2, ["vip_t2"] = 2 } )

local Item = {}
Item.Name = "Chemical Reaction Chamber"
Item.Desc = "A large lab-grade reaction chamber."
Item.Type = "type_drugs"
Item.Model = "models/props_wasteland/laundry_washer001a.mdl"
Item.Weight = 65
Item.Volume = 60
Item.HealthOverride = 3000
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_reaction_chamber"
Item.LimitID = "reaction chamber"

Item.CraftingEntClass = "ent_crafting_table"
Item.CraftingTab = "Machines"
Item.CraftSkill = "Crafting"
Item.CraftSkillLevel = 1
Item.CraftSkillXP = 5
Item.CraftRecipe = {
	["Metal Bracket"] = 15,
	["Metal Plate"] = 20,
	["Metal Pipe"] = 15,
	["Chunk of Plastic"] = 10,
	["Car Battery"] = 2,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1, { ["vip_t1"] = 2, ["vip_t2"] = 2 } )

--Drug components
local Item = {}
Item.Name = "Aluminum Foil"
Item.Desc = "A sheet of aluminum foil."
Item.Model = "models/gibs/glass_shard02.mdl"
Item.Weight = 2
Item.Volume = 6
Item.CanDrop = true
Item.LimitID = "aluminum foil"
Item.DrugLab_BlenderVars = {
	BlendProgress = 10,
	BlendAmountPerTick = 0.1,
	GiveItem = "Aluminum Powder",
	GiveAmount = 2,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Aluminum Powder"
Item.Desc = "A jar of powdered aluminum metal."
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.LimitID = "aluminum powder"
Item.DropClass = "ent_fluid_aluminum_powder"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Red Phosphorous"
Item.Desc = "A box of red phosphorous."
Item.Type = "type_drugs"
Item.Model = "models/props_lab/box01a.mdl"
Item.Weight = 2
Item.Volume = 4
Item.CanDrop = true
Item.CanCook = true
Item.LimitID = "red phosphorous"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 3 )

local Item = {}
Item.Name = "Cleaning Solution"
Item.Desc = "A bottle of ammonia-based cleaning solution."
Item.Model = "models/props_junk/garbage_plasticbottle002a.mdl"
Item.Weight = 6
Item.Volume = 4
Item.CanDrop = true
Item.LimitID = "cleaning solution"
Item.DropClass = "ent_fluid_ammonia"
Item.IsPosion = true
Item.CanUse = true
Item.PlayerCanUse = PlayerCanDrinkItem
Item.OnUse = PlayerDrinkItem
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Methylamine"
Item.Desc = "A jar of the compound methylamine, an illegal methamphetamine precursor."
Item.Type = "type_drugs"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 5
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_methylamine"
Item.LimitID = "methylamine"
Item.IsPosion = true
Item.CanUse = true
Item.PlayerCanUse = PlayerCanDrinkItem
Item.OnUse = PlayerDrinkItem

Item.ReactionChamberVars = {
	Mats = { --Items needed to make a single MakeAmount of the output fluid
		["Ammonia"] = 1,
		["Methanol"] = 2,
		["Aluminum Powder"] = 1,
	},
	Interval = 0.75, --Interval
	MakeAmount = 2, --Amount of fluid to make per interval
	MinGiveAmount = 500, --Amount of the output fluid needed to give a player an item
	GiveItem = "Methylamine",
	GiveAmount = 1,
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Methanol"
Item.Desc = "A jar of methanol."
Item.Type = "type_drugs"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 3
Item.CanDrop = true
Item.DropClass = "ent_fluid_methanol"
Item.LimitID = "methanol"
Item.IsPosion = true
Item.CanUse = true
Item.PlayerCanUse = PlayerCanDrinkItem
Item.OnUse = PlayerDrinkItem

GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Phenylacetic Acid"
Item.Desc = "A jar of phenylacetic acid, an illegal drug precursor."
Item.Type = "type_drugs"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 3
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_phenylacetic_acid"
Item.LimitID = "phenylacetic acid"
Item.IsPosion = true
Item.CanUse = true
Item.PlayerCanUse = PlayerCanDrinkItem
Item.OnUse = PlayerDrinkItem

GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Acetic Acid"
Item.Desc = "A jar of acetic acid, an illegal drug precursor."
Item.Type = "type_drugs"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 3
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_acetic_acid"
Item.LimitID = "acetic acid"
Item.IsPosion = true
Item.CanUse = true
Item.PlayerCanUse = PlayerCanDrinkItem
Item.OnUse = PlayerDrinkItem

GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )

local Item = {}
Item.Name = "Phenylacetone"
Item.Desc = "A jar of the compound phenylacetone, an illegal methamphetamine precursor."
Item.Type = "type_drugs"
Item.Model = "models/props_lab/jar01b.mdl"
Item.Weight = 5
Item.Volume = 3
Item.CanDrop = true
Item.Illegal = true
Item.DropClass = "ent_fluid_phenylacetone"
Item.LimitID = "phenylacetone"
Item.IsPosion = true
Item.CanUse = true
Item.PlayerCanUse = PlayerCanDrinkItem
Item.OnUse = PlayerDrinkItem

Item.CookingPotVars = {
	Skill = "Chemistry",
	SkillWeight = 0.32, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked it! This batch is ruined!",
	OverTimeExplode = true, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 10,
	MaxTime = 90,
	TimeWeight = -0.85, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.7, --% from min to max time to consider ideal

	Items = {},
	Fluids = {
		["Acetic Acid"] = { IdealAmount = 400, MaxAmount = 500, MinAmount = 300 },
		["Phenylacetic Acid"] = { IdealAmount = 325, MaxAmount = 450, MinAmount = 250 },
		["Aluminum Powder"] = { IdealAmount = 175, MaxAmount = 250, MinAmount = 100 },
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Phenylacetone", GiveAmount = 1 },
		{ MinQuality = 0.66, GiveItem = "Phenylacetone", GiveAmount = 2 },
		{ MinQuality = 0.9, GiveItem = "Phenylacetone", GiveAmount = 4 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.66, GiveAmount = 6 },
		{ MinQuality = 0.9, GiveAmount = 7 },
	}
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 2 )


--Drug items
local Item = {}
Item.Name = "Methamphetamine (Low Quality)"
Item.Desc = "A bag of low quality crystal methamphetamine."
Item.Type = "type_drugs"
Item.Model = "models/weapons/w_package.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "methamphetamine"
Item.IntoxMin = 120
Item.IntoxMax = 240
Item.PlayerCanUse = MethPlayerCanUse
Item.OnUse = MethPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CookingPotVars = {
	Skill = "Chemistry",
	SkillWeight = 0.39, --max % to remove from the score in the worst case

	--Only displayed if over time explode/fire are both off and item is grabbed before it reaches the max time cap
	--anything catches fire past the max time cap (set in the cooking pot shared file)
	OverCookMsg = "You overcooked it! This batch is ruined!",
	OverTimeExplode = true, --Explode and start a fire if the item goes over max time
	OverTimeStartFire = false, --Start a fire if the item goes over max time

	MinTime = 10,
	MaxTime = 90,
	TimeWeight = -0.85, --the closer this number is to 0, the less impact time has on the end score (-4 = 0/100% impact do not go below)
	IdealTimePercent = 0.66, --% from min to max time to consider ideal

	Items = {
		["Red Phosphorous"] = { IdealAmount = 3, MaxAmount = 4, MinAmount = 1 }
	},
	Fluids = {
		["Phenylacetone"] = { IdealAmount = 350, MaxAmount = 425, MinAmount = 200 },
		["Methylamine"] = { IdealAmount = 400, MaxAmount = 500, MinAmount = 325 },
		["Water"] = { IdealAmount = 100, MaxAmount = 250, MinAmount = 25 }
	},
	GiveItems = { --In order from low quality to high quality (enter only 1 for no quality)
		{ MinQuality = 0, GiveItem = "Methamphetamine (Low Quality)", GiveAmount = 4 },
		{ MinQuality = 0.61, GiveItem = "Methamphetamine (Medium Quality)", GiveAmount = 6 },
		{ MinQuality = 0.825, GiveItem = "Methamphetamine (High Quality)", GiveAmount = 8 },
	},
	GiveXP = { --In order from 0 score up
		{ MinQuality = 0, GiveAmount = 5 },
		{ MinQuality = 0.61, GiveAmount = 7 },
		{ MinQuality = 0.825, GiveAmount = 9 },
	}
}
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 8 )

local Item = {}
Item.Name = "Methamphetamine (Medium Quality)"
Item.Desc = "A bag of medium quality crystal methamphetamine."
Item.Type = "type_drugs"
Item.Model = "models/weapons/w_package.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "methamphetamine"
Item.IntoxMin = 300
Item.IntoxMax = 450
Item.PlayerCanUse = MethPlayerCanUse
Item.OnUse = MethPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )

local Item = {}
Item.Name = "Methamphetamine (High Quality)"
Item.Desc = "A bag of high quality crystal methamphetamine."
Item.Type = "type_drugs"
Item.Model = "models/weapons/w_package.mdl"
Item.Weight = 2
Item.Volume = 3
Item.CanDrop = true
Item.CanUse = true
Item.Illegal = true
Item.LimitID = "methamphetamine"
Item.IntoxMin = 550
Item.IntoxMax = 700
Item.PlayerCanUse = MethPlayerCanUse
Item.OnUse = MethPlayerUse
Item.SetupEntity = function( _, eEnt )
	eEnt.CanPlayerPickup = Item.CanPlayerPickup
	eEnt.CanPlayerUse = Item.CanPlayerUse
end
Item.CanPlayerPickup = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
Item.CanPlayerUse = function( eEnt, pPlayer, bCanUse )
	return true --Anyone can take drugs!
end
GM.Inv:RegisterItem( Item )