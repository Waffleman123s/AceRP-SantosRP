--[[
Original Creators: MazeRP Development Team
Modified and reworked by: GNetRP Development Team
Legal Information: Legal@gnetrp.com
Extra Information: www.gnetrp.com or www.gnetrp.gg | https://discord.gg/2Mnk937aMn | @Tylr#9999 STEAM_0:1:71010553 @Krusty STEAM_0:1:164681911 @Meaty STEAM_0:1:151895828 | https://github.com/TylrDevs | https://github.com/gnetrp |
]]--

local Item = {}
Item.Name = "Crafting Table"
Item.Desc = "A crafting table for making items."
Item.Model = "models/mosi/fallout76/furniture/workstations/tinkerstation.mdl"
Item.Weight = 50
Item.Volume = 45
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "crafting table"
Item.DropClass = "ent_crafting_table"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Gun Smithing Table"
Item.Desc = "A gun smithing table for making gun parts."
Item.Model = "models/mosi/fallout4/furniture/workstations/workshopbench.mdl"
Item.Weight = 50
Item.Volume = 45
Item.HealthOverride = 3000
Item.CanDrop = true
Item.DropClass = "ent_gunsmithing_table"
Item.LimitID = "gun smithing table"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Assembly Table"
Item.Desc = "An assembly table for putting together items."
Item.Model = "models/mosi/fallout4/furniture/workstations/weaponworkbench01.mdl"
Item.Weight = 50
Item.Volume = 45
Item.HealthOverride = 3000
Item.CanDrop = true
Item.DropClass = "ent_assembly_table"
Item.LimitID = "assembly table"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )

local Item = {}
Item.Name = "Food-Prep Table"
Item.Desc = "A large kitchen table suitable for preparing food on."
Item.Type = "type_food"
Item.Model = "models/props_wasteland/kitchen_counter001a.mdl"
Item.Weight = 50
Item.Volume = 45
Item.HealthOverride = 3000
Item.CanDrop = true
Item.LimitID = "food-prep table"
Item.DropClass = "ent_foodprep_table"
GM.Inv:RegisterItem( Item )
GM.Inv:RegisterItemLimit( Item.LimitID, 1 )