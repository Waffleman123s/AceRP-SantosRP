--[[
	Property of acerp.gg ©2022
	By: Tylr (tylrdevs@gmail.com, Tylr#6345)
	For: AceRP.gg 
]]--


GM.Map = {}
GM.Map.DT_IS_MAP_PROP = 30
GM.Map.m_tblPropRegister = {}

function GM.Map:Load()
	self:LoadMapCode()
	self:LoadMapProps()
end

function GM.Map:Initialize()
end

function GM.Map:InitPostEntity()
	for k, v in pairs( self.m_tblPropRegister ) do
		if v.CustomSpawn then v:CustomSpawn() end
	end
end

--[[ Map Code ]]--
function GM.Map:LoadMapCode()
	GM:PrintDebug( 0, "->LOADING MAP CODE" )

	local map = game.GetMap():gsub( ".bsp", "" )
	local path = GM.Config.GAMEMODE_PATH.. "maps/".. map.. "/map_code/"

	local foundFiles, foundFolders = file.Find( path.. "*.lua", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )
		if not v:StartWith( "sv_" ) then
			include( path.. v )
		end
	end

	GM:PrintDebug( 0, "->MAP CODE LOADED" )
end

--[[ Map props ]]--
function GM.Map:LoadMapProps()
	GM:PrintDebug( 0, "->LOADING MAP PROPS" )

	local map = game.GetMap():gsub(".bsp", "")
	local path = GM.Config.GAMEMODE_PATH.. "maps/".. map.. "/map_props/"

	local foundFiles, foundFolders = file.Find( path.. "*.lua", "LUA" )
	GM:PrintDebug( 0, "\tFound ".. #foundFiles.. " files." )

	for k, v in pairs( foundFiles ) do
		GM:PrintDebug( 0, "\tLoading ".. v )
		if not v:StartWith( "sv_" ) then
			include( path.. v )
		end
	end

	GM:PrintDebug( 0, "->MAP PROPS LOADED" )
end

function GM.Map:RegisterMapProp( tblMapProp )
	self.m_tblPropRegister[tblMapProp.ID] = tblMapProp
end

function GM.Map:GetMapProp( strID )
	return self.m_tblPropRegister[strID]
end